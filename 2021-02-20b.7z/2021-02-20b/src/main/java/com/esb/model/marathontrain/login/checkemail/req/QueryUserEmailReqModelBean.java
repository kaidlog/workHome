package com.esb.model.marathontrain.login.checkemail.req;
import java.io.Serializable;

//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryUserEmailReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
  /** email */
  @ApiModelProperty(value = "email", allowEmptyValue = true, required = false)
  private String email;
}
