package com.esb.model.marathontrain.goal.queryhistorygoal.res;

import java.io.Serializable;

import com.esb.core.bean.model.AbstractBasePaggingResModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryHistoryGoalResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** Goal ID */
    @ApiModelProperty(value = "目標紀錄ID", allowEmptyValue = true, required = false)
    private String goalId;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** Distance */
    @ApiModelProperty(value = "Distance", allowEmptyValue = true, required = false)
    private String setPeriod;
    /** Calories */
    @ApiModelProperty(value = "Calories", allowEmptyValue = true, required = false)
    private String idealDistance;
    /** HeartRate */
    @ApiModelProperty(value = "HeartRate", allowEmptyValue = true, required = false)
    private String idealPacePerKm;
    /** Cre_Date_Time */
    @ApiModelProperty(value = "Cre_Date_Time", allowEmptyValue = true, required = false)
    private String creDateTime;
    /** Upd_Date_Time */
    @ApiModelProperty(value = "Upd_Date_Time", allowEmptyValue = true, required = false)
    private String updDateTime;
    /** Creator */
    @ApiModelProperty(value = "Creator", allowEmptyValue = true, required = false)
    private String creator;
    /** Updater */
    @ApiModelProperty(value = "Updater", allowEmptyValue = true, required = false)
    private String updater;
    /** Is_Valid */
    @ApiModelProperty(value = "Is_Valid", allowEmptyValue = true, required = false)
    private String isValid;
    /** difficulty */
    @ApiModelProperty(value = "difficulty", allowEmptyValue = true, required = false)
    private String difficulty;
}
