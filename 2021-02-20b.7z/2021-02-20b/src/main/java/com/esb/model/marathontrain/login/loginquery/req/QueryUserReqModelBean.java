package com.esb.model.marathontrain.login.loginquery.req;
import java.io.Serializable;

//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryUserReqModelBean implements Serializable{

    /** */
    private static final long serialVersionUID = 1L;
    /** email */
    @ApiModelProperty(value = "email", allowEmptyValue = true, required = false)
    private String email;
    /** user_password */
    @ApiModelProperty(value = "userPassword", allowEmptyValue = true, required = false)
    private String userPassword;
    /** 是否停權 */
    @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
    private String suspendOrNot;
}
