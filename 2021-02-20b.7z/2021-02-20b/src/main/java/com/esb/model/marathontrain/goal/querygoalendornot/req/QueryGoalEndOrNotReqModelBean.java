package com.esb.model.marathontrain.goal.querygoalendornot.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/** 查詢目標是否存在 */

@Data
public class QueryGoalEndOrNotReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** isValid */
    @ApiModelProperty(value = "idValid", allowEmptyValue = true, required = false)
    private String isValid;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** goalId */
    @ApiModelProperty(value = "goalId", allowEmptyValue = true, required = false)
    private String goalId;
    /** curTime */
    @ApiModelProperty(value = "curTime", allowEmptyValue = true, required = false)
    private String curTime;
}