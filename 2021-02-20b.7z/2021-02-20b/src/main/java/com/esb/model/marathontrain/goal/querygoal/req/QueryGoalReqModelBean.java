package com.esb.model.marathontrain.goal.querygoal.req;
import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/** 查詢目標是否存在 */

@Data
public class QueryGoalReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** isValid */
  @ApiModelProperty(value = "idValid", allowEmptyValue = true, required = false)
  private String isValid;
  /** uuid */
  @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
  private String uuid;
}