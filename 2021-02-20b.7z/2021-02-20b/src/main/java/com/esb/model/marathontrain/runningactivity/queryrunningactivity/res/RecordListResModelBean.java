package com.esb.model.marathontrain.runningactivity.queryrunningactivity.res;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class RecordListResModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** RunningActivity ID */
    @ApiModelProperty(value = "跑步活動紀錄ID", allowEmptyValue = true, required = false)
    private String runningactivityId;
    /** PacePerKm */
    @ApiModelProperty(value = "pacePerKm", allowEmptyValue = true, required = false)
    private String pacePerKm;
    /** Distance */
    @ApiModelProperty(value = "Distance", allowEmptyValue = true, required = false)
    private String distance;
    /** Calories */
    @ApiModelProperty(value = "Calories", allowEmptyValue = true, required = false)
    private String calories;
    /** HeartRate */
    @ApiModelProperty(value = "HeartRate", allowEmptyValue = true, required = false)
    private String heartrate;
    /** ElevationVariation */
    @ApiModelProperty(value = "ElevationVariation", allowEmptyValue = true, required = false)
    private String elevationvariation;
    /** Cre_Date_Time */
    @ApiModelProperty(value = "Cre_Date_Time", allowEmptyValue = true, required = false)
    private String creDateTime;
    /** Upd_Date_Time */
    @ApiModelProperty(value = "Upd_Date_Time", allowEmptyValue = true, required = false)
    private String updDateTime;
    /** Creator */
    @ApiModelProperty(value = "Creator", allowEmptyValue = true, required = false)
    private String creator;
    /** Updater */
    @ApiModelProperty(value = "Updater", allowEmptyValue = true, required = false)
    private String updater;
    /** Is_Valid */
    @ApiModelProperty(value = "Is_Valid", allowEmptyValue = true, required = false)
    private String isValid;
}


