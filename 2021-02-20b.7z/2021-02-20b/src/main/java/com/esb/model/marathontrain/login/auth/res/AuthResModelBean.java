package com.esb.model.marathontrain.login.auth.res;

public class AuthResModelBean {

}
