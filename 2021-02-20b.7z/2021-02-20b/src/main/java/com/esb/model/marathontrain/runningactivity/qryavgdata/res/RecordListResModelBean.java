package com.esb.model.marathontrain.runningactivity.qryavgdata.res;

import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RecordListResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** haveDoneTimes */
    @ApiModelProperty(value = "haveDoneTimes", allowEmptyValue = true, required = false)
    private String haveDoneTimes;
    /** avgDistance */
    @ApiModelProperty(value = "avgDistance", allowEmptyValue = true, required = false)
    private String avgDistance;
    /** fastPacePerKm */
    @ApiModelProperty(value = "fastPacePerKm", allowEmptyValue = true, required = false)
    private String fastPacePerKm;
    /** avgHeartrate */
    @ApiModelProperty(value = "avgHeartrate", allowEmptyValue = true, required = false)
    private String avgHeartrate;
    /** avgEleVar */
    @ApiModelProperty(value = "avgEleVar", allowEmptyValue = true, required = false)
    private String avgEleVar;
    /** timeTicks */
    @ApiModelProperty(value = "timeTicks", allowEmptyValue = true, required = false)
    private String timeTicks;
}


