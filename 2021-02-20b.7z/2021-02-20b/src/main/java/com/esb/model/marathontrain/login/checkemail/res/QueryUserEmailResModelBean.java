package com.esb.model.marathontrain.login.checkemail.res;

import java.io.Serializable;

//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryUserEmailResModelBean implements Serializable{
    
    private static final long serialVersionUID = 1L;
  /** User ID */
  @ApiModelProperty(value = "UserID", allowEmptyValue = false, required = true, position = 1)
  private String uuid;
  /** creDateTime */
  @ApiModelProperty(value = "creDateTime", allowEmptyValue = false, required = true, position = 1)
  private String creDateTime;
  /** PacePerKm */
  @ApiModelProperty(value = "updDateTime", allowEmptyValue = true, required = false)
  private String updDateTime;
  /** suspendOrNot */
  @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
  private String suspendOrNot;
  /** creator */
  @ApiModelProperty(value = "creator", allowEmptyValue = true, required = false)
  private String creator;
  /** updater */
  @ApiModelProperty(value = "updater", allowEmptyValue = true, required = false)
  private String updater;
  /** email */
  @ApiModelProperty(value = "email", allowEmptyValue = true, required = false)
  private String email;

}
