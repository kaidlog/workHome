package com.esb.model.marathontrain.goal.qrylastdays.res;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryLastDaysResModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** periodDays */
    @ApiModelProperty(value = "periodDays", allowEmptyValue = true, required = false)
    private String periodDays;
    /** spanDays */
    @ApiModelProperty(value = "spanDays", allowEmptyValue = true, required = false)
    private String spanDays;
}


