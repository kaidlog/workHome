package com.esb.model.marathontrain.goal.addgoal.req;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AddGoalReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** Goal ID */
    @ApiModelProperty(value = "目標設定ID", allowEmptyValue = false, required = true, position = 1)
    private String goalId;
    /** uuid  */
    /** 是否不需要? */
    @ApiModelProperty(value = "uuid", allowEmptyValue = false, required = true, position = 1)
    private String uuid;
    /** PacePerKm */
    @ApiModelProperty(value = "SetPeriod", allowEmptyValue = true, required = false)
    private String setPeriod;
    /** difficulty */
    @ApiModelProperty(value = "difficulty", allowEmptyValue = true, required = false)
    private String difficulty;
    /** PacePerKm */
    @ApiModelProperty(value = "IdealPacePerKm", allowEmptyValue = true, required = false)
    private Number idealPacePerKm;
    /** Distance */
    @ApiModelProperty(value = "IdealDistance", allowEmptyValue = true, required = false)
    private Number idealDistance;
    /** Creator */
    @ApiModelProperty(value = "Creator", allowEmptyValue = true, required = false)
    private String creator;
    /** Updater */
    @ApiModelProperty(value = "Updater", allowEmptyValue = true, required = false)
    private String updater;
}
