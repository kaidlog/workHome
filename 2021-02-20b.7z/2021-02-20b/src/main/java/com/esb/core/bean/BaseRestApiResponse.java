package com.esb.core.bean;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Restful API Response Entity.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Data
public class BaseRestApiResponse {
    /** 處理結果狀態碼，請參閱HTTP Status code */
    @ApiModelProperty(value = "處理結果狀態碼，請參閱HTTP Status code", position = 1)
    private String status = "200"; // 200: Success
    /** 服務端告知呼叫端訊息內容清單 */
    @ApiModelProperty(value = "服務端告知呼叫端訊息內容清單", position = 2)
    private List<String> msg = new ArrayList<String>();
}