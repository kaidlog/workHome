package com.esb.core.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 取得IP Address工具
 * @author 20718 Jason Chan by Esunbank
 */
public class IpAddrUtils {
    /**
     * Default construct
     * @remark
     */
    private IpAddrUtils() {
    }

    /**
     * HTTP頭一般格式為:X-Forwarded-For: client1, proxy1, proxy2
     * 其中的值通過一個 逗號+空格 把多個IP位址區分開, 最左邊（client1）是最原始用戶端的IP位址, 代理伺服器每成功收到一個請求，就把請求來源IP位址添加到右邊。 在上面這個例子中，這個請求成功通過了三台代理伺服器：proxy1, proxy2 及 proxy3。
     * 請求由client1發出，到達了proxy3（proxy3可能是請求的終點）。請求剛從client1中發出時，XFF是空的，請求被發往proxy1；通過proxy1的時候，client1被添加到XFF中，之後請求被發往proxy2;通過proxy2的時候，
     * proxy1被添加到XFF中，之後請求被發往proxy3；通過proxy3時，proxy2被添加到XFF中，之後請求的的去向不明，如果proxy3不是請求終點，請求會被繼續轉發。
     * 透過此method，會將所經過的每一節點IP取出，並置入List<String>裡回傳。
     * @param request HTTP Request
     * @return List<String> IP清單
     */
    public static List<String> getRequestIpAddresses(HttpServletRequest request) {
        List<String> result = new ArrayList<String>();

        String ip = request.getHeader("X-Forwarded-For");
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        if (StringUtils.isNotBlank(ip)) {
            result = Arrays.stream(ip.split(",")).map(address -> {
                return StringUtils.trim(address);
            }).collect(Collectors.toList());
        }

        return result;
    }

    /**
     * HTTP頭一般格式為:X-Forwarded-For: client1, proxy1, proxy2
     * 其中的值通過一個 逗號+空格 把多個IP位址區分開, 最左邊（client1）是最原始用戶端的IP位址, 代理伺服器每成功收到一個請求，就把請求來源IP位址添加到右邊。 在上面這個例子中，這個請求成功通過了三台代理伺服器：proxy1, proxy2 及 proxy3。
     * 請求由client1發出，到達了proxy3（proxy3可能是請求的終點）。請求剛從client1中發出時，XFF是空的，請求被發往proxy1；通過proxy1的時候，client1被添加到XFF中，之後請求被發往proxy2;通過proxy2的時候，
     * proxy1被添加到XFF中，之後請求被發往proxy3；通過proxy3時，proxy2被添加到XFF中，之後請求的的去向不明，如果proxy3不是請求終點，請求會被繼續轉發。
     * 透過此method，將取得最後一個(proxy2)發送點的IP做回傳。
     * @param request HTTP Request
     * @return String IP
     */
    public static String getLastClientIp(HttpServletRequest request) {
        List<String> ipList = getRequestIpAddresses(request);
        if (CollectionUtils.isNotEmpty(ipList)) {
            return ipList.get((ipList.size() - 1));
        }

        return "";
    }

    /**
     * HTTP頭一般格式為:X-Forwarded-For: client1, proxy1, proxy2
     * 其中的值通過一個 逗號+空格 把多個IP位址區分開, 最左邊（client1）是最原始用戶端的IP位址, 代理伺服器每成功收到一個請求，就把請求來源IP位址添加到右邊。 在上面這個例子中，這個請求成功通過了三台代理伺服器：proxy1, proxy2 及 proxy3。
     * 請求由client1發出，到達了proxy3（proxy3可能是請求的終點）。請求剛從client1中發出時，XFF是空的，請求被發往proxy1；通過proxy1的時候，client1被添加到XFF中，之後請求被發往proxy2;通過proxy2的時候，
     * proxy1被添加到XFF中，之後請求被發往proxy3；通過proxy3時，proxy2被添加到XFF中，之後請求的的去向不明，如果proxy3不是請求終點，請求會被繼續轉發。
     * 透過此method，將取得第1個(client1)發送點的IP做回傳。
     * @param request HTTP Request
     * @return String IP
     */
    public static String getFirstClientIp(HttpServletRequest request) {
        return getRequestIpAddresses(request).stream().findFirst().orElse("");
    }
}