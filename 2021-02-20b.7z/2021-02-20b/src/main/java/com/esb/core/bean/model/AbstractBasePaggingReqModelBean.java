package com.esb.core.bean.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Base Pagging Request Model Bean
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年8月5日
 * @remark
 */
@Data
public abstract class AbstractBasePaggingReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 頁次 */
    @ApiModelProperty(value = "頁次", allowEmptyValue = false, required = true)
    @NotNull(message = "頁次不可為空")
    @DecimalMin(message = "頁次必須大於0", value = "1")
    private BigDecimal pageNo;
    /** 顯示筆數 */
    @ApiModelProperty(value = "顯示筆數", allowEmptyValue = false, required = true)
    @NotNull(message = "顯示筆數不可為空")
    @Range(min = 1, max = 1000, message = "顯示筆數必須在(1~1,000筆)之間")
    private BigDecimal pageSize;
    /** 排序欄位 */
    @ApiModelProperty(value = "排序欄位", allowEmptyValue = true, required = false)
    @Size(max = 60, message = "排序欄位長度需小於60")
    private String sortColumn;
    /** 排序方式 */
    @ApiModelProperty(value = "排序方式", allowEmptyValue = true, required = false)
    @Pattern(regexp = "ASC|DESC", message = "排序方式僅能填入「ASC」或「DESC」")
    private String sortType;
}