package com.esb.core.service;

import java.util.Collection;

import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;

/**
 * 授權決策服務.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public interface IAuthorizationDecisionService {

    /**
     * Resolves an access control decision for the passed parameters.
     *
     * @param authentication the caller invoking the method (not null)
     * @param object the secured object being called
     * @param configAttributes the configuration attributes associated with the secured object being invoked
     * @return Boolean true:同意授權、false:禁止授權
     */
    boolean decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes);
}