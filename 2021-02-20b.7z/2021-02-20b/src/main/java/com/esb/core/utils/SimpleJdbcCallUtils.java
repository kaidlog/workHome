package com.esb.core.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import com.alibaba.fastjson.JSONObject;

import lombok.SneakyThrows;

/**
 * SimpleJdbcCall Utility.
 *
 * @author 20718 Jason Chan by Esunbank
 */
public class SimpleJdbcCallUtils {
    /** logger */
    private static Log logger = LogFactory.getLog(SimpleJdbcCallUtils.class);

    /**
     * 轉換Map to Java Bean，此method會做命名的轉換，將資料庫的Column name轉換成Java field name再做對應，ex. CARD_TYPE -> cardType、 USER_ID -> userId、 NAME -> name 接收的參數srcMap中Map<?,
     * ?>裡頭的?是因為透過SimpleJdbcCall呼叫procedure後取得的所有結果會封裝在Map<String, Object>，但裡頭其中一個output為List<Map<?, ?>， 要將裡頭每一筆取出來再轉成明確的型別會造成Compile warning，所以在這邊會用?來接
     * @param <T> T
     * @param srcMap the source Map to transfer
     * @param clazz the class to instantiate
     * @return T the new instance java bean
     */
    @SneakyThrows
    public static <T> T convertMap2Bean(Map<?, ?> srcMap, Class<T> clazz) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("clazz", clazz);

            srcMap.keySet().stream().filter(row -> {
                return srcMap.get(row) != null;
            }).forEach(row -> {
                logParams.put(row.toString(), CIFMaskUtils.doMaskOthers(srcMap.get(row).toString()));
            });

            logger.trace(logParams);
        }

        // 1. 將來源Map做一次命名轉換 ----------------------------------------------------------------------------------------
        Map<String, Object> targetMap = new HashMap<String, Object>();
        srcMap.keySet().stream().forEach(columnName -> {
            targetMap.put(NamingRuleUtils.convertColumnName2FieldName((String) columnName), srcMap.get(columnName));
        });

        // 2. 將Map的資料copy至Java Bean --------------------------------------------------------------------------------
        T result = BeanUtils.instantiateClass(clazz);
        org.apache.commons.beanutils.BeanUtils.populate(result, targetMap);

        return result;
    }

    /**
     * 轉換Map List to Bean List，此method會做命名的轉換，將資料庫的Column name轉換成Java field name再做對應，ex. CARD_TYPE -> cardType、 USER_ID -> userId、 NAME -> name
     * 接收的參數mapList中List<?>裡頭的?是因為透過SimpleJdbcCall呼叫procedure後取得的所有結果會封裝在Map<String, Object>，但裡頭其中一個output為List<Map<?, ?>， 要將裡頭的List出來再轉成明確的型別會造成Compile warning，所以在這邊會用?來接
     * @param mapList the source Map list to transfer
     * @param clazz the class to instantiate
     * @return List<T> the new instance java bean List
     */
    @SneakyThrows
    public static <T> List<T> convertMapList2BeanList(List<?> mapList, Class<T> clazz) {
        return mapList.stream().map(row -> {
            return convertMap2Bean((Map<?, ?>) row, clazz);
        }).collect(Collectors.toList());
    }
}