package com.esb.core.bean.model;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Base Pagging Response Model Bean
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年8月5日
 * @remark
 */
@Data
public abstract class AbstractBasePaggingResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 資料總筆數 */
    @ApiModelProperty(value = "資料總筆數", allowEmptyValue = false, required = true)
    private BigDecimal totalCount;
    /** 實際頁次 */
    @ApiModelProperty(value = "實際頁次", allowEmptyValue = false, required = true)
    private BigDecimal pageNo;
}