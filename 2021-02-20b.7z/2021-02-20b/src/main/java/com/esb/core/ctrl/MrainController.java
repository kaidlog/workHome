package com.esb.core.ctrl;



import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin
public class MrainController {
    @GetMapping("/hello")
    public String main(){
        return "hello";
    }

    /**
     *  /test1 和 /test2 需要登錄後才能訪問
     */
    @GetMapping("/test1")
    public String test1(){
        return "test1";
    }

    @GetMapping("/test2")
    public String test2(){
        return "test2";
    }

    @GetMapping("/needAdminRole")
    public String needAdminRole(){
        return "needAdminRole";
    }

    @GetMapping("/needTestRole")
    public String needTestRole(){
        return "TEST角色才能訪問";
    }

    @RequestMapping("/loginInfo")
    public String loginInfo(){
        return "請先登錄！";
    }

    /**
     * 注銷登錄成功後跳轉的路由
     * @return
     */
    @RequestMapping("/logoutSuccess")
    public String logoutSuccess(){
        return "退出成功！";
    }
}