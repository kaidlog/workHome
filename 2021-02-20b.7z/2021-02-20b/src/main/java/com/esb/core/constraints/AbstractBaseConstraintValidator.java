package com.esb.core.constraints;

import java.lang.annotation.Annotation;

import javax.validation.ConstraintValidator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.esb.core.service.IGeneralSimpleJdbcCallDaoService;

import lombok.Getter;

/**
 * Base JSR-303 Validator.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 * @param <A>
 * @param <T>
 */
public abstract class AbstractBaseConstraintValidator<A extends Annotation, T> implements ConstraintValidator<A, T> {
    /** Spring application context */
    @Getter
    @Autowired
    private ApplicationContext applicationContext;
    /** General SimpleJdbcCall Data access object service */
    @Getter
    @Autowired
    private IGeneralSimpleJdbcCallDaoService generalSimpleJdbcCallDaoService;
}