package com.esb.core.ctrl;

import java.security.Principal;

import javax.servlet.ServletException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;

/**
 * Keycloak Logout Controller.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@RestController
@RequestMapping("/logout")
public class LogoutController extends AbstractBaseController {
    /** logger */
    private static Log logger = LogFactory.getLog(LogoutController.class);

    /**
     * Logout handler
     * @param principal
     * @return RestApiOneResponse<String>
     * @throws ServletException
     * @remark
     */
    @GetMapping
    public RestApiOneResponse<String> doLogout(Principal principal) throws ServletException {
        JSONObject logParams = new JSONObject();
        logParams.put("principal-1", principal);
        logParams.put("principal-2", getRequest().getUserPrincipal());

        if (logger.isDebugEnabled()) {
            logger.debug(logParams);
        }

        getRequest().logout();

        return doGetDefaultOneResult("OK");
    }
}