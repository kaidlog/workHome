package com.esb.core.config;

import java.util.Arrays;
/*
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;
import org.keycloak.adapters.springsecurity.config.KeycloakWebSecurityConfigurerAdapter;
*/
/*新增 WebSecurityConfiguration 暫持用來接替  keycloak 的工作*/
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Spring Security for Keycloak SSO Configuration.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
/*
@KeycloakConfiguration
*/
public class SecurityConfigOld {
    // private static Log logger = LogFactory.getLog(SecurityConfig.class);

    /** 直接放行URL白名單 */
    @Value("${security.ignore-security-check-uri-list}")
    private String[] ignoreSecurityCheckUriList;
    /** 乎略進行CSRF Token驗證URI */
    @Value("${security.ignore-csrf-uri-list}")
    private String[] ignoreCsrfUris;
    /** 跨站資源共享准許站台清單 */
    @Value("${security.cors.allowed-origins}")
    private String[] securityCorsAllowedOrigins;
    /** 跨站資源准許HTTP Method清單 */
    @Value("${security.cors.allowed-methods}")
    private String[] corsAllowedMethods;

    /** Spring security access decision manager */
    @Autowired
    private AccessDecisionManager accessDecisionManager;

    /**
     * 取得認證服務者
     * @return AuthenticationProvider
     */
    /*
    @Bean
    public AuthenticationProvider authenticationProvider() {
        // SimpleAuthorityMapper grantedAuthorityMapper = new SimpleAuthorityMapper();
        // grantedAuthorityMapper.setPrefix("ROLE_");
        
        KeycloakAuthenticationProvider keycloakAuthenticationProvider = keycloakAuthenticationProvider();
        keycloakAuthenticationProvider.setGrantedAuthoritiesMapper(new SimpleAuthorityMapper());

        return keycloakAuthenticationProvider;
        
    }*/


    /**
     * Cors configuration
     * @return CorsConfigurationSource
     * @remark
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowCredentials(true);
        configuration.addAllowedHeader("*");
        configuration.setAllowedOrigins(Arrays.asList(securityCorsAllowedOrigins));
        configuration.setAllowedMethods(Arrays.asList(corsAllowedMethods));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);

        return source;
    }
    /*
    @Bean
    @Override
    protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        return new NullAuthenticatedSessionStrategy();
    }
    */

    /**
     * 配置全域設定
     * @param auth
     * @throws Exception
     */
    /*
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authenticationProvider());
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        super.configure(http);

        // http.csrf().ignoringAntMatchers(ignoreCsrfUris);

        // TODO
        http.csrf().disable();

        http.headers().frameOptions().sameOrigin();
        http.headers().addHeaderWriter(new StaticHeadersWriter("Server", "Web Server"));

        http.authorizeRequests().accessDecisionManager(accessDecisionManager);
        http.authorizeRequests().antMatchers(ignoreSecurityCheckUriList).permitAll()
                .antMatchers("/**").denyAll()
                .and().cors();
    }
    */
}