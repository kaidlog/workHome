package com.esb.core.config;

import java.util.Arrays;

import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Tomcat embedded application configuration.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Configuration
public class TomcatConfig {
    /** resource collection url pattern */
    @Value("${security-constraint.web-resource-collection.url-pattern}")
    private String urlPattern;
    /** is resource collection allow trace */
    @Value("${security-constraint.web-resource-collection.allow-trace}")
    private boolean allowTrace;
    /** allow HTTP methods */
    @Value("${security-constraint.web-resource-collection.http-methods}")
    private String[] httpMethods;

    /**
     * 設定embedded Tomcat參數值
     * @return TomcatServletWebServerFactory
     */
    @Bean
    public TomcatServletWebServerFactory tomcatServletWebServerFactory() {
        TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();

        factory.addConnectorCustomizers(connector -> {
            connector.setAllowTrace(allowTrace);
        });

        factory.addContextCustomizers(context -> {
            SecurityConstraint securityConstraint = new SecurityConstraint();
            securityConstraint.setUserConstraint("CONFIDENTIAL");

            // 調整拒絕名單內的HTTP Method服務 -------------------------------------------------------------------------------
            SecurityCollection securityCollection = new SecurityCollection();
            securityCollection.addPattern(urlPattern);

            Arrays.stream(httpMethods).forEach(method -> {
                securityCollection.addMethod(method);
            });

            securityConstraint.addCollection(securityCollection);
            context.addConstraint(securityConstraint);
        });

        return factory;
    }
}