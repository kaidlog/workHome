package com.esb.core.ctrl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Validator;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiListResponse;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.core.service.IGeneralSimpleJdbcCallDaoService;

import lombok.Getter;
import lombok.SneakyThrows;

/**
 * Base Spring MVC Controller.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseController {
    /** logger */
    private static Log logger = LogFactory.getLog(AbstractBaseController.class);

    /** default error message */
    @Getter
    @Value("${runtime.default-err-msg}")
    private String defaultErrMsg;

    /** Spring application context */
    @Getter
    @Autowired
    private ApplicationContext applicationContext;
    /** General SimpleJdbcCall Data access object service */
    @Getter
    @Autowired
    private IGeneralSimpleJdbcCallDaoService generalSimpleJdbcCallDaoService;

    /** Http Session */
    @Getter
    @Autowired
    private HttpSession session;
    /** Http Request */
    @Getter
    @Autowired
    private HttpServletRequest request;
    /** Http Response */
    @Getter
    @Autowired
    private HttpServletResponse response;

    // ----------------------------------------------------------------------------
    /** JSR-303 Validator */
    @Getter
    @Autowired
    private Validator validator;

    // ----------------------------------------------------------------------------
    /**
     * 取得預設File download Response headers
     * @param fileName 檔案名稱
     * @return HttpHeaders file download HTTP headers
     */
    @SneakyThrows
    protected HttpHeaders doGetFileDownloadHeaders(String fileName) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("fileName", fileName);
            logger.trace(logParams);
        }

        fileName = URLEncoder.encode(fileName, "UTF-8");

        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        headers.add("charset", "UTF-8");
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"" + "; filename*=UTF-8‘‘" + fileName);

        return headers;
    }

    // ----------------------------------------------------------------------------
    /**
     * 取得預設單筆執行成功結果
     * @param body 請求處理結果內容
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiOneResponse<T> doGetDefaultOneResult(T body) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("body", body);
            logger.trace(logParams);
        }

        RestApiOneResponse<T> response = new RestApiOneResponse<T>();
        response.setBody(body);

        return response;
    }

    /**
     * 取得預設多筆筆執行成功結果
     * @param body 請求處理結果內容清單
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiListResponse<T> doGetDefaultListResult(List<T> body) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("body", body);
            logger.trace(logParams);
        }

        RestApiListResponse<T> response = new RestApiListResponse<T>();
        response.setBody(body);

        return response;
    }

    /**
     * 取得預設單筆執行失敗結果
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiOneResponse<T> doGetDefaultOneErrResult() {
        if (logger.isTraceEnabled()) {
            logger.trace(new JSONObject());
        }

        return doGetDefaultOneErrResult("500", Arrays.asList(defaultErrMsg)); // 500: Internal Server Error
    }

    /**
     * 取得預設單筆執行失敗結果
     * @param status 狀態碼
     * @param msg 訊息清單
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiOneResponse<T> doGetDefaultOneErrResult(String status, List<String> msg) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("status", status)
                    .fluentPut("msg", msg);
            logger.trace(logParams);
        }

        RestApiOneResponse<T> response = new RestApiOneResponse<T>();
        response.setStatus(StringUtils.defaultIfBlank(status, "500")); // 500: Internal Server Error
        response.setMsg(msg);

        msg = Optional.ofNullable(msg).orElse(new ArrayList<String>());
        if (CollectionUtils.isEmpty(msg)) {
            msg.add(defaultErrMsg);
        }

        return response;
    }

    /**
     * 取得預設多筆執行失敗結果
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiListResponse<T> doGetDefaultListErrResult() {
        if (logger.isTraceEnabled()) {
            logger.trace(new JSONObject());
        }

        return doGetDefaultListErrResult("500", Arrays.asList(defaultErrMsg));
    }

    /**
     * 取得預設單筆執行失敗結果
     * @param status 狀態碼
     * @param msg 訊息清單
     * @return RestApiOneResponse<T> 處理結果
     */
    protected final <T> RestApiListResponse<T> doGetDefaultListErrResult(String status, List<String> msg) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("status", status)
                    .fluentPut("msg", msg);
            logger.trace(logParams);
        }

        RestApiListResponse<T> response = new RestApiListResponse<T>();
        response.setStatus(StringUtils.defaultIfBlank(status, "500")); // 500: Internal Server Error
        response.setMsg(msg);

        msg = Optional.ofNullable(msg).orElse(new ArrayList<String>());
        if (CollectionUtils.isEmpty(msg)) {
            msg.add(defaultErrMsg);
        }

        return response;
    }
}