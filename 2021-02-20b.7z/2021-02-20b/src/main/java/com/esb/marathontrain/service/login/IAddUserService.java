package com.esb.marathontrain.service.login;

import java.math.BigDecimal;

import com.esb.model.marathontrain.login.register.req.AddUserReqModelBean;

public interface IAddUserService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doAddUserList(AddUserReqModelBean model);
}
