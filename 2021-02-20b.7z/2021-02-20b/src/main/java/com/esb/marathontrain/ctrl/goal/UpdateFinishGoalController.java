package com.esb.marathontrain.ctrl.goal;

import java.math.BigDecimal;
import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IUpdateFinishGoalService;
import com.esb.model.marathontrain.goal.updatefinishgoal.req.UpdateFinishGoalReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/updatefinishgoal")
@Api(tags = "更新已完成目標")
public class UpdateFinishGoalController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(UpdateFinishGoalController.class);

    /** AddRunningActivityService */
    @Autowired
    private IUpdateFinishGoalService updatefinishgoalService;

    /**
     * 刪除目標查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "更新已完成目標")
    public RestApiOneResponse<BigDecimal> doUpdateFinishGoalList(@Valid @RequestBody UpdateFinishGoalReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(updatefinishgoalService.doUpdateFinishGoalList(model));
    }
}
