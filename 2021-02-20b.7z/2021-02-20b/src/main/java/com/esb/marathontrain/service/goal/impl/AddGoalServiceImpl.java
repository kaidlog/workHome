package com.esb.marathontrain.service.goal.impl;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.goal.IAddGoalService;
import com.esb.model.marathontrain.goal.addgoal.req.AddGoalReqModelBean;
//import com.esuncard.model.marathontrain.goal.addgoal.res.AddGoalResModelBean;
import com.stun4j.guid.LocalGuid;


@Service
@Transactional
public class AddGoalServiceImpl extends AbstractBaseApService implements IAddGoalService {
    /** logger */
    private static Log logger = LogFactory.getLog(AddGoalServiceImpl.class);

    /**
     * 新增跑步紀錄
     */
    public BigDecimal doAddGoalList(AddGoalReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        LocalGuid guid = LocalGuid.init(0/*datacenterId*/, 0/*workerId*/);
        long id1 = guid.next();
        long id2 = LocalGuid.instance().next();
        Calendar calendar = Calendar.getInstance();
        String currentTime = (new SimpleDateFormat("yyyy-MM-dd 24HH:mm:ss")).format(calendar.getTime());

        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_GOAL_ID", LocalGuid.instance().next())
                .addValue("I_UUID", model.getUuid())
                .addValue("I_SET_PERIOD", model.getSetPeriod())
                .addValue("I_IDEAL_PACE_PER_KM", model.getIdealPacePerKm())
                .addValue("I_IDEAL_DISTANCE", model.getIdealDistance())
                .addValue("I_CRE_DATE_TIME", currentTime)
                .addValue("I_UPD_DATE_TIME", currentTime)
                .addValue("I_CREATOR", model.getCreator())
                .addValue("I_UPDATER", model.getUpdater())
                .addValue("I_IS_VALID", "1")
                .addValue("I_DIFFICULTY", model.getDifficulty());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_MT_GOAL",
                "ADD",
                parameterSource);
    }
}
