package com.esb.marathontrain.ctrl.runningactivity;


import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IQryAvgDataService;
import com.esb.model.marathontrain.runningactivity.qryavgdata.req.QryAvgDataReqModelBean;
import com.esb.model.marathontrain.runningactivity.qryavgdata.res.QryAvgDataResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/qryavgdata")
@Api(tags = "圖表查詢")
public class QryAvgDataController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QryAvgDataController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IQryAvgDataService qryavgdataservice;
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢某筆跑步資料")
    public RestApiOneResponse<QryAvgDataResModelBean> doQryAvgDataList(@Valid @RequestBody QryAvgDataReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(qryavgdataservice.doQryAvgDataList(model));
    };
}
