package com.esb.marathontrain.ctrl.runningactivity;

import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IQryDiagramService;
import com.esb.model.marathontrain.runningactivity.qrydiagram.req.QryDiagramReqModelBean;
import com.esb.model.marathontrain.runningactivity.qrydiagram.res.QryDiagramResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/qrydiagram")
@Api(tags = "圖表查詢")
public class QryDiagramController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QryDiagramController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IQryDiagramService qrydiagramservice;
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢某筆跑步資料")
    public RestApiOneResponse<QryDiagramResModelBean> doQryDiagramList(@Valid @RequestBody QryDiagramReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(qrydiagramservice.doQryDiagramList(model));
    };
}
