package com.esb.marathontrain.ctrl.goal;

import java.util.List;

import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IQueryLastDaysService;
import com.esb.model.marathontrain.goal.qrylastdays.res.QueryLastDaysResModelBean;
import com.esb.model.marathontrain.goal.qrylastdays.req.QueryLastDaysReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/querylastdays")
@Api(tags = "圖表查詢")
public class QueryLastDaysController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryLastDaysController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IQueryLastDaysService querylastdaysservice;
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢某筆跑步資料")
    public RestApiOneResponse<List<QueryLastDaysResModelBean>> doQueryLastDaysList(@Valid @RequestBody QueryLastDaysReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(querylastdaysservice.doQueryLastDaysList(model));
    };
}
