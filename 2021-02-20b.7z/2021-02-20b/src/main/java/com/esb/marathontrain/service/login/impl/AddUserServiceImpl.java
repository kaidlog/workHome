package com.esb.marathontrain.service.login.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.login.IAddUserService;
import com.esb.model.marathontrain.login.register.req.AddUserReqModelBean;
//import com.esuncard.model.marathontrain.goal.addgoal.res.AddGoalResModelBean;
import com.stun4j.guid.LocalGuid;
import java.math.BigInteger;
import java.security.MessageDigest;


@Service
@Transactional
public class AddUserServiceImpl extends AbstractBaseApService implements IAddUserService {
    /** logger */
    private static Log logger = LogFactory.getLog(AddUserServiceImpl.class);
    /** sha256 加密演算法 */
    public static String getSHA256(String input) {
        String toReturn = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.reset();
            digest.update(input.getBytes("utf8"));
            toReturn = String.format("%064x", new BigInteger(1, digest.digest()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return toReturn;
    }
    /**
     * 新增使用者
     */
    public BigDecimal doAddUserList(AddUserReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        LocalGuid guid = LocalGuid.init(0/*datacenterId*/, 0/*workerId*/);
        long id1 = guid.next();
        long id2 = LocalGuid.instance().next();
        Calendar calendar = Calendar.getInstance();
        String currentTime = (new SimpleDateFormat("yyyy-MM-dd 24HH:mm:ss")).format(calendar.getTime());
        long snowflakeNum = LocalGuid.instance().next();
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        System.out.println(model.getBirthday().replace("T", " ").replace(".000Z", ""));
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                /** 雪花 ID */
                .addValue("I_UUID", snowflakeNum)
                /** 創建時間 */
                .addValue("I_CRE_DATE_TIME", currentTime)
                /** 更新時間  */
                .addValue("I_UPD_DATE_TIME", currentTime)
                /** 是否停權帳號，預設為否  */
                .addValue("I_SUSPEND_OR_NOT", "0")
                /** 地址  */
                .addValue("I_ADDR", model.getAddr())
                /** 手機號碼  */
                .addValue("I_HANDPHONE", model.getHandphone())
                /** 名字  */
                .addValue("I_FIRSTNAME", model.getFirstname())
                /** 姓氏 */
                .addValue("I_LASTNAME", model.getLastname())
                /** 性別  */
                .addValue("I_GENDER", model.getGender())
                /** 生日， 但是還沒做時間處理 */
                /** 想一下 要怎麼做 format */
                .addValue("I_BIRTHDAY", model.getBirthday().replace("T", " ").replace(".000Z", ""))
                /** 身高 */
                .addValue("I_HEIGHT", model.getHeight())
                /** 密碼， sha256 加密演算法處理  */
                .addValue("I_USER_PASSWORD", getSHA256(model.getUserPassword()))
                /** 創建的使用者 uuid */
                .addValue("I_CREATOR", snowflakeNum)
                /** 更新的使用者 uuid */
                .addValue("I_UPDATER", snowflakeNum)
                /** 身分證字號 */
                .addValue("I_ID_NUMBER", model.getIdNumber())
                /** 體重 */
                .addValue("I_WEIGHT", model.getWeight())
                /** 信箱 */
                .addValue("I_EMAIL", model.getEmail());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_ADD_MT_USER",
                "ADD",
                parameterSource);
    }
}
