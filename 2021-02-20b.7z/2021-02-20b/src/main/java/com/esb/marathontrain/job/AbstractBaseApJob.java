package com.esb.marathontrain.job;

import com.esb.core.job.AbstractBaseJob;

/**
 * Abstract base job for this project.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseApJob extends AbstractBaseJob {
    // private static Log logger = LogFactory.getLog(AbstractBaseApJob.class);
}