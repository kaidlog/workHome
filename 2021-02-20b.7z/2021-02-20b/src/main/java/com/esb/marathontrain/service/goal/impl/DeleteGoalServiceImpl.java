package com.esb.marathontrain.service.goal.impl;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.goal.IDeleteGoalService;
import com.esb.model.marathontrain.goal.deletegoal.req.DeleteGoalReqModelBean;

@Service
@Transactional
public class DeleteGoalServiceImpl extends AbstractBaseApService implements IDeleteGoalService {
    /** logger */
    private static Log logger = LogFactory.getLog(DeleteGoalServiceImpl.class);

    /**
     * 刪除跑步紀錄
     */
    public BigDecimal doDeleteGoalList(DeleteGoalReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        Calendar calendar = Calendar.getInstance();
        String str = (new SimpleDateFormat("yyyy-MM-dd 24HH:mm:ss")).format(calendar.getTime());

        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_UUID", model.getUuid());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_MT_GOAL",
                "FN_CANCEL_RECORD",
                parameterSource);
    }
}
