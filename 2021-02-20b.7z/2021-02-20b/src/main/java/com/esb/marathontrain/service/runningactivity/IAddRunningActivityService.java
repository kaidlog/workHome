package com.esb.marathontrain.service.runningactivity;

import java.math.BigDecimal;

import com.esb.model.marathontrain.runningactivity.addrunningactivity.req.AddRunningActivityReqModelBean;

public interface IAddRunningActivityService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doAddRunningActivityList(AddRunningActivityReqModelBean model);
}
