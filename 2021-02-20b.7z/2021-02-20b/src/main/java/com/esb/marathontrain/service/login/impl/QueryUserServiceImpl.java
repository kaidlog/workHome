package com.esb.marathontrain.service.login.impl;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.login.IQueryUserService;
import com.esb.model.marathontrain.login.loginquery.req.QueryUserReqModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

@Service
@Transactional
public class QueryUserServiceImpl extends AbstractBaseApService implements IQueryUserService {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryUserServiceImpl.class);
    /** sha256 加密演算法 */
    public static String getSHA256(String input) {
        String toReturn = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.reset();
            digest.update(input.getBytes("utf8"));
            toReturn = String.format("%064x", new BigInteger(1, digest.digest()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return toReturn;
    }
    /**
     * 登入
     */
    @Override
    public List<QueryUserResModelBean> doQueryUserList(QueryUserReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_SUSPEND_OR_NOT", '0')
                .addValue("I_USER_PASSWORD", getSHA256(model.getUserPassword()))
                .addValue("I_EMAIL", model.getEmail());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_ADD_MT_USER",
                "FN_QRY_RECORD",
                parameterSource);
        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, QueryUserResModelBean.class);
    }
}
