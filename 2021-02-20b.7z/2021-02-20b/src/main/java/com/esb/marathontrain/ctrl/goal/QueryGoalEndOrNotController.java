package com.esb.marathontrain.ctrl.goal;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IQueryGoalEndOrNotServiceService;
import com.esb.model.marathontrain.goal.querygoalendornot.req.QueryGoalEndOrNotReqModelBean;
import com.esb.model.marathontrain.goal.querygoalendornot.res.QueryGoalEndOrNotResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/querygoalendornot")
@Api(tags = "目標是否結束查詢")
public class QueryGoalEndOrNotController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryGoalEndOrNotController.class);

    @Autowired
    private IQueryGoalEndOrNotServiceService querygoalendornotService;

    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢目標資料")
    public RestApiOneResponse<List<QueryGoalEndOrNotResModelBean>> doQueryGoalEndOrNotList(@Valid @RequestBody QueryGoalEndOrNotReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(querygoalendornotService.doQueryGoalEndOrNotList(model));
    }
}
