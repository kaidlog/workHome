package com.esb.marathontrain.ctrl.login;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IQueryGoalService;
import com.esb.model.marathontrain.goal.querygoal.req.QueryGoalReqModelBean;
import com.esb.model.marathontrain.goal.querygoal.res.QueryGoalResModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/auth")
@Api(tags = "鑑權")
public class AuthController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(AuthController.class);
    @Autowired
    private IQueryGoalService querygoalService;
    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "鑑權")
    public RestApiOneResponse<List<QueryUserResModelBean>> doQueryGoalList(@Valid @RequestBody QueryUserResModelBean model, HttpServletRequest request) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }
        @SuppressWarnings("unchecked")
        List<QueryUserResModelBean> userDataSession = (List<QueryUserResModelBean>) request.getSession().getAttribute("userProfile");
        System.out.println("這邊這邊" + userDataSession);

        return doGetDefaultOneResult(userDataSession);
    }
}
