package com.esb.marathontrain.service.runningactivity;
import java.util.List;

import com.esb.model.marathontrain.runningactivity.queryrunningactivity.req.QueryRunningActivityReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivity.res.RecordListResModelBean;

public interface IQueryTwelveWeekRunningActivityService {
    List<RecordListResModelBean> doQueryTwelveWeekRunningActivityList(QueryRunningActivityReqModelBean model);
}