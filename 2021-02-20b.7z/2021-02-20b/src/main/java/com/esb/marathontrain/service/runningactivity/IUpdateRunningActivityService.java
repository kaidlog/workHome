package com.esb.marathontrain.service.runningactivity;
import java.math.BigDecimal;

import com.esb.model.marathontrain.runningactivity.updaterunningactivity.req.UpdateRunningActivityReqModelBean;


public interface IUpdateRunningActivityService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doUpdateRunningActivityList(UpdateRunningActivityReqModelBean model);
}






