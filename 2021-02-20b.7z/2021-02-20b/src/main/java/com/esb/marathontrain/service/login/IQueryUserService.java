package com.esb.marathontrain.service.login;

import java.util.List;

import com.esb.model.marathontrain.login.loginquery.req.QueryUserReqModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

public interface IQueryUserService {
    List<QueryUserResModelBean> doQueryUserList(QueryUserReqModelBean model);
}
