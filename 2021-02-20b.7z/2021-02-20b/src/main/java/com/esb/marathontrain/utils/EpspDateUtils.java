package com.esb.marathontrain.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.ApDateUtils;

import lombok.experimental.UtilityClass;

/**
 * Date Utility for EPSP Project
 * New use for marathon train
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年7月13日
 * @remark
 */
@UtilityClass
public class EpspDateUtils {
    /** logger */
    private static Log logger = LogFactory.getLog(EpspDateUtils.class);

    public static LocalDate dateStr2LocalDate(String date) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("date", date);

            logger.trace(logParams);
        }

        if (StringUtils.isBlank(date)) {
            return null;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        return LocalDate.parse(ApDateUtils.doCleanDateFormat(date), formatter);
    }
}