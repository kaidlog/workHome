package com.esb.marathontrain.service.login;

import java.util.List;

import com.esb.model.marathontrain.login.checkemail.req.QueryUserEmailReqModelBean;
import com.esb.model.marathontrain.login.checkemail.res.QueryUserEmailResModelBean;

public interface IQueryUserEmailService {
    List<QueryUserEmailResModelBean> doQueryUserEmailList(QueryUserEmailReqModelBean model);
}
