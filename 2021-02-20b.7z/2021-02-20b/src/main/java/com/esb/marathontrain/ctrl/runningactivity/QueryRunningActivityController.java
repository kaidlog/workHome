package com.esb.marathontrain.ctrl.runningactivity;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IQueryEighteenWeekRunningActivityService;
import com.esb.marathontrain.service.runningactivity.IQueryRunningActivityService;
import com.esb.marathontrain.service.runningactivity.IQuerySixWeekRunningActivityService;
import com.esb.marathontrain.service.runningactivity.IQueryTwelveWeekRunningActivityService;
import com.esb.marathontrain.service.runningactivity.IQueryWeekRunningActivityService;
import com.esb.model.marathontrain.runningactivity.queryrunningactivity.req.QueryRunningActivityReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivity.res.RecordListResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/queryrunningactivity")
@Api(tags = "查詢跑步")
public class QueryRunningActivityController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryRunningActivityController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IQueryRunningActivityService queryrunningactivityService;
    /** UpdateWeekRunningActivityService */
    @Autowired
    private IQueryWeekRunningActivityService queryweekrunningactivityService;
    /** UpdateSixWeekRunningActivityService */
    @Autowired
    private IQuerySixWeekRunningActivityService querysixweekrunningactivityService;
    /** UpdateTwelveWeekRunningActivityService */
    @Autowired
    private IQueryTwelveWeekRunningActivityService querytwelveweekrunningactivityService;
    /** UpdateEighteenWeekRunningActivityService */
    @Autowired
    private IQueryEighteenWeekRunningActivityService queryeighteenweekrunningactivityService;

    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢某筆跑步資料")
    public RestApiOneResponse<List<RecordListResModelBean>> doQueryRunningActivityList(@Valid @RequestBody QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(queryrunningactivityService.doQueryRunningActivityList(model));
    };
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/02")
    @ApiOperation(value = "查詢一周內跑步資料")
    public RestApiOneResponse<List<RecordListResModelBean>> doQueryWeekRunningActivityList(@Valid @RequestBody QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(queryweekrunningactivityService.doQueryWeekRunningActivityList(model));
    };
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/03")
    @ApiOperation(value = "查詢六周內跑步資料")
    public RestApiOneResponse<List<RecordListResModelBean>> doQuerySixWeekRunningActivityList(@Valid @RequestBody QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(querysixweekrunningactivityService.doQuerySixWeekRunningActivityList(model));
    };
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/04")
    @ApiOperation(value = "查詢十二周內跑步資料")
    public RestApiOneResponse<List<RecordListResModelBean>> doQueryTwelveWeekRunningActivityList(@Valid @RequestBody QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(querytwelveweekrunningactivityService.doQueryTwelveWeekRunningActivityList(model));
    };
    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/05")
    @ApiOperation(value = "查詢十八周內跑步資料")
    public RestApiOneResponse<List<RecordListResModelBean>> doQueryEighteenWeekRunningActivityList(@Valid @RequestBody QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(queryeighteenweekrunningactivityService.doQueryEighteenWeekRunningActivityList(model));
    };
}
