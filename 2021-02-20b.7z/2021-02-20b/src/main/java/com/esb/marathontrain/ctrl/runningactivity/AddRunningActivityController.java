package com.esb.marathontrain.ctrl.runningactivity;
import java.math.BigDecimal;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IAddRunningActivityService;
import com.esb.model.marathontrain.runningactivity.addrunningactivity.req.AddRunningActivityReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("/addrunningactivity")
@Api(tags = "新增跑步")
public class AddRunningActivityController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(AddRunningActivityController.class);

    /** AddRunningActivityService */
    @Autowired
    private IAddRunningActivityService addrunningactivityService;

    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "新增一筆跑步資料")
    public RestApiOneResponse<BigDecimal> doAddRunningActivityList(@Valid @RequestBody AddRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(addrunningactivityService.doAddRunningActivityList(model));
    }
}










