package com.esb.marathontrain.ctrl.goal;
import java.math.BigDecimal;
import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IDeleteGoalService;
import com.esb.model.marathontrain.goal.deletegoal.req.DeleteGoalReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/deletegoal")
@Api(tags = "刪除目標")
public class DeleteGoalController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(DeleteGoalController.class);

    /** AddRunningActivityService */
    @Autowired
    private IDeleteGoalService deletegoalService;

    /**
     * 刪除目標查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "刪除目標資料")
    public RestApiOneResponse<BigDecimal> doDeleteGoalList(@Valid @RequestBody DeleteGoalReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(deletegoalService.doDeleteGoalList(model));
    }
}
