package com.esb.marathontrain.service.login;

import java.math.BigDecimal;

import com.esb.model.marathontrain.login.updateuserdata.req.UpdateUserDataReqModelBean;

public interface IUpdateUserDataService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doUpdateUserDataList(UpdateUserDataReqModelBean model);
}



