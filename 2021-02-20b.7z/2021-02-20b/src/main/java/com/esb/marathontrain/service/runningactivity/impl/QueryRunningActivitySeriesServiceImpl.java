package com.esb.marathontrain.service.runningactivity.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.runningactivity.IQueryRunningActivitySeriesService;
import com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.req.QueryRunningActivitySeriesReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.res.QueryRunningActivitySeriesResModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.res.RecordListResModelBean;


/** 沒做完的 service */
@Service
@Transactional
public class QueryRunningActivitySeriesServiceImpl extends AbstractBaseApService implements IQueryRunningActivitySeriesService {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryRunningActivitySeriesServiceImpl.class);
    /**
     * 查詢目標紀錄
     */
    @Override
    public QueryRunningActivitySeriesResModelBean doQueryRunningActivitySeriesList(QueryRunningActivitySeriesReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        System.out.println(model.getStartDate());
        System.out.println(model.getEndDate());
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                //查詢資料
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_START_DATE", model.getStartDate())
                .addValue("I_END_DATE", model.getEndDate())
                .addValue("I_UUID", model.getUuid())
                .addValue("I_IS_VALID", model.getIsValid())
                //分頁資料
                .addValue("I_PAGE_NO", model.getPageNo())
                .addValue("I_PAGE_SIZE", model.getPageSize())
                .addValue("I_SORT_COLUMN", StringUtils.defaultIfBlank(model.getSortColumn(), "UUID"))
                .addValue("I_SORT_TYPE", StringUtils.defaultIfBlank(model.getSortType(), "ASC"));
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        Map<String, Object> result = getGeneralSimpleJdbcCallDAO().doCallProcedure(
                "PG_WEEK_QRY_MT_RA_CALORIES",
                "SP_QUERY_FORM_DATA_LIST", // 交換機清單查詢
                parameterSource);
        QueryRunningActivitySeriesResModelBean resModelBean = new QueryRunningActivitySeriesResModelBean();
        resModelBean.setData(SimpleJdbcCallUtils.convertMapList2BeanList((List<?>) result.get("O_DATA"), RecordListResModelBean.class));
        resModelBean.setTotalCount((BigDecimal) result.get("O_TOTAL_COUNT"));
        resModelBean.setPageNo((BigDecimal) result.get("O_PAGE_NO"));
        return resModelBean;
    }
}
