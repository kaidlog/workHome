package com.esb.marathontrain.service.goal;
import java.math.BigDecimal;

import com.esb.model.marathontrain.goal.addgoal.req.AddGoalReqModelBean;

public interface IAddGoalService {
    /**
     * 新增目標的介面
     * 傳回新增的筆數，用 BigDecimal 來接
     */
    BigDecimal doAddGoalList(AddGoalReqModelBean model);
}
