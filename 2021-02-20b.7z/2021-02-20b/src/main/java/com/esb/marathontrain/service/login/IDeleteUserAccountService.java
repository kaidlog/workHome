package com.esb.marathontrain.service.login;

import java.math.BigDecimal;

import com.esb.model.marathontrain.login.delaccount.req.DeleteUserAccountReqModelBean;

public interface IDeleteUserAccountService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doDeleteUserAccountList(DeleteUserAccountReqModelBean model);
}



