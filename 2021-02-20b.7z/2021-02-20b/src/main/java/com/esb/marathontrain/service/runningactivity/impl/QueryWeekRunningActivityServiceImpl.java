package com.esb.marathontrain.service.runningactivity.impl;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.runningactivity.IQueryWeekRunningActivityService;
import com.esb.model.marathontrain.runningactivity.queryrunningactivity.req.QueryRunningActivityReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivity.res.RecordListResModelBean;

@Service
@Transactional
public class QueryWeekRunningActivityServiceImpl extends AbstractBaseApService implements IQueryWeekRunningActivityService {
    /** logger */
    private static Log logger = LogFactory.getLog(UpdateRunningActivityServiceImpl.class);

    /**
     * 查詢跑步紀錄
     */
    @Override
    public List<RecordListResModelBean> doQueryWeekRunningActivityList(QueryRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_END_DATE", model.getEndDate())
                .addValue("I_UUID", model.getUuid())
                .addValue("I_START_DATE", model.getStartDate())
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_IS_VALID", "1");
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_INTERSECT_QRY_MT",
                "FN_ONEWEEK_QRY_GOAL",
                parameterSource);
        //System.out.println(SimpleJdbcCallUtils.convertMapList2BeanList(mapList, RecordListResModelBean.class));
        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, RecordListResModelBean.class);
    }
}
