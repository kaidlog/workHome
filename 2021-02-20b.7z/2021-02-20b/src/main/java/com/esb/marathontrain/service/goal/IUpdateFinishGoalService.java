package com.esb.marathontrain.service.goal;

import java.math.BigDecimal;

import com.esb.model.marathontrain.goal.updatefinishgoal.req.UpdateFinishGoalReqModelBean;

public interface IUpdateFinishGoalService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doUpdateFinishGoalList(UpdateFinishGoalReqModelBean model);
}



