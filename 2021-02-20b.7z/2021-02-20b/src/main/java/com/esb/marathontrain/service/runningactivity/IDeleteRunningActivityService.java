package com.esb.marathontrain.service.runningactivity;
import java.math.BigDecimal;

import com.esb.model.marathontrain.runningactivity.deleterunningactivity.req.DeleteRunningActivityReqModelBean;

public interface IDeleteRunningActivityService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doDeleteRunningActivityList(DeleteRunningActivityReqModelBean model);
}



