package com.esb.marathontrain.service.goal;

import java.util.List;

import com.esb.model.marathontrain.goal.querygoalendornot.req.QueryGoalEndOrNotReqModelBean;
import com.esb.model.marathontrain.goal.querygoalendornot.res.QueryGoalEndOrNotResModelBean;


public interface IQueryGoalEndOrNotServiceService {
    List<QueryGoalEndOrNotResModelBean> doQueryGoalEndOrNotList(QueryGoalEndOrNotReqModelBean model);
}
