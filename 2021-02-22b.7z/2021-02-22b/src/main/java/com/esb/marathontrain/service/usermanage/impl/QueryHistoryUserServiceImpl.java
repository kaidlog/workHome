package com.esb.marathontrain.service.usermanage.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.usermanage.IQueryHistoryUserService;
import com.esb.model.marathontrain.usermanage.req.QueryHistoryUserReqModelBean;
import com.esb.model.marathontrain.usermanage.res.QueryHistoryUserResModelBean;
import com.esb.model.marathontrain.usermanage.res.QueryOnePageHistoryUserResModelBean;


@Service
@Transactional
public class QueryHistoryUserServiceImpl extends AbstractBaseApService implements IQueryHistoryUserService {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryHistoryUserServiceImpl.class);
    /**
     * 查詢目標紀錄
     */
    @Override
    public QueryOnePageHistoryUserResModelBean doQueryHistoryUserList(QueryHistoryUserReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_UUID", model.getUuid())
                .addValue("I_SUSPEND_OR_NOT", model.getSuspendOrNot())
                .addValue("I_PAGE_NO", model.getPageNo())
                .addValue("I_PAGE_SIZE", model.getPageSize())
                .addValue("I_SORT_COLUMN", StringUtils.defaultIfBlank(model.getSortColumn(), "UUID"))
                .addValue("I_SORT_TYPE", StringUtils.defaultIfBlank(model.getSortType(), "ASC"));
//                .addValue("I_PAGE_NO", model.getPageNo())
//                .addValue("I_PAGE_SIZE", model.getPageSize());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
//        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
//                List.class,
//                "PG_MT_GOAL",
//                "FN_QRY_RECORD",
//                parameterSource);
//        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, QueryHistoryGoalResModelBean.class);
        Map<String, Object> result = getGeneralSimpleJdbcCallDAO().doCallProcedure(
                "PG_QUERY_HISTORY_USER",
                "SP_QUERY_FORM_DATA_LIST", // 交換機清單查詢
                parameterSource);
        QueryOnePageHistoryUserResModelBean resModelBean = new QueryOnePageHistoryUserResModelBean();
        resModelBean.setData(SimpleJdbcCallUtils.convertMapList2BeanList((List<?>) result.get("O_DATA"), QueryHistoryUserResModelBean.class));
        resModelBean.setTotalCount((BigDecimal) result.get("O_TOTAL_COUNT"));
        resModelBean.setPageNo((BigDecimal) result.get("O_PAGE_NO"));
        return resModelBean;
    }
}
