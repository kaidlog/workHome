package com.esb.marathontrain.service.runningactivity;

import com.esb.model.marathontrain.runningactivity.queryrunningactivitydistance.req.QueryRunningActivityDistanceReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivitydistance.res.QueryRunningActivityDistanceResModelBean;

public interface IQueryRunningActivityDistanceService {
    QueryRunningActivityDistanceResModelBean doQueryRunningActivityDistanceList(QueryRunningActivityDistanceReqModelBean model);
}
