package com.esb.marathontrain.service.runningactivity;

import java.util.List;

import com.esb.model.marathontrain.runningactivity.qrydiagram.req.QryDiagramReqModelBean;
import com.esb.model.marathontrain.runningactivity.qrydiagram.res.QryDiagramResModelBean;

public interface IQryDiagramService {
    QryDiagramResModelBean doQryDiagramList(QryDiagramReqModelBean model);
}
