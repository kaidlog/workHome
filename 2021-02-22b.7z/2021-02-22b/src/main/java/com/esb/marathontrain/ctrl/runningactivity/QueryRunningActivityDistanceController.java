package com.esb.marathontrain.ctrl.runningactivity;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IQueryRunningActivityDistanceService;
import com.esb.model.marathontrain.runningactivity.queryrunningactivitydistance.req.QueryRunningActivityDistanceReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivitydistance.res.QueryRunningActivityDistanceResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/queryrunningactivitydistance")
@Api(tags = "距離區間")
public class QueryRunningActivityDistanceController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryRunningActivityController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IQueryRunningActivityDistanceService queryrunningactivitydistanceService;
    /** UpdateWeekRunningActivityService */


    /**
     * 跑步紀錄查詢
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢區間")
    public RestApiOneResponse<QueryRunningActivityDistanceResModelBean> doQueryRunningActivityDistanceList(@Valid @RequestBody QueryRunningActivityDistanceReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(queryrunningactivitydistanceService.doQueryRunningActivityDistanceList(model));
    };
}
