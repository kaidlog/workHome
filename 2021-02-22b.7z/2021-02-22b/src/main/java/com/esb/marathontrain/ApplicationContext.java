package com.esb.marathontrain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * Spring Boot starter.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@EnableScheduling
@EnableEncryptableProperties
@EnableFeignClients(basePackages = {"com.esb" })
@SpringBootApplication(scanBasePackages = {"com.esb" })
public class ApplicationContext {
    /**
     * Application entry point
     * @param args
     * @remark
     */
    public static void main(String[] args) {
        SpringApplication.run(ApplicationContext.class, args);
    }
}