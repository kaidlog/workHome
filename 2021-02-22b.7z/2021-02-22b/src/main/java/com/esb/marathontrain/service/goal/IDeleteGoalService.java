package com.esb.marathontrain.service.goal;
import java.math.BigDecimal;

import com.esb.model.marathontrain.goal.deletegoal.req.DeleteGoalReqModelBean;

public interface IDeleteGoalService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doDeleteGoalList(DeleteGoalReqModelBean model);
}



