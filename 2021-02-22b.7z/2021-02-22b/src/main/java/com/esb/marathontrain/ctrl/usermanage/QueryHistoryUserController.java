package com.esb.marathontrain.ctrl.usermanage;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.usermanage.IQueryHistoryUserService;
import com.esb.model.marathontrain.usermanage.req.QueryHistoryUserReqModelBean;
import com.esb.model.marathontrain.usermanage.res.QueryHistoryUserResModelBean;
import com.esb.model.marathontrain.usermanage.res.QueryOnePageHistoryUserResModelBean;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/queryhistoryuser")
@Api(tags = "查詢用戶")
public class QueryHistoryUserController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryHistoryUserController.class);

    @Autowired
    private IQueryHistoryUserService queryhistoryuserService;

    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢用戶")
    public RestApiOneResponse<QueryOnePageHistoryUserResModelBean> doQueryHistoryUserList(@Valid @RequestBody QueryHistoryUserReqModelBean model, HttpServletRequest request) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }
        HttpSession session = request.getSession();
        return doGetDefaultOneResult(queryhistoryuserService.doQueryHistoryUserList(model));
    }
}
