package com.esb.marathontrain.service.runningactivity;
import java.util.List;
import com.esb.model.marathontrain.runningactivity.qryavgdata.req.QryAvgDataReqModelBean;
import com.esb.model.marathontrain.runningactivity.qryavgdata.res.QryAvgDataResModelBean;

public interface IQryAvgDataService {
    QryAvgDataResModelBean doQryAvgDataList(QryAvgDataReqModelBean model);
}
