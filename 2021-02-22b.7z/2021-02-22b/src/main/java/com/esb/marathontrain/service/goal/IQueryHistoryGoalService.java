package com.esb.marathontrain.service.goal;

import java.util.List;

import com.esb.model.marathontrain.goal.queryhistorygoal.req.QueryHistoryGoalReqModelBean;
import com.esb.model.marathontrain.goal.queryhistorygoal.res.QueryOnePageHistoryGoalResModelBean;

public interface IQueryHistoryGoalService {
    QueryOnePageHistoryGoalResModelBean doQueryHistoryGoalList(QueryHistoryGoalReqModelBean model);
}
