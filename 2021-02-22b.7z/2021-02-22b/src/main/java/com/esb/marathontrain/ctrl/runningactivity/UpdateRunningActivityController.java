package com.esb.marathontrain.ctrl.runningactivity;

import java.math.BigDecimal;
import javax.validation.Valid;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.runningactivity.IUpdateRunningActivityService;
import com.esb.model.marathontrain.runningactivity.updaterunningactivity.req.UpdateRunningActivityReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/updaterunningactivity")
@Api(tags = "更新跑步")
public class UpdateRunningActivityController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(UpdateRunningActivityController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IUpdateRunningActivityService updaterunningactivityService;

    /**
     * 更新跑步紀錄
     * @return RestApiResponse 跑步紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "更新某筆跑步資料")
    public RestApiOneResponse<BigDecimal> doUpdateRunningActivityList(@Valid @RequestBody UpdateRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(updaterunningactivityService.doUpdateRunningActivityList(model));
    }
}
