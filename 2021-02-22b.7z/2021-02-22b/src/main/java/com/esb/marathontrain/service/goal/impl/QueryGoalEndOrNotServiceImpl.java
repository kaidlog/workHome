package com.esb.marathontrain.service.goal.impl;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.goal.IQueryGoalEndOrNotServiceService;
import com.esb.model.marathontrain.goal.querygoalendornot.req.QueryGoalEndOrNotReqModelBean;
import com.esb.model.marathontrain.goal.querygoalendornot.res.QueryGoalEndOrNotResModelBean;


@Service
@Transactional
public class QueryGoalEndOrNotServiceImpl extends AbstractBaseApService implements IQueryGoalEndOrNotServiceService {
    /** logger */
    private static Log logger = LogFactory.getLog(UpdateGoalServiceImpl.class);
    /**
     * 查詢目標紀錄
     */
    @Override
    public List<QueryGoalEndOrNotResModelBean> doQueryGoalEndOrNotList(QueryGoalEndOrNotReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }

        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_UUID", model.getUuid())
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_CUR_TIME", model.getCurTime())
                .addValue("I_IS_VALID", '1');
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_MT_GOAL_END_OR_NOT",
                "FN_QRY_RECORD",
                parameterSource);
        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, QueryGoalEndOrNotResModelBean.class);
    }
}
