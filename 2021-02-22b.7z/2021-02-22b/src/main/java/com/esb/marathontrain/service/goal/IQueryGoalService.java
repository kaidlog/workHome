package com.esb.marathontrain.service.goal;
import java.util.List;

import com.esb.model.marathontrain.goal.querygoal.req.QueryGoalReqModelBean;
import com.esb.model.marathontrain.goal.querygoal.res.QueryGoalResModelBean;


public interface IQueryGoalService {
    List<QueryGoalResModelBean> doQueryGoalList(QueryGoalReqModelBean model);
}
