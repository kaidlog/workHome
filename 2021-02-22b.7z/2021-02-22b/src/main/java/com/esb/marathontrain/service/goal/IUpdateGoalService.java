package com.esb.marathontrain.service.goal;
import java.math.BigDecimal;

import com.esb.model.marathontrain.goal.updategoal.req.UpdateGoalReqModelBean;

public interface IUpdateGoalService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doUpdateGoalList(UpdateGoalReqModelBean model);
}






