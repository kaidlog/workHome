package com.esb.marathontrain.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.esb.core.service.AbstractBaseService;

/**
 * Base Business Services for AP project.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseApService extends AbstractBaseService {
    /** logger */
    private static Log logger = LogFactory.getLog(AbstractBaseApService.class);
}