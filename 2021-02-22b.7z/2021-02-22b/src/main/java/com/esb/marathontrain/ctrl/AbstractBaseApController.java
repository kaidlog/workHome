package com.esb.marathontrain.ctrl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.esb.core.ctrl.AbstractBaseController;

/**
 * Base Spring MVC Controller for this project.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseApController extends AbstractBaseController {
    /** logger */
    private static Log logger = LogFactory.getLog(AbstractBaseApController.class);
}