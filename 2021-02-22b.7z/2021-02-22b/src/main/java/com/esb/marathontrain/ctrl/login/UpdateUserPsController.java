package com.esb.marathontrain.ctrl.login;

import java.math.BigDecimal;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.login.IUpdateUserPwService;
import com.esb.model.marathontrain.login.updatepw.req.UpdateUserPwReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/updateps")
@Api(tags = "updateps")
public class UpdateUserPsController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryUserEmailController.class);

    /** UpdateRunningActivityService */
    @Autowired
    private IUpdateUserPwService updateuserpwService;

    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "emailcheck")
    public RestApiOneResponse<BigDecimal> doUpdateUserPwList(@Valid @RequestBody UpdateUserPwReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(updateuserpwService.doUpdateUserPwList(model));
    }
}











