package com.esb.marathontrain.service.login;

import java.math.BigDecimal;

import com.esb.model.marathontrain.login.updatepw.req.UpdateUserPwReqModelBean;

public interface IUpdateUserPwService {
    /**
     * @param model
     * @return
     * @remark
     */
    BigDecimal doUpdateUserPwList(UpdateUserPwReqModelBean model);
}



