package com.esb.marathontrain.service.runningactivity.impl;

import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.SimpleJdbcCallUtils;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.runningactivity.IQryAvgDataService;
import com.esb.model.marathontrain.runningactivity.qryavgdata.req.QryAvgDataReqModelBean;
import com.esb.model.marathontrain.runningactivity.qryavgdata.res.QryAvgDataResModelBean;
import com.esb.model.marathontrain.runningactivity.qryavgdata.res.RecordListResModelBean;
/** 沒做完的 service */
@Service
@Transactional
public class QryAvgDataServiceImpl extends AbstractBaseApService implements IQryAvgDataService {
    /** logger */
    private static Log logger = LogFactory.getLog(QryDiagramServiceImpl.class);
    /**
     * 查詢目標紀錄
     */
    @Override
    public QryAvgDataResModelBean doQryAvgDataList(QryAvgDataReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                //查詢資料
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_CRE_DATE_TIME", model.getCreDateTime() + " " + "00:00:00")
                .addValue("I_UUID", model.getUuid())
                .addValue("I_IS_VALID", model.getIsValid());
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        Map<String, Object> result = getGeneralSimpleJdbcCallDAO().doCallProcedure(
                "PG_MT_JUDGE_GOAL",
                "SP_QUERY_FORM_DATA_LIST", // 交換機清單查詢
                parameterSource);
        QryAvgDataResModelBean resModelBean = new QryAvgDataResModelBean();
        resModelBean.setOData(SimpleJdbcCallUtils.convertMapList2BeanList((List<?>) result.get("O_DATA"), RecordListResModelBean.class));
        return resModelBean;
    }
}

