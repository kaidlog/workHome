package com.esb.marathontrain.service.runningactivity.impl;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.fastjson.JSONObject;
import com.esb.marathontrain.service.AbstractBaseApService;
import com.esb.marathontrain.service.runningactivity.IUpdateRunningActivityService;
import com.esb.model.marathontrain.runningactivity.updaterunningactivity.req.UpdateRunningActivityReqModelBean;

@Service
@Transactional
public class UpdateRunningActivityServiceImpl extends AbstractBaseApService implements IUpdateRunningActivityService {
    /** logger */
    private static Log logger = LogFactory.getLog(UpdateRunningActivityServiceImpl.class);

    /**
     * 更新跑步紀錄
     */
    public BigDecimal doUpdateRunningActivityList(UpdateRunningActivityReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logger.debug(logParams);
        }
        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        Calendar calendar = Calendar.getInstance();
        String currentTime = (new SimpleDateFormat("yyyy-MM-dd 24HH:mm:ss")).format(calendar.getTime());
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_RUNNINGACTIVITY_ID", model.getRunningActivityId())
                .addValue("I_PACE_PER_KM", model.getPacePerKm())
                .addValue("I_DISTANCE", model.getDistance())
                .addValue("I_CALORIES", model.getCalories())
                .addValue("I_HEARTRATE", model.getHeartRate())
                .addValue("I_ELEVATIONVARIATION", model.getElevationVariation())
                .addValue("I_CRE_DATE_TIME", currentTime)
                .addValue("I_UPD_DATE_TIME", currentTime)
                .addValue("I_GOAL_ID", model.getGoalId())
                .addValue("I_IS_VALID", "1")
                .addValue("I_CREATOR", model.getCreator())
                .addValue("I_UUID", model.getUuid())
                .addValue("I_UPDATER", model.getUpdater());
        System.out.println(parameterSource);
        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_VALID_MT_RUNNINGACTIVITY",
                "FN_EDIT_RECORD",
                parameterSource);
    }
}
