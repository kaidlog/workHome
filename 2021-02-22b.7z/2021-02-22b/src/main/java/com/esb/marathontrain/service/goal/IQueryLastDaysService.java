package com.esb.marathontrain.service.goal;

import java.util.List;

import com.esb.model.marathontrain.goal.qrylastdays.res.QueryLastDaysResModelBean;
import com.esb.model.marathontrain.goal.qrylastdays.req.QueryLastDaysReqModelBean;


public interface IQueryLastDaysService {
    List<QueryLastDaysResModelBean> doQueryLastDaysList(QueryLastDaysReqModelBean model);
}
