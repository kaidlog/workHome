package com.esb.marathontrain.service.usermanage;

import com.esb.model.marathontrain.usermanage.req.QueryHistoryUserReqModelBean;
import com.esb.model.marathontrain.usermanage.res.QueryOnePageHistoryUserResModelBean;

public interface IQueryHistoryUserService {
    QueryOnePageHistoryUserResModelBean doQueryHistoryUserList(QueryHistoryUserReqModelBean model);
}
