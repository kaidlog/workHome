package com.esb.marathontrain.ctrl.goal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IQueryGoalService;
import com.esb.model.marathontrain.goal.querygoal.req.QueryGoalReqModelBean;
import com.esb.model.marathontrain.goal.querygoal.res.QueryGoalResModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/querygoal")
@Api(tags = "目標查詢")
public class QueryGoalController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryGoalController.class);

    @Autowired
    private IQueryGoalService querygoalService;

    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢目標資料")
    public RestApiOneResponse<List<QueryGoalResModelBean>> doQueryGoalList(@Valid @RequestBody QueryGoalReqModelBean model, HttpServletRequest request) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        @SuppressWarnings("unchecked")
        List<QueryUserResModelBean> userDataSession = (List<QueryUserResModelBean>) request.getSession().getAttribute("userProfile");
        System.out.println("這邊這邊" + userDataSession);

        System.out.println("我好笨");
        System.out.println(request.getSession().getAttribute("token"));

        return doGetDefaultOneResult(querygoalService.doQueryGoalList(model));
    }
}
