package com.esb.marathontrain.service.runningactivity;

import java.util.List;

import com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.req.QueryRunningActivitySeriesReqModelBean;
import com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.res.QueryRunningActivitySeriesResModelBean;

public interface IQueryRunningActivitySeriesService {
    QueryRunningActivitySeriesResModelBean doQueryRunningActivitySeriesList(QueryRunningActivitySeriesReqModelBean model);
}
