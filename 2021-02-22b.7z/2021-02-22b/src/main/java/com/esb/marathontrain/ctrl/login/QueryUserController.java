package com.esb.marathontrain.ctrl.login;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.login.IQueryUserService;
import com.esb.model.marathontrain.login.loginquery.req.QueryUserReqModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/login")
@Api(tags = "登入")
public class QueryUserController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(QueryUserController.class);
    /** UpdateRunningActivityService */
    @Autowired
    private IQueryUserService queryuserService;
    /** sha256 加密演算法 */
    public static String getSHA256(String input) {
        String toReturn = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.reset();
            digest.update(input.getBytes("utf8"));
            toReturn = String.format("%064x", new BigInteger(1, digest.digest()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return toReturn;
    }

    /**
     * 目標紀錄查詢
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "登陸檢核")
    public RestApiOneResponse<List<QueryUserResModelBean>> doQueryGoalList(@Valid @RequestBody QueryUserReqModelBean model, HttpServletRequest request) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }
        Calendar calendar = Calendar.getInstance();
        String currentTime = (new SimpleDateFormat("yyyy-MM-dd 24HH:mm:ss")).format(calendar.getTime());
        @SuppressWarnings("unchecked")
        List<String> userDataSession = (List<String>) request.getSession().getAttribute("userProfile");
        System.out.println(request.getSession().getAttribute("LOGIN"));
        if (userDataSession == null) {
            userDataSession = new ArrayList<>();
            // 建立一個 session 叫做 userDataSession，一開始肯定是空的值
            request.getSession().setAttribute("userProfile", userDataSession);
        }
        if (logger.isTraceEnabled()) {
            logger.trace(new JSONObject());
        }
        List<QueryUserResModelBean> responseResult = queryuserService.doQueryUserList(model);
        if (responseResult.size() != 0) {
            // 取得 uuid 放進去 loginsession 裡面
         // 把 token 回傳回去
            // email 是唯一的，用唯一的值去做 sha256
            responseResult.get(0).setToken(getSHA256(model.getEmail()));
            // 把 timeout 回傳回去 預設是600 秒
            responseResult.get(0).setTimeout(600);
            userDataSession.add(responseResult.get(0).getToken());
            request.getSession().setAttribute("userProfile", userDataSession);
        }
        // if token 有的話，就來這邊撈 userProfile 的資料
        System.out.println(request.getSession().getAttribute("userProfile"));
        if (request.getSession().getAttribute("token") != null) {
            System.out.println(request.getSession().getAttribute("userProfile"));
            System.out.println();
            return doGetDefaultOneResult(responseResult);
        } else {
            return doGetDefaultOneResult(responseResult);
        }
    }
}











