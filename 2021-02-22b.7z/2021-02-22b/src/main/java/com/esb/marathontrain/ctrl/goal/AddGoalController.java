package com.esb.marathontrain.ctrl.goal;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSONObject;
import com.esb.core.bean.RestApiOneResponse;
import com.esb.marathontrain.ctrl.AbstractBaseApController;
import com.esb.marathontrain.service.goal.IAddGoalService;
import com.esb.model.marathontrain.goal.addgoal.req.AddGoalReqModelBean;
import com.esb.model.marathontrain.login.loginquery.res.QueryUserResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("/addgoal")
@Api(tags = "新增目標")
public class AddGoalController extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(AddGoalController.class);

    /** AddGoalRunningActivityService */
    @Autowired
    private IAddGoalService addgoalService;

    /**
     * 新增目標
     * @return RestApiResponse 目標紀錄
     */
    @PostMapping("/01")
    @ApiOperation(value = "新增目標資料")
    public RestApiOneResponse<BigDecimal> doAddGoalList(@Valid @RequestBody AddGoalReqModelBean model, HttpServletRequest request) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }
        @SuppressWarnings("unchecked")
        List<QueryUserResModelBean> userDataSession = (List<QueryUserResModelBean>) request.getSession().getAttribute("userProfile");
        System.out.println("這邊這邊" + userDataSession);

        return doGetDefaultOneResult(addgoalService.doAddGoalList(model));
    }
}










