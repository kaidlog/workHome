package com.esb.core.service.impl.auth;

import java.util.Collection;
import java.util.Optional;

import org.springframework.core.annotation.Order;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.esb.core.service.AbstractBaseService;
import com.esb.core.service.IAuthorizationDecisionService;

/**
 * 於Security Config中設定permitAll同意放行.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Order(1)
@Service("SecurityConfigPassAuthDecisionServiceImpl")
public class SecurityConfigPassAuthDecisionServiceImpl extends AbstractBaseService implements IAuthorizationDecisionService {

    /**
     * 決定是否放行
     */
    @Override
    public boolean decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) {
        // SecurityConfig設定直接放行 -------------------------------------------------------------------------------------
        Optional<ConfigAttribute> optional = configAttributes.stream().filter(row -> {
            return "permitAll".equals(row.toString()); // permitAll: 直接放行
        }).findFirst();

        return optional.isPresent();
    }
}