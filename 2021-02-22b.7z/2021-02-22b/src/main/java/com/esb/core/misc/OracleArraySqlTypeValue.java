package com.esb.core.misc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.support.AbstractSqlTypeValue;

import oracle.jdbc.driver.OracleConnection;

/**
 * 建立Oracle資料庫中自定陣列型別物件
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月24日
 * @remark
 */
public class OracleArraySqlTypeValue extends AbstractSqlTypeValue {
    /** Array value */
    private Object[] values;

    /**
     * Constructor for type List<Object>
     * @param values
     * @remark
     */
    public OracleArraySqlTypeValue(List<Object> values) {
        this.values = Optional.ofNullable(values).orElse(
                new ArrayList<Object>()
        ).toArray();
    }

    /**
     * Constructor for type Object[]
     * @param values
     * @remark
     */
    public OracleArraySqlTypeValue(Object[] values) {
        this.values = Optional.ofNullable(values).orElse(new Object[] {});
    }

    @Override
    protected Object createTypeValue(Connection con, int sqlType, String typeName) throws SQLException {
        OracleConnection oracleConnection = con.unwrap(OracleConnection.class);
        return oracleConnection.createARRAY(typeName, values);
    }
}