package com.esb.core.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger Configuration.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
    /** Runtime stage */
    @Value("${runtime.environment}")
    private String environment;

    /**
     * Swagger configuration entry point
     * @return Docket
     * @remark
     */
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                /** 正式環境不產生Swagger UI */
                .enable(!"prod".equals(environment)) // prod: 正式環境
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.esuncard"))
                .build();
    }
}