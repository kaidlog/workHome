package com.esb.core.interceptor;

import java.io.IOException;

import org.springframework.stereotype.Component;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * Feign Client HTTP Request MDC Interceptor.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Component
public class FeignClientHttpRequestMDCInterceptor implements Interceptor {
    /**
     * Feign HTTP request MDC interceptor
     */
    @Override
    public Response intercept(Chain chain) throws IOException {
        // TODO
        return chain.proceed(chain.request());
    }
}