package com.esb.core.utils;

import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSONObject;

import lombok.experimental.UtilityClass;

/**
 * Date Utility
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年5月26日
 * @remark
 */
@UtilityClass
public class ApDateUtils {
    /** logger */
    private static Log logger = LogFactory.getLog(ApDateUtils.class);

    /**
     * 清除日期格式符號，移除符號及空白，Ex. 2020/01/01 -> 20200101、2020-01-01 16:12:11 -> 20200101161211
     * @param date 來源日期資料
     * @return 移除符號日期字串
     * @remark
     */
    public String doCleanDateFormat(String date) {
        if (logger.isTraceEnabled()) {
            logger.trace(new JSONObject().fluentPut("date", date));
        }

        if (StringUtils.isBlank(date)) {
            return date;
        }

        return RegExUtils.removeAll(date, "[^0-9]");
    }
}