package com.esb.core.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import org.apache.commons.lang3.StringUtils;

/**
 * BigDecimal type Object Utility，用於處理跟數字相關的API Ex. Number Formate, Number type convert ...
 * @author 20718 Jason Chan by Esunbank
 */
public class DecimalUtils {
    /**
     * Default construct
     * @remark
     */
    private DecimalUtils() {
    }

    /**
     * 將Number型別的資料轉成BigDecimal，若傳入值為null，則回傳BigDecimal("0")
     * @param number 要被轉換的數字參數
     * @return 轉換後的BigDecimal數字
     */
    public static BigDecimal defaultDecimal(Number number) {
        if (number == null) {
            return new BigDecimal("0");
        }
        return new BigDecimal(number.toString());
    }

    /**
     * 將Number型別的資料轉成BigDecimal，若傳入值為null或空白，則回傳defaultNum
     * @param number 要被轉換的數字參數
     * @param defaultNum 預設回傳數字
     * @return 轉換後的BigDecimal數字
     */
    public static BigDecimal defaultDecimal(Number number, String defaultNum) {
        if (number == null && StringUtils.isBlank(defaultNum)) {
            return null;
        }
        if (number == null) {
            return new BigDecimal(defaultNum);
        }

        return new BigDecimal(number.toString());
    }

    /**
     * 將String型別的數字資料轉成BigDecimal，若傳入值為null或空白，則回傳BigDecimal("0")
     * @param number 要被轉換的數字參數
     * @return 轉換後的BigDecimal數字
     */
    public static BigDecimal defaultDecimal(String number) {
        if (StringUtils.isBlank(number)) {
            number = "0";
        }
        number = number.trim();
        number = StringUtils.remove(number, ",");

        return new BigDecimal(number);
    }

    /**
     * 將String型別的數字資料轉成BigDecimal，若傳入值為null或空白，則回傳BigDecimal("0")
     * @param number 要被轉換的數字參數
     * @return 轉換後的BigDecimal數字
     */
    public static BigDecimal toDecimal(String number) {
        number = StringUtils.defaultString(number, "0");
        number = StringUtils.remove(number, ",");
        return new BigDecimal(number);
    }

    /**
     * 取得預設的數字，若來源number為空，則回傳defaultNum
     * @param number
     * @param defaultNum
     * @return BigDecimal
     */
    public static BigDecimal defaultDecimal(String number, String defaultNum) {
        if (StringUtils.isBlank(number) && StringUtils.isBlank(defaultNum)) {
            return null;
        }

        if (StringUtils.isBlank(number)) {
            number = defaultNum;
        }
        number = number.trim();
        number = StringUtils.remove(number, ",");

        return defaultDecimal(number);
    }

    /**
     * 數字格式化
     * @param number
     * @param pattern
     * @return BigDecimal
     */
    public static String format(Number number, String pattern) {
        NumberFormat nf = new DecimalFormat(pattern);
        number = defaultDecimal(number);

        return nf.format(number);
    }

    /**
     * 數字格式化
     * @param number
     * @param pattern
     * @return BigDecimal
     */
    public static String format(String number, String pattern) {
        if (StringUtils.isBlank(number)) {
            number = "0";
        }

        number = StringUtils.remove(number, ",");
        BigDecimal decimal = new BigDecimal(number);
        return format(decimal, pattern);
    }

    /**
     * 2數字相乘
     * @param b1
     * @param b2
     * @return BigDecimal
     */
    public static BigDecimal multiply(BigDecimal b1, BigDecimal b2) {
        b1 = defaultDecimal(b1);
        b2 = defaultDecimal(b2);
        return b1.multiply(b2);
    }

    /**
     * 四捨五入除法 result = dividend / divisor
     * @param dividend 被除數
     * @param divisor 除數
     * @param scale 小數保留幾位
     * @return BigDecimal
     */
    public static BigDecimal divide(BigDecimal dividend, BigDecimal divisor, int scale) {
        BigDecimal result = new BigDecimal("0");
        if (result.equals(divisor) || divisor == null) {
            return result;
        } // 除數不得為0，如果為0 or null return 0

        dividend = defaultDecimal(dividend);

        return dividend.divide(divisor, scale, BigDecimal.ROUND_HALF_UP); // 四捨五入
    }

    /**
     * 若number為null，則回傳defaultStr，若number != null，則將number轉形為字串回傳
     * @param number
     * @param defaultStr
     * @return BigDecimal
     */
    public static String defaultString(Number number, String defaultStr) {
        if (number == null) {
            return defaultStr;
        } else {
            return number.toString();
        }
    }
}