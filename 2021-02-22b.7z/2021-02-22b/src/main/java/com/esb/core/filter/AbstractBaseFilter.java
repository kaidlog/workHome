package com.esb.core.filter;

import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.filter.OncePerRequestFilter;


import lombok.Getter;

/**
 * Base Filter
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年5月4日
 * @remark
 */
public abstract class AbstractBaseFilter extends OncePerRequestFilter {
    /** 運行環境 */
    @Getter
    @Value("${runtime.environment}")
    private String runtimeEnv;
    /** 應用系統代碼 */
    @Getter
    @Value("demo")
    private String sysName;

    // -------------------------------------------------------------------------------------------------------------
    /** Spring application context */
    @Getter
    @Autowired
    private ApplicationContext applicationContext;



    // -------------------------------------------------------------------------------------------------------------
    @Override
    protected void initFilterBean() throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, getServletContext());
    }
}