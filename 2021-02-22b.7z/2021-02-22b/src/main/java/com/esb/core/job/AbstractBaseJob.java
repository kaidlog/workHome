package com.esb.core.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import com.esb.core.service.IGeneralSimpleJdbcCallDaoService;

import lombok.Getter;

/**
 * Abstract base job.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseJob {
    /** 一秒鐘 */
    public static final long ONE_SECOND = 1 * 1000;
    /** 一分鐘 */
    public static final long ONE_MINUTE = 60 * ONE_SECOND;
    /** 一小時 */
    public static final long ONE_HOUR = 60 * ONE_MINUTE;
    /** 一天 */
    public static final long ONE_DAY = 24 * ONE_HOUR;

    // ----------------------------------------------------------------------------
    /** 運行環境 */
    @Getter
    @Value("${runtime.environment}")
    private String runtimeEnv;

    // ----------------------------------------------------------------------------
    /** Spring application context */
    @Getter
    @Autowired
    private ApplicationContext applicationContext;
    /** General SimpleJdbcCall Data access object service */
    @Getter
    @Autowired
    private IGeneralSimpleJdbcCallDaoService generalSimpleJdbcCallDaoService;

    // ----------------------------------------------------------------------------
    /**
     * 啟動Job入口點(Entry Point)
     */
    protected abstract void doExecJob();
}