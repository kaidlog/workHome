package com.esb.core.constraints.validator;

import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.DateValidator;

import com.esb.core.constraints.AbstractBaseConstraintValidator;
import com.esb.core.constraints.ValidDate;

/**
 * JSR-303 方式，檢查日期格式是否正確.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public class DateFormatValidator extends AbstractBaseConstraintValidator<ValidDate, String> {
    /** 日期格式 */
    private String pattern;

    @Override
    public void initialize(ValidDate constraintAnnotation) {
        this.pattern = constraintAnnotation.pattern();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        DateValidator dateValidator = DateValidator.getInstance();
        if (pattern.length() == value.length() && dateValidator.validate(value, pattern) != null) {
            return true;
        }

        return false;
    }
}