package com.esb.core.service.impl;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.service.AbstractBaseService;
import com.esb.core.service.IGeneralSimpleJdbcCallDaoService;
import com.esb.core.utils.CIFMaskUtils;

/**
 * General SimpleJdbcCall Data Access Service implementation for all procedure call.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Service
@Transactional
public class GeneralSimpleJdbcCallDaoServiceImpl extends AbstractBaseService implements IGeneralSimpleJdbcCallDaoService {
    /** logger */
    private static Log logger = LogFactory.getLog(GeneralSimpleJdbcCallDaoServiceImpl.class);

    // 1. Stored procedure -----------------------------------------------------------------------------------------
    @Override
    public Map<String, Object> doCallProcedure(String catalogName, String procedureName, SqlParameterSource parameterSource) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("catalogName", catalogName);
            logParams.put("procedureName", procedureName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallProcedure(catalogName, procedureName, parameterSource);
    }

    @Override
    public Map<String, Object> doCallProcedure(String catalogName, String procedureName) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("catalogName", catalogName);
            logParams.put("procedureName", procedureName);

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallProcedure(catalogName, procedureName);
    }

    @Override
    public Map<String, Object> doCallProcedure(String procedureName, SqlParameterSource parameterSource) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("procedureName", procedureName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallProcedure(procedureName, parameterSource);
    }

    @Override
    public Map<String, Object> doCallProcedure(String procedureName) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject().fluentPut("procedureName", procedureName));
        }

        return getGeneralSimpleJdbcCallDAO().doCallProcedure(procedureName);
    }

    // 2. Stored function ------------------------------------------------------------------------------------------
    @Override
    public <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName, SqlParameterSource parameterSource) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("catalogName", catalogName);
            logParams.put("functionName", functionName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallFunction(returnType, catalogName, functionName, parameterSource);
    }

    @Override
    public <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("catalogName", catalogName);
            logParams.put("functionName", functionName);

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallFunction(returnType, catalogName, functionName);
    }

    @Override
    public <T> T doCallFunction(Class<T> returnType, String functionName, SqlParameterSource parameterSource) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("functionName", functionName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallFunction(returnType, functionName, parameterSource);
    }

    @Override
    public <T> T doCallFunction(Class<T> returnType, String functionName) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("functionName", functionName);

            logger.debug(logParams);
        }

        return getGeneralSimpleJdbcCallDAO().doCallFunction(returnType, functionName);
    }
}