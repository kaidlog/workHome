package com.esb.core.dao;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.EmptySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.esb.core.utils.CIFMaskUtils;

/**
 * General SimpleJdbcCall Data Access Object for all procedure/function call.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Repository
public class GeneralSimpleJdbcCallDAO {
    /** logger */
    private static Log logger = LogFactory.getLog(GeneralSimpleJdbcCallDAO.class);

    /** SimpleJdbcCall Pool */
    private ConcurrentHashMap<String, SimpleJdbcCall> simpleJdbcCallPool = new ConcurrentHashMap<String, SimpleJdbcCall>();

    /** Data source */
    @Autowired
    private DataSource dataSource;

    // 1. Stored procedure -----------------------------------------------------------------------------------------
    /**
     * Execute the Stored procedure with package and parameters, specify the name of the catalog that contains the stored procedure.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param catalogName the catalog or package name
     * @param procedureName the name of the stored procedure
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return a Map of output params
     */
    public Map<String, Object> doCallProcedure(String catalogName, String procedureName, SqlParameterSource parameterSource) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("catalogName", catalogName);
            logParams.put("procedureName", procedureName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.info(logParams);
        }

        String name = StringUtils.defaultString(catalogName) + "." + procedureName;

        SimpleJdbcCall simpleJdbcCall = simpleJdbcCallPool.computeIfAbsent(name, (key) -> {
            return new SimpleJdbcCall(dataSource).withCatalogName(catalogName)
                    .withProcedureName(procedureName);
        });

        return simpleJdbcCall.execute(parameterSource);
    }

    /**
     * Execute the Stored procedure with package and without parameters, specify the name of the catalog that contains the stored procedure.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param catalogName the catalog or package name
     * @param procedureName the name of the stored procedure
     * @return a Map of output params
     */
    public Map<String, Object> doCallProcedure(String catalogName, String procedureName) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("catalogName", catalogName);
            logParams.put("procedureName", procedureName);

            logger.info(logParams);
        }

        return doCallProcedure(catalogName, procedureName, EmptySqlParameterSource.INSTANCE);
    }

    /**
     * Execute the Stored procedure with parameters
     * @param procedureName the name of the stored procedure
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return a Map of output params
     */
    public Map<String, Object> doCallProcedure(String procedureName, SqlParameterSource parameterSource) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("procedureName", procedureName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.info(logParams);
        }

        return doCallProcedure("", procedureName, parameterSource);
    }

    /**
     * Execute the Stored procedure without parameters
     * @param procedureName the name of the stored procedure
     * @return a Map of output params
     */
    public Map<String, Object> doCallProcedure(String procedureName) {
        if (logger.isInfoEnabled()) {
            logger.info(new JSONObject().fluentPut("procedureName", procedureName));
        }

        return doCallProcedure("", procedureName, EmptySqlParameterSource.INSTANCE);
    }

    // 2. Stored function ------------------------------------------------------------------------------------------
    /**
     * Execute the Stored function with package and parameters, specify the name of the catalog that contains the stored function.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param returnType the type of the value to return
     * @param catalogName the catalog or package name
     * @param functionName the name of the stored function
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return T
     */
    public <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName, SqlParameterSource parameterSource) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("catalogName", catalogName);
            logParams.put("functionName", functionName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.info(logParams);
        }

        String name = StringUtils.defaultString(catalogName) + "." + functionName;

        SimpleJdbcCall simpleJdbcCall = simpleJdbcCallPool.computeIfAbsent(name, (key) -> {
            return new SimpleJdbcCall(dataSource).withCatalogName(catalogName)
                    .withFunctionName(functionName);
        });

        return simpleJdbcCall.executeFunction(returnType, parameterSource);
    }

    /**
     * Execute the Stored function with package and without parameters, specify the name of the catalog that contains the stored function.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param returnType the type of the value to return
     * @param catalogName the catalog or package name
     * @param functionName the name of the stored function
     * @return T
     */
    public <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("catalogName", catalogName);
            logParams.put("functionName", functionName);

            logger.info(logParams);
        }

        return doCallFunction(returnType, catalogName, functionName, EmptySqlParameterSource.INSTANCE);
    }

    /**
     * Execute the Stored function with parameters
     * @param returnType the type of the value to return
     * @param functionName the name of the stored function
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return T
     */
    public <T> T doCallFunction(Class<T> returnType, String functionName, SqlParameterSource parameterSource) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("functionName", functionName);

            Arrays.stream(Optional.ofNullable(parameterSource.getParameterNames()).orElse(
                    new String[] {})).filter(row -> {
                        return parameterSource.getValue(row) != null;
                    }).forEach(row -> {
                        logParams.put(row, CIFMaskUtils.doMaskOthers(parameterSource.getValue(row).toString()));
                    });

            logger.info(logParams);
        }

        return doCallFunction(returnType, "", functionName, parameterSource);
    }

    /**
     * Execute the Stored function without parameters
     * @param returnType the type of the value to return
     * @param functionName the name of the stored function
     * @return T
     */
    public <T> T doCallFunction(Class<T> returnType, String functionName) {
        if (logger.isInfoEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("returnType", returnType.getName());
            logParams.put("functionName", functionName);

            logger.info(logParams);
        }

        return doCallFunction(returnType, "", functionName, EmptySqlParameterSource.INSTANCE);
    }
}