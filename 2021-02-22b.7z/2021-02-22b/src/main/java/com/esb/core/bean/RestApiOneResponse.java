package com.esb.core.bean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Restful API Response Entity.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 * @param <T>
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RestApiOneResponse<T> extends BaseRestApiResponse {
    /** 請求處理結果 */
    @ApiModelProperty(value = "請求處理結果", position = 100)
    private T body;
}