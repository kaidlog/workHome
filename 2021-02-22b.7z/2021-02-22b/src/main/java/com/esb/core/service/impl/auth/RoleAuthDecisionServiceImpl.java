package com.esb.core.service.impl.auth;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Service;

import com.esb.core.service.AbstractBaseService;
import com.esb.core.service.IAuthorizationDecisionService;

/**
 * 依操作者角色決定是否放行.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Order(2)
@Service("RoleAuthDecisionServiceImpl")
public class RoleAuthDecisionServiceImpl extends AbstractBaseService implements IAuthorizationDecisionService {
    /** logger */
    private static Log logger = LogFactory.getLog(RoleAuthDecisionServiceImpl.class);

    /**
     * 決定是否放行
     */
    @Override
    public boolean decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) {
        HttpServletRequest request = ((FilterInvocation) object).getRequest();

        // 組合查詢參數 ---------------------------------------------------------------------------------------------------
        List<String> roles = authentication.getAuthorities().stream().map(row -> {
            return row.getAuthority();
        }).collect(Collectors.toList());

        // 查詢是否通過角色授權 ----------------------------------------------------------------------------------------------
       /*
        KeycloakAuthenticationToken token = (KeycloakAuthenticationToken) request.getUserPrincipal();
        KeycloakPrincipal<?> principal = (KeycloakPrincipal<?>) token.getPrincipal();
        KeycloakSecurityContext session = principal.getKeycloakSecurityContext();
        AccessToken accessToken = session.getToken();

        System.out.println(accessToken.getPreferredUsername());
        System.out.println(accessToken.getEmail());
        System.out.println(accessToken.getFamilyName());
        System.out.println(accessToken.getGivenName());
        System.out.println(accessToken.getIssuer());

        System.out.println("LALA = " + ReflectionToStringBuilder.reflectionToString(authentication));
        */

        // TODO
        // return roles.contains("ROLE_00");
        return true;
    }
}