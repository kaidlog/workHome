package com.esb.core.constraints;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.esb.core.constraints.validator.DateFormatValidator;

/**
 * Base JSR-303 Validator.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Target({ElementType.FIELD, ElementType.METHOD })
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = {DateFormatValidator.class })
public @interface ValidDate {

    /**
     * Default error message
     * @return String
     * @remark
     */
    String message() default "Date format is invalid";

    /**
     * Default date format pattern
     * @return String
     * @remark
     */
    String pattern() default "yyyyMMdd";

    /**
     * Validation group
     * @return Class<?>[]
     * @remark
     */
    Class<?>[] groups() default {};

    /**
     * Payload
     * @return Class<? extends Payload>[]
     * @remark
     */
    Class<? extends Payload>[] payload() default {};
}