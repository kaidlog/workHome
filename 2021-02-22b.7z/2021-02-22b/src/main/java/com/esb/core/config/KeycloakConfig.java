package com.esb.core.config;
/*
import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
*/
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Keycloak Configuration.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
/*
@Configuration
*/
public class KeycloakConfig {

    /**
     * 配置Keycloak設定參數由Spring Boot設定參數檔中讀取
     * @return KeycloakSpringBootConfigResolver
     */
    /*
    @Bean
    public KeycloakSpringBootConfigResolver keycloakConfigResolver() {
        return new KeycloakSpringBootConfigResolver();
    }
    */
}