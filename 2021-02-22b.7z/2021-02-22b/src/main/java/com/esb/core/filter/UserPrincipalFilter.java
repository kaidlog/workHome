package com.esb.core.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.core.util.IOUtils;
import org.springframework.stereotype.Component;

import com.esb.core.misc.MultiReadHttpServletRequest;

/**
 * User Principal Filter，取得使用者基本資料後，存入Session供後續程式使用
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年5月22日
 * @remark
 */
@Component
public class UserPrincipalFilter extends AbstractBaseFilter {
    /** 登入者基本資料 */
    public static final String LOGIN_USER_PROFILE = "LOGIN_USER_PROFILE";
    /** 操作者基本資料 */
    public static final String OPT_USER_PROFILE = "OPT_USER_PROFILE";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        MultiReadHttpServletRequest multiReadRequest = new MultiReadHttpServletRequest((HttpServletRequest) request);
        try {
            @SuppressWarnings("unchecked")
            List<String> userDataSession = (List<String>) request.getSession().getAttribute("userProfile");

            String token = IOUtils.toString(multiReadRequest.getReader()).split("\"token\":\"")[1].split("\"")[0];
            // 如果 使用者要來打以下三支 api 則放行
            if ("/marathontrain/register/01".equals(multiReadRequest.getRequestURI())
                    || "/marathontrain/login/01".equals(multiReadRequest.getRequestURI())
                    || "/marathontrain/emailcheck/01".equals(multiReadRequest.getRequestURI())) {

                filterChain.doFilter(multiReadRequest, response);
            } else {
                // 如果使用者沒有帶著 token 前來請求 api 的話，我們就回傳 401
                if (!userDataSession.contains(token)) {
                    String replacedContent = "{\"status\":\"401\",\"spanId\":null,\"msg\":[],\"body\":[{\"ERROR\":\"ERROR\"}]}";
                    response.setStatus(401);
                    response.getWriter().write(replacedContent);
                } else {
                    // 如果有 token 的話
                    // 如果  session 是  false 就沒關係，但是如果有的話則銷毀
//                    HttpSession session = request.getSession(false);
//                    // 如果 session 不為空，或是 session 不為一個新的值，則把這個 session 銷毀
//                    if (session != null && !session.isNew()) {
//                        session.invalidate();
//                    }
//                    // 再重新 建立一個新的 session
//                    request.getSession(true); // create the session
//                    filterChain.doFilter(multiReadRequest, response);
//                    userDataSession = new ArrayList<>();
//                    userDataSession.add(token); 
//                    request.getSession().setAttribute("userProfile", userDataSession);
                    filterChain.doFilter(multiReadRequest, response);
                }
            }
        } catch (Exception e) {
            String replacedContent = "{\"status\":\"401\",\"spanId\":null,\"msg\":[],\"body\":[{\"ERROR\":\"ERROR\"}]}";
            response.setStatus(401);
            response.getWriter().write(replacedContent);
        }
    }
}