package com.esb.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import com.esb.core.dao.GeneralSimpleJdbcCallDAO;

import lombok.Getter;

/**
 * Base Business Services.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public abstract class AbstractBaseService {
    /** 運行環境 */
    @Getter
    @Value("${runtime.environment}")
    private String runtimeEnv;

    // ----------------------------------------------------------------------------
    /** Spring application context */
    @Getter
    @Autowired
    private ApplicationContext applicationContext;
    /** General SimpleJdbcCall Data access object service */
    @Getter
    @Autowired
    private GeneralSimpleJdbcCallDAO generalSimpleJdbcCallDAO;
}