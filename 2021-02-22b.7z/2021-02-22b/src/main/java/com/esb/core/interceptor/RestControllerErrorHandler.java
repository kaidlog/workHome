package com.esb.core.interceptor;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.esb.core.bean.BaseRestApiResponse;

import lombok.Getter;

/**
 * Restfual API Global Exception Handler.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@RestControllerAdvice
public class RestControllerErrorHandler {
    /** logger */
    private static Log logger = LogFactory.getLog(RestControllerErrorHandler.class);

    /** Default error message */
    @Getter
    @Value("${runtime.default-err-msg}")
    private String defaultErrMsg;

    /**
     * 統一處理未受處理的異常錯誤
     * @param e 異常訊息
     * @return BaseRestApiReponse 處理結果
     */
    @ExceptionHandler(Exception.class)
    public BaseRestApiResponse doHandleException(Exception e) {
        if (logger.isErrorEnabled()) {
            logger.error(e.getMessage(), e);
        }

        BaseRestApiResponse response = new BaseRestApiResponse();
        response.setStatus("500"); // 500: Internal Server Error
        response.setMsg(Arrays.asList(defaultErrMsg));

        return response;
    }

    /**
     * 處理欄位驗證失敗錯誤訊息，此method處理Client使用@RequestBody傳入的參數驗證
     * @param e 異常訊息
     * @return BaseRestApiReponse 處理結果
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public BaseRestApiResponse doHandleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        if (logger.isTraceEnabled()) {
            logger.trace(e.getMessage(), e);
        }

        BaseRestApiResponse response = new BaseRestApiResponse();
        response.setStatus("412"); // 412: Precondition Failed
        response.setMsg(e.getBindingResult().getAllErrors().stream().map(row -> {
            return row.getDefaultMessage();
        }).collect(Collectors.toList()));

        return response;
    }

    /**
     * 處理欄位驗證失敗錯誤訊息，此method處理Client非使用@RequestBody傳入的參數驗證
     * @param e 異常訊息
     * @return BaseRestApiReponse 處理結果
     */
    @ExceptionHandler(BindException.class)
    public BaseRestApiResponse doHandleBindException(BindException e) {
        if (logger.isTraceEnabled()) {
            logger.trace(e.getMessage(), e);
        }

        BaseRestApiResponse response = new BaseRestApiResponse();
        response.setStatus("412"); // 412: Precondition Failed
        response.setMsg(e.getAllErrors().stream().map(row -> {
            return row.getDefaultMessage();
        }).collect(Collectors.toList()));

        return response;
    }
}