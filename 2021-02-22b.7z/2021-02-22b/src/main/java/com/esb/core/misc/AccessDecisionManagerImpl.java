package com.esb.core.misc;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Component;

import com.esb.core.service.IAuthorizationDecisionService;

/**
 * 用於決定該角色可否存取此URI.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
@Component
public class AccessDecisionManagerImpl implements AccessDecisionManager {

    /** 是否忽略所有認證/授權檢查 */
    @Value("${security.ignore-all-security-check}")
    private boolean ignoreAllSecurityCheck;

    /** 授權服務清單 */
    @Autowired
    private List<IAuthorizationDecisionService> authorizationDecisionServices;

    @Override
    public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) {
        HttpServletRequest httpServletRequest = ((FilterInvocation) object).getRequest();
        String uri = httpServletRequest.getServletPath();

        // 設定直接放行所有的檢查 --------------------------------------------------------------------------------------------
        if (ignoreAllSecurityCheck) {
            return;
        }

        // 授權決策服務檢查 ------------------------------------------------------------------------------------------------
        Optional<IAuthorizationDecisionService> optional = authorizationDecisionServices.stream().filter(authorizationDecisionService -> {
            return authorizationDecisionService.decide(authentication, object, configAttributes);
        }).findFirst();

        if (optional.isPresent()) {
            return;
        }

        // -----------------------------------------------------------------------------------------------------------
        httpServletRequest.setAttribute("javax.servlet.error.status_code", HttpStatus.FORBIDDEN.value());
        throw new AccessDeniedException("Access Denied, The user can't access this URI " + uri);
    }

    @Override
    public boolean supports(ConfigAttribute attribute) {
        return true;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return true;
    }
}