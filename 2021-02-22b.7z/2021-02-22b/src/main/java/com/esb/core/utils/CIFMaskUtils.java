package com.esb.core.utils;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

/**
 * CIF 欄位Mask Util
 * @author 20718 Jason Chan by Esunbank
 */
public class CIFMaskUtils {
    // private static Log logger = LogFactory.getLog(CIFMaskUtils.class);

    /**
     * Default construct
     * @remark
     */
    private CIFMaskUtils() {
    }

    /**
     * 身份證字號/護照/居留證/統一證號隱碼處理
     * @param userId 身份證字號
     * @return String
     */
    public static String doMaskUserId(String userId) {
        if (StringUtils.isBlank(userId)) {
            return userId;
        }

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(userId, 0, 3));
        result.append("****");
        result.append(StringUtils.substring(userId, 7));

        return result.toString();
    }

    /**
     * 銀行帳號隱碼處理
     * @param bankAccount 銀行帳號
     * @return String
     */
    public static String doMaskBankAccount(String bankAccount) {
        if (StringUtils.isBlank(bankAccount)) {
            return bankAccount;
        }

        int size = bankAccount.length();

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(bankAccount, 0, 4));
        result.append(StringUtils.rightPad("*", (size - 8), "*"));
        result.append(StringUtils.substring(bankAccount, (size - 4)));

        return result.toString();
    }

    /**
     * 信用卡號隱碼處理
     * @param cardNo 信用卡號
     * @return String
     */
    public static String doMaskCreditCardNo(String cardNo) {
        return doMaskBankAccount(cardNo);
    }

    /**
     * 使用者姓名隱碼
     * @param userNm 使用者姓名
     * @return String
     */
    public static String doMaskUserName(String userNm) {
        if (StringUtils.isBlank(userNm)) {
            return userNm;
        }

        int size = userNm.length();

        StringBuilder result = new StringBuilder();
        if (size < 3) {
            result.append(StringUtils.substring(userNm, 0, 1));
            result.append("*");
        } else if (size == 3) {
            result.append(StringUtils.substring(userNm, 0, 1));
            result.append("*");
            result.append(StringUtils.substring(userNm, 2, 3));
        } else {
            result.append(StringUtils.substring(userNm, 0, 2));
            result.append(StringUtils.rightPad("*", (size - 3), "*"));
            result.append(StringUtils.substring(userNm, (size - 1)));
        }

        return result.toString();
    }

    /**
     * 生日隱碼處理
     * @param birthday 生日
     * @return String
     */
    public static String doMaskBirthday(Date birthday) {
        if (birthday == null) {
            return "";
        }

        String year = DateFormatUtils.format(birthday, "yyyy");
        String month = DateFormatUtils.format(birthday, "MM");
        String day = DateFormatUtils.format(birthday, "dd");

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(year, 0, 3)).append("*/");
        result.append(StringUtils.substring(month, 0, 1)).append("*/");
        result.append(StringUtils.substring(day, 0, 1)).append("*");

        return result.toString();
    }

    /**
     * 生日隱碼處理
     * @param birthday 生日
     * @return String
     * @throws ParseException
     */
    public static String doMaskBirthday(String birthday) throws ParseException {
        if (StringUtils.isBlank(birthday)) {
            return birthday;
        }

        String[] parsePatterns = new String[] {
                "yyyy/MM/dd HH:mm:ss",
                "yyyyMMdd HH:mm:ss",
                "yyyyMMddHHmmss",
                "yyyy/MM/dd",
                "yyyyMMdd"
        };

        return doMaskBirthday(DateUtils.parseDate(birthday, parsePatterns));
    }

    /**
     * 電話號碼隱碼處理
     * @param phoneNo
     * @return String
     */
    public static String doMaskPhoneNo(String phoneNo) {
        if (StringUtils.isBlank(phoneNo)) {
            return phoneNo;
        }

        int size = phoneNo.length();

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(phoneNo, 0, 3));
        result.append(StringUtils.rightPad("*", (size - 6), "*"));
        result.append(StringUtils.substring(phoneNo, (size - 3)));

        return result.toString();
    }

    /**
     * 行動電話號碼隱碼處理
     * @param mobileNo 行動電話號碼
     * @return String
     */
    public static String doMaskMobileNo(String mobileNo) {
        return doMaskPhoneNo(mobileNo);
    }

    /**
     * 地址隱碼處理
     * @param address 地址
     * @return String
     */
    public static String doMaskAddress(String address) {
        if (StringUtils.isBlank(address)) {
            return address;
        }

        int size = address.length();

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(address, 0, (size - 8)));
        result.append("********");

        return result.toString();
    }

    /**
     * 電子郵件信箱隱碼處理
     * @param email 電子郵件信箱
     * @return String
     */
    public static String doMaskEmail(String email) {
        if (StringUtils.isBlank(email)) {
            return email;
        }

        int size = email.length();
        String account = StringUtils.substring(email, 0, StringUtils.indexOf(email, "@"));

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(account, 0, (account.length() - 3))).append("***");
        result.append(StringUtils.substring(email, StringUtils.indexOf(email, "@"), size));

        return result.toString();
    }

    /**
     * 特徵、指紋、婚姻、家庭、教育程度、職業、病歷、醫療、基因、性生活、健康檢查、犯罪前科等其他欄位隱碼處理
     * @param data
     * @return String
     */
    public static String doMaskOthers(String data) {
        if (StringUtils.isBlank(data)) {
            return data;
        }

        int size = data.length();

        StringBuilder result = new StringBuilder();
        result.append(StringUtils.substring(data, 0, 1));
        result.append(StringUtils.rightPad("*", (size - 1), "*"));

        return result.toString();
    }
}