package com.esb.core.service;

import java.util.Map;

import org.springframework.jdbc.core.namedparam.SqlParameterSource;

/**
 * General SimpleJdbcCall Data Access Service for all procedure/function call.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月20日
 * @remark
 */
public interface IGeneralSimpleJdbcCallDaoService {

    // 1. Stored procedure -----------------------------------------------------------------------------------------
    /**
     * Execute the Stored procedure with package and parameters, specify the name of the catalog that contains the stored procedure.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param catalogName the catalog or package name
     * @param procedureName the name of the stored procedure
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return a Map of output params
     */
    Map<String, Object> doCallProcedure(String catalogName, String procedureName, SqlParameterSource parameterSource);

    /**
     * Execute the Stored procedure with package and without parameters, specify the name of the catalog that contains the stored procedure.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param catalogName the catalog or package name
     * @param procedureName the name of the stored procedure
     * @return a Map of output params
     */
    Map<String, Object> doCallProcedure(String catalogName, String procedureName);

    /**
     * Execute the Stored Procedure with parameters
     * @param procedureName the name of the stored procedure
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return a Map of output params
     */
    Map<String, Object> doCallProcedure(String procedureName, SqlParameterSource parameterSource);

    /**
     * Execute the Stored procedure without parameters
     * @param procedureName the name of the stored procedure
     * @return a Map of output params
     */
    Map<String, Object> doCallProcedure(String procedureName);

    // 2. Stored function ------------------------------------------------------------------------------------------
    /**
     * Execute the Stored function with package and parameters, specify the name of the catalog that contains the stored function.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param returnType the type of the value to return
     * @param catalogName the catalog or package name
     * @param functionName the name of the stored function
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return T
     */
    <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName, SqlParameterSource parameterSource);

    /**
     * Execute the Stored function with package and without parameters, specify the name of the catalog that contains the stored function.
     * <p>
     * To provide consistency with the Oracle DatabaseMetaData, this is used to specify the package name if the procedure is declared as part of a package.
     * @param returnType the type of the value to return
     * @param catalogName the catalog or package name
     * @param functionName the name of the stored function
     * @return T
     */
    <T> T doCallFunction(Class<T> returnType, String catalogName, String functionName);

    /**
     * Execute the Stored function with parameters
     * @param returnType the type of the value to return
     * @param functionName the name of the stored function
     * @param parameterSource the SqlParameterSource containing the parameter values to be used in the call
     * @return T
     */
    <T> T doCallFunction(Class<T> returnType, String functionName, SqlParameterSource parameterSource);

    /**
     * Execute the Stored function without parameters
     * @param returnType the type of the value to return
     * @param functionName the name of the stored function
     * @return T
     */
    <T> T doCallFunction(Class<T> returnType, String functionName);
}