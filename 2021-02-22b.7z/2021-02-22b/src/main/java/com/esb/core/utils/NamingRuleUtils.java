package com.esb.core.utils;

import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.text.WordUtils;

import com.alibaba.fastjson.JSONObject;

/**
 * Naming Rule Utility.
 *
 * @author 20718 Jason Chan by Esunbank
 */
public class NamingRuleUtils {
    /** logger */
    private static Log logger = LogFactory.getLog(NamingRuleUtils.class);

    /** Default construct */
    private NamingRuleUtils() {
    }

    /**
     * Transfer table's column name to Java filed name, ex. CARD_TYPE -> cardType、 USER_ID -> userId、 NAME -> name
     * @param name column
     * @return String field name
     */
    public static String convertColumnName2FieldName(String name) {
        if (logger.isTraceEnabled()) {
            JSONObject logParams = new JSONObject().fluentPut("name", name);
            logger.trace(logParams);
        }

        StringBuilder sb = new StringBuilder();

        String[] tokens = StringUtils.split(name, "_");
        if (tokens.length > 1 && tokens[0].length() == 1) {
            for (String token : tokens) {
                sb.append(WordUtils.capitalizeFully(token));
            }
            return sb.toString();
        }

        StringTokenizer parser = new StringTokenizer(name, "_");
        boolean isFirst = true;
        while (parser.hasMoreTokens()) {
            String s = parser.nextToken().toLowerCase();
            if (isFirst) {
                sb.append(s);
                isFirst = false;
            } else {
                char c = Character.toUpperCase(s.charAt(0));
                sb.append(c);
                sb.append(s.substring(1, s.length()));
            }
        }

        return sb.toString();
    }
}