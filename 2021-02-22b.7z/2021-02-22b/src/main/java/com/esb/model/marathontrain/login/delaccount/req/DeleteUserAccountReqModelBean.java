package com.esb.model.marathontrain.login.delaccount.req;
import java.io.Serializable;
//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DeleteUserAccountReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** User ID */
    @ApiModelProperty(value = "UserID", allowEmptyValue = false, required = true, position = 1)
    private String uuid;
    /** suspendOrNot */
    @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
    private String suspendOrNot;
    /** userPassword */
    @ApiModelProperty(value = "userPassword", allowEmptyValue = true, required = false)
    private String userPassword;
}
