package com.esb.model.marathontrain.login.auth.req;

import java.io.Serializable;

//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AuthReqModelBean implements Serializable{

    /** */
    private static final long serialVersionUID = 1L;
    /** token */
    @ApiModelProperty(value = "token", allowEmptyValue = true, required = false)
    private String token;
//    /** timeout */
//    @ApiModelProperty(value = "timeout", allowEmptyValue = true, required = false)
//    private String timeout;

}
