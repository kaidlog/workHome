package com.esb.model.marathontrain.runningactivity.addrunningactivity.req;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AddRunningActivityReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** RunningActivity ID */
    @ApiModelProperty(value = "跑步活動紀錄ID", allowEmptyValue = false, required = true, position = 1)
    private String runningActivityId;
    /** PacePerKm */
    @ApiModelProperty(value = "PacePerKm", allowEmptyValue = true, required = false)
    private Number pacePerKm;
    /** Distance */
    @ApiModelProperty(value = "Distance", allowEmptyValue = true, required = false)
    private Number distance;
    /** Calories */
    @ApiModelProperty(value = "Calories", allowEmptyValue = true, required = false)
    private Number calories;
    /** HeartRate */
    @ApiModelProperty(value = "HeartRate", allowEmptyValue = true, required = false)
    private Number heartRate;
    /** ElevationVariation */
    @ApiModelProperty(value = "ElevationVariation", allowEmptyValue = true, required = false)
    private Number elevationVariation;
    /** Creator */
    @ApiModelProperty(value = "Creator", allowEmptyValue = true, required = false)
    private String creator;
    /** Updater */
    @ApiModelProperty(value = "Updater", allowEmptyValue = true, required = false)
    private String updater;
    /** goalId */
    @ApiModelProperty(value = "goalId", allowEmptyValue = true, required = false)
    private String goalId;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
}
