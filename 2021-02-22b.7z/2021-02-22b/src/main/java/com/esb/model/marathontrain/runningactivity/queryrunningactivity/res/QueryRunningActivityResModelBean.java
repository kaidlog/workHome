package com.esb.model.marathontrain.runningactivity.queryrunningactivity.res;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.esb.core.bean.model.AbstractBasePaggingResModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 跑步紀錄查詢Response Model Bean.
 * @author 21637 Kevin Cheng by Esunbank
 * @date 2021年1月11日
 * @remark
 */

@Data
@EqualsAndHashCode(callSuper = true)
 public class QueryRunningActivityResModelBean extends AbstractBasePaggingResModelBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 一頁查詢結果 */
    @ApiModelProperty(value = "一頁查詢結果", allowEmptyValue = true, required = false)
    private List<RecordListResModelBean> data = new ArrayList<RecordListResModelBean>();
}