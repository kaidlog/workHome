package com.esb.model.marathontrain.usermanage.req;

import java.io.Serializable;

import com.esb.core.bean.model.AbstractBasePaggingReqModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** 查詢目標是否存在 */

@Data
@EqualsAndHashCode(callSuper = true)
public class QueryHistoryUserReqModelBean extends AbstractBasePaggingReqModelBean implements Serializable {
    /**
     * first try for pagination
     */
    private static final long serialVersionUID = 1L;
    /** suspendOrNot */
    @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
    private String suspendOrNot;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
}