package com.esb.model.marathontrain.runningactivity.qryavgdata.res;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.esb.core.bean.model.AbstractBasePaggingResModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * 跑步紀錄查詢Response Model Bean.
 * @author 21637 Kevin Cheng by Esunbank
 * @date 2021年1月11日
 * @remark
 */

@Data
@EqualsAndHashCode(callSuper = true)
 public class QryAvgDataResModelBean extends AbstractBasePaggingResModelBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 一頁查詢結果 */
    @ApiModelProperty(value = "一頁所有距離模型", allowEmptyValue = true, required = false)
    private List<RecordListResModelBean> oData = new ArrayList<RecordListResModelBean>();
}