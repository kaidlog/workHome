package com.esb.model.marathontrain.runningactivity.queryrunningactivitydistance.res;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.esb.core.bean.model.AbstractBasePaggingResModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 交換機通話紀錄 Response Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年8月7日
 * @remark
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class QueryRunningActivityDistanceResModelBean extends AbstractBasePaggingResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 一頁查詢結果 */
    @ApiModelProperty(value = "一頁查詢結果", allowEmptyValue = true, required = false)
    private List<RecordListResModelBean> data = new ArrayList<RecordListResModelBean>();
}