package com.esb.model.marathontrain.runningactivity.qrydiagram.res;
import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RecordCaloriesListResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** creDateTime */
    @ApiModelProperty(value = "creDateTime", allowEmptyValue = true, required = false)
    private String creDateTime;
    /** calories */
    @ApiModelProperty(value = "calories", allowEmptyValue = true, required = false)
    private String calories;

}


