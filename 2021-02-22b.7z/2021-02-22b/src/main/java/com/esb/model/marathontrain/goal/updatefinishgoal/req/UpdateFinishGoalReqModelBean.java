package com.esb.model.marathontrain.goal.updatefinishgoal.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UpdateFinishGoalReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** Goal ID */
    @ApiModelProperty(value = "目標紀錄ID", allowEmptyValue = false, required = true, position = 1)
    private String goalId;
    /** UUID */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** IS_VALID */
    @ApiModelProperty(value = "isValid", allowEmptyValue = true, required = false)
    private String isValid;
}