package com.esb.model.marathontrain.runningactivity.qrydiagram.res;

import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RecordPacePerKmListResModelBean implements Serializable {
    /** creDateTime */
    @ApiModelProperty(value = "creDateTime", allowEmptyValue = true, required = false)
    private String creDateTime;
    private static final long serialVersionUID = 1L;
    /** pacePerKm */
    @ApiModelProperty(value = "pacePerKm", allowEmptyValue = true, required = false)
    private String pacePerKm;
}

