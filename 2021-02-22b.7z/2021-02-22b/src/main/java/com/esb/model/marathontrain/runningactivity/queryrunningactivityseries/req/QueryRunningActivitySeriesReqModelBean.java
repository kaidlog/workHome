package com.esb.model.marathontrain.runningactivity.queryrunningactivityseries.req;
import java.io.Serializable;

import com.esb.core.bean.model.AbstractBasePaggingReqModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
@EqualsAndHashCode(callSuper = true)
public class QueryRunningActivitySeriesReqModelBean extends AbstractBasePaggingReqModelBean  implements Serializable {
    /**
     * 123
     */
    private static final long serialVersionUID = 1L;
    /** startDate */
    @ApiModelProperty(value = "startDate", allowEmptyValue = true, required = false)
    private String startDate;
    /** endDate */
    @ApiModelProperty(value = "endDate", allowEmptyValue = true, required = false)
    private String endDate;
    /** Is_Valid */
    @ApiModelProperty(value = "Is_Valid", allowEmptyValue = true, required = false)
    private String isValid;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** goalId */
    @ApiModelProperty(value = "goalId", allowEmptyValue = true, required = false)
    private String goalId;
}