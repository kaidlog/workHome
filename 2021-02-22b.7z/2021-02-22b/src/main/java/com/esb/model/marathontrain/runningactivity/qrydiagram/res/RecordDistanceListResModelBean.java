package com.esb.model.marathontrain.runningactivity.qrydiagram.res;

import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RecordDistanceListResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** upper42 */
    @ApiModelProperty(value = "upper42", allowEmptyValue = true, required = false)
    private String upper42;
    /** upper42 */
    @ApiModelProperty(value = "between21And42", allowEmptyValue = true, required = false)
    private String between21And42;
    /** upper42 */
    @ApiModelProperty(value = "between15And21", allowEmptyValue = true, required = false)
    private String between15And21;
    /** upper42 */
    @ApiModelProperty(value = "between10And15", allowEmptyValue = true, required = false)
    private String between10And15;
    /** upper42 */
    @ApiModelProperty(value = "between4And10", allowEmptyValue = true, required = false)
    private String between4And10;
    /** upper42 */
    @ApiModelProperty(value = "lower4", allowEmptyValue = true, required = false)
    private String lower4;
}
