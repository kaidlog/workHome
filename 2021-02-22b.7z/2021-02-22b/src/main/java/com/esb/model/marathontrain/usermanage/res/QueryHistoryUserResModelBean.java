package com.esb.model.marathontrain.usermanage.res;

import java.io.Serializable;

import com.esb.core.bean.model.AbstractBasePaggingResModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class QueryHistoryUserResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** suspendOrNot */
    @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
    private String suspendOrNot;
    /** Cre_Date_Time */
    @ApiModelProperty(value = "Cre_Date_Time", allowEmptyValue = true, required = false)
    private String creDateTime;
    /** Upd_Date_Time */
    @ApiModelProperty(value = "Upd_Date_Time", allowEmptyValue = true, required = false)
    private String updDateTime;
    /** addr */
    @ApiModelProperty(value = "addr", allowEmptyValue = true, required = false)
    private String addr;
    /** handphone */
    @ApiModelProperty(value = "handphone", allowEmptyValue = true, required = false)
    private String handphone;
    /** firstname */
    @ApiModelProperty(value = "firstname", allowEmptyValue = true, required = false)
    private String firstname;
    /** lastname */
    @ApiModelProperty(value = "lastname", allowEmptyValue = true, required = false)
    private String lastname;
    /** gender */
    @ApiModelProperty(value = "gender", allowEmptyValue = true, required = false)
    private String gender;
    /** birthday */
    @ApiModelProperty(value = "birthday", allowEmptyValue = true, required = false)
    private String birthday;
    /** height */
    @ApiModelProperty(value = "height", allowEmptyValue = true, required = false)
    private Number height;
    /** weight */
    @ApiModelProperty(value = "weight", allowEmptyValue = true, required = false)
    private Number weight;
    /** email */
    @ApiModelProperty(value = "email", allowEmptyValue = true, required = false)
    private String email;
}
