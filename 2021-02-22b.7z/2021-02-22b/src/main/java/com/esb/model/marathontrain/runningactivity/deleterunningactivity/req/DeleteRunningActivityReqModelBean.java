package com.esb.model.marathontrain.runningactivity.deleterunningactivity.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Data
public class DeleteRunningActivityReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;
    /** RunningActivity ID */
    @ApiModelProperty(value = "跑步活動紀錄ID", allowEmptyValue = false, required = true, position = 1)
    private String runningActivityId;
    /** UUID */
    @ApiModelProperty(value = "uuid", allowEmptyValue = false, required = true, position = 1)
    private String uuid;
    /** goalId */
    @ApiModelProperty(value = "goalId", allowEmptyValue = false, required = true, position = 1)
    private String goalId;
}