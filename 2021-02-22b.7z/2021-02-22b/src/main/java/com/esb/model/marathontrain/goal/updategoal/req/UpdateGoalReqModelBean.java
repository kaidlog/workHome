package com.esb.model.marathontrain.goal.updategoal.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 更新目標的 modelBean
 */
/** 不需要這支 */

@Data
public class UpdateGoalReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    /** Goal ID */
    @ApiModelProperty(value = "目標紀錄ID", allowEmptyValue = false, required = true)
    private String goalId;
    /** idealPacePerKm */
    @ApiModelProperty(value = "idealPacePerKm", allowEmptyValue = true, required = false)
    private String idealPacePerKm;
    /** idealDistance */
    @ApiModelProperty(value = "idealDistance", allowEmptyValue = true, required = false)
    private String idealDistance;
    /** setPeriod */
    @ApiModelProperty(value = "setPeriod", allowEmptyValue = true, required = false)
    private String setPeriod;
    /** Updater */
    @ApiModelProperty(value = "updater", allowEmptyValue = true, required = false)
    private String updater;
    /** setPeriod */
    @ApiModelProperty(value = "updDateTime", allowEmptyValue = true, required = false)
    private String updDateTime;
}