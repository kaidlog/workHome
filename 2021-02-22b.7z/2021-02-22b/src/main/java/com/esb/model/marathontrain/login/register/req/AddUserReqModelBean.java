package com.esb.model.marathontrain.login.register.req;

import java.io.Serializable;

//import javax.validation.constraints.NotBlank;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AddUserReqModelBean implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
  /** User ID */
  @ApiModelProperty(value = "UserID", allowEmptyValue = false, required = true, position = 1)
  private String uuid;
  /** RunningActivity ID */
  @ApiModelProperty(value = "creDateTime", allowEmptyValue = false, required = true, position = 1)
  private String creDateTime;
  /** updDateTime */
  @ApiModelProperty(value = "updDateTime", allowEmptyValue = true, required = false)
  private String updDateTime;
  /** suspendOrNot */
  @ApiModelProperty(value = "suspendOrNot", allowEmptyValue = true, required = false)
  private String suspendOrNot;
  /** addr */
  @ApiModelProperty(value = "addr", allowEmptyValue = true, required = false)
  private String addr;
  /** hand phone */
  @ApiModelProperty(value = "handphone", allowEmptyValue = true, required = false)
  private String handphone;
  /** first name */
  @ApiModelProperty(value = "firstname", allowEmptyValue = true, required = false)
  private String firstname;
  /** last name */
  @ApiModelProperty(value = "lastname", allowEmptyValue = true, required = false)
  private String lastname;
  /** gender */
  @ApiModelProperty(value = "gender", allowEmptyValue = true, required = false)
  private String gender;
  /** birthday */
  @ApiModelProperty(value = "birthday", allowEmptyValue = true, required = false)
  private String birthday;
  /** height */
  @ApiModelProperty(value = "height", allowEmptyValue = true, required = false)
  private Number height;
  /** user_password */
  @ApiModelProperty(value = "user_password", allowEmptyValue = true, required = false)
  private String userPassword;
  /** creator */
  @ApiModelProperty(value = "creator", allowEmptyValue = true, required = false)
  private String creator;
  /** updater */
  @ApiModelProperty(value = "updater", allowEmptyValue = true, required = false)
  private String updater;
  /** idNumber */
  @ApiModelProperty(value = "idNumber", allowEmptyValue = true, required = false)
  private String idNumber;
  /** email */
  @ApiModelProperty(value = "email", allowEmptyValue = true, required = false)
  private String email;
  /** expireTime */
  @ApiModelProperty(value = "weight", allowEmptyValue = true, required = false)
  private Number weight;
}
