package com.esb.model.marathontrain.runningactivity.qryavgdata.req;

import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class QryAvgDataReqModelBean implements Serializable{
    private static final long serialVersionUID = 1L;

    /** Is_Valid */
    @ApiModelProperty(value = "Is_Valid", allowEmptyValue = true, required = false)
    private String isValid;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** goalId */
    @ApiModelProperty(value = "goalId", allowEmptyValue = true, required = false)
    private String goalId;
    /** creDateTime */
    @ApiModelProperty(value = "creDateTime", allowEmptyValue = true, required = false)
    private String creDateTime;
}
