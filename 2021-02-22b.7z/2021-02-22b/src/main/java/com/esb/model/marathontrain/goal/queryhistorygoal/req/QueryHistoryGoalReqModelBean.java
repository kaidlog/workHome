package com.esb.model.marathontrain.goal.queryhistorygoal.req;

import java.io.Serializable;

import com.esb.core.bean.model.AbstractBasePaggingReqModelBean;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** 查詢目標是否存在 */

@Data
@EqualsAndHashCode(callSuper = true)
public class QueryHistoryGoalReqModelBean extends AbstractBasePaggingReqModelBean implements Serializable {
    /**
     * first try for pagination
     */
    private static final long serialVersionUID = 1L;
    /** isValid */
    @ApiModelProperty(value = "idValid", allowEmptyValue = true, required = false)
    private String isValid;
    /** uuid */
    @ApiModelProperty(value = "uuid", allowEmptyValue = true, required = false)
    private String uuid;
    /** idealDistanceBeg */
    @ApiModelProperty(value = "idealDistanceBeg", allowEmptyValue = true, required = false)
    private Number idealDistanceBeg;
    /** idealDistanceEnd */
    @ApiModelProperty(value = "idealDistanceEnd", allowEmptyValue = true, required = false)
    private Number idealDistanceEnd;
    /** idealPacePerKmBeg */
    @ApiModelProperty(value = "idealPacePerKmBeg", allowEmptyValue = true, required = false)
    private Number idealPacePerKmBeg;
    /** idealPacePerKmEnd */
    @ApiModelProperty(value = "idealPacePerKmEnd", allowEmptyValue = true, required = false)
    private Number idealPacePerKmEnd;
    /** setPeriod */
    @ApiModelProperty(value = "setPeriod", allowEmptyValue = true, required = false)
    private String setPeriod;
    /** difficulty */
    @ApiModelProperty(value = "difficulty", allowEmptyValue = true, required = false)
    private String difficulty;
    /** startDate */
    @ApiModelProperty(value = "startDate", allowEmptyValue = true, required = false)
    private String startDate;
    /** endDate */
    @ApiModelProperty(value = "endDate", allowEmptyValue = true, required = false)
    private String endDate;
}