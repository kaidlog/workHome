package com.esuncard.rbacw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.esb.marathontrain.ApplicationContext;

/**
 * Spring boot Unit Test.
 * @author 20718 Jason Chan by Esunbank
 * @date 2020年4月21日
 * @remark
 */
@SpringBootTest(classes = ApplicationContext.class)
//@SpringBootTest
class ApplicationTests {

    /**
     * Unit test entry point
     * @remark
     */
    @Test
    void contextLoads() {
    }
}