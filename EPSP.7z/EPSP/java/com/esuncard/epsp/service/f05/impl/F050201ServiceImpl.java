package com.esuncard.epsp.service.f05.impl;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.utils.ApDateUtils;
import com.esuncard.core.utils.CIFMaskUtils;
import com.esuncard.core.utils.SimpleJdbcCallUtils;
import com.esuncard.epsp.service.AbstractBaseApService;
import com.esuncard.epsp.service.f05.F050201Service;
import com.esuncard.model.epsp.f05.f05020101.req.F05020101ReqModelBean;
import com.esuncard.model.epsp.f05.f05020101.res.F05020101ResModelBean;
import com.esuncard.model.epsp.f05.f05020101.res.RecordListResModelBean;

/**
 * 交換機通話紀錄 Service
 * @author ESB20447 by Esunbank
 * @date 2020年9月9日
 * @remark
 */
@Service
@Transactional
public class F050201ServiceImpl extends AbstractBaseApService implements F050201Service {
    /** logger */
    private static Log logger = LogFactory.getLog(F050201ServiceImpl.class);

    @Override
    @Transactional(readOnly = true)
    public F05020101ResModelBean qryCDRRecordList(F05020101ReqModelBean model) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("model.callType", model.getCallType());
            logParams.put("model.startDate", model.getStartDate());
            logParams.put("model.endDate", model.getEndDate());
            logParams.put("model.callingName", CIFMaskUtils.doMaskUserName(model.getCallingName()));
            logParams.put("model.callingCode", CIFMaskUtils.doMaskUserId(model.getCallingCode()));
            logParams.put("model.callingNumber", CIFMaskUtils.doMaskPhoneNo(model.getCallingNumber()));
            logParams.put("model.calledName", CIFMaskUtils.doMaskUserName(model.getCalledName()));
            logParams.put("model.calledCode", CIFMaskUtils.doMaskUserId(model.getCalledCode()));
            logParams.put("model.calledNumber", CIFMaskUtils.doMaskPhoneNo(model.getCalledNumber()));
            logParams.put("model.pageNo", model.getPageNo());
            logParams.put("model.pageSize", model.getPageSize());

            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_CALL_TYPE", model.getCallType())
                .addValue("I_START_DATE", ApDateUtils.doCleanDateFormat(model.getStartDate()))
                .addValue("I_END_DATE", ApDateUtils.doCleanDateFormat(model.getEndDate()))
                .addValue("I_CALLING_NAME", model.getCallingName())
                .addValue("I_CALLING_CODE", model.getCallingCode())
                .addValue("I_CALLING_NUMBER", model.getCallingNumber())
                .addValue("I_CALLED_NAME", model.getCalledName())
                .addValue("I_CALLED_CODE", model.getCalledCode())
                .addValue("I_CALLED_NUMBER", model.getCalledNumber())
                .addValue("I_PAGE_NO", model.getPageNo())
                .addValue("I_PAGE_SIZE", model.getPageSize());

        // 2. 依據查詢條件，呼叫DB Procedure，取得代碼明細清單資料 ------------------------------------------------------------------
        Map<String, Object> result = getGeneralSimpleJdbcCallDAO().doCallProcedure(
                "PG_F050201",
                "SP_QRY_CDR_DTL_LIST", // 交換機清單查詢
                parameterSource);

        // 3. 組合查詢結果 ------------------------------------------------------------------------------------------------
        // 受話號碼來源 Z1: 個人分機, Z2: 撥號群組, Z3: 單位簡碼, Z4: 自訂通訊錄, S: 手動撥號
        List<String> callSrcfield = Arrays.asList("Z1", "Z2", "Z3", "Z4", "S");
        List<RecordListResModelBean> recordCdrList = SimpleJdbcCallUtils.convertMapList2BeanList((List<?>) result.get("O_DATA"), RecordListResModelBean.class);

        recordCdrList.stream().forEach(row -> {
            String calledId = callSrcfield.contains(row.getCalledNumbersrcfield()) ? row.getCalledId() : CIFMaskUtils.doMaskUserId(row.getCalledId());
            row.setCalledId(StringUtils.defaultString(calledId));
        });

        F05020101ResModelBean recordList = new F05020101ResModelBean();
        recordList.setData(recordCdrList);
        recordList.setTotalCount((BigDecimal) result.get("O_TOTAL"));
        recordList.setPageNo((BigDecimal) result.get("O_PAGE_NO"));

        return recordList;
    }
}