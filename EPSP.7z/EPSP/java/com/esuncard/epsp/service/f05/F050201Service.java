package com.esuncard.epsp.service.f05;

import com.esuncard.model.epsp.f05.f05020101.req.F05020101ReqModelBean;
import com.esuncard.model.epsp.f05.f05020101.res.F05020101ResModelBean;

/**
 * 交換機通話紀錄 Service
 * @author ESB20447 by Esunbank
 * @date 2020年8月27日
 * @remark
 */
public interface F050201Service {
    /**
     * 交換機通話紀錄查詢
     * @param model 查詢交換機參數
     * @return F05020101ResModelBean 查詢結果
     * @remark
     */
    F05020101ResModelBean qryCDRRecordList(F05020101ReqModelBean model);
}