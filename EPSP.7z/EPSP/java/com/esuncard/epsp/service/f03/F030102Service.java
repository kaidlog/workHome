package com.esuncard.epsp.service.f03;

import java.math.BigDecimal;
import com.esuncard.core.bean.UserProfile;
import com.esuncard.model.epsp.f03.f03010201.req.F03010201ReqModelBean;
import com.esuncard.model.epsp.f03.f03010201.res.F03010201ResModelBean;
import com.esuncard.model.epsp.f03.f03010202.req.F03010202ReqModelBean;
import com.esuncard.model.epsp.f03.f03010203.req.F03010203ReqModelBean;
import com.esuncard.model.epsp.f03.f03010204.req.F03010204ReqModelBean;
import com.esuncard.model.epsp.f03.f03010205.req.F03010205ReqModelBean;

/**
 * 個人備忘錄存取 Service
 * @author ESB20447 by Esunbank
 * @date 2020年7月17日
 * @remark
 */
public interface F030102Service {
    /**
     * 查詢單筆個人/週期備忘錄
     * @param model 查詢參數
     * @param userProfile 使用者資訊
     * @return F03010201ResModelBean 查詢結果
     * @remark
     */
    F03010201ResModelBean qryMemo(F03010201ReqModelBean model, UserProfile userProfile);

    /**
     * 更新個人備忘錄
     * @param model 更新個人備忘錄參數
     * @param userProfile 使用者資訊
     * @return BigDecimal 更新結果
     * @remark
     */
    BigDecimal updMemo(F03010202ReqModelBean model, UserProfile userProfile);

    /**
     * 更新個人備忘錄狀態
     * @param model 更新個人備忘錄參數
     * @param userProfile 使用者資訊
     * @return BigDecimal 更新結果
     * @remark
     */
    BigDecimal updMemoStatus(F03010203ReqModelBean model, UserProfile userProfile);

    /**
     * 更新週期備忘錄
     * @param model 更新週期備忘錄參數
     * @param userProfile 使用者資訊
     * @return BigDecimal 更新結果
     * @remark
     */
    BigDecimal updCycleMemo(F03010204ReqModelBean model, UserProfile userProfile);

    /**
     * 刪除週期備忘錄
     * @param model 週期備忘錄參數
     * @param userProfile 使用者資訊
     * @return BigDecimal 移除結果
     * @remark
     */
    BigDecimal delCycleMemo(F03010205ReqModelBean model, UserProfile userProfile);
}