package com.esuncard.epsp.service.f03.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.UserProfile;
import com.esuncard.core.utils.ApDateUtils;
import com.esuncard.core.utils.DecimalUtils;
import com.esuncard.core.utils.SimpleJdbcCallUtils;
import com.esuncard.epsp.service.AbstractBaseApService;
import com.esuncard.epsp.service.f02.F020103Service;
import com.esuncard.epsp.service.f03.F030102Service;
import com.esuncard.model.epsp.f03.f03010201.req.F03010201ReqModelBean;
import com.esuncard.model.epsp.f03.f03010201.res.F03010201ResModelBean;
import com.esuncard.model.epsp.f03.f03010202.req.F03010202ReqModelBean;
import com.esuncard.model.epsp.f03.f03010203.req.F03010203ReqModelBean;
import com.esuncard.model.epsp.f03.f03010204.req.F03010204ReqModelBean;
import com.esuncard.model.epsp.f03.f03010205.req.F03010205ReqModelBean;

/**
 * 個人備忘錄存取 Service
 * @author ESB20447 by Esunbank
 * @date 2020年7月17日
 * @remark
 */
@Service
@Transactional
public class F030102ServiceImpl extends AbstractBaseApService implements F030102Service {
    /** logger */
    private static Log logger = LogFactory.getLog(F030102ServiceImpl.class);

    /** 通知訊息轉入個人備忘錄 Service */
    @Autowired
    private F020103Service f020103service;

    @Override
    @Transactional(readOnly = true)
    public F03010201ResModelBean qryMemo(F03010201ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Function參數 ------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        // 2. 呼叫DB Function，查詢單筆個人備忘錄清單 --------------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_F030102",
                "FN_QRY_MEMO", // 取得單筆個人/週期備忘錄
                parameterSource);

        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, F03010201ResModelBean.class).stream().findFirst().orElse(null);
    }

    @Override
    public BigDecimal updMemo(F03010202ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 更新個人備忘錄管理 -------------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_START_DATE", ApDateUtils.doCleanDateFormat(model.getStartDate()))
                .addValue("I_END_DATE", ApDateUtils.doCleanDateFormat(model.getEndDate()))
                .addValue("I_OVERDUE_DAY", DecimalUtils.defaultDecimal(model.getOverdueDay()))
                .addValue("I_MEMO_LEVEL", model.getMemoLevel())
                .addValue("I_MEMO_TITLE", model.getMemoTitle())
                .addValue("I_MEMO_CONTENT", model.getMemoContent())
                .addValue("I_URL", model.getUrl())
                .addValue("I_CONTENT_STATUS", model.getContentStatus())
                .addValue("I_MEMO_CYCLE", model.getMemoCycle())
                .addValue("I_WEEK_DAY", model.getWeekDay())
                .addValue("I_MONTH_DAY", model.getMonthDay())
                .addValue("I_YEAR_DAY", model.getYearDay())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_UPD_MEMO", // 更新個人備忘錄
                parameterSource);

        // 2. 更新個人備忘錄明細 -------------------------------------------------------------------------------------------
        parameterSource = new MapSqlParameterSource()
                .addValue("I_UPDATER", userProfile.getAdAccount())
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_MEMO_NO", model.getMemoNo())
                .addValue("I_MEMO_STATUS", model.getMemoStatus())
                .addValue("I_OVERDUE_DATE", ApDateUtils.doCleanDateFormat(model.getEndDate()));

        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_UPD_MEMO_DETAIL", // 更新個人備忘錄明細
                parameterSource);
    }

    @Override
    public BigDecimal updMemoStatus(F03010203ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Function參數 -------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_MEMO_NO", model.getMemoNo())
                .addValue("I_MEMO_STATUS", model.getMemoStatus())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        // 2. 呼叫DB Function，更新個人備忘錄狀態 ------------------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_UPD_MEMO_DETAIL_STATUS", // 更新個人備忘錄狀態
                parameterSource);
    }

    @Override
    public BigDecimal updCycleMemo(F03010204ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 註銷週期備忘錄 -----------------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_CANCEL_MEMO", // 註銷週期備忘錄
                parameterSource);

        // 2. 中止週期備忘錄明細 --------------------------------------------------------------------------------------------
        parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount())
                .addValue("I_CANCEL_ALL", "N"); // N: 通知日期 > 今日

        getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_CANCEL_MEMO_DETAIL", // 中止週期備忘錄明細
                parameterSource);

        return f020103service.mergeAddMemo(model, LocalDate.now().toString(), userProfile);
    }

    @Override
    public BigDecimal delCycleMemo(F03010205ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 註銷週期備忘錄 -----------------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_CANCEL_MEMO", // 註銷週期備忘錄
                parameterSource);

        // 2. 中止週期備忘錄明細 ---------------------------------------------------------------------------------------------
        parameterSource = new MapSqlParameterSource()
                .addValue("I_MEMO_SEQ_NO", model.getMemoSeqNo())
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount())
                .addValue("I_CANCEL_ALL", "N"); // N: 通知日期 > 今日

        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F030102",
                "FN_CANCEL_MEMO_DETAIL", // 中止週期備忘錄明細
                parameterSource);
    }
}