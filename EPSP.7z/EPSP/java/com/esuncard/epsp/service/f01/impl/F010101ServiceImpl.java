package com.esuncard.epsp.service.f01.impl;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.UserProfile;
import com.esuncard.core.utils.SimpleJdbcCallUtils;
import com.esuncard.epsp.service.AbstractBaseApService;
import com.esuncard.epsp.service.f01.F010101Service;
import com.esuncard.model.epsp.f01.f01010101.res.F01010101ResModelBean;

/**
 * 取得首頁備忘錄、通訊錄筆數 Service
 * @author ESB21306 by Esunbank
 * @date 2020年8月21日
 * @remark
 */
@Service
@Transactional
public class F010101ServiceImpl extends AbstractBaseApService implements F010101Service {
    /** logger */
    private static Log logger = LogFactory.getLog(F010101ServiceImpl.class);

    @Override
    @Transactional(readOnly = true)
    public F01010101ResModelBean qryMemoNum(UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());

            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Function參數 ------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        // 2. 依據查詢條件，呼叫DB Function，取得個人備忘錄筆數 --------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_F010101",
                "FN_QRY_MEMO_NUM", // 取得個人備忘錄筆數
                parameterSource);

        // 3. 轉換MapList to BeanList --------------------------------------------------------------------------------
        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, F01010101ResModelBean.class)
                .stream().findFirst().orElse(new F01010101ResModelBean());
    }

    @Override
    @Transactional(readOnly = true)
    public BigDecimal qryUserDirectoryNum(UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());

            logger.debug(logParams);
        }
        // 1. 組合呼叫DB Function參數 ------------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
                .addValue("I_AD_ACCOUNT", userProfile.getAdAccount());

        // 2. 依據查詢條件，呼叫DB Function，取得個人自訂通訊錄筆數------------------------------------------------------------------
        return getGeneralSimpleJdbcCallDAO().doCallFunction(
                BigDecimal.class,
                "PG_F010101",
                "FN_QRY_USER_DIRECTORY_NUM", // 取得個人自訂通訊錄筆數
                parameterSource);
    }
}