package com.esuncard.epsp.service.f01;

import java.math.BigDecimal;

import com.esuncard.core.bean.UserProfile;
import com.esuncard.model.epsp.f01.f01010101.res.F01010101ResModelBean;

/**
 * 取得首頁備忘錄、通訊錄筆數 Service
 * @author ESB21306 by Esunbank
 * @date 2020年8月21日
 * @remark
 */
public interface F010101Service {
    /**
     * 取得進行中/已逾期個人備忘錄筆數
     * @param userProfile 使用者基本資料
     * @return F01010101ResModelBean 取得進行中/已逾期個人備忘錄筆數
     * @remark
     */
    F01010101ResModelBean qryMemoNum(UserProfile userProfile);

    /**
     * 取得個人自訂通訊錄筆數
     * @param userProfile 使用者基本資料
     * @return BigDecimal 取得個人自訂通訊錄筆數
     * @remark
     */
    BigDecimal qryUserDirectoryNum(UserProfile userProfile);
}