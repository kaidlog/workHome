package com.esuncard.epsp.service.f01.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.UserProfile;
import com.esuncard.core.utils.SimpleJdbcCallUtils;
import com.esuncard.epsp.service.AbstractBaseApService;
import com.esuncard.epsp.service.f01.F010102Service;
import com.esuncard.epsp.service.f01.F010104Service;
import com.esuncard.model.epsp.common.res.UserBookmarkResModelBean;
import com.esuncard.model.epsp.f01.f01010402.req.F01010402ReqModelBean;

/**
 * 功能總覽-我的最愛 Service
 * @author ESB19350 by Esunbank
 * @date 2020年8月13日
 * @remark
 */
@Service
@Transactional
public class F010104ServiceImpl extends AbstractBaseApService implements F010104Service {
    /** logger */
    private static Log logger = LogFactory.getLog(F010104ServiceImpl.class);

    /** 功能總覽-我的最愛異動與取得功能總覽 Service */
    @Autowired
    private F010102Service f010102Service;

    @Override
    @Transactional(readOnly = true)
    public List<UserBookmarkResModelBean> qryBookmarkList(UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", userProfile.getAdAccount());

            logger.debug(logParams);
        }

        // 1. 組合呼叫DB Procedure參數 -----------------------------------------------------------------------------------
        MapSqlParameterSource parameterSource = new MapSqlParameterSource().addValue(
                "I_AD_ACCOUNT", userProfile.getAdAccount());

        // 2. 依據查詢條件，呼叫DB function，查詢我的最愛清單 ---------------------------------------------------------------------
        List<?> mapList = getGeneralSimpleJdbcCallDAO().doCallFunction(
                List.class,
                "PG_F010104",
                "FN_QRY_USER_BOOKMARK_LIST", // 查詢我的最愛清單
                parameterSource);

        // 3. 轉換MapList to BeanList --------------------------------------------------------------------------------
        return SimpleJdbcCallUtils.convertMapList2BeanList(mapList, UserBookmarkResModelBean.class);
    }

    @Override
    public Boolean updBookmarkList(F01010402ReqModelBean model, UserProfile userProfile) {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("model", model);

            logger.debug(logParams);
        }

        // 1. 刪除我的最愛清單 ---------------------------------------------------------------------------------------------
        model.getRemoveFavoriteList().forEach(userBookmark -> {
            f010102Service.delUserBookmark(userBookmark, userProfile);
        });

        // 2. 新增我的最愛清單 ---------------------------------------------------------------------------------------------
        model.getAddFavoriteList().forEach(userBookmark -> {
            f010102Service.addUserBookmark(userBookmark, userProfile);
        });

        return true;
    }
}