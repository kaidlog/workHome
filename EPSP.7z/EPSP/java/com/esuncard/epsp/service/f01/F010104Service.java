package com.esuncard.epsp.service.f01;

import java.util.List;

import com.esuncard.core.bean.UserProfile;
import com.esuncard.model.epsp.common.res.UserBookmarkResModelBean;
import com.esuncard.model.epsp.f01.f01010402.req.F01010402ReqModelBean;

/**
 * 功能總覽-我的最愛 Service
 * @author ESB19350 by Esunbank
 * @date 2020年8月13日
 * @remark
 */
public interface F010104Service {
    /**
     * 查詢我的最愛清單
     * @param userProfile 使用者基本資料
     * @return List<UserBookmarkResModelBean> 查詢我的最愛清單結果
     * @remark
     */
    List<UserBookmarkResModelBean> qryBookmarkList(UserProfile userProfile);

    /**
     * 更新我的最愛清單
     * @param model 更新我的最愛清單參數
     * @param userProfile 使用者基本資料
     * @return Boolean 更新我的最愛列表執行結果
     * @remark
     */
    Boolean updBookmarkList(F01010402ReqModelBean model, UserProfile userProfile);
}