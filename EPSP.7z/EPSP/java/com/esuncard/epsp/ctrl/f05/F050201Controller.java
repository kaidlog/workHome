package com.esuncard.epsp.ctrl.f05;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.RestApiOneResponse;
import com.esuncard.epsp.ctrl.AbstractBaseApController;
import com.esuncard.epsp.service.f05.F050201Service;
import com.esuncard.model.epsp.f05.f05020101.req.F05020101ReqModelBean;
import com.esuncard.model.epsp.f05.f05020101.res.F05020101ResModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 交換機通話紀錄 Controller
 * @author ESB20447 by Esunbank
 * @date 2020年8月27日
 * @remark
 */
@RestController
@RequestMapping("/f050201")
@Api(tags = "交換機通話紀錄 Controller")
public class F050201Controller extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(F050201Controller.class);

    /** 交換機通話紀錄 Service */
    @Autowired
    private F050201Service f050201Service;

    /**
     * 交換機通話紀錄查詢
     * @param model 查詢條件
     * @return RestApiOneResponse<F05020101ResModelBean> 查詢結果
     * @remark
     */
    @PostMapping("/01")
    @ApiOperation(value = "交換機通話紀錄查詢")
    public RestApiOneResponse<F05020101ResModelBean> qryCDRRecordList(@Valid @RequestBody F05020101ReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f050201Service.qryCDRRecordList(model));
    }
}