package com.esuncard.epsp.ctrl.f01;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.RestApiOneResponse;
import com.esuncard.epsp.ctrl.AbstractBaseApController;
import com.esuncard.epsp.service.f01.F010101Service;
import com.esuncard.model.epsp.f01.f01010101.res.F01010101ResModelBean;

/**
 * 取得備忘錄、通訊錄筆數 Controller
 * @author ESB21306 by Esunbank
 * @date 2020年8月21日
 * @remark
 */
@RestController
@RequestMapping("/f010101")
@Api(tags = "取得備忘錄、通訊錄筆數 Controller")
public class F010101Controller extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(F010101Controller.class);

    /** 取得首頁備忘錄、通訊錄筆數 Service */
    @Autowired
    private F010101Service f010101Service;

    /**
     * 取得進行中/已逾期個人備忘錄筆數
     * @return RestApiOneResponse<F01010101ResModelBean> 查詢結果
     * @remark
     */
    @PostMapping("/01")
    @ApiOperation(value = "取得進行中/已逾期個人備忘錄筆數")
    public RestApiOneResponse<F01010101ResModelBean> qryMemoNum() {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f010101Service.qryMemoNum(doGetLoginUserProfile()));
    }

    /**
     * 取得自訂通訊錄筆數
     * @return RestApiOneResponse<BigDecimal> 查詢結果
     * @remark
     */
    @PostMapping("/02")
    @ApiOperation(value = "取得自訂通訊錄筆數")
    public RestApiOneResponse<BigDecimal> qryUserDirectoryNum() {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f010101Service.qryUserDirectoryNum(doGetLoginUserProfile()));
    }
}