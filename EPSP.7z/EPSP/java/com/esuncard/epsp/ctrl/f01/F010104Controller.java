package com.esuncard.epsp.ctrl.f01;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.RestApiListResponse;
import com.esuncard.core.bean.RestApiOneResponse;
import com.esuncard.epsp.ctrl.AbstractBaseApController;
import com.esuncard.epsp.service.f01.F010104Service;
import com.esuncard.model.epsp.common.res.UserBookmarkResModelBean;
import com.esuncard.model.epsp.f01.f01010402.req.F01010402ReqModelBean;

/**
 * 功能總覽-我的最愛 Controller
 * @author ESB19350 by Esunbank
 * @date 2020年8月03日
 * @remark
 */
@RestController
@RequestMapping("/f010104")
@Api(tags = "功能總覽-我的最愛 Controller")
public class F010104Controller extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(F010104Controller.class);

    /** 功能總覽-我的最愛 Service */
    @Autowired
    private F010104Service f010104Service;

    /**
     * 查詢我的最愛清單
     * @return RestApiListResponse<UserBookmarkResModelBean> 查詢結果
     * @remark
     */
    @PostMapping("/01")
    @ApiOperation(value = "查詢我的最愛清單")
    public RestApiListResponse<UserBookmarkResModelBean> qryBookmarkList() {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultListResult(f010104Service.qryBookmarkList(doGetLoginUserProfile()));
    }

    /**
     * 更新我的最愛清單
     * @param model 更新我的最愛清單參數
     * @return RestApiOneResponse<Boolean> 更新結果
     * @remark
     */
    @PostMapping("/02")
    @ApiOperation(value = "更新我的最愛清單")
    public RestApiOneResponse<Boolean> updBookmarkList(@Valid @RequestBody F01010402ReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f010104Service.updBookmarkList(model, doGetLoginUserProfile()));
    }
}