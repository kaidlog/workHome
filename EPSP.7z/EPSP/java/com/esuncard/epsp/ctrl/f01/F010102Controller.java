package com.esuncard.epsp.ctrl.f01;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.esuncard.core.bean.RestApiListResponse;
import com.esuncard.core.bean.RestApiOneResponse;
import com.esuncard.core.bean.model.csip.Csip4Cbp2ReqWrapBean;
import com.esuncard.core.bean.model.csip.Csip4Cbp2ResWrapBean;
import com.esuncard.core.bean.model.profile.SystemResModelBean;
import com.esuncard.epsp.ctrl.AbstractBaseApController;
import com.esuncard.epsp.service.common.EiamService;
import com.esuncard.epsp.service.f01.F010102Service;
import com.esuncard.model.eiam.common.req.UserSysListReqModelBean;
import com.esuncard.model.epsp.common.req.UserBookmarkReqModelBean;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 功能總覽-我的最愛異動與取得功能總覽 Controller
 * @author ESB19350 by Esunbank
 * @date 2020年8月14日
 * @remark
 */
@RestController
@RequestMapping("/f010102")
@Api(tags = "功能總覽-我的最愛異動與取得功能總覽 Controller")
public class F010102Controller extends AbstractBaseApController {
    /** logger */
    private static Log logger = LogFactory.getLog(F010102Controller.class);

    /** 功能總覽-我的最愛異動與取得功能總覽 Service */
    @Autowired
    private F010102Service f010102Service;

    /** 權限管理平台(EIAM) Service */
    @Autowired
    private EiamService eiamService;

    /**
     * 取得系統功能總覽資料
     * @return RestApiListResponse<F01010201ResModelBean> 系統功能總覽資料
     * @remark
     */
    @PostMapping("/01")
    @ApiOperation(value = "取得系統功能總覽資料")
    public RestApiListResponse<SystemResModelBean> qryFunctionList() {
        if (logger.isDebugEnabled()) {
            JSONObject logParams = new JSONObject();
            logParams.put("userProfile.adAccount", doGetLoginUserProfile().getAdAccount());
        }

        // 1. 組合發送CSIP電文Request ------------------------------------------------------------------------------------
        UserSysListReqModelBean userSysListReqModelBean = new UserSysListReqModelBean();
        userSysListReqModelBean.setAdAccount(doGetOptUserProfile().getAdAccount());
        Csip4Cbp2ReqWrapBean<UserSysListReqModelBean> reqModel = getCsipBuildService().doBuildCsip4Cbp2Request(userSysListReqModelBean);

        // 2. 發送電文取得系統功能清單並組合回傳結果 -------------------------------------------------------------------------------
        Csip4Cbp2ResWrapBean<List<SystemResModelBean>> resModel = eiamService.doGetSysFunction(reqModel);

        RestApiListResponse<SystemResModelBean> response = new RestApiListResponse<SystemResModelBean>();
        response.setBody(resModel.getResBody());
        response.setStatus(resModel.getResHeader().getStsCode());
        response.setMsg(resModel.getResHeader().getResMsgs());

        return response;
    }

    /**
     * 新增我的最愛
     * @param model 新增我的最愛參數
     * @return RestApiOneResponse<BigDecimal> 新增結果
     * @remark
     */
    @PostMapping("/02")
    @ApiOperation(value = "新增我的最愛")
    public RestApiOneResponse<BigDecimal> addUserBookmark(@Valid @RequestBody UserBookmarkReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f010102Service.addUserBookmark(model, doGetLoginUserProfile()));
    }

    /**
     * 刪除我的最愛
     * @param model 刪除我的最愛參數
     * @return RestApiOneResponse<BigDecimal> 刪除結果
     * @remark
     */
    @PostMapping("/03")
    @ApiOperation(value = "刪除我的最愛")
    public RestApiOneResponse<BigDecimal> delUserBookmark(@Valid @RequestBody UserBookmarkReqModelBean model) {
        if (logger.isDebugEnabled()) {
            logger.debug(new JSONObject());
        }

        return doGetDefaultOneResult(f010102Service.delUserBookmark(model, doGetLoginUserProfile()));
    }
}