package com.esuncard.model.epsp.f01.f01010101.res;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * 個人備忘錄查詢 Response Model Bean
 * @author ESB21306 by Esunbank
 * @date 2020年8月21日
 * @remark
 */
@Data
public class F01010101ResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 進行中個人備忘錄筆數 */
    @ApiModelProperty(value = "進行中個人備忘錄筆數", allowEmptyValue = false, required = true)
    private BigDecimal todoMemoNum; // >> TODO_MEMO_NUM
    /** 已逾期個人備忘錄筆數 */
    @ApiModelProperty(value = "已逾期個人備忘錄筆數", allowEmptyValue = false, required = true)
    private BigDecimal overdueMemoNum; // >> OVERDUE_MEMO_NUM
}