package com.esuncard.model.epsp.f03.f03010203.req;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 更新個人備忘錄狀態 Request Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年7月31日
 * @remark
 */
@Data
public class F03010203ReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=26 */
    @ApiModelProperty(value = "備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=26", allowEmptyValue = true, required = false)
    @Size(max = 30, message = "備忘錄狀態長度需小於30")
    private String memoStatus;
    /** 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO */
    @ApiModelProperty(value = "個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO", allowEmptyValue = false, required = true)
    @NotBlank(message = "個人備忘錄SEQ_NO為必填")
    @Size(max = 19, message = "個人備忘錄SEQ_NO長度需小於19")
    private String memoSeqNo;
    /** 備忘錄週期編號 */
    @ApiModelProperty(value = "備忘錄週期編號", allowEmptyValue = true, required = false)
    @Size(max = 19, message = "備忘錄週期編號長度需小於19")
    private String memoNo;
    /** 備忘錄內容狀態, DATASHARE.TB_SYS_CD.CD_ID, CT_ID=158 */
    @ApiModelProperty(value = "備忘錄內容狀態, DATASHARE.TB_SYS_CD.CD_ID, CT_ID=158", allowEmptyValue = true, required = false)
    @Size(max = 30, message = "備忘錄內容狀態長度需小於30")
    private String contentStatus;
}