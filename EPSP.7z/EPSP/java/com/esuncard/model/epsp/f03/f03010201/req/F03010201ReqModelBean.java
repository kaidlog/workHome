package com.esuncard.model.epsp.f03.f03010201.req;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 查詢單筆個人備忘錄 Request Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年7月31日
 * @remark
 */
@Data
public class F03010201ReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO */
    @ApiModelProperty(value = "個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO", allowEmptyValue = false, required = true)
    @NotBlank(message = "個人備忘錄SEQ_NO不可為空")
    @Size(max = 19, message = "個人備忘錄SEQ_NO長度需小於19")
    private String memoSeqNo;
}