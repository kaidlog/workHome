package com.esuncard.model.epsp.f03.f03010205.req;

import java.io.Serializable;

import com.esuncard.model.epsp.f03.f03010203.req.F03010203ReqModelBean;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 刪除週期備忘錄 Request Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年7月31日
 * @remark
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class F03010205ReqModelBean extends F03010203ReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
}