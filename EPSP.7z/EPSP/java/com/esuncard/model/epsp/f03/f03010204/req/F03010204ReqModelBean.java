package com.esuncard.model.epsp.f03.f03010204.req;

import java.io.Serializable;

import com.esuncard.model.epsp.f03.f03010202.req.F03010202ReqModelBean;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 更新週期備忘錄 Request Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年7月31日
 * @remark
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class F03010204ReqModelBean extends F03010202ReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;
}