package com.esuncard.model.epsp.f03.f03010201.res;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 查詢單筆個人備忘錄 Response Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年7月31日
 * @remark
 */
@Data
public class F03010201ResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 主鍵 **/
    @ApiModelProperty(value = "主鍵", allowEmptyValue = false, required = true)
    private String memoSeqNo;
    /** 資料建立時間 **/
    @ApiModelProperty(value = "資料建立時間", allowEmptyValue = false, required = true)
    private String createTime;
    /** 資料最後異動時間 **/
    @ApiModelProperty(value = "資料最後異動時間", allowEmptyValue = false, required = true)
    private String updateTime;
    /** 資料建立人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT **/
    @ApiModelProperty(value = "資料建立人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT", allowEmptyValue = false, required = true)
    private String creator;
    /** 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT **/
    @ApiModelProperty(value = "資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT", allowEmptyValue = false, required = true)
    private String updater;
    /** 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT **/
    @ApiModelProperty(value = "使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT", allowEmptyValue = false, required = true)
    private String userAd;
    /** 備忘錄類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=23 **/
    @ApiModelProperty(value = "備忘錄類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=23", allowEmptyValue = false, required = true)
    private String memoType;
    /** 起始日期(YYYYMMDD) **/
    @ApiModelProperty(value = "起始日期(YYYYMMDD)", allowEmptyValue = false, required = true)
    private String startDate;
    /** 結束日期(YYYYMMDD) **/
    @ApiModelProperty(value = "結束日期(YYYYMMDD)", allowEmptyValue = false, required = true)
    private String endDate;
    /** 逾期天數 **/
    @ApiModelProperty(value = "逾期天數", allowEmptyValue = false, required = true)
    private BigDecimal overdueDay;
    /** 緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20 **/
    @ApiModelProperty(value = "緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20", allowEmptyValue = false, required = true)
    private String memoLevel;
    /** 系統代碼, Ref EIAM.TB_SYSTEM.SYS_ID **/
    @ApiModelProperty(value = "系統代碼, Ref EIAM.TB_SYSTEM.SYS_ID", allowEmptyValue = false, required = true)
    private String sysId;
    /** 來源功能代碼 **/
    @ApiModelProperty(value = "來源功能代碼", allowEmptyValue = false, required = true)
    private String funcCode;
    /** 來源功能名稱 **/
    @ApiModelProperty(value = "來源功能名稱", allowEmptyValue = false, required = true)
    private String funcName;
    /** 主旨 **/
    @ApiModelProperty(value = "主旨", allowEmptyValue = false, required = true)
    private String memoTitle;
    /** 內容 **/
    @ApiModelProperty(value = "內容", allowEmptyValue = false, required = true)
    private String memoContent;
    /** 連結 **/
    @ApiModelProperty(value = "連結", allowEmptyValue = true, required = false)
    private String url;
    /** 備忘錄內容狀態, DATASHARE.TB_SYS_CD.CD_ID, CT_ID=158 **/
    @ApiModelProperty(value = "備忘錄內容狀態, DATASHARE.TB_SYS_CD.CD_ID, CT_ID=158", allowEmptyValue = false, required = true)
    private String contentStatus;
    /** 備忘錄週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24 **/
    @ApiModelProperty(value = "備忘錄週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24", allowEmptyValue = false, required = true)
    private String memoCycle;
    /** 週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45 **/
    @ApiModelProperty(value = "週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45", allowEmptyValue = false, required = true)
    private String weekDay;
    /** 週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47 **/
    @ApiModelProperty(value = "週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47", allowEmptyValue = false, required = true)
    private String monthDay;
    /** 週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46 **/
    @ApiModelProperty(value = "週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46", allowEmptyValue = false, required = true)
    private String yearDay;
}