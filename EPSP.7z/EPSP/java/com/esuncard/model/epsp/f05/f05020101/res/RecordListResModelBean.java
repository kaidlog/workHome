package com.esuncard.model.epsp.f05.f05020101.res;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 交換機通話紀錄服務一頁詳細清單 Response Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年9月16日
 * @remark
 */
@Data
public class RecordListResModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 系統名稱 */
    @ApiModelProperty(value = "系統名稱", allowEmptyValue = true, required = false)
    private String sysNm;
    /** 通話來源名稱 */
    @ApiModelProperty(value = "通話來源名稱", allowEmptyValue = true, required = false)
    private String srcFuncnm;
    /** 通話狀態名稱 */
    @ApiModelProperty(value = "通話狀態名稱", allowEmptyValue = true, required = false)
    private String callStatusNm;
    /** 通話日期 */
    @ApiModelProperty(value = "通話日期", allowEmptyValue = false, required = true)
    private String cdrStarttime;
    /** 通話秒數 */
    @ApiModelProperty(value = "通話秒數", allowEmptyValue = false, required = true)
    private String totalSecond;
    /** 發話號碼 */
    @ApiModelProperty(value = "發話號碼", allowEmptyValue = false, required = true)
    private String callingNumber;
    /** 受話電話來源 */
    @ApiModelProperty(value = "受話電話來源", allowEmptyValue = true, required = false)
    private String calledNumbersrcfield;
    /** 受話人員 */
    @ApiModelProperty(value = "受話人員", allowEmptyValue = true, required = false)
    private String calledInfo;
    /** 受話人員鍵值 */
    @ApiModelProperty(value = "受話人員鍵值", allowEmptyValue = true, required = false)
    private String calledId;
    /** 發話人員 */
    @ApiModelProperty(value = "發話人員", allowEmptyValue = false, required = true)
    private String userid;
    /** 受話號碼 */
    @ApiModelProperty(value = "受話號碼", allowEmptyValue = true, required = false)
    private String calledNumber;
}