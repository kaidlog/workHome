package com.esuncard.model.epsp.f05.f05020101.req;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.GroupSequence;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.esuncard.core.bean.model.AbstractBasePaggingReqModelBean;
import com.esuncard.core.constraints.ValidDate;
import com.esuncard.epsp.utils.EpspDateUtils;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 交換機通話紀錄 Request Model Bean
 * @author ESB20447 by Esunbank
 * @date 2020年9月16日
 * @remark
 */
@Data
@EqualsAndHashCode(callSuper = true)
@GroupSequence({F05020101ReqModelBean.DateValid.class, F05020101ReqModelBean.class })
public class F05020101ReqModelBean extends AbstractBasePaggingReqModelBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 通話類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=193 */
    @ApiModelProperty(value = "通話類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=193", allowEmptyValue = false, required = true)
    @NotBlank(message = "通話類型為必填")
    @Size(max = 2, message = "通話類型長度需小於2")
    private String callType;
    /** 通話日期_開始(yyyy/MM/dd) */
    @ApiModelProperty(value = "通話日期_開始(yyyy/MM/dd) ", allowEmptyValue = false, required = true)
    @NotBlank(message = "通話日期_開始為必填", groups = {DateValid.class })
    @ValidDate(pattern = "yyyy/MM/dd", message = "通話日期_開始時間格式錯誤", groups = {DateValid.class })
    private String startDate;
    /** 通話日期_結束(yyyy/MM/dd) */
    @ApiModelProperty(value = "通話日期_結束(yyyy/MM/dd)", allowEmptyValue = false, required = true)
    @NotBlank(message = "通話日期_結束為必填", groups = {DateValid.class })
    @ValidDate(pattern = "yyyy/MM/dd", message = "通話日期_結束時間格式錯誤", groups = {DateValid.class })
    private String endDate;
    /** 發話人員名稱 */
    @ApiModelProperty(value = "發話人員名稱", allowEmptyValue = true, required = false)
    @Size(max = 30, message = "發話人員名稱長度需小於30")
    private String callingName;
    /** 發話人員代碼 */
    @ApiModelProperty(value = "發話人員代碼", allowEmptyValue = true, required = false)
    @Size(max = 15, message = "發話人員代碼長度需小於15")
    private String callingCode;
    /** 發話號碼 */
    @ApiModelProperty(value = "發話號碼", allowEmptyValue = true, required = false)
    @Size(max = 10, message = "發話號碼長度需小於10")
    private String callingNumber;
    /** 受話人員名稱 */
    @ApiModelProperty(value = "受話人員名稱", allowEmptyValue = true, required = false)
    @Size(max = 30, message = "受話人員名稱長度需小於30")
    private String calledName;
    /** 受話人員代碼 */
    @ApiModelProperty(value = "受話人員代碼", allowEmptyValue = true, required = false)
    @Size(max = 15, message = "受話人員代碼長度需小於15")
    private String calledCode;
    /** 受話號碼 */
    @ApiModelProperty(value = "受話號碼", allowEmptyValue = true, required = false)
    @Size(max = 10, message = "受話號碼長度需小於10")
    private String calledNumber;

    /**
     * 通話日期檢核, 系統日-6個月 ≦ 日期 ≦ 系統日
     */
    @AssertTrue(message = "通話日期異常")
    public boolean isDateValid() {
        LocalDate start = EpspDateUtils.dateStr2LocalDate(startDate);
        LocalDate end = EpspDateUtils.dateStr2LocalDate(endDate);
        LocalDate sixMonthsAgo = LocalDate.now().minusMonths(6L);
        LocalDate today = LocalDate.now();

        if (start.isBefore(sixMonthsAgo) || end.isBefore(sixMonthsAgo)) {
            return false;
        }

        if (start.isAfter(today) || end.isAfter(today)) {
            return false;
        }

        return start.isBefore(end) || start.isEqual(end);
    }

    /**
     * 日期檢核群組
     */
    public interface DateValid {
    }
}