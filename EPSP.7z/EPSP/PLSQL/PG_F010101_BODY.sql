CREATE OR REPLACE PACKAGE BODY EPSP.PG_F010101 AS                                                                             
-----------------------------------------------------------------                                                    
-- 功能總覽服務服務                  	   	       			   --                                                    
-- @author ESB19350 by Esunbank                        	   	   --                                                    
-----------------------------------------------------------------     
	/**
	 * 取得自訂通訊錄筆數
	 */
    FUNCTION FN_QRY_USER_DIRECTORY_NUM(
        I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
    ) RETURN NUMBER                                                                                                 -- 自訂通訊錄筆數  
    AS                                                                                                               
		O_RESULT NUMBER;                                                                                       		-- 自訂通訊錄筆數
    BEGIN                                                                                                            
		SELECT                                                                                                       
			COUNT(1) INTO O_RESULT																					-- 自訂通訊錄筆數
		FROM                                                                                                         
			EPSP.TB_USER_DIRECTORY UD                                                                               -- 自訂通訊錄
		WHERE                                                                                                        
			UD.AD_ACCOUNT = I_AD_ACCOUNT                                                                            -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		;                                                                                                            
																													 
		RETURN O_RESULT;																							-- 自訂通訊錄筆數
    
    END FN_QRY_USER_DIRECTORY_NUM;
	
    /**
	 * 取得進行中, 已逾期個人備忘錄筆數
	 */
	FUNCTION FN_QRY_MEMO_NUM(
        I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN SYS_REFCURSOR                                                                                          -- 備忘錄筆數清單	
	AS                                                                                                              
		O_RESULT SYS_REFCURSOR; 																					-- 備忘錄筆數清單	
		V_TODAY VARCHAR(8) := TO_CHAR(SYSDATE, 'YYYYMMDD');                                                         -- 今天日期(YYYYMMDD)
	BEGIN
		OPEN O_RESULT FOR                                                                                           -- 備忘錄筆數清單
		SELECT
			NVL(
				SUM(CASE
					WHEN (MD.OVERDUE_DATE < V_TODAY)                                                              	-- 當日系統日期大於逾期日期                                                                   	
					THEN 1                                                                                               
					ELSE 0                                                                                               
				END), 0
			) AS OVERDUE_MEMO_NUM,                                                                             		-- 已逾期個人備忘錄筆數
			NVL(
				SUM(CASE                                                                                                    
					WHEN (V_TODAY <= MD.OVERDUE_DATE AND V_TODAY >= MD.NOTIFY_DATE)                                 -- 逾期日期超過今天且今天大於通知日期
					THEN 1
					ELSE 0
				END), 0
			) AS TODO_MEMO_NUM                                                                                  	-- 進行中個人備忘錄筆數
		FROM 
			EPSP.TB_MEMO M                                                                                          -- 個人備忘錄管理
			INNER JOIN EPSP.TB_MEMO_DETAIL MD ON M.MEMO_SEQ_NO = MD.MEMO_SEQ_NO                                     -- 個人備忘錄明細
		WHERE
			M.AD_ACCOUNT = I_AD_ACCOUNT                                                                             -- 查詢使用者AD帳號
			AND MD.MEMO_STATUS = '00'                                                                               -- 備忘錄狀態, 00: 進行中
        ;
		
		RETURN O_RESULT;   																							-- 備忘錄筆數清單	
		
	END FN_QRY_MEMO_NUM ;
	 
END PG_F010101;