CREATE OR REPLACE PACKAGE EPSP.PG_F030102 AS 
-----------------------------------------------------------------
-- 個人備忘錄編輯                            	   	           --
-- @author ESB20447 by Esunbank                        	       --
-----------------------------------------------------------------
	/**
	 * 取得單筆個人/週期備忘錄
	 */
	FUNCTION FN_QRY_MEMO(																													
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO.MEMO_SEQ_NO%TYPE,                                                             -- 個人備忘錄管理主鍵
		I_AD_ACCOUNT IN EPSP.TB_MEMO.AD_ACCOUNT%TYPE                                                                -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN SYS_REFCURSOR;                                                                                         -- 個人備忘錄管理清單
	
    /**
     * 更新個人備忘錄管理
     */
    FUNCTION FN_UPD_MEMO(	    
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO.MEMO_SEQ_NO%TYPE,                                                             -- 個人備忘錄管理主鍵
	    I_AD_ACCOUNT IN EPSP.TB_MEMO.AD_ACCOUNT%TYPE,                                                               -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT	    
	    I_START_DATE IN EPSP.TB_MEMO.START_DATE%TYPE,                                                               -- 起始日期(YYYYMMDD)
	    I_END_DATE IN EPSP.TB_MEMO.END_DATE%TYPE,                                                                   -- 結束日期(YYYYMMDD)
	    I_OVERDUE_DAY IN EPSP.TB_MEMO.OVERDUE_DAY%TYPE,                                                             -- 逾期天數
	    I_MEMO_LEVEL IN EPSP.TB_MEMO.MEMO_LEVEL%TYPE,                                                               -- 緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20	    
	    I_MEMO_TITLE IN EPSP.TB_MEMO.MEMO_TITLE%TYPE,                                                               -- 主旨
	    I_MEMO_CONTENT IN EPSP.TB_MEMO.MEMO_CONTENT%TYPE,                                                           -- 內容
	    I_URL IN EPSP.TB_MEMO.URL%TYPE,                                                                             -- 連結
	    I_MEMO_CYCLE IN EPSP.TB_MEMO.MEMO_CYCLE%TYPE,                                                               -- 週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24	    
	    I_WEEK_DAY IN EPSP.TB_MEMO.WEEK_DAY%TYPE,                                                                   -- 週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45	    
	    I_MONTH_DAY IN EPSP.TB_MEMO.MONTH_DAY%TYPE,                                                                 -- 週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47	    
	    I_YEAR_DAY IN EPSP.TB_MEMO.YEAR_DAY%TYPE                                                                    -- 週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46
    ) RETURN NUMBER;                                                                                                -- 更新個人備忘錄管理筆數
	
	/**
     * 更新個人備忘錄明細
     */
    FUNCTION FN_UPD_MEMO_DETAIL(        
	    I_UPDATER IN EPSP.TB_MEMO_DETAIL.UPDATER%TYPE,                                                              -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT	 	    
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO_DETAIL.MEMO_SEQ_NO%TYPE,                                                      -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO	    
	    I_MEMO_NO IN EPSP.TB_MEMO_DETAIL.MEMO_NO%TYPE,                                                              -- 備忘錄週期編號	          
	    I_MEMO_STATUS IN EPSP.TB_MEMO_DETAIL.MEMO_STATUS%TYPE,                                                      -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CD_ID=26	    
	    I_OVERDUE_DATE IN EPSP.TB_MEMO_DETAIL.OVERDUE_DATE%TYPE                                                     -- 逾期時間(YYYYMMDDHH24MISS)
    ) RETURN NUMBER;                                                                                                -- 更新個人備忘錄明細筆數
    
    /**
     * 更新個人備忘錄狀態
     */
    FUNCTION FN_UPD_MEMO_DETAIL_STATUS(
        I_MEMO_STATUS IN VARCHAR2,                                                                                  -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=26
		I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO        
		I_MEMO_NO IN NUMBER,                                                                                        -- 備忘錄週期編號
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
    ) RETURN NUMBER;                                                                                                -- 更新個人備忘錄狀態筆數
	
    /**
     * 註銷週期備忘錄
     */
    FUNCTION FN_CANCEL_MEMO(
        I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 主鍵
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
    ) RETURN NUMBER;                                                                                                -- 註銷週期備忘錄筆數
	
	/**
     * 中止週期備忘錄明細
     */
    FUNCTION FN_CANCEL_MEMO_DETAIL(
        I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 主鍵
		I_AD_ACCOUNT IN VARCHAR2,                                                                                   -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		I_CANCEL_ALL IN VARCHAR2                                                                                    -- 註銷型態
	) RETURN NUMBER;                                                                                                -- 中止週期備忘錄明細筆數
    
END PG_F030102;