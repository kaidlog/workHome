CREATE OR REPLACE PACKAGE EPSP.PG_F010104 AS                                                                         
-----------------------------------------------------------------                                                    
-- 我的最愛服務查詢服務                   	   	      		   --                                                    
-- @author ESB19350 by Esunbank                        	   	   --                                                    
-----------------------------------------------------------------                                                    
	/**                                                                                                               
	 * 查詢我的最愛清單                                                                                                 
	 */                                                                                                              
	FUNCTION FN_QRY_USER_BOOKMARK_LIST (
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN SYS_REFCURSOR;                                                                                         -- 我的最愛清單
	

END PG_F010104;                                                                                                      