CREATE OR REPLACE PACKAGE BODY EPSP.PG_F050201 AS
-----------------------------------------------------------------
-- 交換機紀錄查詢                               	   	       --
-- @author ESB20447 by Esunbank                       	       --
-----------------------------------------------------------------
    /**
     * 交換機通話紀錄查詢
     */
    PROCEDURE SP_QRY_CDR_DTL_LIST(
        -- 查詢條件 ----------------------------------------------------------------------------------------------------
		I_CALL_TYPE IN VARCHAR2,                                                                                    -- 通話類型
		I_START_DATE IN VARCHAR2,                                                                                   -- 通話日期(起)
		I_END_DATE IN VARCHAR2,                                                                                     -- 通話日期(迄)
		I_CALLING_NAME IN VARCHAR2,                                                                                 -- 發話人員名稱
		I_CALLING_CODE IN VARCHAR2,                                                                                 -- 發話人員代碼
		I_CALLING_NUMBER IN VARCHAR2,                                                                               -- 發話號碼
		I_CALLED_NAME IN VARCHAR2,                                                                                  -- 受話人員名稱
		I_CALLED_CODE IN VARCHAR2,                                                                                  -- 受話人員代碼
		I_CALLED_NUMBER IN VARCHAR2,                                                                                -- 受話號碼
		-- 分頁排序條件 ------------------------------------------------------------------------------------------------
		I_PAGE_NO IN NUMBER,                                                                                        -- 查詢第幾頁資料
		I_PAGE_SIZE IN NUMBER,                                                                                      -- 一頁顯示幾筆
		-- 輸出結果 ----------------------------------------------------------------------------------------------------
        O_TOTAL OUT NUMBER,																							-- 輸出查詢總筆數
		O_PAGE_NO OUT NUMBER,                                                                                       -- 輸出實際頁次
		O_DATA OUT SYS_REFCURSOR																					-- 輸出該頁資料
    )AS				                                                                                                
		CDR_RECORD_LIST TT_CDR_RECORD_LIST;																			-- 交換機紀錄清單
	BEGIN                                                                                                           
        -- 1. 依據條件，查詢交換機分頁資料內容 -------------------------------------------------------------------------
		SELECT
			B.CALL_STATUS,                                                                                          -- 撥號狀態
			B.USERID,                                                                                               -- 發話人員
			B.CALLED_ID,                                                                                            -- 受話者鍵值
			B.CALLED_INFO,                                                                                          -- 受話者資訊
			B.CALLED_NUMBERSRCFIELD,                                                                                -- 受話電話來源
			B.SRC_SYSID,                                                                                            -- 來源系統別
			B.SRC_FUNCNM,                                                                                           -- 來源功能名稱
			C.CDR_STARTTIME,                                                                                        -- 通話起始時間
			C.TOTAL_SECOND,                                                                                         -- 通話秒數
			C.CALLING_NUMBER,                                                                                       -- 發話號碼
			C.CALLED_NUMBER,                                                                                        -- 受話號碼
			U.EMP_NO,                                                                                               -- 員工編號
			U.EMP_NM                                                                                                -- 員工姓名
        BULK COLLECT INTO CDR_RECORD_LIST                                                                           -- 交換機紀錄清單
		FROM
			TPS.CDR_DTL C                                                                                           -- CDR記錄檔
			OUTER APPLY(
				SELECT
				  A.CALL_STATUS,                                                                                  	-- 撥號狀態
				  A.USERID,                                                                                       	-- 發話人員
				  A.CALLED_ID,                                                                                    	-- 受話者鍵值
				  A.CALLED_INFO,                                                                                  	-- 受話者資訊
				  A.CALLED_NUMBERSRCFIELD,                                                                        	-- 受話電話來源
				  A.SRC_SYSID,                                                                                    	-- 來源系統別
				  A.SRC_FUNCNM                                                                                    	-- 來源功能名稱  
				FROM (
					SELECT
						ROW_NUMBER() OVER(ORDER BY T.SRC_CALLDATE || T.SRC_CALLTIME DESC) AS ROW_NO,                -- 以撥號日期+時間排序
						T.CALL_STATUS,                                                                              -- 撥號狀態
						T.USERID,                                                                                   -- 發話人員
						T.CALLED_ID,                                                                                -- 受話者鍵值
						T.CALLED_INFO,                                                                              -- 受話者資訊
						T.CALLED_NUMBERSRCFIELD,                                                                    -- 受話電話來源
						T.SRC_SYSID,                                                                                -- 來源系統別
						T.SRC_FUNCNM                                                                                -- 來源功能名稱
					FROM
						TPS.TPS_DTL T                                                                               -- 使用者撥號記錄檔
					WHERE
						T.SRC_SYSTEM = '03'                                                                         -- 撥號記錄來源, 03: CBP2_B02
						AND T.CALLIN_NUMBER = C.CALLING_NUMBER                                                      -- 發話號碼
						AND T.CALLED_NUMBER = C.CALLED_NUMBER                                                       -- 受話號碼
						AND T.SRC_CALLDATE || T.SRC_CALLTIME <= C.SRC_CDRDATE || C.SRC_CDRTIME                      -- 撥號日期+時間小於結束撥號日期+時間
				) A
				WHERE
				  A.ROW_NO = 1                                                                                      -- 取第一筆
			) B
			LEFT JOIN EIAM.TB_USER U ON U.AD_ACCOUNT = B.USERID                                                     -- 使用者資料表
		WHERE
			C.SRC_CDRDATE >= I_START_DATE                                                                           -- 通話日期(起)小於通話結束時間
			AND C.SRC_CDRDATE <= I_END_DATE                                                                         -- 通話日期(迄)大於通話結束時間
			AND (
                I_CALLING_NUMBER IS NULL																			-- 發話號碼		  
                OR C.CALLING_NUMBER = I_CALLING_NUMBER                                                             	-- 發話號碼
            )
            AND (
                I_CALLED_NUMBER IS NULL																				-- 受話號碼	    
                OR C.CALLED_NUMBER = I_CALLED_NUMBER																-- 受話號碼
            )
			AND (
                I_CALLING_NAME IS NULL																				-- 發話人員名稱	    
                OR U.EMP_NM LIKE ('%' || I_CALLING_NAME || '%')                                                     -- 發話人員名稱
			)
            AND (
                I_CALLING_CODE IS NULL																				-- 發話人員代號	    
                OR U.EMP_NO = I_CALLING_CODE                                                                      	-- 發話人員代號
			)
			AND (
                I_CALLED_NAME IS NULL																				-- 受話人員名稱	    
                OR B.CALLED_INFO LIKE ('%' || I_CALLED_NAME || '%')                                                 -- 受話人員名稱
			)
			AND (
                I_CALLED_CODE IS NULL																				-- 受話人員代號
                OR B.CALLED_ID = I_CALLED_CODE                                                                      -- 受話人員代號
			)
			AND (
				I_CALL_TYPE IS NULL                                                                                 -- 通話類型
				OR ((
					'01' = I_CALL_TYPE                                                                              -- 通話類型, 01: 撥入
					AND C.COND_CODE IN (                                                                            -- 來去電狀態碼
						'M',                                                                                        -- M: 外線進線(逾時)
						'9'                                                                                         -- 9: 外線進線
					)
				) OR (
					'01' = I_CALL_TYPE                                                                              -- 通話類型, 01: 撥入
					AND C.IN_TRUNK != ' '                                                                           -- 進線線路不為空白
					AND C.OUT_TRUNK = ' '                                                                           -- 外撥線路為空白
					AND C.COND_CODE IN (                                                                            -- 來去電狀態碼
						'C',                                                                                        -- C: 三方通話
						'4',                                                                                        -- 4: 逾10小時通話
						'6'                                                                                         -- 6: 記錄遺失
					)
				) OR (
					'02' = I_CALL_TYPE                                                                              -- 通話類型, 02: 撥出
					AND C.COND_CODE IN (                                                                            -- 來去電狀態碼
						'A',                                                                                        -- A: 分機外撥
						'B',                                                                                        -- B: 系統外撥
						'0',                                                                                        -- 0: 內線互撥
						'7'                                                                                         -- 7: 分機外撥(依系統表)
					)
				) OR (
					'02' = I_CALL_TYPE                                                                              -- 通話類型, 02: 撥出
					AND C.OUT_TRUNK != ' '                                                                          -- 外撥線路不為空白
					AND C.IN_TRUNK = ' '                                                                            -- 進線線路為空白
					AND C.COND_CODE IN (                                                                            -- 來去電狀態碼
						'C',                                                                                        -- C: 三方通話
						'4',                                                                                        -- 4: 逾10小時通話
						'6'                                                                                         -- 6: 記錄遺失
					) 
				) OR (
					'03' = I_CALL_TYPE                                                                              -- 通話類型, 03: 其他
					AND C.IN_TRUNK = ' '                                                                            -- 進線線路為空白
					AND C.OUT_TRUNK = ' '                                                                           -- 外撥線路為空白
					AND C.COND_CODE IN (                                                                            -- 來去電狀態碼
						'C',                                                                                        -- C: 三方通話
						'4',                                                                                        -- 4: 逾10小時通話
						'6'                                                                                         -- 6: 記錄遺失
					)
				) OR (
					'03' = I_CALL_TYPE                                                                              -- 通話類型, 03: 其他
					AND C.COND_CODE NOT IN (                                                                        -- 來去電狀態碼
						'A',                                                                                        -- A: 分機外撥
						'B',                                                                                        -- B: 系統外撥
						'C',                                                                                        -- C: 三方通話
						'M',                                                                                        -- M: 外線進線(逾時)
						'0',                                                                                        -- 0: 內線互撥
						'4',                                                                                        -- 4: 逾10小時通話
						'6',                                                                                        -- 6: 記錄遺失
						'7',                                                                                        -- 7: 分機外撥(依系統表)
						'9'                                                                                         -- 9: 外線進線
					) 
				))
			)
		ORDER BY
			C.CDR_STARTTIME DESC                                                                                    -- 通話時間
		;        		
        
        -- 2. 取得資料總筆數 -------------------------------------------------------------------------------------------
		O_TOTAL := CDR_RECORD_LIST.COUNT;																			-- 資料總筆數
		
		-- 3. 計算實際頁次 ---------------------------------------------------------------------------------------------
		O_PAGE_NO := GREATEST(LEAST(CEIL(O_TOTAL / I_PAGE_SIZE), I_PAGE_NO), 1);                                	-- 實際頁次

		-- 4. 取得分頁後的資料 -----------------------------------------------------------------------------------------
		OPEN O_DATA FOR																								-- 該頁資料
		SELECT			
            S.SYS_NM,                                                                                               -- 系統名稱
			A.SRC_FUNCNM,                                                                                           -- 通話來源名稱
			EPSP.PG_CORE.GET_CODE_NAME('EPSP', 17, A.CALL_STATUS, '') AS CALL_STATUS_NM,                            -- 撥號狀態, 17: 通話狀態
			EPSP.PG_CORE.FORMAT_TIME(TO_CHAR(A.CDR_STARTTIME, 'YYYYMMDDHH24MISS'), '001', '101') AS CDR_STARTTIME,  -- 通話時間, 001: YYYYMMDDHH24MISS, 101: YYYY/MM/DD HH24:MI:SS
			A.TOTAL_SECOND,                                                                                         -- 通話秒數
			A.CALLING_NUMBER,                                                                                       -- 發話號碼
			A.CALLED_NUMBERSRCFIELD,                                                                                -- 受話電話來源 
			A.CALLED_INFO,                                                                                          -- 受話者資訊
			A.CALLED_ID,                                                                                            -- 受話者鍵值
			
			CASE 
				WHEN A.EMP_NM IS NOT NULL 
				THEN A.EMP_NM || '(' || A.EMP_NO || ')'                                                             -- 員工姓名(員工編號)
			END AS USERID,
			
			CASE 
				WHEN EPSP.PG_CORE.GET_CODE_NAME('EPSP', 16, A.CALLED_NUMBERSRCFIELD, NULL) IS NOT NULL              -- 受話號碼(通話類別, 16: 通話類別)
				THEN A.CALLED_NUMBER || '(' 
					|| EPSP.PG_CORE.GET_CODE_NAME('EPSP', 16, A.CALLED_NUMBERSRCFIELD, NULL) || ')'                 -- 受話號碼(通話類別, 16: 通話類別)
			END AS CALLED_NUMBER
		FROM			
			TABLE(CDR_RECORD_LIST) A																				-- 交換機紀錄清單
			LEFT JOIN EIAM.TB_SYSTEM S ON S.SYS_ID = A.SRC_SYSID                                                    -- 系統資料表
		OFFSET (O_PAGE_NO - 1) * I_PAGE_SIZE ROWS																	-- 略過筆數，最小為0筆
		FETCH NEXT I_PAGE_SIZE ROWS ONLY																			-- 取後N筆資料
        ;
        
    END SP_QRY_CDR_DTL_LIST;

END PG_F050201;