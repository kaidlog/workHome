CREATE OR REPLACE PACKAGE BODY EPSP.PG_F030102 AS
-----------------------------------------------------------------
-- 個人備忘錄編輯                            	   	           --
-- @author ESB20447 by Esunbank                        	       --
-----------------------------------------------------------------
	/**
	 * 取得單筆個人/週期備忘錄
	 */
	FUNCTION FN_QRY_MEMO(
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO.MEMO_SEQ_NO%TYPE,                                                             -- 個人備忘錄管理主鍵
		I_AD_ACCOUNT IN EPSP.TB_MEMO.AD_ACCOUNT%TYPE                                                                -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN SYS_REFCURSOR                                                                                          -- 個人備忘錄管理清單
	AS
		O_RESULT SYS_REFCURSOR;                                                                                     -- 個人備忘錄管理清單
	BEGIN
		OPEN O_RESULT FOR
		SELECT		
			M.CONTENT_STATUS,                                                                                       -- 備忘錄內容狀態, DATASHARE.TB_SYS_CD.CD_ID, CT_ID=158
			M.MEMO_SEQ_NO,                                                                                          -- 主鍵
			M.CREATE_TIME,                                                                                          -- 資料建立時間
			M.UPDATE_TIME,                                                                                          -- 資料最後異動時間
			M.CREATOR,                                                                                              -- 資料建立人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT		
			M.UPDATER,                                                                                              -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT	
			M.AD_ACCOUNT,                                                                                           -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			M.MEMO_TYPE,                                                                                            -- 備忘錄類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=23
			EPSP.PG_CORE.FORMAT_DATE(M.START_DATE) AS START_DATE,                                                   -- 起始日期(YYYYMMDD)
			EPSP.PG_CORE.FORMAT_DATE(M.END_DATE) AS END_DATE,                                                       -- 結束日期(YYYYMMDD)
			M.OVERDUE_DAY,                                                                                          -- 逾期天數
			M.MEMO_LEVEL,                                                                                           -- 緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20
			M.SYS_ID,                                                                                               -- 系統代碼, Ref EIAM.TB_SYSTEM.SYS_ID
			M.FUNC_CODE,                                                                                            -- 來源功能代碼
			M.FUNC_NAME,                                                                                            -- 來源功能名稱
			M.MEMO_TITLE,                                                                                           -- 主旨
			M.MEMO_CONTENT,                                                                                         -- 內容
			M.URL,                                                                                                  -- 連結
			M.MEMO_CYCLE,                                                                                           -- 週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24
			M.WEEK_DAY,                                                                                             -- 週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45
			M.MONTH_DAY,                                                                                            -- 週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47
			M.YEAR_DAY                                                                                              -- 週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46
		FROM
			EPSP.TB_MEMO M                                                                                          -- 個人備忘錄管理
		WHERE
			M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                           -- 個人備忘錄管理主鍵
			AND M.AD_ACCOUNT = I_AD_ACCOUNT                                                                         -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		;
		
		RETURN O_RESULT;                                                                                            -- 個人備忘錄管理清單
		
	END FN_QRY_MEMO;

	/**
     * 更新個人備忘錄管理
     */
	FUNCTION FN_UPD_MEMO(
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO.MEMO_SEQ_NO%TYPE,                                                             -- 個人備忘錄管理主鍵	    	   	    
	    I_AD_ACCOUNT IN EPSP.TB_MEMO.AD_ACCOUNT%TYPE,                                                               -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT	    	  
	    I_START_DATE IN EPSP.TB_MEMO.START_DATE%TYPE,                                                               -- 起始日期(YYYYMMDD)
	    I_END_DATE IN EPSP.TB_MEMO.END_DATE%TYPE,                                                                   -- 結束日期(YYYYMMDD)
	    I_OVERDUE_DAY IN EPSP.TB_MEMO.OVERDUE_DAY%TYPE,                                                             -- 逾期天數
	    I_MEMO_LEVEL IN EPSP.TB_MEMO.MEMO_LEVEL%TYPE,                                                               -- 緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20	    
	    I_MEMO_TITLE IN EPSP.TB_MEMO.MEMO_TITLE%TYPE,                                                               -- 主旨
	    I_MEMO_CONTENT IN EPSP.TB_MEMO.MEMO_CONTENT%TYPE,                                                           -- 內容
	    I_URL IN EPSP.TB_MEMO.URL%TYPE,                                                                             -- 連結
	    I_MEMO_CYCLE IN EPSP.TB_MEMO.MEMO_CYCLE%TYPE,                                                               -- 週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24	    
	    I_WEEK_DAY IN EPSP.TB_MEMO.WEEK_DAY%TYPE,                                                                   -- 週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45	    
	    I_MONTH_DAY IN EPSP.TB_MEMO.MONTH_DAY%TYPE,                                                                 -- 週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47	    
	    I_YEAR_DAY IN EPSP.TB_MEMO.YEAR_DAY%TYPE                                                                    -- 週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46
	) RETURN NUMBER                                                                                                 -- 更新個人備忘錄管理筆數
	AS
	BEGIN
		UPDATE
			EPSP.TB_MEMO M                                                                                          -- 個人備忘錄管理
		SET
			M.UPDATE_TIME = SYSDATE,                                                                                -- 資料最後異動時間
			M.UPDATER = I_AD_ACCOUNT,                                                                               -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			M.AD_ACCOUNT = I_AD_ACCOUNT,                                                                            -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT	    			
			M.START_DATE = I_START_DATE,       																		-- 起始日期(YYYYMMDD)
			M.END_DATE = I_END_DATE,                                                               					-- 結束日期(YYYYMMDD)
			M.OVERDUE_DAY = I_OVERDUE_DAY,                                                     						-- 逾期天數
			M.MEMO_LEVEL = I_MEMO_LEVEL,                                                        					-- 緊急程度, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=20	    
			M.MEMO_TITLE = I_MEMO_TITLE,                                                         					-- 主旨
			M.MEMO_CONTENT = I_MEMO_CONTENT,                                                   						-- 內容
			M.URL = I_URL,                                                                             				-- 連結    
			M.MEMO_CYCLE = I_MEMO_CYCLE,                                                       						-- 週期, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=24	    
			M.WEEK_DAY = I_WEEK_DAY,                                                               					-- 週期-週幾, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=45	    
			M.MONTH_DAY = I_MONTH_DAY,                                                        						-- 週期-幾日, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=47	    
			M.YEAR_DAY = I_YEAR_DAY                                                             					-- 週期-幾月, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=46
		WHERE
			M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                           -- 個人備忘錄管理主鍵
			AND M.AD_ACCOUNT = I_AD_ACCOUNT                                                                         -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		;
	
		RETURN SQL%ROWCOUNT;                                                                                        -- 更新個人備忘錄管理筆數
		
	END FN_UPD_MEMO;

	/**
     * 更新個人備忘錄明細
     */
	FUNCTION FN_UPD_MEMO_DETAIL(	    
	    I_UPDATER IN EPSP.TB_MEMO_DETAIL.UPDATER%TYPE,                                                              -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	    I_MEMO_SEQ_NO IN EPSP.TB_MEMO_DETAIL.MEMO_SEQ_NO%TYPE,                                                      -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO	    
	    I_MEMO_NO IN EPSP.TB_MEMO_DETAIL.MEMO_NO%TYPE,                                                              -- 備忘錄週期編號	      
	    I_MEMO_STATUS IN EPSP.TB_MEMO_DETAIL.MEMO_STATUS%TYPE,                                                      -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CD_ID=26	     
	    I_OVERDUE_DATE IN EPSP.TB_MEMO_DETAIL.OVERDUE_DATE%TYPE                                                     -- 逾期時間(YYYYMMDDHH24MISS)
	) RETURN NUMBER                                                                                                 -- 更新個人備忘錄明細筆數
	AS
	BEGIN
		UPDATE
			EPSP.TB_MEMO_DETAIL MD                                                                                  -- 個人備忘錄明細
		SET
			MD.UPDATE_TIME = SYSDATE,                                                                               -- 資料最後異動時間
			MD.UPDATER = I_UPDATER,                                                                                 -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			MD.MEMO_STATUS = NVL(I_MEMO_STATUS, MD.MEMO_STATUS),                                                    -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CD_ID=26 
			MD.OVERDUE_DATE = I_OVERDUE_DATE                                                 						-- 逾期時間(YYYYMMDDHH24MISS) 
		WHERE
			MD.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                          -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
			AND MD.MEMO_NO = I_MEMO_NO                                                                              -- 備忘錄週期編號
			AND MD.MEMO_SEQ_NO = (                                                                                  -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
				SELECT																								-- 確保備忘錄的使用者才能異動該筆資料
					M.MEMO_SEQ_NO                                                                                   -- 個人備忘錄管理主鍵
				FROM
					EPSP.TB_MEMO M                                                                                  -- 個人備忘錄管理
				WHERE
					M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                   -- 個人備忘錄管理主鍵
					AND M.AD_ACCOUNT = I_UPDATER                                	                                -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			)																																							 
		;
		
		RETURN SQL%ROWCOUNT;                                                                                        -- 更新個人備忘錄明細筆數
		
	END FN_UPD_MEMO_DETAIL;

	/**
     * 更新個人備忘錄狀態
     */
	FUNCTION FN_UPD_MEMO_DETAIL_STATUS(
		I_MEMO_STATUS IN VARCHAR2,                                                                                  -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=26
		I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO		
		I_MEMO_NO IN NUMBER,                                                                                        -- 備忘錄週期編號
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN NUMBER                                                                                                 -- 更新個人備忘錄狀態筆數
	AS
	BEGIN
		UPDATE
			EPSP.TB_MEMO_DETAIL MD                                                                                  -- 個人備忘錄明細
		SET
			MD.UPDATE_TIME = SYSDATE,                                                                               -- 資料最後異動時間
			MD.UPDATER = I_AD_ACCOUNT,                                                                              -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			MD.MEMO_STATUS = I_MEMO_STATUS                                                                          -- 備忘錄狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=26
		WHERE
			MD.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                          -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
			AND MD.MEMO_NO = I_MEMO_NO                                                                              -- 備忘錄週期編號
			AND MD.MEMO_SEQ_NO = (                                                                                  -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
				SELECT																								-- 確保備忘錄的使用者才能異動該筆資料
					M.MEMO_SEQ_NO                                                                                   -- 個人備忘錄管理主鍵
				FROM
					EPSP.TB_MEMO M                                                                                  -- 個人備忘錄管理
				WHERE
					M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                   -- 個人備忘錄管理主鍵
					AND M.AD_ACCOUNT = I_AD_ACCOUNT                                                                 -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			)
		;

		RETURN SQL%ROWCOUNT;                                                                                        -- 更新個人備忘錄狀態筆數
		
	END FN_UPD_MEMO_DETAIL_STATUS;
	
	/**
     * 註銷週期備忘錄
     */
	FUNCTION FN_CANCEL_MEMO(
		I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 個人備忘錄管理主鍵
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN NUMBER                                                                                                 -- 註銷週期備忘錄筆數
	AS
	BEGIN
		UPDATE
			EPSP.TB_MEMO M                                                                                          -- 個人備忘錄管理
		SET
			M.UPDATE_TIME = SYSDATE,                                                                                -- 資料最後異動時間
			M.UPDATER = I_AD_ACCOUNT,                                                                               -- 資料最後異動人員帳號, Ref EIAM.TB_USER.AD_ACCOUNT	 
			M.CONTENT_STATUS = '02'                                                                                 -- 備忘錄內容狀態, 02: 已註銷
		WHERE
			M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                           -- 個人備忘錄管理主鍵
			AND M.AD_ACCOUNT = I_AD_ACCOUNT                                                                         -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		;
		
		RETURN SQL%ROWCOUNT;                                                                                        -- 註銷週期備忘錄筆數
		
	END FN_CANCEL_MEMO;

	/**
     * 中止週期備忘錄明細
     */
	FUNCTION FN_CANCEL_MEMO_DETAIL(
		I_MEMO_SEQ_NO IN VARCHAR2,                                                                                  -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
		I_AD_ACCOUNT IN VARCHAR2,                                                                                   -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
		I_CANCEL_ALL IN VARCHAR2                                                                                    -- 註銷型態
	) RETURN NUMBER                                                                                                 -- 中止週期備忘錄明細筆數
	AS
		V_TODAY VARCHAR2(8) := TO_CHAR(SYSDATE, 'YYYYMMDD');                                                        -- 今日(YYYYMMDD)
	BEGIN
		UPDATE EPSP.TB_MEMO_DETAIL MD                                                                               -- 個人備忘錄明細
		SET
			MD.UPDATE_TIME = SYSDATE,                                                                               -- 資料最後異動時間
			MD.UPDATER = I_AD_ACCOUNT,                                                                              -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			MD.MEMO_STATUS = '03'                                                                         			-- 備忘錄狀態, 03: 已註銷
		WHERE
			MD.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                          -- 個人備忘錄SEQ_NO, Ref EPSP.TB_MEMO.SEQ_NO
			AND MD.MEMO_SEQ_NO = (
				SELECT																								-- 確保備忘錄的使用者才能異動該筆資料
					M.MEMO_SEQ_NO                                                                                   -- 個人備忘錄管理主鍵
				FROM
					EPSP.TB_MEMO M                                                                                  -- 個人備忘錄管理
				WHERE
					M.MEMO_SEQ_NO = I_MEMO_SEQ_NO                                                                   -- 個人備忘錄管理主鍵
					AND M.AD_ACCOUNT = I_AD_ACCOUNT                                                                 -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			)
			AND (
				'Y'	= I_CANCEL_ALL 																					-- Y: 是否全部註銷
				OR (
					V_TODAY < MD.NOTIFY_DATE                                                   						-- 註銷通知日期今日以後備忘錄
				)
			)
		;
		
		RETURN SQL%ROWCOUNT;                                                                                        -- 中止週期備忘錄明細筆數

	END FN_CANCEL_MEMO_DETAIL;
	
END PG_F030102;