CREATE OR REPLACE PACKAGE EPSP.PG_F010101 AS                                                                         
-----------------------------------------------------------------                                                    
-- 功能總覽服務服務                  	   	       			   --                                                    
-- @author ESB19350 by Esunbank                        	   	   --                                                    
-----------------------------------------------------------------   
    /**
	 * 取得自訂通訊錄筆數
	 */    
    FUNCTION FN_QRY_USER_DIRECTORY_NUM(
        I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
    ) RETURN NUMBER;     																							-- 自訂通訊錄筆數                                                                                            
	
    /**
	 * 取得進行中, 已逾期個人備忘錄筆數清單
	 */
 	FUNCTION FN_QRY_MEMO_NUM(
        I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	) RETURN SYS_REFCURSOR;																							-- 備忘錄筆數清單																		
	
END PG_F010101;                                                                                                      