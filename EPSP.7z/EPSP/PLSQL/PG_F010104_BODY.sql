CREATE OR REPLACE PACKAGE BODY EPSP.PG_F010104 AS                                                                             
-----------------------------------------------------------------                                                   
-- 我的最愛服務查詢服務             	   	       			   --                                                   
-- @author ESB19350 by Esunbank                        	   	   --                                                   
-----------------------------------------------------------------       
	/**                                                                                                               
	 * 查詢我的最愛清單                                                                                                 
	 */                                                                                                              
	FUNCTION FN_QRY_USER_BOOKMARK_LIST(
		I_AD_ACCOUNT IN VARCHAR2                                                                                    -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
	)
	RETURN SYS_REFCURSOR                                                                                            -- 我的最愛清單
	AS   
		O_RESULT SYS_REFCURSOR;                                                                                     -- 查詢結果
	BEGIN                                                                                                           
		OPEN O_RESULT FOR                                                                                           -- 該頁資料
		SELECT				                                                                                        
			UB.MENU_SEQ_NO,																							-- 主鍵
			R.RSRC_NM AS RESOURCE_NAME,                                                                             -- 資源名稱
			S.URL || R.RSRC_URI AS URI,                                                                             -- 資源URI                          
			UB.BOOKMARK_SORT                                                                                        -- 排序
		FROM                                                                                                        
			EPSP.TB_USER_BOOKMARK UB                                                                                -- 我的最愛表單
			INNER JOIN EIAM.TB_MENU M ON M.MENU_SEQ_NO = UB.MENU_SEQ_NO                                             -- 選單資料表
			INNER JOIN EIAM.TB_RESOURCE R ON M.RESOURCE_SEQ_NO = R.RESOURCE_SEQ_NO                                  -- 資源表
			INNER JOIN EIAM.TB_SYSTEM S ON S.SYS_ID = R.SYS_ID                                                      -- 系統資料表
		WHERE
			UB.AD_ACCOUNT = I_AD_ACCOUNT                                                                            -- 使用者AD帳號, Ref EIAM.TB_USER.AD_ACCOUNT
			AND R.RSRC_STS = 'A'																					-- 資源狀態, A: 啟用
			AND S.SYS_STS = 'A'																						-- 系統狀態, A: 啟用
		ORDER BY 
			UB.BOOKMARK_SORT																						-- 排序
		;           

		RETURN O_RESULT;                                                                                            -- 我的最愛清單
                                                                                                   
	END FN_QRY_USER_BOOKMARK_LIST;
	
END PG_F010104;
