CREATE OR REPLACE PACKAGE EPSP.PG_F050201 AS 
-----------------------------------------------------------------
-- 交換機紀錄查詢                            	   	           --
-- @author ESB20447 by Esunbank                        	   	   --
-----------------------------------------------------------------
    -- 交換機紀錄
	TYPE TO_CDR_RECORD IS RECORD(
		CALL_STATUS TPS.TPS_DTL.CALL_STATUS%TYPE,                                                                   -- 撥號狀態
		USERID TPS.TPS_DTL.USERID%TYPE,                                                                             -- 發話人員
		CALLED_ID TPS.TPS_DTL.CALLED_ID%TYPE,                                                                       -- 受話者鍵值
		CALLED_INFO TPS.TPS_DTL.CALLED_INFO%TYPE,                                                                   -- 受話者資訊
		CALLED_NUMBERSRCFIELD TPS.TPS_DTL.CALLED_NUMBERSRCFIELD%TYPE,                                               -- 受話電話來源
		SRC_SYSID TPS.TPS_DTL.SRC_SYSID%TYPE,                                                                       -- 來源系統別
		SRC_FUNCNM TPS.TPS_DTL.SRC_FUNCNM%TYPE,                                                                     -- 來源功能名稱
		CDR_STARTTIME TPS.CDR_DTL.CDR_STARTTIME%TYPE,                                                               -- 通話起始時間
		TOTAL_SECOND TPS.CDR_DTL.TOTAL_SECOND%TYPE,                                                                 -- 通話秒數
		CALLING_NUMBER TPS.CDR_DTL.CALLING_NUMBER%TYPE,                                                             -- 發話號碼
		CALLED_NUMBER TPS.CDR_DTL.CALLED_NUMBER%TYPE,                                                               -- 受話號碼
		EMP_NO EIAM.TB_USER.EMP_NO%TYPE,                                                                            -- 員工編號
		EMP_NM EIAM.TB_USER.EMP_NM%TYPE                                                                             -- 員工姓名
    );
	
	-- 交換機紀錄清單
    TYPE TT_CDR_RECORD_LIST IS TABLE OF TO_CDR_RECORD;
    
	/**
     * 交換機通話紀錄查詢
     */
    PROCEDURE SP_QRY_CDR_DTL_LIST(
        -- 查詢條件 ----------------------------------------------------------------------------------------------------
		I_CALL_TYPE IN VARCHAR2,                                                                                    -- 通話類型
		I_START_DATE IN VARCHAR2,                                                                                   -- 通話日期(起)
		I_END_DATE IN VARCHAR2,                                                                                     -- 通話日期(迄)
		I_CALLING_NAME IN VARCHAR2,                                                                                 -- 發話人員名稱
		I_CALLING_CODE IN VARCHAR2,                                                                                 -- 發話人員代碼
		I_CALLING_NUMBER IN VARCHAR2,                                                                               -- 發話號碼
		I_CALLED_NAME IN VARCHAR2,                                                                                  -- 受話人員名稱
		I_CALLED_CODE IN VARCHAR2,                                                                                  -- 受話人員代碼
		I_CALLED_NUMBER IN VARCHAR2,                                                                                -- 受話號碼
		-- 分頁排序條件 ------------------------------------------------------------------------------------------------
		I_PAGE_NO IN NUMBER,                                                                                        -- 查詢第幾頁資料
		I_PAGE_SIZE IN NUMBER,                                                                                      -- 一頁顯示幾筆
		-- 輸出結果 ----------------------------------------------------------------------------------------------------
        O_TOTAL OUT NUMBER,																							-- 輸出查詢總筆數
		O_PAGE_NO OUT NUMBER,                                                                                       -- 輸出實際頁次
		O_DATA OUT SYS_REFCURSOR																					-- 輸出該頁資料
    );

END PG_F050201;