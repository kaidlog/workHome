package projectTest2;

public interface PetSportCenter {
	
	public void bark();
	public void eat();
	public void takeShower();
	public void drink();
	public void sleep();
	
}
