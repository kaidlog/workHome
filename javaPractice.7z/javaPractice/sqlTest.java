
package projectTest2;

import java.io.File;
import java.security.Security;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.UUID;

import org.apache.commons.codec.binary.Hex;
import org.json.JSONArray;
import org.json.JSONObject;

//import com.itextpdf.io.IOException;
//import com.itextpdf.kernel.crypto.CryptoUtil;
//import com.yankey.ezpayment.core.c;

import esunbank.esunutil.CommonAPI;
import esunbank.esunutil.StringUtil;
import esunbank.esunutil.cacheServer.CacheServerUtil;
import esunbank.esunutil.crypt.CryptUtil;
import esunbank.esunutil.db.DBUtil;
import esunbank.esunutil.info.HostInfoUtil;
import esunbank.esunutil.info.MailUtil;
import esunbank.esunutil.io.LogUtil;
import esunbank.esunutil.io.ssl.RestfulUtil;

public class sqlTest {
	static {
//		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}

	public static void main(String[] args) throws Exception {
		System.out.println(UUID.randomUUID());
//		Connection connection = null;
//		PreparedStatement ps = null;
//		try {
//			connection = new DBUtil().getSQLConn("172.19.246.21", "1433", "TestDB", "sa", "131313");
//			System.out.println(connection.isClosed());
//			String sql = "exec [dbo].[InsertAAAA] ?,?,?,?";
//			
//			
//			ps = connection.prepareStatement(sql);
//			ps.setInt(1, UUID.randomUUID().variant());
//			ps.setString(2, "pipi");
//			ps.setString(3, "Y");
//			ps.setString(4, "heyhey");
//			ps.execute();
//			
//			
//			
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.out.println(e.getMessage());
//			System.out.println(e.getLocalizedMessage());
//			System.out.println(e.getMessage().contains("is not a JSONArray."));
//		} finally {
//			if (ps != null) {
//				ps.close();
//			}
//			if (connection != null) {
//				connection.close();
//			}
//		}
	}

}
