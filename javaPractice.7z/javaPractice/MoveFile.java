public class MoveFile 

{
	public static void main(String[] args) 
	{
		try {
			File afile = new File("C://zuidaima_com_a//zuidaima_com.txt");
			if (afile.renameTo(new File("C://zuidaima_com_b//" + afile.getName()))) 
			{
				System.out.println("File is moved successful!");
			} 
			else 
			{
				System.out.println("File is failed to move!");
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}