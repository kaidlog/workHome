package projectTest2;

public class Dog  extends Pet implements PetSportCenter {
	public Dog(String name, String size, String HostName) {
		super(name, size, HostName);
	}
	
	@Override
	public void bark() {
		System.out.printf("woo");
	}
	
	@Override
	public void eat() {
		System.out.printf("eat");
	}
	
	@Override
	public void takeShower(){
		System.out.printf("bath");
	}
	
	@Override
	public void drink() {
		System.out.printf("drink");
	}
	
	@Override
	public void sleep() {
		System.out.printf("sleep");
	}

}
