package projectTest2;
import java.util.Arrays;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException  {
		
		// �ŧi�Ŷ��x�s
		
		ArrayList<Integer> petId = new ArrayList<Integer>();
		ArrayList<String> name = new ArrayList<String>();
		ArrayList<String> size = new ArrayList<String>();
		ArrayList<String> hostName = new ArrayList<String>();
		
		int dataId = 1;
		int searchIndex = 0;
		
		// �ϥΪ̶i�ӥ�
		Scanner input = new Scanner(System.in);
		
		while(true){
			// �i�Ӥ�����X�{���۩I
			
			System.out.println("Welcom to PetShop");
			System.out.println("Name afteryour pet");
			System.out.println("What do you want to do?");
			System.out.println("1. Name after your pet");
			System.out.println("2. Search your pet");
			System.out.println("3. Export your data");
			System.out.println("4. End");
			int index = input.nextInt();
			
			//�ϥΪ̰����
			
			//�s�W�d�����
			//�m�W���i����
			
			if (index == 1) {
			    System.out.println("Name after your pet");
				String NamePet = input.next();
				System.out.println("Master's name?");
				String HostName = input.next();
				System.out.println("Input sizes of the pet");
				String SizePet = input.next();
				
				Pet pet = new Pet(NamePet, HostName, SizePet);
				
				petId.add(dataId);
				name.add(NamePet);
				hostName.add(HostName);
				size.add(SizePet);
				System.out.println("�Ȥ�w�s�W�@�����");
				System.out.println("��Ʀp�U");
				System.out.println(1);
				System.out.println(NamePet);
				System.out.println(HostName);
				System.out.println(SizePet);
				
				dataId++;
				
			}
			
			
			// �j�M�d�����
			if (index == 2) {
				System.out.println("�п�J�d���W�r!");
				String nameTmp = input.next();
				
				System.out.println(name.indexOf(nameTmp));
				
				searchIndex = name.indexOf(nameTmp);
				
				
				System.out.println(petId.get(searchIndex));
				System.out.println(name.get(searchIndex));
				System.out.println(size.get(searchIndex));
				System.out.println(hostName.get(searchIndex));
				
				
			}
			
			// ���ƶץX ��r��
			if (index == 3) {
//				System.out.println("��Ʈw��ƥ��b�ǳƶץX");
//				
//				File file=new File(".");
//				String path=file.getAbsolutePath();
//				path=file.getPath();
//				
//				
//				FileWriter fw = new FileWriter(path);
//				fw.write("this is test sentence ");
//				fw.flush();
//				fw.close();
			}
		
		
		
		}
	}
}
