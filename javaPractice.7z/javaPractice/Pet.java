package projectTest2;

public class Pet {

	private String name;
	private String size;
	private String HostName;

	public Pet(String name, String size, String HostName) {
		super();
		this.name = name;
		this.size = size;
		this.HostName = HostName;
	}
	
	public void setName(String newName) {
		name = newName;
	}
	
	public String getName() {
		return name;
	}
	
	
	public void setSize(String size) {
		this.size = size;
	}
	
	public String getSize() {
		return size;
	}
	
	public void setHostName(String HostName) {
		this.HostName = HostName;
	}
	
	public String getHostName() {
		return HostName;
	}

}
