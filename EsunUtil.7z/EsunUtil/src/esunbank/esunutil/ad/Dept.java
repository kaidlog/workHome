package esunbank.esunutil.ad;

public class Dept {

	private String DEPT_CODE;

	private String DEPT_OU;

	private String DEPT_INFO;

	private String DESC_Content;

	private int DataOrder;

	private boolean isUnlockAvalible;

	public boolean isUnlockAvalible() {
		return isUnlockAvalible;
	}

	public void setUnlockAvalible(boolean isUnlockAvalible) {
		this.isUnlockAvalible = isUnlockAvalible;
	}

	public String getDEPT_OU() {
		return DEPT_OU;
	}

	public void setDEPT_OU(String dEPT_OU) {
		DEPT_OU = dEPT_OU;
	}

	public String getDEPT_CODE() {
		return DEPT_CODE;
	}

	public void setDEPT_CODE(String dEPT_CODE) {
		DEPT_CODE = dEPT_CODE;
	}

	public String getDEPT_INFO() {
		return DEPT_INFO;
	}

	public void setDEPT_INFO(String dEPT_INFO) {
		DEPT_INFO = dEPT_INFO;
	}

	public String getDESC_Content() {
		return DESC_Content;
	}

	public void setDESC_Content(String dESC_Content) {
		DESC_Content = dESC_Content;
	}

	public int getDataOrder() {
		return DataOrder;
	}

	public void setDataOrder(int dataOrder) {
		DataOrder = dataOrder;
	}

}
