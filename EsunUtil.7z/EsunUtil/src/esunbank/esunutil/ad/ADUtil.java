package esunbank.esunutil.ad;
 
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.ResourceBundle;
 
import esunbank.esunutil.info.HostInfoUtil;
import esunbank.esunutil.io.ssl.SSLUtil;
 
public class ADUtil {
 
    private static final String ssoHost = ResourceBundle.getBundle("esunbank.esunutil.config").getString("ssoHost");
 
    private static final String ssoPortal = ResourceBundle.getBundle("esunbank.esunutil.config").getString("ssoPortal");
 
    private static final String infoGroup = ResourceBundle.getBundle("esunbank.esunutil.config").getString("HostInfoSystemGroup");
 
    private static final String defaultIDField = "sid";
 
    private static final String defaultNameField = "sname";
 
    private static final String defaultImage = "<img src=\"" + ssoHost + "/ADMag/image/calSel.gif\">";
 
    public static final String singleSelected = "radio"; // ���o�h�HAD �b�� - ���
 
    public static final String multiSelected = "checkbox"; // ���o�h�HAD �b�� - �h��
 
    /**
     * ���oAD�C��
     */
    public String getADMenu() {
        return getADMenu(defaultIDField, defaultNameField, defaultImage, "");
    }
 
    /**
     * ���oAD�C��(�ۭqID���W�١BNAME���W��)
     * 
     * @param idField
     *            ID���W��
     * @param nameField
     *            NAME���W��
     */
    public String getADMenu(String idField, String nameField) {
        return getADMenu(idField, nameField, defaultImage, "");
    }
 
    /**
     * ���oAD�C��(�ۭq����/��r)
     * 
     * @param imageField
     *            ����/��r���e(EX:<img src="../image/image.jpg">)
     */
    public String getADMenu(String imageField) {
        return getADMenu(defaultIDField, defaultNameField, imageField, "");
    }
 
    /**
     * ���oAD�C��(�ۭqID���W�١BNAME���W�١B�B�~���檺�ʧ@)
     * 
     * @param idField
     *            ID���W��
     * @param nameField
     *            NAME���W��
     * @param customWork
     *            �ۭq���U��ܫ��s���B�~���檺�ʧ@
     */
    public String getADMenu(String idField, String nameField, String customWork) {
        return getADMenu(idField, nameField, defaultImage, customWork);
    }
 
    /**
     * ���oAD�C��(�ۭqID���W�١BNAME���W�١B�ι���/��r�B�B�~���檺�ʧ@)
     * 
     * @param idField
     *            ID���W��
     * @param nameField
     *            NAME���W��
     * @param imageField
     *            ����/��r���e(EX:<img src="../image/image.jpg">)
     * @param customWork
     *            �ۭq���U��ܫ��s���B�~���檺�ʧ@
     */
    public String getADMenu(String idField, String nameField,
            String imageField, String customWork) {
        String rslt = "<script type=text/javascript>"
                + "var flag = 1;"
                + "function chgmode(event){"
                + "var plane0DOM = document.getElementById('plane0');"
                + "plane0DOM.style.top = document.documentElement.scrollTop + event.clientY + 2 + 'px';"
                + "plane0DOM.style.left = document.documentElement.scrollLeft + event.clientX + 2 + 'px';"
                + "if(flag == 1){plane0DOM.style.visibility='visible';flag = 2;"
                + "}else if(flag == 2){plane0DOM.style.visibility='hidden';flag = 1;}}"
                + "function getGrpData(){"
                + "clrGrpData();"
                + "var selGrpDOM = document.getElementById('selGrp');"
                + "selGrpDOM.disabled = true;"
                + "var selGrpDOMValue = selGrpDOM.options[selGrpDOM.selectedIndex].value;"
                + "if(selGrpDOMValue == '0'){selGrpDOM.disabled = false;return;}"
                + "var url = '"
                + ssoHost
                + "/ADMag/ADGetData?selGrp=' + selGrpDOMValue;"
                + "if(window.XMLHttpRequest){req = new XMLHttpRequest();"
                + "}else if(window.ActiveXObject){req = new ActiveXObject('Microsoft.XMLHTTP');}"
                + "req.open('GET', url, true);"
                + "req.onreadystatechange = callback;"
                + "req.send(null);}"
                + "function callback(){"
                + "if(req.readyState == 4){"
                + "if(req.status == 200){parseMessage();"
                + "}else{alert('AJAX Process Failed ! ' + req.status);"
                + "document.getElementById('selGrp').disabled = false;}}}"
                + "function parseMessage(){"
                + "var selGrpDOM = document.getElementById('selGrp');"
                + "if(req.responseXML.getElementsByTagName('size')[0] == null){"
                + "alert('�d�L���');"
                + "selGrpDOM.disabled = false;"
                + "return;}"
                + "var size = req.responseXML.getElementsByTagName('size')[0].firstChild.data;"
                + "var trDOM = document.getElementById('mySelTr');"
                + "var td = document.createElement('td');"
                + "td.id = 'dataTd';"
                + "var txt = document.createElement('select');"
                + "txt.id = 'dataSel';"
                + "if(parseInt(size, 10) > 0){"
                + "txt.options[0] = new Option;"
                + "txt.options[0].value = '0';"
                + "txt.options[0].text = '�п��';"
                + "}else if(parseInt(size, 10) == 0 ){"
                + "alert('�d�L���');"
                + "selGrpDOM.disabled = false;"
                + "return;}"
                + "for(var i = 0; i < parseInt(size, 10); i++ ){"
                + "var userID = req.responseXML.getElementsByTagName('userID')[i].firstChild.data;"
                + "var userName = req.responseXML.getElementsByTagName('userName')[i].firstChild.data;"
                + "var userHName = req.responseXML.getElementsByTagName('userHName')[i].firstChild.data;"
                + "txt.options[i+1] = new Option;"
                + "txt.options[i+1].value = userID + ',' + userName + ',' + userHName;"
                + "txt.options[i+1].text = userID + '(' + userName + ')';}"
                + "if(parseInt(size, 10) > 0){td.appendChild(txt);trDOM.appendChild(td);}"
                + "selGrpDOM.disabled = false;}"
                + "function setData(){"
                + "var selGrpDOM = document.getElementById('selGrp');"
                + "if(selGrpDOM.options[selGrpDOM.selectedIndex].value == 0){alert('�п�ܲէO');return;}"
                + "var dateSelDOM = document.getElementById('dataSel');"
                + "var selValue = '';"
                + "if(dateSelDOM == null || (selValue = dateSelDOM.options[dateSelDOM.selectedIndex].value) == '0'){"
                + "alert('�п�ܤH��');return;}"
                + "var tid = selValue.substring(0,selValue.indexOf(','));"
                + "var tname = selValue.substring(selValue.indexOf(',') + 1, selValue.lastIndexOf(','));"
                + "setOutsideField('"
                + idField
                + "', tid);"
                + "setOutsideField('"
                + nameField
                + "', tname);"
                + customWork
                + "document.getElementById('plane0').style.visibility='hidden';"
                + "flag = 1;}"
                + "function clrGrpData(){"
                + "var trDOM = document.getElementById('mySelTr');"
                + "var dataTdDOM = document.getElementById('dataTd');"
                + "if(dataTdDOM != null){trDOM.removeChild(dataTdDOM);}}"
                + "function setOutsideField(field, value){"
                + "var fieldDOM = document.getElementById(field);"
                + "if(fieldDOM != null){fieldDOM.value = value;"
                + "}else{fieldDOM = document.getElementsByName(field);fieldDOM[0].value = value;}}"
                + "</script>"
                + "<span id=\"mySpan\" onclick=\"chgmode(event)\">"
                + imageField
                + "</span>"
                + "<div id=\"plane0\" style=\"visibility:hidden;position:absolute;"
                + "top:0px;left:0px;width:330px;height:100px;border:0px;background-color:white;\">"
                + "<table style=\"background-color:#53A8DA;margin-left:auto;margin-right:auto;text-align:center\""
                + "cellpadding=\"3\" cellspacing=\"1\" border=\"0\">"
                + "<tr><td style=\"width:330px;height:100px;background-color:#B4E1F0\" align=\"center\">"
                + "<table><tr id=\"mySelTr\"><td>"
                + "<select id=\"selGrp\" onchange=\"getGrpData()\">"
                + "<option value=\"0\">�п�ܲէO</option>";
 
        ArrayList<Dept> deptList = getDeptList();
        for (int i = 0; i < deptList.size(); i++) {
            rslt = rslt + "<option value=\"" + deptList.get(i).getDEPT_CODE()
                    + "\">" + deptList.get(i).getDEPT_INFO() + "</option>";
        }
 
        rslt = rslt
                + "</select>&nbsp;</td></tr></table><p>"
                + "<input type=\"button\" class=\"button\" value=\"���\" onclick=\"setData()\">"
                + "<input type=\"button\" class=\"button\" value=\"����\" onclick=\"chgmode(event)\"></td></tr></table></div>";
        return rslt;
    }
 
    public boolean getLoginChecker(String strId, String strPassword) {
        HttpURLConnection urlConn = null;
        OutputStreamWriter outStrm = null;
        InputStream inStrm = null;
        try {
            if (strId == null || strId.equals("") || strPassword == null
                    || strPassword.equals("")) {
                throw new Exception("�b���αK�X��NULL�Ϊť�");
            }
             
            String pars = "strId=" + strId + "&strPassword=" + URLEncoder.encode(strPassword, "UTF-8");
 
            urlConn = SSLUtil.getHttpURLConnection(ssoHost + "/ADMag/authMag/adLoginChecker.jsp");
            urlConn.setRequestMethod("POST");
            urlConn.setDoOutput(true);
            urlConn.setDoInput(true);
             
            outStrm = new OutputStreamWriter(urlConn.getOutputStream());
            outStrm.write(pars);
            outStrm.flush();
             
            inStrm = urlConn.getInputStream();
            byte[] rslt = new byte[urlConn.getContentLength()];
            inStrm.read(rslt);
            // ���o�^�ǵ��G
            String result = new String(rslt).trim();
            // �ѪR�^�ǵ��G
            if (result.equals("TRUE")) {
                return true;
            } else if (result.equals("FALSE")) {
                return false;
            } else {
                throw new Exception("���ݱb�����Ҹ�Ʀ^�ǲ��`" + result);
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                new HostInfoUtil().sendMailToGroupUser(infoGroup,
                        "����AD�b���n�J�o�Ϳ��~", e.toString());
            } catch (Exception ex) {
 
            }
            return false;
        } finally {
            try {
                outStrm.close();
            } catch (Exception e) {
            }
            try {
                inStrm.close();
            } catch (Exception e) {
            }
            try {
                urlConn.disconnect();
            } catch (Exception e) {
            }
        }
    }
 
    public ArrayList<Dept> getDeptList() {
        HttpURLConnection urlConn = null;
        InputStream inStrm = null;
        ArrayList<Dept> deptList = new ArrayList<Dept>();
        try {
            // �s��
            String pars = "/ADMag/GetDeptList";
            urlConn = SSLUtil.getHttpURLConnection(ssoHost + pars);
            urlConn.setRequestMethod("POST");
            urlConn.setDoOutput(true);
            urlConn.setDoInput(true);
             
            inStrm = urlConn.getInputStream();
            byte[] rslt = new byte[urlConn.getContentLength()];
            inStrm.read(rslt);
            // ���o�^�ǵ��G
            String[] deptListRslt = new String(rslt).trim().split("[#][|]");
            for (int i = 0; i < deptListRslt.length; i++) {
                String[] tmp = deptListRslt[i].split(",");
                Dept dept = new Dept();
                dept.setDEPT_CODE(tmp[0]);
                dept.setDEPT_OU(URLDecoder.decode(tmp[1], "UTF-8"));
                dept.setDEPT_INFO(URLDecoder.decode(tmp[2], "UTF-8"));
                dept.setDataOrder(Integer.parseInt(tmp[3]));
                dept.setUnlockAvalible(tmp[4].equals("Y"));
                deptList.add(dept);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                inStrm.close();
            } catch (Exception e) {
            }
            try {
                urlConn.disconnect();
            } catch (Exception e) {
            }
        }
        return deptList;
    }
 
    /**
     * ���o�h�HAD �b��
     * 
     * @author Roger
     * @param getID
     *            ID
     * @param getName
     *            Name
     * @param getEmpNo
     *            ���u�s��
     * @param getDivList
     *            DIV ��ܿ�ܪ��b��
     * @param getAct
     *            ���Φh��
     * @param getDept
     *            �����Ѽ�
     * @return String
     */
    public String getMutiADMenu(String getID, String getName, String getEmpNo,
            String getDivList, String getAct, String getDept) {
        return getMutiADMenu(getID, getName, getEmpNo, getDivList, getAct,
                getDept, defaultImage);
    }
 
    /**
     * ���o�h�HAD �b��
     * 
     * @author Roger
     * @param getID
     *            ID
     * @param getName
     *            �m�W
     * @param getEmpNo
     *            ���u�s��
     * @param getDivList
     *            DIV ��ܿ�ܪ��b��
     * @param getAct
     *            ���Φh��
     * @param getDept
     *            �����Ѽ�
     * @param imageField
     *            ����/��r���e (EX:<img src="../image/image.jpg">)
     * @return String
     */
    public String getMutiADMenu(String getID, String getName, String getEmpNo,
            String getDivList, String getAct, String getDept, String imageField) {
        String rslt = " <script type=text/javascript> "
                + " function showDialog(event) { "
                + "var selectedAD = document.getElementById(\""
                + getID
                + "\").value; "
                + "window.open('"
                + ssoPortal
                + "/EsunSSO/authMag/GetMoreUserInfo.jsp?"
                + "getCol1="
                + getID
                + "&getCol2="
                + getName
                + "&getCol3="
                + getEmpNo
                + "&getCol4="
                + getDivList
                + "&getSelect=' + selectedAD + '&getAct="
                + getAct
                + "&getDept="
                + getDept
                + "', '_blank','toolbar=no,scrollbars=1,Width=700px,Height=500px,menubar=no,status=no'); }"
                + " </script>"
                + "<span id=\"mySpan\" onclick=\"showDialog(event)\">"
                + imageField + "</span>";
        return rslt;
    }
}