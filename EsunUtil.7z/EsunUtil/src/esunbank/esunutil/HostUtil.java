package esunbank.esunutil;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ResourceBundle;

public class HostUtil {

	/**
	 * @param args
	 * @throws Exception
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(HostUtil.getHostName("ACQ"));
		System.out.println(HostUtil.getISSBakupHost());
		System.out.println(HostUtil.getACQHost());
		System.out.println(HostUtil.getACQBakupHost());
		System.out.println(HostUtil.getHRHost());
		new HostUtil().sendBreakMsg("ISS", "", "����MSG");
	}

	// private static final ResourceBundle config = ResourceBundle
	// .getBundle("esunbank.esunutil.config");
	// private static final String iss = config.getString("Host_ISS");
	// private static final String acq = config.getString("Host_ACQ");
	// private static final String issb = config.getString("Host_ISSB");
	// private static final String acqb = config.getString("Host_ACQB");
	// private static final String hr = config.getString("Host_HR");

	private static String iss = null;

	private static String acq = null;

	private static String issb = null;

	private static String acqb = null;

	private static String hr = null;

	static {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			File hostConfig = new File("D:\\host.config");
			if (!hostConfig.isFile()
					&& !(hostConfig = new File("C:\\host.config")).isFile()) {
				throw new Exception("�d�L�Ѽ���:" + hostConfig.getAbsolutePath());
			}

			fr = new FileReader(hostConfig);
			br = new BufferedReader(fr);
			String data = "";
			while ((data = br.readLine()) != null) {
				if (data.toUpperCase().startsWith("HOST_ISS=")) {
					iss = data.substring(9, data.length()).trim();
				} else if (data.toUpperCase().startsWith("HOST_ISSB=")) {
					issb = data.substring(10, data.length()).trim();
				} else if (data.toUpperCase().startsWith("HOST_ACQ=")) {
					acq = data.substring(9, data.length()).trim();
				} else if (data.toUpperCase().startsWith("HOST_ACQB=")) {
					acqb = data.substring(10, data.length()).trim();
				} else if (data.toUpperCase().startsWith("HOST_HR=")) {
					hr = data.substring(8, data.length()).trim();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (Exception ex) {
			}
			try {
				fr.close();
			} catch (Exception ex) {
			}
		}
	}

	/**
	 * �o�d��B�D���O�W
	 */
	public static final String issShortName = "ISS";

	/**
	 * �o�d�ƴ��D���O�W
	 */
	public static final String issShortName_Bak = "ISSB";

	/**
	 * ������B�D���O�W
	 */
	public static final String acqShortName = "ACQ";

	/**
	 * ����ƴ��D���O�W
	 */
	public static final String acqShortName_Bak = "ACQB";

	/**
	 * �H�ƥD���O�W
	 */
	public static final String hrShortName = "HR";

	/**
	 * �̥D���W�٨��oHostName
	 */
	public static final String getHost(String shortName) {
		if (shortName.equals(issShortName)) {
			return getISSHost();
		} else if (shortName.equals(acqShortName)) {
			return getACQHost();
		} else if (shortName.equals(hrShortName)) {
			return getHRHost();
		} else if (shortName.equals(issShortName_Bak)) {
			return getISSBakupHost();
		} else if (shortName.equals(acqShortName_Bak)) {
			return getACQBakupHost();
		} else {
			return null;
		}
	}

	/**
	 * �̥D���W�٨��o��ܦW��
	 */
	public static final String getHostName(String shortName) {
		if (shortName.equals(issShortName)) {
			return "�o�d��B(" + getISSHost() + ")";
		} else if (shortName.equals(acqShortName)) {
			return "������B(" + getACQHost() + ")";
		} else if (shortName.equals(hrShortName)) {
			return "�H����B(" + getHRHost() + ")";
		} else if (shortName.equals(issShortName_Bak)) {
			return "�o�d�ƴ�(" + getISSBakupHost() + ")";
		} else if (shortName.equals(acqShortName_Bak)) {
			return "����ƴ�(" + getACQBakupHost() + ")";
		} else {
			return null;
		}
	}

	/**
	 * ���o�ثe�i�o�d��B�j�D���W��
	 */
	public static final String getISSHost() {
		return iss;
	}

	/**
	 * ���o�ثe�i������B�j�D���W��
	 */
	public static final String getACQHost() {
		return acq;
	}

	/**
	 * ���o�ثe�i�H����B�j�D���W��
	 */
	public static final String getHRHost() {
		return hr;
	}

	/**
	 * ���o�ثe�i�o�d�ƴ��j�D���W��
	 */
	public static final String getISSBakupHost() {
		return issb;
	}

	/**
	 * ���o�ثe�i����ƴ��j�D���W��
	 */
	public static final String getACQBakupHost() {
		return acqb;
	}

	private static ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.config");

	private static String breakMsgHost = dmres.getString("breakMsgHost");

	/**
	 * �ǰeBreakMsg��400�D��
	 */
	public boolean sendBreakMsg(String hostShortName, String msgType,
			String eventMsg) throws Exception {
		HttpURLConnection http = null;
		InputStream in = null;
		try {
			if (hostShortName == null || hostShortName.equals("")) {
				throw new Exception("�����w�D��²�g");
			}
			if (msgType == null || msgType.equals("")) {
				throw new Exception("�����w�T���s��");
			}
			if (eventMsg == null || eventMsg.equals("")) {
				throw new Exception("�����w�ǰe�T��");
			}
			if (StringUtil.getAS400StringLen(eventMsg) > 80) {
				// �ǰe�r����׹L��
				throw new Exception("�T���r����׹L��");
			}
			byte[] data = new byte[1024];
			String url = breakMsgHost + "?HostShortName=" + hostShortName
					+ "&MsgType=" + URLEncoder.encode(msgType, "UTF-8")
					+ "&EventMsg=" + URLEncoder.encode(eventMsg, "UTF-8");
			URL u = new URL(url);
			http = (HttpURLConnection) u.openConnection();
			http.setRequestMethod("POST");
			in = http.getInputStream();
			int idx = in.read(data);
			String str = "";
			if (idx >= 0) {
				str = new String(data, 0, idx);
			}
			if (str.trim().toUpperCase().startsWith("OK")) {
				// ��ƥ��`
				return str.trim().substring(2, str.trim().length()).equals(
						"SUCCESS");
			} else {
				// ��Ʋ��`
				throw new Exception("BreakMagReciever�^�и�Ʋ��` " + str);
			}
		} finally {
			try {
				in.close();
			} catch (Exception e) {
			}
			try {
				http.disconnect();
			} catch (Exception e) {
			}
		}
	}

}
