package esunbank.esunutil.echo;

import java.net.InetAddress;
import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * �ݰ���Lecho���� <br>
 * 1. ��@���դ��e(implements Interface)<br>
 * 2. new setCheckList to add Job
 * 
 * @author ESB17430
 * @date 2018/12/06
 * 
 */

@WebServlet(urlPatterns = { "/EchoTest/CommonEchoTest" })
public class RcvEcho extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * WEB�Ȼs�ʱ����e
	 */
	private static ArrayList<CheckJob> checkJobList = new ArrayList<CheckJob>();

	public boolean setCheckList(CheckJob c) {
		return RcvEcho.checkJobList.add(c);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {

		String rslt = null;
		String hostIP = null;

		try {
			hostIP = InetAddress.getLocalHost().getHostAddress();
			rslt = doJob();
			response.setHeader("Content-type", "application/json;charset=UTF-8");
			response.setContentLength(rslt.getBytes("UTF-8").length);
			response.getOutputStream().write(rslt.getBytes("UTF-8"));
			response.getOutputStream().flush();
			response.getOutputStream().close();
		} catch (Exception e) {
			Const.logUtil.Error("Echo�ˬd�o�Ϳ��~�GhostIP=" + hostIP);
			Const.logUtil.Error(e);
		}
	}

	public String doJob() throws Exception {
		JSONArray rtnMsg = null;
		JSONObject checkObj = null;
		JSONObject rtnObj = null;
		boolean isCheckOK = true;

		try {
			rtnObj = new JSONObject();
			rtnObj.put("RC", Const.rtnER);
			rtnObj.put("MSG", "DEFAULT ERROR");

			// �Ȼs�ʱ��ˬd
			if (checkJobList.size() > 0) {
				rtnMsg = new JSONArray();
				for (CheckJob c : checkJobList) {
					checkObj = c.doCheck();
					if (!checkObj.has("RC") || !checkObj.has("MSG")) {
						Const.logUtil.Error("�A�ȴ��զ^�в��`�G" + checkObj.toString());
						isCheckOK = false;
						continue;
					}
					if (!checkObj.getString("RC").equals(Const.rtnOK)) {
						isCheckOK = false;
					}
					rtnMsg.put(checkObj);
				}
				if (isCheckOK) {
					rtnObj.put("RC", Const.rtnOK);
				}
				rtnObj.put("MSG", rtnMsg);
			} else {
				rtnObj.put("RC", Const.rtnOK);
				rtnObj.put("MSG", "DEFAULT OK");
			}
		} catch (Exception e) {
			rtnObj.put("MSG", "EXCEPTION ERROR");
			Const.logUtil.Error(e);
		}
		return rtnObj.toString();
	}

}