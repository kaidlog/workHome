package esunbank.esunutil.echo;

import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * echoTest���ξɤJ�{��
 * 
 * @author ������
 * @date 2019/01/20
 * 
 */
public class SetupEcho extends Thread {
	public static void main(String[] args) {
		try {
			HashMap<String, String> param = null;
			String ClassName = null;
			String ProjectID = null;
			String[] arg = null;
			for (String str : args) {
				// -p���Ȼs�ƺʱ��ѼƳ]�w(-1�������M�ιw�])
				if (str.startsWith("-p")) {
					String[] tmp = str.substring(2).split(",");
					if (tmp.length != 6) {
						System.out.println("�ѼƦ��~�A�ʱ��ѼƱa�J�w�]!");
						continue;
					}
					try {
						param = new HashMap<String, String>();
						if (!tmp[0].equals("-1")) {
							param.put(Const.MaxErrCountKey, tmp[0]);
						}
						if (!tmp[1].equals("-1")) {
							param.put(Const.MaxNotifyCountKey, tmp[1]);
						}
						if (!tmp[2].equals("-1")) {
							param.put(Const.NotifyIntervalKey, tmp[2]);
						}
						if (!tmp[3].equals("-1")) {
							param.put(Const.JobIntervalKey, tmp[3]);
						}
						if (!tmp[4].equals("-1")) {
							param.put(Const.MailGroupIDKey, tmp[4]);
						}
						if (!tmp[5].equals("-1")) {
							param.put(Const.MonitorIDKey, tmp[5]);
						}
					} catch (Exception ex) {
						System.out.println("�ѼƦ��~�A�ʱ��ѼƱa�J�w�]!");
						param.clear();
					}
				} else if (str.startsWith("-m")) {
					// -m���Q�ʱ��{����projectIDclassname�H��main�һݤ��Ѽ�
					String[] tmp = str.substring(2).split(" ");
					ProjectID = tmp[0];
					ClassName = tmp[1];
					if (tmp.length > 1) {
						arg = new String[tmp.length - 2];
						for (int i = 2; i < tmp.length; i++) {
							arg[i - 2] = tmp[i];
						}
					}
				}
			}
			// ����ʱ�
			SndEcho sndEcho = new SndEcho(ProjectID, param, null);
			sndEcho.start();
			System.out.println("�ʱ��Ұʦ��\");
			// ����Q�ʱ��{��
			System.out.println("�Y�N�Ұʰ���{���G" + ClassName);
			Class<?> APclass = Class.forName(ClassName);
			Method APmain = APclass.getMethod("main", String[].class);
			APmain.invoke(null, (Object) arg);
			System.out.println("�{�����榨�\(Thread)");
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Error er) {
			er.printStackTrace();
		}
	}
}
