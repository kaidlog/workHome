package esunbank.esunutil.echo;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import esunbank.esunutil.io.ssl.SSLUtil;

/**
 * �ϥΦۦ�o�eecho�\�� <br>
 * 1. new SndEcho(�M�צW��, �ˬd�C��)<br>
 * 2. ��@���դ��e(implements Interface)<br>
 * 3. new setCheckList to add Job
 * 
 * @author ESB17430
 * @date 2018/12/06
 * 
 */

public class SndEcho extends Thread {

	/**
	 * AP�Ȼs�ʱ����e
	 */
	private static ArrayList<CheckJob> checkJobList = new ArrayList<CheckJob>();

	/**
	 * �[�J�Ȼs�ʱ����e
	 * 
	 * @param ��@���ʱ����e
	 */
	public static boolean setCheckList(CheckJob c) {
		return SndEcho.checkJobList.add(c);
	}

	/**
	 * AP�ʱ��C��<br>
	 * 
	 * KEY:�ʱ��M�צW��<br>
	 * VALUE:�Ȼs�ʱ��C��
	 */
	private static HashMap<String, ArrayList<CheckJob>> sndProject = new HashMap<String, ArrayList<CheckJob>>();

	private String projectID = null;

	/**
	 * AP�ۭq�ʱ��ѼƤΫȻs�ʱ����e
	 * 
	 * @param projectID
	 *            �M�צW��
	 * @param paramMap
	 *            �ʱ��Ѽ�(�Y�L�h��null)
	 * @param checkJobList
	 *            �Ȼs�ʱ����e(�Y�L�h��null)
	 * @throws Exception
	 */
	public SndEcho(String projectID, HashMap<String, String> paramMap, ArrayList<CheckJob> checkJobList) throws Exception {
		doInit(projectID, paramMap, checkJobList);
	}

	public SndEcho(String projectID) throws Exception {
		doInit(projectID, null, null);
	}

	public void run() {
		while (true) {
			try {
				sendEcho();
			} catch (Exception e) {
				Const.logUtil.Error(e);
			} finally {
				try {
					Thread.sleep(Integer.parseInt(Const.echoParamList.get(Const.JobIntervalKey)) * 60 * 1000L);
				} catch (Exception ex) {
				}
			}
		}
	}

	/**
	 * AP�o�e�ʱ�to server
	 */
	private void sendEcho() {
		String desURL = Const.serverPath;
		OutputStream outStream = null;
		HttpURLConnection httpConn = null;
		JSONArray rtnMsg = null;
		JSONObject rtnObj = null;
		JSONObject checkObj = null;
		boolean isCheckOK = true;

		try {
			rtnObj = new JSONObject();
			rtnObj.put("PID", projectID);
			rtnObj.put("SN", InetAddress.getLocalHost().getHostName());
			rtnObj.put("SIP", InetAddress.getLocalHost().getHostAddress());

			rtnObj.put("RC", Const.rtnER);
			rtnObj.put("MSG", "DEFAULT ERROR");

			rtnObj.put("PARAM", Const.echoParamList);

			// �Ȼs�ʱ��ˬd
			if (checkJobList.size() > 0) {
				rtnMsg = new JSONArray();
				for (CheckJob c : checkJobList) {
					checkObj = c.doCheck();
					if (!checkObj.has("RC") || !checkObj.has("MSG")) {
						Const.logUtil.Error("�A�ȴ��զ^�в��`�G" + checkObj.toString());
						isCheckOK = false;
						continue;
					}
					if (!checkObj.getString("RC").equals(Const.rtnOK)) {
						isCheckOK = false;
					}
					rtnMsg.put(checkObj);
				}
				if (isCheckOK) {
					rtnObj.put("RC", Const.rtnOK);
				}
				rtnObj.put("MSG", rtnMsg);
			} else {
				rtnObj.put("RC", Const.rtnOK);
				rtnObj.put("MSG", "DEFAULT OK");
			}

			httpConn = SSLUtil.getHttpURLConnection(desURL);
			httpConn.setDoOutput(true);
			httpConn.setRequestMethod("POST");
			httpConn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			httpConn.setConnectTimeout(Const.connTimeOut);
			outStream = httpConn.getOutputStream();
			outStream.write(rtnObj.toString().getBytes("UTF-8"));
			outStream.flush();

			int responseCode = httpConn.getResponseCode();
			Const.logUtil.Info("ProjectID:" + projectID + "�AAP:" + InetAddress.getLocalHost() + "�ARtnMsg:" + responseCode);
		} catch (Exception e) {
			Const.logUtil.Error(e);
		} finally {
			try {
				if (outStream != null) {
					outStream.close();
				}
			} catch (Exception e) {
			}
			try {
				if (httpConn != null) {
					httpConn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	private void doInit(String projectID, HashMap<String, String> paramMap, ArrayList<CheckJob> checkJobList) throws Exception {
		if (projectID == null) {
			throw new Exception("�ʱ��M�צW�ٿ��~�G" + projectID);
		}

		// �w�]�ʱ��Ѽ�
		Const.echoParamList.put(Const.MaxErrCountKey, Const.maxErrCount);
		Const.echoParamList.put(Const.MaxNotifyCountKey, Const.maxNotifyCount);
		Const.echoParamList.put(Const.JobIntervalKey, Const.jobInterval);
		Const.echoParamList.put(Const.NotifyIntervalKey, Const.notifyInterval);
		Const.echoParamList.put(Const.MailGroupIDKey, Const.mailGroupID);
		Const.echoParamList.put(Const.MonitorIDKey, Const.monitorID);

		// ���o�Ȼs�ʱ��Ѽ�
		if (paramMap != null) {
			if (paramMap.containsKey(Const.MaxErrCountKey)) {
				Const.echoParamList.put(Const.MaxErrCountKey, paramMap.get(Const.MaxErrCountKey));
			}
			if (paramMap.containsKey(Const.MaxNotifyCountKey)) {
				Const.echoParamList.put(Const.MaxNotifyCountKey, paramMap.get(Const.MaxNotifyCountKey));
			}
			if (paramMap.containsKey(Const.JobIntervalKey)) {
				Const.echoParamList.put(Const.JobIntervalKey, paramMap.get(Const.JobIntervalKey));
			}
			if (paramMap.containsKey(Const.NotifyIntervalKey)) {
				Const.echoParamList.put(Const.NotifyIntervalKey, paramMap.get(Const.NotifyIntervalKey));
			}
			if (paramMap.containsKey(Const.MailGroupIDKey)) {
				Const.echoParamList.put(Const.MailGroupIDKey, paramMap.get(Const.MailGroupIDKey));
			}
			if (paramMap.containsKey(Const.MonitorIDKey)) {
				Const.echoParamList.put(Const.MonitorIDKey, paramMap.get(Const.MonitorIDKey));
			}
		}

		// ���o�Ȼs�ʱ����e
		if (checkJobList != null) {
			SndEcho.checkJobList = checkJobList;
		}

		synchronized (sndProject) {
			if (!sndProject.containsKey(projectID)) {
				sndProject.put(projectID, checkJobList);
			} else {
				throw new Exception("���ư���EchoTest[" + projectID + "]");
			}
			this.projectID = projectID;
		}
	}
}
