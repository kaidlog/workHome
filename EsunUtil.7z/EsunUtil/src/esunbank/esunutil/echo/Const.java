package esunbank.esunutil.echo;

import java.util.HashMap;
import java.util.ResourceBundle;

import esunbank.esunutil.io.LogUtil;

public class Const {
	public static final ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.echo.config");

	public static final String systemID = dmres.getString("systemID");

	public static final LogUtil logUtil = new LogUtil(systemID);
	
	public static final String mailGroupID = dmres.getString("mailGroupID");
	public static final String monitorID = dmres.getString("monitorID");

	/**
	 * WEB�ʱ�Server��m
	 */
	public static final String serverPath = dmres.getString("serverPath");

	/**
	 * �s�utimeout�ɶ�(��)
	 */
	public static final int connTimeOut = Integer.parseInt(dmres.getString("connTimeOut"));

	public static final String rtnOK = "OK";
	public static final String rtnER = "ER";

	/**
	 * AP�ʱ��Ѽ�KEY
	 */

	public static final String MaxErrCountKey = dmres.getString("MaxErrCountKey");
	public static final String MaxNotifyCountKey = dmres.getString("MaxNotifyCountKey");
	public static final String NotifyIntervalKey = dmres.getString("NotifyIntervalKey");
	public static final String JobIntervalKey = dmres.getString("JobIntervalKey");
	public static final String MailGroupIDKey = dmres.getString("MailGroupIDKey");
	public static final String MonitorIDKey = dmres.getString("MonitorIDKey");

	/**
	 * AP�s����~����
	 */
	public static final String maxErrCount = dmres.getString("maxErrCount");

	/**
	 * AP�s��q������
	 */
	public static final String maxNotifyCount = dmres.getString("maxNotifyCount");
	
	/**
	 * AP�ʱ��h�[�o�ʤ@��(��)
	 */
	public static final String jobInterval = dmres.getString("jobInterval");
	
	/**
	 * AP�q���ɶ����j(��)
	 */
	public static final String notifyInterval = dmres.getString("notifyInterval");

	/**
	 * AP�ʱ��Ѽ�<br>
	 * 
	 * KEY:�ʱ����ئW��<br>
	 * VALUE:�ѼƳ]�w
	 */
	public static HashMap<String, String> echoParamList = new HashMap<String, String>();

}
