package esunbank.esunutil.db;

import java.sql.*;
import java.util.ResourceBundle;
import esunbank.esunutil.info.HostInfoUtil;
import esunbank.esunutil.io.IOUtil;

public class DBUtil {
	private static String HostInfoDBAlertGroup = ResourceBundle.getBundle(
			"esunbank.esunutil.config").getString("HostInfoSystemGroup");
	private final String classPath_SQL = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String classPath_DB2_Type4 = "COM.ibm.db2.jdbc.net.DB2Driver";
	private final String classPath_DB2_as400 = "com.ibm.as400.access.AS400JDBCDriver"; // @Cross
	private final int DBTYPE_SQL = 1;
	private final int DBTYPE_DB2 = 2;
	private final int DBTYPE_DB2_AS400 = 3; // @Cross

	private String getSubjectReTryFail(String dataBaseName) {
		return "�iEsunUtil�j��Ʈw[" + dataBaseName + "]�s�u���Ѳ��`�q��";
	}

	private String getSubjectReTrySuccess(String dataBaseName) {
		return "�iEsunUtil�j��Ʈw[" + dataBaseName + "]���s�s�u���\�q��:";
	}

	/**
	 * ���o���w��SQL��Ʈw�s�u<br>
	 * ����2000�B2005�B2008 <br>
	 * ���ճW�h:�Ĥ@��SQLException�ɵo�H�q��<br>
	 * ���ն��j:5��<br>
	 * �C����60���A�o�H�q��(��5����)<br>
	 * ���իᦨ�\�s�u�|�A�o�H�q��
	 * 
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @param isAutoRetry
	 * @return
	 * @throws Exception
	 */
	public Connection getSQLConn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD,
			boolean isAutoRetry) throws Exception {
		if (isAutoRetry) {
			return getConnWithRetry(DBTYPE_SQL, serverAddress, serverPort,
					dataBaseName, serverID, serverPassWD);
		} else {
			return getConn(DBTYPE_SQL, serverAddress, serverPort, dataBaseName,
					serverID, serverPassWD);
		}
	}

	/**
	 * ���o���w��SQL��Ʈw�A������<br>
	 * ����2000�B2005�B2008 <br>
	 * 
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @return
	 * @throws Exception
	 */
	public Connection getSQLConn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD)
			throws Exception {
		return getConn(DBTYPE_SQL, serverAddress, serverPort, dataBaseName,
				serverID, serverPassWD);
	}

	/**
	 * ���o���w��DB2��Ʈw(Type4)<br>
	 * DB2�w�]Port��6789<br>
	 * ���ճW�h:�Ĥ@��SQLException�ɵo�H�q��<br>
	 * ���ն��j:5��<br>
	 * �C����60���A�o�H�q��(��5����)<br>
	 * ���իᦨ�\�s�u�|�A�o�H�q��
	 * 
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @param isAutoRetry
	 * @return
	 * @throws Exception
	 */
	public Connection getDB2Conn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD,
			boolean isAutoRetry) throws Exception {
		if (isAutoRetry) {
			return getConnWithRetry(DBTYPE_DB2, serverAddress, serverPort,
					dataBaseName, serverID, serverPassWD);
		} else {
			return getConn(DBTYPE_DB2, serverAddress, serverPort, dataBaseName,
					serverID, serverPassWD);
		}
	}

	/**
	 * ���o���w��DB2��Ʈw(Type4)�A������<br>
	 * DB2�w�]Port��6789<br>
	 * 
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @return
	 * @throws Exception
	 */
	public Connection getDB2Conn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD)
			throws Exception {
		return getConn(DBTYPE_DB2, serverAddress, serverPort, dataBaseName,
				serverID, serverPassWD);
	}

	/**
	 * ���o���w��as400 DB2��Ʈw�A����<br>
	 * 
	 * @author Cross
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @param isAutoRetry
	 * @return
	 * @throws Exception
	 */
	public Connection getAS400DB2Conn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD,
			boolean isAutoRetry) throws Exception {
		if (isAutoRetry) {
			return getConnWithRetry(DBTYPE_DB2_AS400, serverAddress,
					serverPort, dataBaseName, serverID, serverPassWD);
		} else {
			return getConn(DBTYPE_DB2_AS400, serverAddress, serverPort,
					dataBaseName, serverID, serverPassWD);
		}
	}

	/**
	 * ���o���w��as400 DB2��Ʈw�A������<br>
	 * DB2�w�]Port��6789<br>
	 * 
	 * @author Cross
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @return
	 * @throws Exception
	 */
	public Connection getAS400DB2Conn(String serverAddress, String serverPort,
			String dataBaseName, String serverID, String serverPassWD)
			throws Exception {
		return getConn(DBTYPE_DB2_AS400, serverAddress, serverPort,
				dataBaseName, serverID, serverPassWD);
	}

	/**
	 * ���o��Ʈw�s�u
	 * 
	 * @param sqlType
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @return
	 * @throws Exception
	 */
	private Connection getConnWithRetry(int sqlType, String serverAddress,
			String serverPort, String dataBaseName, String serverID,
			String serverPassWD) throws Exception {
		Connection conn = null;
		int retry = 0;
		String errorString;
		while (conn == null || conn.isClosed()) {
			errorString = "";
			try {
				retry++;
				conn = getConn(sqlType, serverAddress, serverPort,
						dataBaseName, serverID, serverPassWD);
			} catch (SQLException sqlex) {
				errorString = sqlex.getMessage();
			} finally {
				if (conn == null || conn.isClosed()) {
					IOUtil.printInfo("��Ʈw�s�u����(��" + retry + "���s�u)�ñN��5���᭫��"
							+ " ��}:" + serverAddress + " port:" + serverPort
							+ " ��Ʈw�W��:" + dataBaseName + " ���ѭ�]:" + errorString);
					if (retry == 1 || retry % 60 == 0) {
						// �Ĥ@�����ѳq����A���C�j5�����q���@��
						new HostInfoUtil().sendMailToGroupUser(
								HostInfoDBAlertGroup,
								getSubjectReTryFail(dataBaseName), "��Ʈw�s�u����(��"
										+ retry + "���s�u)�ñN��5���᭫��<br>" + "��}:"
										+ serverAddress + "<br>" + "port:"
										+ serverPort + "<br>" + "��Ʈw�W��:"
										+ dataBaseName + "<br>" + "���ѭ�]:"
										+ errorString);
					}
					// �C5�����ճs�u
					try {
						Thread.sleep(5 * 1000);
					} catch (Exception e) {
					}
				} else if (retry > 1) {
					IOUtil.printInfo("��Ʈw�s�u���\(��" + retry + "���s�u)" + " ��}:"
							+ serverAddress + " port:" + serverPort + " ��Ʈw�W��:"
							+ dataBaseName);
					new HostInfoUtil().sendMailToGroupUser(
							HostInfoDBAlertGroup,
							getSubjectReTrySuccess(dataBaseName), "��Ʈw�s�u���\(��"
									+ retry + "���s�u)<br>" + "��}:"
									+ serverAddress + "<br>" + "port:"
									+ serverPort + "<br>" + "��Ʈw�W��:"
									+ dataBaseName);
				}
			}
		}
		return conn;
	}

	/**
	 * ���o��Ʈw�s�u
	 * 
	 * @param sqlType
	 * @param serverAddress
	 * @param serverPort
	 * @param dataBaseName
	 * @param serverID
	 * @param serverPassWD
	 * @return
	 * @throws Exception
	 */
	private Connection getConn(int sqlType, String serverAddress,
			String serverPort, String dataBaseName, String serverID,
			String serverPassWD) throws Exception {
		if (sqlType == DBTYPE_SQL) {
			Class.forName(classPath_SQL);
			return DriverManager.getConnection("jdbc:sqlserver://"
					+ serverAddress + ":" + serverPort
					+ ";SelectMethod=cursor;DatabaseName=" + dataBaseName,
					serverID, serverPassWD);
		} else if (sqlType == DBTYPE_DB2) {
			Class.forName(classPath_DB2_Type4);
			return DriverManager.getConnection("jdbc:db2://" + serverAddress
					+ ":" + serverPort + "/" + dataBaseName, serverID,
					serverPassWD);
		} else if (sqlType == DBTYPE_DB2_AS400) { // 20140926 @Cross
			Class.forName(classPath_DB2_as400);
			return DriverManager.getConnection("jdbc:as400://" + serverAddress
					+ ":" + serverPort + ";database name=" + dataBaseName,
					serverID, serverPassWD);
		} else {
			throw new Exception("��������Ʈw����");
		}
	}
}