package esunbank.esunutil;

public class UserSect {

	private String SECT;
	private String SECT_INFO;
	private int SECT_CNT;
	private String DEPT;
	private String DEPT_INFO;

	public String getSECT() {
		return SECT;
	}

	public void setSECT(String sECT) {
		SECT = sECT;
	}

	public String getSECT_INFO() {
		return SECT_INFO;
	}

	public void setSECT_INFO(String sECT_INFO) {
		SECT_INFO = sECT_INFO;
	}

	public String getDEPT() {
		return DEPT;
	}

	public void setDEPT(String dEPT) {
		DEPT = dEPT;
	}

	public String getDEPT_INFO() {
		return DEPT_INFO;
	}

	public void setDEPT_INFO(String dEPT_INFO) {
		DEPT_INFO = dEPT_INFO;
	}

	public int getSECT_CNT() {
		return SECT_CNT;
	}

	public void setSECT_CNT(int sECT_CNT) {
		SECT_CNT = sECT_CNT;
	}

}
