package esunbank.esunutil.test;

import esunbank.esunutil.info.MailUtil;

public class TestMail {

	public static void main(String[] args) throws Exception {

		System.out.print(
				new MailUtil("172.17.204.177", "C810SP1", "C810SP1@EMAIL.ESUNBANK.COM.TW").sendMail(new String[] { "c820m@ezcheckp.esunbank.com.tw" }, null, null, null, "subject", "content", null));

	}

}
