package esunbank.esunutil.test;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import esunbank.esunutil.DateUtil;
import esunbank.esunutil.StringUtil;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

	}

	public int getBiggestSum(int[] input) {
		int max = 0;
		for (int i = 0; i < input.length; i++) {
			int sum = 0;
			for (int j = i; j < input.length; j++) {
				sum += input[j];
				if (sum > max) {
					max = sum;
				}
			}
		}
		return max;
	}

}
