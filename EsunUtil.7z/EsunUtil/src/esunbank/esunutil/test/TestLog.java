package esunbank.esunutil.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import esunbank.esunutil.io.*;

public class TestLog {// extends LogUtil{

	String s = new String("");
	//s = null;
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		FileInputStream fis = new FileInputStream(new File(
				"D:\\test\\temp\\otp.txt"));
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));

		java.util.LinkedHashSet<String> keys = new java.util.LinkedHashSet<String>();

		String tmp = null;
		while ((tmp = in.readLine()) != null) {
			// if(tmp.startsWith("�iInfo�j")){
			if (tmp.contains("��XKey=")) {
				//System.out.println(tmp);
				
				keys.add(tmp.substring(tmp.indexOf("��XKey=")+6, tmp.indexOf(",")));
				
			}

		}
		for(String tmp1:keys){
			System.out.println(tmp1);
		}
		
		
		in.close();
		fis.close();

		// System.out.println( new
		// String(Base64.decodeBase64("C7BBF75EDF866C968f9e8a93df938690918cC7BBF75EDF866C96"),"Big5"
		// ));
		// System.out.println(new
		// String(Hex.decodeHex("C7BBF75EDF866C968f9e8a93df938690918cC7BBF75EDF866C96".toCharArray())));
		// new TestLog("A").Error("");
	}

	public TestLog(String logType) {
		// super(logType);
	}

}
