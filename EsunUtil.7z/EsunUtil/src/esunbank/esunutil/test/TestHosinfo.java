package esunbank.esunutil.test;

public class TestHosinfo {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		System.out.println(System.currentTimeMillis());

		try {

			esunbank.esunutil.info.HostInfoUtil HostInfo = new esunbank.esunutil.info.HostInfoUtil();

			String projectNo = "WEB01";
			String key1 = "Test1";
			String key2 = "Test2";
			String[] subjectParms = new String[] { "S1", "S2" };
			String[] contentParms = null;
			String sender = null;
			String[] emails_to = new String[] {
					"drinkin-06751@email.esunbank.com.tw",
					"drinkin-06751@email.esunbank.com.tw" };
			String[] emails_cc = null;
			String[] emails_bcc = null;
			String emails_replyto = null;
			String attachmentType = null;
			String[] attachment = null;

			long start = System.currentTimeMillis();
			for (int i = 0; i < 1; i++) {
				HostInfo.sendHostMessage05(projectNo, key1, key2, subjectParms,
						contentParms, sender, emails_to, emails_cc, emails_bcc,
						emails_replyto, attachmentType, attachment);
			}
			System.out.println(System.currentTimeMillis() - start);
		} catch (Error ex) {
			ex.printStackTrace();
		}
	}
}
