package esunbank.esunutil.test;

import esunbank.esunutil.mq.*;
import javax.jms.*;

public class TestActiveMQ {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		ActiveMQUtil activeMQUtil = new ActiveMQUtil();

		Connection conn = activeMQUtil.getMQConnection();
		Session session = activeMQUtil.getMQSession(conn);
		MessageProducer mp = activeMQUtil.getMessageProducer(session, "TestQ",
				false);
//		MessageConsumer mc = activeMQUtil.getMessageConsumer(session, "TestQ");
//		activeMQUtil.writeQ(mp, session.createTextMessage("test queue data"));
//		System.out.println(mc.receive(1000).toString());

		//test select queue
		TextMessage data = session.createTextMessage("test queue data 1");
		data.setStringProperty("key","value");
		data.setLongProperty("long", System.currentTimeMillis());
		activeMQUtil.writeQ(mp, data);

		//MessageConsumer mc = activeMQUtil.getMessageConsumer(session, "TestQ", " key='value'");
		MessageConsumer mc = activeMQUtil.getMessageConsumer(session, "TestQ", " long<="+System.currentTimeMillis());
		System.out.println(((TextMessage)mc.receive(1000)).getText());
		mc.close();
		session.close();// close session�N�s�urelease�^pool
	}

}
