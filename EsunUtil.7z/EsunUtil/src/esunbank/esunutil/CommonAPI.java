package esunbank.esunutil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.json.JSONArray;
import org.json.JSONObject;

import esunbank.esunutil.io.LogUtil;
import esunbank.esunutil.io.ssl.SSLUtil;

/**
 * �z�L CommonService ���o Common Resource, Encoding: UTF-8
 * 
 * 01. Line 85 tbSeq 02. Line 301 CommonUser 03. Line 587 DeptSect 04. Line 792
 * Currency 05. Line 943 CardImg 06. Line 1076 ANTCD 07. Line 1390 EsunBranch
 * 08. Line 1523 CommonAGNO 09. Line 1630 BankData 10. Line 1711 CardData 11.
 * Line 1915 FXMLBank 12. Line 1982 BankDataDtl 13. Line 2062 NCCC Card Verify
 * Bank 14. Line 2180 Nationality
 * 
 * @author ESB19600
 *
 */
public class CommonAPI {
	private LogUtil logUtil;
	private String fqcn = this.getClass().getName();
	// ���J�Ѽ���
	private ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.config");
	// Ū���Ѽ�
	private String commonServiceHost = dmres.getString("commonServiceHost");
	private String operateSeq = dmres.getString("operateSeq");
	private String getCommonUsers = dmres.getString("commonUsers");
	private String getDeptSect = dmres.getString("userDeptSect");
	private String getCurrencyInfo = dmres.getString("currency");
	private String getCardImg = dmres.getString("cardImg");
	private String getAntcd = dmres.getString("antcd");
	private String getEsunBranch = dmres.getString("esunBranch");
	private String getEsunBranchByInPerson = dmres.getString("esunBranchByInPerson");
	private String getAGNO = dmres.getString("AGNO");
	private String getSSBankData = dmres.getString("SSBankData");
	private String getSSBankBin = dmres.getString("SSBankBin");
	private String getEsunSSBankBin = dmres.getString("EsunSSBankBin");
	private String getFXMLBankCtl = dmres.getString("FXMLBankCtl");
	private String getBankDataDtl = dmres.getString("BankDataDtl");
	private String getN3CCardVerify = dmres.getString("N3CCardVerify");
	private String getNationality = dmres.getString("nationality");
	private String getHost = dmres.getString("host");
	private String genSeqNo = dmres.getString("genSeqNo");

	public CommonAPI(LogUtil logUtil) {
		this.logUtil = logUtil;
	}

	private HttpURLConnection commonServiceConnector(String connUrl, String protocal) throws Exception {
		HttpURLConnection conn = SSLUtil.getHttpURLConnection(connUrl);
		conn.setRequestProperty("Connection", "close");
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setUseCaches(false);
		conn.setRequestMethod(protocal.toUpperCase());
		conn.setRequestProperty("Content-Type", "application/json; utf-8");
		conn.setRequestProperty("Accept", "application/json");
		return conn;
	}

	/*************************************
	 * tbSeq
	 ************************************/
	// SeqLocker Map
	private static HashMap<String, Object> seqLocker = new HashMap<String, Object>();

	// �B�z�Ǹ�lock����
	private void seqTypeMapper(String seqType) {
		if (seqLocker.get(seqType) == null) {
			seqLocker.put(seqType, new Object());
		}
	}

	/**
	 * �����t��(EsunSnGenerator)
	 * 
	 * @param sysId
	 * @param funcId
	 * @param sourceKey
	 * @return JSONObject
	 * @throws Exception
	 */
	public JSONObject genSeqNo(String sysId, String funcId, String sourceKey) throws Exception {
		if (sysId == null || "".equals(sysId) || funcId == null || "".equals(funcId)) {
			throw new Exception("SysId �� FuncId ���i���šI");
		}
		HttpURLConnection conn = null;
		OutputStreamWriter oswr = null;
		BufferedReader br = null;
		String response = "";
		JSONObject respJObj = null;
		try {
			conn = commonServiceConnector(commonServiceHost + genSeqNo, "POST");
			JSONObject reqJson = new JSONObject();
			reqJson.put("sysId", sysId);
			reqJson.put("funcId", funcId);
			reqJson.put("sourceKey", sourceKey);
			oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
			oswr.write(reqJson.toString());
			oswr.flush();
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (oswr != null) {
					oswr.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return respJObj;
	}

	/**
	 * ���o�����O���ѧǸ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * 
	 * @return �ثe�Ǹ�
	 * @throws Exception
	 */
	public String getSeqNo(String seqType, int seqLength) throws Exception {
		return getSeqNo(seqType, DateUtil.getNowDate(), seqLength);
	}

	/**
	 * ���o�����O���ѧǸ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param isReset
	 *            �O�_�R����Ʈw��data
	 * 
	 * @return �ثe�Ǹ�
	 * @throws Exception
	 */
	public String getSeqNo(String seqType, int seqLength, boolean isReset) throws Exception {
		return getSeqNo(seqType, DateUtil.getNowDate(), seqLength, isReset);
	}

	/**
	 * ���o�����O�Ǹ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqDate
	 *            �Ǹ����
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * 
	 * @return �ثe�Ǹ�
	 * @throws Exception
	 */
	public String getSeqNo(String seqType, String seqDate, int seqLength) throws Exception {
		return getSeqNo(seqType, seqDate, seqLength, false);
	}

	/**
	 * ���o�����O�Ǹ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqDate
	 *            �Ǹ����
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param isReset
	 *            �O�_�R����Ʈw��data
	 * 
	 * @return �ثe�Ǹ�
	 * @throws Exception
	 */
	public String getSeqNo(String seqType, String seqDate, int seqLength, boolean isReset) throws Exception {
		seqTypeMapper(seqType);
		synchronized (seqLocker.get(seqType)) {
			// set variables
			HttpURLConnection conn = null;
			OutputStreamWriter oswr = null;
			BufferedReader br = null;
			String response = "";
			JSONObject respJObj = null;
			try {
				if (seqLength < 1 || seqLength > 9) {
					throw new Exception("�W�L���׭���");
				}
				conn = commonServiceConnector(commonServiceHost + operateSeq, "POST");
				JSONObject reqJson = new JSONObject();
				reqJson.put("seqType", seqType);
				reqJson.put("seqDate", seqDate);
				reqJson.put("isReset", isReset);
				oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
				oswr.write(reqJson.toString());
				oswr.flush();
				int responseCode = conn.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) {
					String line = "";
					br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
					while ((line = br.readLine()) != null) {
						response += line;
					}
					respJObj = new JSONObject(response);
					if (respJObj.getString("RC").equals("OK")) {
						JSONObject dataJObj = new JSONObject(respJObj.getString("Data"));
						int SeqNum = Integer.parseInt(dataJObj.getString("seqNum"));
						int MaxSeq = getMaxSeq(seqLength);
						if (SeqNum < MaxSeq) {
							return StringUtil.apdSplt(seqLength, SeqNum + "", "0", false);
						} else {
							throw new Exception("�W�L�̤j�Ǹ�");
						}
					} else {
						throw new Exception(respJObj.toString());
					}
				} else {
					throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
				}
			} finally {
				try {
					if (br != null) {
						br.close();
					}
				} catch (Exception e) {
				}
				try {
					if (oswr != null) {
						oswr.close();
					}
				} catch (Exception e) {
				}
				try {
					if (conn != null) {
						conn.disconnect();
					}
				} catch (Exception e) {
				}
			}
		}
	}

	/**
	 * ���o�Ӫ��קǸ��̤j��
	 * 
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @return �Ӫ��קǸ��̤j��
	 */
	public int getMaxSeq(int seqLength) {
		return seqLength <= 0 ? 0 : (int) Math.pow(10, seqLength) - 1;
	}

	/*********************************************************************************/

	/**********************************
	 * CommonUser
	 *********************************/
	/**
	 * ��¾���p�G����
	 */
	public static final String CDSTS_InPos = "1"; // 1:����

	/**
	 * ��¾���p�G�d¾
	 */
	public static final String CDSTS_KeepPos = "2"; // 2:�d¾

	/**
	 * ��¾���p�G��¾
	 */
	public static final String CDSTS_OutofPos = "3"; // 3:��¾

	static TreeMap<String, CommonUser> CommonUserList_byAD = null;

	static TreeMap<String, CommonUser> CommonUserList_by400ID = null;

	static TreeMap<String, CommonUser> CommonUserList_byEMNO = null;

	static TreeMap<String, ArrayList<CommonUser>> CommonUserList_byDeptSect = null;

	static Object userlock = new Object();

	static boolean isUserUpdater = false;

	static int keyType_AD = 1;

	static int keyType_400ID = 2;

	static int keyType_EMNO = 3;

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param userAD
	 *            �ϥΪ�AD�b��
	 * @return CommonUser
	 * @throws Exception
	 */
	public CommonUser getCommonUser(String userAD) throws Exception {
		return getUser(keyType_AD, userAD);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param user400ID
	 *            �ϥΪ�400�b��
	 * @return CommonUser
	 * @throws Exception
	 */
	public CommonUser getCommonUserBy400ID(String user400ID) throws Exception {
		return getUser(keyType_400ID, user400ID);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param userEMNO
	 *            �ϥΪ̭��u�s��
	 * @return CommonUser
	 * @throws Exception
	 */
	public CommonUser getCommonUserByEMNO(String userEMNO) throws Exception {
		return getUser(keyType_EMNO, userEMNO);
	}

	/**
	 * �q�Τ�k
	 * 
	 * @param keyType
	 *            ���w�ӷ����x
	 * @param key
	 *            �������
	 * @return CommonUser
	 * @throws Exception
	 */
	private CommonUser getUser(int keyType, String key) throws Exception {
		updCommonUser(false);
		CommonUser commonUser = null;
		if (keyType == keyType_AD) {
			commonUser = CommonUserList_byAD.get(key.toUpperCase());
		} else if (keyType == keyType_400ID) {
			commonUser = CommonUserList_by400ID.get(key.toUpperCase());
		} else if (keyType == keyType_EMNO) {
			commonUser = CommonUserList_byEMNO.get(key.toUpperCase());
		}
		if (commonUser == null) {
			commonUser = new CommonUser();
			if (keyType == keyType_AD) {
				commonUser.setUSRID("");
				commonUser.setADACC(key);
				commonUser.setEMNO("");
			} else if (keyType == keyType_400ID) {
				commonUser.setUSRID(key);
				commonUser.setADACC("");
				commonUser.setEMNO("");
			} else if (keyType == keyType_EMNO) {
				commonUser.setUSRID("");
				commonUser.setADACC("");
				commonUser.setEMNO(key);
			}
			commonUser.setEMCNM(key);
			commonUser.setSECT("");
			commonUser.setSECT_INFO("");
			commonUser.setDEPT("");
			commonUser.setDEPT_INFO("");
			commonUser.setEXPNO("");
			commonUser.setTWSID("");
			commonUser.setCELL("");
			commonUser.setEMAIL("");
			commonUser.setPSRK1("");
			commonUser.setPSNM("");
			commonUser.setCDSTS(CDSTS_OutofPos);
		}
		return commonUser;
	}

	/**
	 * �̳����էO���o�ϥΪ�
	 * 
	 * @param dept
	 *            �����N�X
	 * @param sect
	 *            �էO�N�X
	 * @return �ϥΪ̦C��
	 * @throws Exception
	 */
	public ArrayList<CommonUser> getCommonUserByDeptSect(String dept, String sect) throws Exception {
		updCommonUser(false);
		return CommonUserList_byDeptSect.get(dept.toUpperCase() + "#|" + sect.toUpperCase());
	}

	/**
	 * �̳������o�ϥΪ�
	 * 
	 * @param dept
	 *            �����N�X
	 * @return �ϥΪ̦C��
	 * @throws Exception
	 */
	public ArrayList<CommonUser> getCommonUserByDept(String dept) throws Exception {
		updCommonUser(false);
		ArrayList<CommonUser> rslt = new ArrayList<CommonUser>();
		for (Map.Entry<String, ArrayList<CommonUser>> list : CommonUserList_byDeptSect.entrySet()) {
			if (list.getKey().split("[#][|]")[0].equals(dept.toUpperCase())) {
				rslt.addAll(list.getValue());
			}
		}
		return rslt;
	}

	/**
	 * ��s CommonUser Map, �j���s (call updUser()) �μ��X thread �C���s
	 * 
	 * @param isForceUpdate
	 *            �j���s User Map �P�_
	 * @throws Exception
	 */
	protected void updCommonUser(boolean isForceUpdate) throws Exception {
		if (isForceUpdate || CommonUserList_byAD == null || CommonUserList_by400ID == null || CommonUserList_byEMNO == null || CommonUserList_byDeptSect == null) {
			synchronized (userlock) {
				if (isForceUpdate || CommonUserList_byAD == null || CommonUserList_by400ID == null || CommonUserList_byEMNO == null || CommonUserList_byDeptSect == null) {
					updUser();
				}
				if (!isUserUpdater) {
					new UserInfoUpdater().start();
					isUserUpdater = true;
				}
			}
		}
	}

	/**
	 * ��ڧ�s User Map ����k
	 * 
	 * @throws Exception
	 */
	private void updUser() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONObject respJObj = null;
		JSONArray jsonArray = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getCommonUsers, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
			respJObj = new JSONObject(response);
			if (respJObj.getString("RC").equals("OK")) {
				jsonArray = new JSONArray(respJObj.getString("Data"));
				TreeMap<String, CommonUser> tmp_CommonUserList_byAD = new TreeMap<String, CommonUser>();
				TreeMap<String, CommonUser> tmp_CommonUserList_by400ID = new TreeMap<String, CommonUser>();
				TreeMap<String, CommonUser> tmp_CommonUserList_byEMNO = new TreeMap<String, CommonUser>();
				TreeMap<String, ArrayList<CommonUser>> tmp_CommonUserList_byDeptSect = new TreeMap<String, ArrayList<CommonUser>>();
				CommonUser user = null;
				JSONObject jObj = null;
				String key = null;
				for (int i = 0; i < jsonArray.length(); i++) {
					user = new CommonUser();
					jObj = (JSONObject) jsonArray.get(i);
					user.setEMNO(jObj.getString("emno"));
					user.setUSRID(jObj.getString("usrid"));
					user.setADACC(jObj.getString("adacc"));
					user.setEMCNM(jObj.getString("emcnm"));
					user.setSECT(jObj.getString("sect"));
					user.setSECT_INFO(jObj.getString("sect_INFO"));
					user.setDEPT(jObj.getString("dept"));
					user.setDEPT_INFO(jObj.getString("dept_INFO"));
					user.setEXPNO(jObj.getString("expno"));
					user.setTWSID(jObj.getString("twsid"));
					user.setCELL(jObj.getString("cell"));
					user.setEMAIL(jObj.getString("email"));
					user.setPSRK1(jObj.getString("psrk1"));
					user.setPSNM(jObj.getString("psnm"));
					user.setCDSTS(jObj.getString("cdsts"));
					user.setDTREL(Integer.parseInt(jObj.getString("dtrel")));
					tmp_CommonUserList_byAD.put(user.getADACC().toUpperCase(), user);
					tmp_CommonUserList_by400ID.put(user.getUSRID().toUpperCase(), user);
					tmp_CommonUserList_byEMNO.put(user.getEMNO().toUpperCase(), user);
					key = jObj.getString("dept").toUpperCase() + "#|" + jObj.getString("sect").toUpperCase();
					if (tmp_CommonUserList_byDeptSect.get(key) == null) {
						tmp_CommonUserList_byDeptSect.put(key, new ArrayList<CommonUser>());
					}
					tmp_CommonUserList_byDeptSect.get(key).add(user);
				}
				CommonUserList_byAD = tmp_CommonUserList_byAD;
				CommonUserList_by400ID = tmp_CommonUserList_by400ID;
				CommonUserList_byEMNO = tmp_CommonUserList_byEMNO;
				CommonUserList_byDeptSect = tmp_CommonUserList_byDeptSect;
			} else {
				throw new Exception(respJObj.toString());
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Thread - responsible for User info update
	 * 
	 * @author ESB19600
	 *
	 */
	class UserInfoUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000); // one day
				} catch (Exception e) {
				}
				try {
					updCommonUser(true);
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + " : " + this.getClass().getSimpleName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/***********************************
	 * DeptSect
	 **********************************/
	static ArrayList<UserDept> userDeptList = null;

	static ArrayList<UserSect> userSectList = null;

	static Object deptsectlock = new Object();

	static boolean isDeptSectUpdater = false;

	/**
	 * �̳������o������T
	 * 
	 * @param dept
	 *            �����N�X
	 * @return ������T
	 * @throws Exception
	 */
	public UserDept getDept(String dept) throws Exception {
		updUserDeptSect(false);
		for (int i = 0; i < userDeptList.size(); i++) {
			if (userDeptList.get(i).getDEPT().equals(dept.toUpperCase())) {
				return userDeptList.get(i);
			}
		}
		return null;
	}

	/**
	 * ���o�Ҧ�������T
	 * 
	 * @return ������T
	 * @throws Exception
	 */
	public ArrayList<UserDept> getDept() throws Exception {
		updUserDeptSect(false);
		return userDeptList;
	}

	/**
	 * �̳����βէO���o�էO��T
	 * 
	 * @param dept
	 *            �����N�X
	 * @param sect
	 *            �էO�N�X
	 * @return �էO��T
	 * @throws Exception
	 */
	public UserSect getSect(String dept, String sect) throws Exception {
		updUserDeptSect(false);
		for (int i = 0; i < userSectList.size(); i++) {
			if (userSectList.get(i).getDEPT().equals(dept.toUpperCase()) && userSectList.get(i).getSECT().equals(sect.toUpperCase())) {
				return userSectList.get(i);
			}
		}
		return null;
	}

	/**
	 * �̳������o�ӳ����Ҧ����էO��T
	 * 
	 * @param dept
	 *            �����N�X
	 * @return �էO��T
	 * @throws Exception
	 */
	public ArrayList<UserSect> getSect(String dept) throws Exception {
		updUserDeptSect(false);
		ArrayList<UserSect> list = new ArrayList<UserSect>();
		for (int i = 0; i < userSectList.size(); i++) {
			if (userSectList.get(i).getDEPT().equals(dept.toUpperCase())) {
				list.add(userSectList.get(i));
			}
		}
		return list;
	}

	/**
	 * ���o�Ҧ��էO��T
	 * 
	 * @return �էO��T
	 */
	public ArrayList<UserSect> getSect() {
		return userSectList;
	}

	/**
	 * ��s Dept/Sect List, �j���s (call updUserDeptSect()) �μ��X thread �C���s
	 * 
	 * @param isForceUpdate
	 *            �j���s Dept/Sect List �P�_
	 * @throws Exception
	 */
	public void updUserDeptSect(boolean isForceUpdate) throws Exception {
		if (isForceUpdate || userDeptList == null || userSectList == null) {
			synchronized (deptsectlock) {
				if (isForceUpdate || userDeptList == null || userSectList == null) {
					updUserDeptSect();
				}
				if (!isDeptSectUpdater) {
					new DeptsectInfoUpdater().start();
					isDeptSectUpdater = true;
				}
			}
		}
	}

	/**
	 * ��ڧ�s Dept/Sect List ����k
	 * 
	 * @throws Exception
	 */
	private void updUserDeptSect() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getDeptSect, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					ArrayList<UserDept> tmp_userDeptList = new ArrayList<UserDept>();
					ArrayList<UserSect> tmp_userSectList = new ArrayList<UserSect>();
					TreeMap<String, UserDept> tmp_userDeptList_proc = new TreeMap<String, UserDept>();
					UserDept userDept = null;
					UserSect userSect = null;
					JSONObject jObj = null;
					for (int i = 0; i < jsonArray.length(); i++) {
						userSect = new UserSect();
						jObj = (JSONObject) jsonArray.get(i);
						userSect.setDEPT(jObj.getString("DEPT").toUpperCase());
						userSect.setDEPT_INFO(jObj.getString("DEPT_INFO"));
						userSect.setSECT(jObj.getString("SECT").toUpperCase());
						userSect.setSECT_INFO(jObj.getString("SECT_INFO"));
						userSect.setSECT_CNT(Integer.parseInt(jObj.getString("CNT")));
						tmp_userSectList.add(userSect);
						if (tmp_userDeptList_proc.get(userSect.getDEPT()) == null) {
							userDept = new UserDept();
							userDept.setDEPT(userSect.getDEPT().toUpperCase());
							userDept.setDEPT_INFO(userSect.getSECT_INFO());
							userDept.setDEPT_CNT(0);
							tmp_userDeptList_proc.put(userDept.getDEPT(), userDept);
						}
						tmp_userDeptList_proc.get(userDept.getDEPT()).setDEPT_CNT(tmp_userDeptList_proc.get(userDept.getDEPT()).getDEPT_CNT() + userSect.getSECT_CNT());
					}
					for (Map.Entry<String, UserDept> entry : tmp_userDeptList_proc.entrySet()) {
						tmp_userDeptList.add(entry.getValue());
					}
					userDeptList = tmp_userDeptList;
					userSectList = tmp_userSectList;
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Thread - responsible for Dept/Sect List update
	 * 
	 * @author ESB19600
	 *
	 */
	class DeptsectInfoUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000); // one day
				} catch (Exception e) {
				}
				try {
					updUserDeptSect(true);
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/***********************************
	 * Currency
	 **********************************/
	static TreeMap<String, CurrencyInfo> currencyInfoList = null;

	static Object currencylock = new Object();

	static boolean isCurrencyInfoUpdater = false;

	/**
	 * ��POSID���o���O��T
	 * 
	 * @param posid
	 *            POSID
	 * 
	 * @return ���O��T
	 * @throws Exception
	 */
	public CurrencyInfo getCurrencyInfo(String posid) throws Exception {
		updCurrencyInfo(false);
		if (posid.startsWith("50")) {
			return currencyInfoList.get("50[0-9]{6}");
		} else if (posid.startsWith("51")) {
			return currencyInfoList.get("51[0-9]{6}");
		} else if (posid.startsWith("52")) {
			return currencyInfoList.get("52[0-9]{6}");
		} else if (posid.startsWith("53")) {
			return currencyInfoList.get("53[0-9]{6}");
		} else if (posid.startsWith("54")) {
			return currencyInfoList.get("54[0-9]{6}");
		} else if (posid.startsWith("E") && posid.endsWith("1")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}1");
		} else if (posid.startsWith("E") && posid.endsWith("2")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}2");
		} else if (posid.startsWith("E") && posid.endsWith("3")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}3");
		} else if (posid.startsWith("E") && posid.endsWith("4")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}4");
		} else if (posid.startsWith("E") && posid.endsWith("5")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}5");
		}
		for (Map.Entry<String, CurrencyInfo> currencyInfoItem : currencyInfoList.entrySet()) {
			if (posid.matches(currencyInfoItem.getKey())) {
				CurrencyInfo currencyInfo = currencyInfoItem.getValue();
				currencyInfo.setPOSID(posid);
				return currencyInfo;
			}
		}
		return null;
	}

	/**
	 * ��s currencyInfoList, �j���s (call updCurrencyInfo()) �μ��X thread �C���s
	 * 
	 * @param isForceUpdate
	 *            �j���s Dept/Sect List �P�_
	 * @throws Exception
	 */
	public void updCurrencyInfo(boolean isForceUpdate) throws Exception {
		if (isForceUpdate || currencyInfoList == null) {
			synchronized (currencylock) {
				if (isForceUpdate || currencyInfoList == null) {
					updCurrencyInfo();
				}
				if (!isCurrencyInfoUpdater) {
					new CurrencyInfoUpdater().start();
					isCurrencyInfoUpdater = true;
				}
			}
		}
	}

	/**
	 * ��ڧ�s currencyInfo Map ����k
	 * 
	 * @throws Exception
	 */
	private void updCurrencyInfo() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getCurrencyInfo, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					TreeMap<String, CurrencyInfo> tmp_currencyInfoList = new TreeMap<String, CurrencyInfo>();
					CurrencyInfo currencyInfo = null;
					JSONObject jObj = null;
					for (int i = 0; i < jsonArray.length(); i++) {
						currencyInfo = new CurrencyInfo();
						jObj = (JSONObject) jsonArray.get(i);
						currencyInfo.setPOSID(jObj.getString("posid"));
						currencyInfo.setCurrency(jObj.getString("currency"));
						currencyInfo.setCurrencyDesc(jObj.getString("currencyDesc"));
						currencyInfo.setCode(jObj.getString("code"));
						currencyInfo.setInfo(jObj.getString("info"));
						tmp_currencyInfoList.put(currencyInfo.getPOSID(), currencyInfo);
					}
					currencyInfoList = tmp_currencyInfoList;
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Thread - responsible for currencyInfoList update
	 * 
	 * @author ESB19600
	 *
	 */
	class CurrencyInfoUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000); // one day
				} catch (Exception e) {
				}
				try {
					updCurrencyInfo(true);
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/***********************************
	 * CardImage
	 *********************************/
	private static TreeMap<String, CardImageObj> CardImage = new TreeMap<String, CardImageObj>();

	class CardImageObj {
		byte[] image;
		long lastUpdateTime;
	}

	/**
	 * �q CardImg Map ���o�d������
	 * 
	 * @param AGNO
	 *            �{�P����
	 * @param CATP
	 *            �d��
	 * @return byte[] cardImg
	 * @throws Exception
	 */
	public byte[] getCardImage(String AGNO, String CATP) throws Exception {
		long time = System.currentTimeMillis();
		CardImageObj cardimage = null;
		// 1.���P�_ MAP �̭����S���A�S���ζW�L�@�ѭ��s�e request to service
		cardimage = CardImage.get(AGNO + "#|" + CATP);
		if (cardimage == null || (time - CardImage.get(AGNO + "#|" + CATP).lastUpdateTime > 86400)) {
			cardimage = getCardImageForcedFromServiceAndUpdate(AGNO, CATP, time);
		}
		// 2.�٬O�S�����ɡA�^�� BANK+CATP
		if (cardimage == null) {
			if ((cardimage = CardImage.get("BANK" + "#|" + CATP)) == null) {
				cardimage = getCardImageForcedFromServiceAndUpdate("BANK", CATP, time);
			}
		}
		// 3.�٬O�S�����ɡA�^�� BANK+CATP �Ĥ@�X
		if (cardimage == null) {
			if ((cardimage = CardImage.get("BANK" + "#|" + CATP.substring(0, 1))) == null) {
				cardimage = getCardImageForcedFromServiceAndUpdate("BANK", CATP.substring(0, 1), time);
			}
		}
		return cardimage == null ? null : cardimage.image;
	}

	/**
	 * �q CommonService ���o�d�����ɨç�s CardImg Map
	 * 
	 * @param AGNO
	 *            �{�P����
	 * @param CATP
	 *            �d��
	 * @param time
	 *            ��s�ɶ�
	 * @return CardImageObj
	 * @throws Exception
	 */
	private CardImageObj getCardImageForcedFromServiceAndUpdate(String AGNO, String CATP, long time) throws Exception {
		CardImageObj cardImageObj = null;
		byte[] image = getCardImageFromService(AGNO, CATP);
		if (image != null) {
			cardImageObj = new CardImageObj();
			cardImageObj.image = image;
			cardImageObj.lastUpdateTime = time;
			CardImage.put(AGNO + "#|" + CATP, cardImageObj);
		}
		return cardImageObj;
	}

	/**
	 * �q CommonService ���o�d������
	 * 
	 * @param AGNO
	 *            �{�P����
	 * @param CATP
	 *            �d��
	 * @return
	 * @throws IOException
	 * @throws Exception
	 */
	private byte[] getCardImageFromService(String AGNO, String CATP) throws Exception {
		byte[] image = null;
		HttpURLConnection conn = null;
		OutputStreamWriter oswr = null;
		BufferedReader br = null;
		String response = "";
		JSONObject respJObj = null;
		JSONObject dataJObj = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getCardImg, "POST");
			JSONObject reqJson = new JSONObject();
			reqJson.put("AGNO", AGNO);
			reqJson.put("CATP", CATP);
			oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
			oswr.write(reqJson.toString());
			oswr.flush();
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					dataJObj = new JSONObject(respJObj.getString("Data"));
					image = dataJObj.getString("cardFile").getBytes(StandardCharsets.UTF_8);
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (oswr != null) {
					oswr.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return image;
	}

	/*********************************************************************************/

	/*************************************
	 * ANTCD
	 ***********************************/
	public static final String non_holiday_Code = "1";

	public static final String half_holiday_Code = "2";

	public static final String holiday_Code = "3";

	public static final int Month_Period_Next = 1;

	public static final int Month_Period_Previous = -1;

	private static TreeMap<String, HolidayInfo> actcdList = new TreeMap<String, HolidayInfo>();

	class HolidayInfo {
		String antcdStr;
		String sysDate;

		public String getAntcdStr() {
			return antcdStr;
		}

		public void setAntcdStr(String antcdStr) {
			this.antcdStr = antcdStr;
		}

		public String getSysDate() {
			return sysDate;
		}

		public void setSysDate(String sysDate) {
			this.sysDate = sysDate;
		}
	}

	/**
	 * �d�ߤ릳�X��
	 * 
	 * @param year
	 *            �d�ߦ~
	 * @param month
	 *            �d�ߤ�
	 * @return Int day in month
	 */
	private int getDaysInMonth(int month, int year) {
		if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {
			return 31;
		} else if (month == 4 || month == 6 || month == 9 || month == 11) {
			return 30;
		} else if (month == 2) { // �P�_�O���O�|�~
			if (new GregorianCalendar().isLeapYear(year)) {
				return 29;
			} else {
				return 28;
			}
		}
		return 0;
	}

	/*
	 * �^�ǥN�����w������W�Z�񰲦r��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return antcd
	 * 
	 * @throws Exception
	 */
	public String getMonthsANTCD(GregorianCalendar gc) throws Exception {
		HolidayInfo info = null;
		String antcd = "";
		info = actcdList.get(gc.get(GregorianCalendar.YEAR) + "" + (gc.get(GregorianCalendar.MONTH) + 1));
		if (info != null && info.getSysDate().equals(DateUtil.getNowDate())) {
			antcd = info.getAntcdStr();
		} else {
			antcd = getANTCD(gc.get(GregorianCalendar.YEAR), gc.get(GregorianCalendar.MONTH) + 1);
		}
		return antcd;
	}

	/*
	 * �W����
	 * 
	 * @param GregorianCalendar ���
	 * 
	 * @param control ����[�άO��
	 * 
	 * @return GregorianCalendar new instance
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getAddMonOrSubMon(GregorianCalendar gc, int control) throws Exception {
		GregorianCalendar gcAdded = new GregorianCalendar(gc.get(GregorianCalendar.YEAR), gc.get(GregorianCalendar.MONTH), gc.get(GregorianCalendar.DAY_OF_MONTH));
		gcAdded.add(GregorianCalendar.MONTH, control);
		return gcAdded;
	}

	/**
	 * �P�_���ѬO�_������
	 * 
	 * @return �O�_������(true/false)
	 * @throws Exception
	 */
	public boolean isHoliday() throws Exception {
		return isHoliday(new GregorianCalendar());
	}

	/**
	 * �P�_���Ѫ�����O�_������
	 * 
	 * @param GregorianCalendar
	 *            ���
	 * @return �O�_������(true/false)
	 * @throws Exception
	 */
	public boolean isHoliday(GregorianCalendar gc) throws Exception {
		return getMonthsANTCD(gc).substring(gc.get(GregorianCalendar.DATE) - 1, gc.get(GregorianCalendar.DATE)).equals(holiday_Code);
	}

	/**
	 * �d�ߤ��Ѥ���U�@�Ӱ���
	 * 
	 * @return GregorianCalendar new instance
	 * @throws Exception
	 */
	public GregorianCalendar getNextHoliday() throws Exception {
		return getNextHoliday(new GregorianCalendar());
	}

	/*
	 * ���w����d�ߤU�@�Ӱ���
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar new instance
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getNextHoliday(GregorianCalendar gc) throws Exception {
		return getAfterDay(gc, holiday_Code);

	}

	/*
	 * �d�ߤ��Ѥ���U�@�Ӥu�@��
	 * 
	 * @return GregorianCalendar new instance
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getNextWorkday() throws Exception {
		return getNextWorkday(new GregorianCalendar());
	}

	/*
	 * ���w����d�߫e�@�Ӥu�@��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar new instance
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getPreviousWorkday(GregorianCalendar gc) throws Exception {
		return getBeforeDay(gc, non_holiday_Code);
	}

	/*
	 * ���w����d�ߤU�@�Ӥu�@��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar new instance
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getNextWorkday(GregorianCalendar gc) throws Exception {
		return getAfterDay(gc, non_holiday_Code);
	}

	/**
	 * �^�ǩ��e�d�ߥX�Ӫ����@��
	 * 
	 * @param GregorianCalendar
	 *            ���
	 * @param compare_date
	 *            �n�d�ߤu�@�άO�񰲪��N��String
	 * @return GregorianCalendar new instance
	 * @throws Exception
	 */
	public GregorianCalendar getBeforeDay(GregorianCalendar gc, String compare_date) throws Exception {
		GregorianCalendar tmp_gc = new GregorianCalendar(gc.get(GregorianCalendar.YEAR), gc.get(GregorianCalendar.MONTH), gc.get(GregorianCalendar.DAY_OF_MONTH));
		String antcd = "";
		int idx = 0;
		boolean isfinded = false;
		tmp_gc.add(GregorianCalendar.DATE, -2); // �@�}�l����@�� �]���q0�}�l�ҥH�A��@��
		while (!isfinded) {
			antcd = getMonthsANTCD(tmp_gc); // �@����@�Ӥ몺�r��
			idx = antcd.lastIndexOf(compare_date, tmp_gc.get(GregorianCalendar.DATE)); // �q�ۤv�o�@�Ѷ}�l��
			if (idx != -1) { // �N�������
				isfinded = true;
				tmp_gc.set(GregorianCalendar.DATE, idx + 1);
			} else { // �N���S���
				tmp_gc = getAddMonOrSubMon(tmp_gc, Month_Period_Previous);
				tmp_gc.set(GregorianCalendar.DATE, getDaysInMonth((tmp_gc.get(GregorianCalendar.MONTH) + 1), tmp_gc.get(GregorianCalendar.YEAR)));
			}
		}
		return tmp_gc;
	}

	/**
	 * �^�ǩ���d�ߥX�Ӫ����@��
	 * 
	 * @param GregorianCalendar
	 *            ���
	 * @param compare_date
	 *            �n�d�ߤu�@�άO�񰲪��N��String
	 * @return GregorianCalendar new instance
	 * @throws Exception
	 */
	public GregorianCalendar getAfterDay(GregorianCalendar gc, String compare_date) throws Exception {
		GregorianCalendar tmp_gc = new GregorianCalendar(gc.get(GregorianCalendar.YEAR), gc.get(GregorianCalendar.MONTH), gc.get(GregorianCalendar.DAY_OF_MONTH));
		String antcd = "";
		int idx = 0;
		boolean isfinded = false;
		tmp_gc.add(GregorianCalendar.DATE, 1); // �@�}�l���[�@��
		while (!isfinded) {
			antcd = getMonthsANTCD(tmp_gc);
			idx = antcd.indexOf(compare_date, tmp_gc.get(GregorianCalendar.DATE) - 1); // �q�ۤv�o�@�Ѷ}�l��
			if (idx != -1) { // �N�������
				isfinded = true;
				tmp_gc.set(GregorianCalendar.DATE, idx + 1);
			} else {
				tmp_gc = getAddMonOrSubMon(tmp_gc, Month_Period_Next);
				tmp_gc.set(GregorianCalendar.DATE, 1);
			}
		}
		return tmp_gc;
	}

	/**
	 * �d�߸�Ʈw���@�Ӥ����������
	 * 
	 * @param conn
	 *            ��Ʈw�s�u
	 * @param year
	 *            �d�ߦ~
	 * @param month
	 *            �d�ߤ�
	 * @return String
	 * @throws Exception
	 */
	private String getANTCD(int year, int month) throws Exception {
		HttpURLConnection conn = null;
		OutputStreamWriter oswr = null;
		BufferedReader br = null;
		JSONObject respJObj = null;
		JSONObject dataJObj = null;
		HolidayInfo info = null;
		String response = "";
		String antcdStr = "";
		try {
			conn = commonServiceConnector(commonServiceHost + getAntcd, "POST");
			JSONObject reqJson = new JSONObject();
			reqJson.put("year", year);
			reqJson.put("month", month);
			oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
			oswr.write(reqJson.toString());
			oswr.flush();
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					dataJObj = new JSONObject(respJObj.getString("Data"));
					info = new HolidayInfo();
					info.setAntcdStr(dataJObj.getString("antcd"));
					info.setSysDate(DateUtil.getNowDate());
					actcdList.put(dataJObj.getString("year") + dataJObj.getString("month"), info);
					antcdStr = dataJObj.getString("antcd");
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (oswr != null) {
					oswr.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return antcdStr;
	}

	/*********************************************************************************/

	/***********************************
	 * EsunBranch
	 ********************************/
	// �x�s����W�٤ΥN�X
	private static LinkedHashMap<String, String> esunBranch = null;

	// �x�s�U�ȥi�H�˻⪺����ξ��c�W�٤ΥN�X
	private static LinkedHashMap<String, String> esunBranchByInPerson = null;

	/**
	 * �d�߳��W��
	 * 
	 * @param String
	 *            ���w���s/�˻���N�X
	 * 
	 * @return String ���s/�˻���W��
	 * @throws Exception
	 */
	public String getEsunBranch(String branchNo) throws Exception {
		String branchName = "";
		if (esunBranch == null || esunBranch.size() <= 0) {
			esunBranch = getEsunBranch();
		}
		branchName = esunBranch.get(branchNo);
		return branchName;
	}

	/**
	 * �d�ߩҦ����s/�˻���
	 * 
	 * @return ���s/�˻���N�X�ΦW��
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getEsunBranch() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		try {
			if (esunBranch == null || esunBranch.size() <= 0) {
				esunBranch = new LinkedHashMap<String, String>();
				conn = commonServiceConnector(commonServiceHost + getEsunBranch, "GET");
				int responseCode = conn.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) {
					String line = "";
					br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
					while ((line = br.readLine()) != null) {
						response += line;
					}
					respJObj = new JSONObject(response);
					if (respJObj.getString("RC").equals("OK")) {
						jsonArray = new JSONArray(respJObj.getString("Data"));
						for (int i = 0; i < jsonArray.length(); i++) {
							esunBranch.put(((JSONObject) jsonArray.get(i)).getString("branchNo"), StringUtil.getChineseTrim(((JSONObject) jsonArray.get(i)).getString("bankName")));
						}
					} else {
						throw new Exception(respJObj.toString());
					}
				} else {
					throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
				}
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return esunBranch;
	}

	/**
	 * �d�߿˻���N�X�ΦW��
	 * 
	 * @return �˻���N�X�ΦW��
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getEsunBranchByInPerson() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		try {
			if (esunBranchByInPerson == null || esunBranchByInPerson.size() <= 0) {
				esunBranchByInPerson = new LinkedHashMap<String, String>();
				conn = commonServiceConnector(commonServiceHost + getEsunBranchByInPerson, "GET");
				int responseCode = conn.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) {
					String line = "";
					br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
					while ((line = br.readLine()) != null) {
						response += line;
					}
					respJObj = new JSONObject(response);
					if (respJObj.getString("RC").equals("OK")) {
						jsonArray = new JSONArray(respJObj.getString("Data"));
						for (int i = 0; i < jsonArray.length(); i++) {
							esunBranchByInPerson.put(((JSONObject) jsonArray.get(i)).getString("branchNo"), StringUtil.getChineseTrim(((JSONObject) jsonArray.get(i)).getString("bankName")));
						}
					} else {
						throw new Exception(respJObj.toString());
					}
				} else {
					throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
				}
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return esunBranchByInPerson;
	}

	/*********************************************************************************/

	/***********************************
	 * CommonAGNO
	 ********************************/
	private static TreeMap<String, CommonAGNO> CommonAGNOList = null;
	private static boolean isAGNOUpdater = false;
	private static final Object agnolock = new Object();

	public CommonAGNO getAGNO(String AGNO) throws Exception {
		if (CommonAGNOList == null) {
			updAGNOBatch();
		}
		CommonAGNO commonAGNO = CommonAGNOList.get(AGNO);
		if (commonAGNO == null) {
			commonAGNO = new CommonAGNO();
			commonAGNO.setAGNO(AGNO);
			commonAGNO.setCMCNM("�ɤs�Ȧ�");
			commonAGNO.setCMSNM("�ɤs�Ȧ�");
			commonAGNO.setCMENM("E.SUN BANK");
			commonAGNO.setAFCNM("�ɤs�H�Υd");
		}
		return commonAGNO;
	}

	protected void updAGNOBatch() throws Exception {
		synchronized (agnolock) {
			updAGNO();
			if (!isAGNOUpdater) {
				isAGNOUpdater = true;
				new AgnoUpdater().start();
			}
		}
	}

	private void updAGNO() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getAGNO, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					TreeMap<String, CommonAGNO> tmp_CommonAGNOList = new TreeMap<String, CommonAGNO>();
					CommonAGNO agno = null;
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_Obj = (JSONObject) jsonArray.get(i);
						agno = new CommonAGNO();
						agno.setAGNO(tmp_Obj.getString("agno"));
						agno.setCMCNM(tmp_Obj.getString("cmcnm"));
						agno.setCMSNM(tmp_Obj.getString("cmsnm"));
						agno.setCMENM(tmp_Obj.getString("cmenm"));
						agno.setAFCNM(tmp_Obj.getString("afcnm"));
						tmp_CommonAGNOList.put(agno.getAGNO(), agno);
					}
					CommonAGNOList = tmp_CommonAGNOList;
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Thread - responsible for CommonAGNOList update
	 * 
	 * @author ESB19600
	 *
	 */
	class AgnoUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000); // one day
				} catch (Exception e) {
				}
				try {
					updAGNOBatch();
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/************************************
	 * BankData
	 *********************************/
	private static HashMap<String, SSBANKDATA> bankData = null;
	private static boolean isBankData = false;
	private static final Object bankDatalock = new Object();

	// ���o�Ȧ��ƦW��
	public HashMap<String, SSBANKDATA> getBankData() throws Exception {
		if (bankData == null) {
			synchronized (bankDatalock) {
				if (!isBankData) {
					setBankNO();
					isBankData = true;
				}
			}
		}
		return bankData;
	}

	/**
	 * ���o SSBankData �üg�J Map
	 * 
	 * @param bankNO
	 *            �Ȧ�N�X
	 */
	private void setBankNO() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		SSBANKDATA data = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getSSBankData, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				bankData = new HashMap<String, SSBANKDATA>();
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						data = new SSBANKDATA();
						data.setBANKNO(tmp_obj.getString("bankno"));
						data.setBANKNAME(StringUtil.getChineseTrim("bankname"));
						data.setBANKTEL1(tmp_obj.getString("banktel1"));
						data.setBANKTEL2(tmp_obj.getString("banktel2"));
						data.setBANKTEL3(tmp_obj.getString("banktel3"));
						data.setBANKTEL4(tmp_obj.getString("banktel4"));
						data.setBANKFAX(tmp_obj.getString("bankfax"));
						data.setBATCHNO(Integer.parseInt(tmp_obj.getString("batchno")));
						data.setNOWDATE(tmp_obj.getString("nowdate"));
						bankData.put(data.getBANKNO(), data);
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/*********************************************************************************/

	/************************************
	 * CardData
	 *********************************/
	// �O�_�O�ɤsBIN
	private static HashMap<String, SSBankBin> ESunCardBinNo = null;
	private static boolean isInit = false;
	private static final Object esunBinLock = new Object();
	// thread ��s EsunCardData()
	private static boolean isEsunUpdater = false;
	private static final Object esunlock = new Object();

	/**
	 * ��J�d�����o�ҹ������d�����Ӹ��
	 * 
	 * @param cardNo
	 *            �d��
	 * @return SSBankBin �d�����
	 * @throws Exception
	 */
	public SSBankBin getCardData(String cardNo) throws Exception {
		HttpURLConnection conn = null;
		OutputStreamWriter oswr = null;
		BufferedReader br = null;
		String response = "";
		JSONObject respJObj = null;
		JSONObject dataJObj = null;
		SSBankBin cardData = null;

		if (cardNo == null || cardNo.length() < 6) {
			return null;
		}

		try {
			conn = commonServiceConnector(commonServiceHost + getSSBankBin, "POST");
			JSONObject reqJson = new JSONObject();
			reqJson.put("cardNO", cardNo);
			oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
			oswr.write(reqJson.toString());
			oswr.flush();
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				cardData = new SSBankBin();
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					dataJObj = new JSONObject(respJObj.getString("Data"));
					cardData.setBinNo(dataJObj.getString("binNo"));
					cardData.setBankNo(dataJObj.getString("bankNo"));
					cardData.setBankType(dataJObj.getString("bankType"));
					cardData.setBrand(dataJObj.getString("brand"));
					cardData.setCardType(dataJObj.getString("cardType"));
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (oswr != null) {
					oswr.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return cardData;
	}

	/**
	 * �O�_�O�ɤs�d
	 * 
	 * @param ����d��
	 */
	public boolean isEsunCard(String cano) throws Exception {
		if (ESunCardBinNo == null) {
			synchronized (esunBinLock) {
				if (!isInit) {
					updEsunCard();
					isInit = true;
				}
			}
		}
		return ESunCardBinNo.containsKey(cano.substring(0, 6));
	}

	/**
	 * ���o�ɤsBIN���
	 * 
	 * @param String
	 *            ����d��
	 * @return SSBankBin �d�����
	 */
	public SSBankBin getEsunCardBinData(String cano) throws Exception {
		if (ESunCardBinNo == null) {
			synchronized (esunBinLock) {
				if (!isInit) {
					updEsunCard();
					isInit = true;
				}
			}
		}
		return ESunCardBinNo.get(cano.substring(0, 6));
	}

	protected void updEsunCard() throws Exception {
		synchronized (esunlock) {
			setEsunCardData();
			if (!isEsunUpdater) {
				isEsunUpdater = true;
				new EsunCardDataUpdater().start();
			}
		}
	}

	/**
	 * ���o�ɤsBIN data
	 * 
	 * @throws Exception
	 */
	private void setEsunCardData() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		SSBankBin cardData = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getEsunSSBankBin, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				ESunCardBinNo = new HashMap<String, SSBankBin>();
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				String line = "";
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						cardData = new SSBankBin();
						cardData.setBinNo(tmp_obj.getString("binNo"));
						cardData.setBankNo(tmp_obj.getString("bankNo"));
						cardData.setBankType(tmp_obj.getString("bankType"));
						cardData.setBrand(tmp_obj.getString("brand"));
						cardData.setCardType(tmp_obj.getString("cardType"));
						ESunCardBinNo.put(cardData.getBinNo(), cardData);
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	class EsunCardDataUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					setEsunCardData();
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/************************************
	 * FXMLBank
	 *********************************/
	/**
	 * ���o�Ҧ�FXML��w
	 * 
	 * @return ArrayList<BankDataCtl> FXML��w
	 * @throws Exception
	 */
	public ArrayList<BankDataCtl> getFXMLBankCtl() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		ArrayList<BankDataCtl> rsltList = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getFXMLBankCtl, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				rsltList = new ArrayList<BankDataCtl>();
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						BankDataCtl tmp_bdc = new BankDataCtl();
						tmp_bdc.setBANKID(tmp_obj.getString("bankid"));
						tmp_bdc.setBANKCNAME(tmp_obj.getString("bankcname"));
						tmp_bdc.setBANKENAME(tmp_obj.getString("bankename"));
						tmp_bdc.setSTATUS(tmp_obj.getString("status"));
						tmp_bdc.setCHANNEL(tmp_obj.getString("channel"));
						tmp_bdc.setSALBANK(tmp_obj.getString("salbank"));
						tmp_bdc.setATM(tmp_obj.getBoolean("atm"));
						tmp_bdc.setRMT(tmp_obj.getBoolean("rmt"));
						tmp_bdc.setFEDI(tmp_obj.getBoolean("fedi"));
						tmp_bdc.setFXML(tmp_obj.getBoolean("fxml"));
						rsltList.add(tmp_bdc);
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return rsltList;
	}

	/*********************************************************************************/

	/***********************************
	 * BankDataDtl
	 *******************************/
	/**
	 * 
	 * @param BANKID
	 *            �Ȧ�N�X
	 * @return ArrayList<BankDataDtl> ����C��
	 * @throws Exception
	 */
	public ArrayList<BankDataDtl> getBankDtl(String BANKID) throws Exception {
		HttpURLConnection conn = null;
		OutputStreamWriter oswr = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		ArrayList<BankDataDtl> rsltList = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getBankDataDtl, "POST");
			oswr = new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8);
			JSONObject reqJObj = new JSONObject();
			reqJObj.put("bankID", BANKID);
			oswr.write(reqJObj.toString());
			oswr.flush();
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				rsltList = new ArrayList<BankDataDtl>();
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						BankDataDtl tmp_bdd = new BankDataDtl();
						tmp_bdd.setXTYPE(tmp_obj.getString("xtype"));
						tmp_bdd.setBANKID(tmp_obj.getString("bankid"));
						tmp_bdd.setBRANCHID(tmp_obj.getString("branchid"));
						tmp_bdd.setBANKNAME(tmp_obj.getString("bankname"));
						tmp_bdd.setBRANCHNAME(tmp_obj.getString("branchname"));
						tmp_bdd.setBRANCHADDR(tmp_obj.getString("branchaddr"));
						tmp_bdd.setBRANCHPHONE(tmp_obj.getString("branchphone"));
						tmp_bdd.setBRANCHDATE(tmp_obj.getString("branchdate"));
						tmp_bdd.setRY(tmp_obj.getString("ry"));
						tmp_bdd.setRM(tmp_obj.getString("rm"));
						rsltList.add(tmp_bdd);
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (oswr != null) {
					oswr.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return rsltList;
	}

	/*********************************************************************************/

	/******************************
	 * NCCC Card Verify Bank
	 **************************/
	private static ArrayList<NCCCCardVerify> cardVerifyBank = null;
	private static final Object CardVerifyBankDatalock = new Object();
	private static boolean isCardVerifyBankUpdater = false;
	private static String cardVerifyBankName = null;

	/**
	 * ���o NCCC �H�Υd���һȦ�W��
	 * 
	 * @return String ���һȦ�W�٦r��
	 */
	public String getCardVerifyBankName() throws Exception {
		if (cardVerifyBank == null) {
			updCardVerifyBank();
		}
		return cardVerifyBankName;
	}

	/**
	 * ���oNCCC �H�Υd���һȦ�
	 * 
	 * @return ArrayList<NCCCCardVerify> ���һȦ�C��
	 */
	public ArrayList<NCCCCardVerify> getCardVerifyBank() throws Exception {
		if (cardVerifyBank == null) {
			updCardVerifyBank();
		}
		return cardVerifyBank;
	}

	private void updCardVerifyBank() throws Exception {
		synchronized (CardVerifyBankDatalock) {
			if (cardVerifyBank == null) {
				getCardVerifyBankData();
			}
			if (!isCardVerifyBankUpdater) {
				isCardVerifyBankUpdater = true;
				new CardVerifyBankUpdater().start();
			}
		}
	}

	private void getCardVerifyBankData() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		NCCCCardVerify tmp = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getN3CCardVerify, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					ArrayList<NCCCCardVerify> tmp_rslt = new ArrayList<NCCCCardVerify>();
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						tmp = new NCCCCardVerify();
						tmp.setBANKID(tmp_obj.getString("bankid"));
						tmp.setBANKCNAME(StringUtil.getChineseTrim(tmp_obj.getString("bankcname")));
						tmp_rslt.add(tmp);
					}
					if (tmp_rslt != null && tmp_rslt.size() > 0) {
						cardVerifyBank = tmp_rslt;
						String tmp_bankName = "";
						for (int i = 0; i < cardVerifyBank.size(); i++) {
							tmp_bankName += "�B" + cardVerifyBank.get(i).getBANKCNAME();
						}
						cardVerifyBankName = tmp_bankName.substring(1);
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	class CardVerifyBankUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getCardVerifyBankData();
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/

	/***********************************
	 * Nationality
	 *******************************/
	private static LinkedHashMap<String, HostConfig> nationalityData = null;
	private static final Object NationalityDataLock = new Object();
	private static boolean isNationalityDataUpdater = false;

	/**
	 * ���o���y���
	 * 
	 * @return LinkedHashMap<String, HostConfig>
	 */
	public LinkedHashMap<String, HostConfig> getNationalitySelectData() throws Exception {
		if (nationalityData == null) {
			updNationalityData();
		}
		return nationalityData;

	}

	/**
	 * ��s���y��ƨåB�Ұ�thread�w�ɧ�s���
	 */
	private void updNationalityData() throws Exception {
		synchronized (NationalityDataLock) {
			if (nationalityData == null) {
				getNationalityData();
			}
			if (!isNationalityDataUpdater) {
				isNationalityDataUpdater = true;
				new NationalityDataUpdater().start();
			}
		}
	}

	/**
	 * ���o���y��ơA�j����01�B������121(�ѷӥD��B3000�]�w)
	 * 
	 * @throws Exception
	 */
	private void getNationalityData() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		HostConfig hostConfig = null;
		try {

			conn = commonServiceConnector(commonServiceHost + getNationality, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					LinkedHashMap<String, HostConfig> tmp_list = new LinkedHashMap<String, HostConfig>();
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						hostConfig = new HostConfig();
						hostConfig.setTTPCD(tmp_obj.getString("ttpcd"));
						hostConfig.setSTPCD(tmp_obj.getString("stpcd"));
						hostConfig.setNOCD(StringUtil.getChineseTrimR(tmp_obj.getString("nocd")));
						hostConfig.setNMCDD(StringUtil.getChineseTrimR(tmp_obj.getString("nmcdd")));
						hostConfig.setDMARK(tmp_obj.getString("dmark"));
						tmp_list.put(hostConfig.getNOCD(), hostConfig);

					}
					if (!tmp_list.isEmpty()) {
						nationalityData = tmp_list;
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	class NationalityDataUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getNationalityData();
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/*********************************************************************************/
	/*********************************************************************************/

	/***********************************
	 * Nationality Parameter
	 *******************************/
	private static LinkedHashMap<String, HostConfig> hostData = null;
	private static final Object HostDataLock = new Object();
	private static boolean isHostDataUpdater = false;

	/**
	 * ��TTPCD,STPCD���o�S�w�N�X��
	 * 
	 * @param TTPCD,STPCD
	 * @return LinkedHashMap<String, HostConfig>
	 * @author ESB20138
	 */
	public LinkedHashMap<String, HostConfig> getHostConfigSelectData(String TTPCD, String STPCD) throws Exception {
		LinkedHashMap<String, HostConfig> hostDataNotNull = null;
		String key = TTPCD + STPCD;

		if (hostData == null) {
			updHostData();
		}

		hostDataNotNull = new LinkedHashMap<String, HostConfig>(hostData);

		Iterator<String> it = hostDataNotNull.keySet().iterator();
		while (it.hasNext()) {
			String obj = it.next();
			if (!obj.startsWith(key)) {
				it.remove();
			}
		}

		return hostDataNotNull;
	}

	/**
	 * ��s�N�X����ƨåB�Ұ�thread�w�ɧ�s���
	 * 
	 * @author ESB20138
	 */
	private void updHostData() throws Exception {
		synchronized (HostDataLock) {
			if (hostData == null) {
				getHostData();
			}
			if (!isHostDataUpdater) {
				isHostDataUpdater = true;
				new HostDataUpdater().start();
			}
		}
	}

	/**
	 * ��s�N�X����ƨåB�Ұ�thread�w�ɧ�s���
	 * 
	 * @author ESB20138
	 */
	class HostDataUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getHostData();
				} catch (Exception e) {
					logUtil.Error("[" + fqcn + "." + this.getClass().getName() + "]" + StringUtil.getStackTraceASString(e));
				}
			}
		}
	}

	/**
	 * ���o�N�X�����(�ѷӥD��B3000�]�w)
	 * 
	 * @throws Exception
	 * @author ESB20138
	 */
	private void getHostData() throws Exception {
		HttpURLConnection conn = null;
		BufferedReader br = null;
		String response = "";
		JSONArray jsonArray = null;
		JSONObject respJObj = null;
		HostConfig hostConfig = null;
		try {
			conn = commonServiceConnector(commonServiceHost + getHost, "GET");
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line = "";
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
				while ((line = br.readLine()) != null) {
					response += line;
				}
				respJObj = new JSONObject(response);
				if (respJObj.getString("RC").equals("OK")) {
					jsonArray = new JSONArray(respJObj.getString("Data"));
					LinkedHashMap<String, HostConfig> tmp_list = new LinkedHashMap<String, HostConfig>();
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject tmp_obj = (JSONObject) jsonArray.get(i);
						hostConfig = new HostConfig();
						hostConfig.setTTPCD(tmp_obj.getString("ttpcd"));
						hostConfig.setSTPCD(tmp_obj.getString("stpcd"));
						hostConfig.setNOCD(StringUtil.getChineseTrimR(tmp_obj.getString("nocd")));
						hostConfig.setNMCDD(StringUtil.getChineseTrimR(tmp_obj.getString("nmcdd")));
						hostConfig.setDMARK(tmp_obj.getString("dmark"));
						tmp_list.put(hostConfig.getTTPCD() + hostConfig.getSTPCD() + hostConfig.getNOCD(), hostConfig);
					}
					if (!tmp_list.isEmpty()) {
						hostData = tmp_list;
					}
				} else {
					throw new Exception(respJObj.toString());
				}
			} else {
				throw new Exception("Request to CommonService ���~�N�X: " + responseCode);
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
	}

	/*********************************************************************************/

}
