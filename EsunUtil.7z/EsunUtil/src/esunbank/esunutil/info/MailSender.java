package esunbank.esunutil.info;

import java.io.*;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.util.*;
import javax.activation.*;
import com.sun.mail.smtp.SMTPTransport;

final class MailSender {

	/**
	 * <pre>
	 * ms_ prefix is for MailSender class variables
	 * str prefix is for String
	 * astr prefix is for array of Strings
	 * strbuf prefix is for StringBuffers, etc.
	 * </pre>
	 */

	String ms_strFrom; // who the message is from

	boolean ms_debugging; // who (plural) the message is to

	String ms_strSMTPHost; // SMTP HOST address

	StringBuffer ms_strbufMsg;

	MimeMessage ms_msg;

	Vector<String[]> ms_fileAttachment;

	Vector<String> ms_byteAttachment_Name;
	Vector<byte[]> ms_byteAttachment_Data;

	Session session;

	public MailSender(InternetAddress strFrom, String[] astrTo, String[] astrCC, String[] astrBCC, String strSubject, String strSMTPHost, String strReplyTo, boolean debugging)
			throws MessagingException {
		MailSenderTo(strFrom, astrTo, astrCC, astrBCC, strSubject, strSMTPHost, strReplyTo, debugging);
	}

	public MailSender(String strFrom, String[] astrTo, String[] astrCC, String[] astrBCC, String strSubject, String strSMTPHost, String strReplyTo, boolean debugging) throws MessagingException {
		MailSenderTo(new InternetAddress(strFrom), astrTo, astrCC, astrBCC, strSubject, strSMTPHost, strReplyTo, debugging);
	}

	/**
	 * �l��o�e
	 * 
	 * <pre>
	 * Mailsender send the plaint text with attached file content
	 * send HTML format Mail
	 * the MailSender can process
	 * 1. plain text message (default), also can include TEXT file to plain text message
	 *    addText(message)
	 *    addFile(filename)
	 * 2. message text can include HTML tag, and setsendasHTML(true)
	 *    addText(message include HTML tag);
	 *    addFile(file name)
	 * 3. send attachment only for plain text format
	 *    addText(message)
	 *    addAttachment(filename)
	 * </pre>
	 * 
	 * @param strFrom
	 *            �H��H�H�c(�i�t�W�١A�p"alan" <alan@xxx.xxx>�A�Y�W�٬�����A�ݦۦ�s�X��ISO-8859-1)
	 * @param astrTo
	 *            ����H�H�c
	 * @param astrCC
	 *            �ƥ�����H�H�c
	 * @param astrBCC
	 *            �K������H�H�c
	 * @param strSubject
	 *            �H����D
	 * @param strSMTPHost
	 *            ���ϥΪ�SMTP Domain / IP
	 * @param strReplyTo
	 *            ���w�^�H�ɪ�����H�A�Y���]�h�N���H��H
	 * @param debugging
	 *            �O�_�}�Ұ����Ҧ�
	 * @throws MessagingException
	 */
	private void MailSenderTo(InternetAddress strFrom, String[] astrTo, String[] astrCC, String[] astrBCC, String strSubject, String strSMTPHost, String strReplyTo, boolean debugging)
			throws MessagingException {
		// ms_strFrom = strFrom; // �H��H
		ms_debugging = debugging; // �����Ҧ�
		ms_strSMTPHost = strSMTPHost; // SMTP Address

		// �]�wSMTP
		Properties props = new Properties();
		props.put("mail.smtp.host", ms_strSMTPHost);

		// �O�ɤ��_(�Y���]�AAPI�w�]�ȬO�ä����_)
		props.put("mail.smtp.timeout", 60000);
		props.put("mail.smtp.connectiontimeout", 60000);

		// �N�ѼƳ]�JSession
		session = Session.getInstance(props);
		session.setDebug(ms_debugging);

		// ����
		ms_strbufMsg = new StringBuffer();

		// ����
		ms_fileAttachment = new Vector<String[]>();

		ms_byteAttachment_Name = new Vector<String>();
		ms_byteAttachment_Data = new Vector<byte[]>();

		// �إ�MimeMessage�榡
		ms_msg = new MimeMessage(session);

		// �]�w�H��H
		ms_msg.setFrom(strFrom);

		// �]�w����H
		ArrayList<InternetAddress> address = new ArrayList<InternetAddress>();
		if (astrTo != null) {
			for (int i = 0; i < astrTo.length; ++i) {
				if (astrTo[i] == null || "".equals(astrTo[i])) {
					continue;
				}
				address.add(new InternetAddress(astrTo[i]));
			}
			ms_msg.setRecipients(MimeMessage.RecipientType.TO, address.toArray(new InternetAddress[address.size()]));
		}
		address.clear();

		// �]�w�ƥ�����H
		if (astrCC != null) {
			for (int i = 0; i < astrCC.length; ++i) {
				if (astrCC[i] == null || "".equals(astrCC[i])) {
					continue;
				}
				address.add(new InternetAddress(astrCC[i]));
			}
			ms_msg.setRecipients(MimeMessage.RecipientType.CC, address.toArray(new InternetAddress[address.size()]));
		}
		address.clear();

		// �]�w�K������H
		if (astrBCC != null) {
			for (int i = 0; i < astrBCC.length; ++i) {
				if (astrBCC[i] == null || "".equals(astrBCC[i])) {
					continue;
				}
				address.add(new InternetAddress(astrBCC[i]));
			}
			ms_msg.setRecipients(MimeMessage.RecipientType.BCC, address.toArray(new InternetAddress[address.size()]));
		}
		// �]�w���D
		ms_msg.setSubject(strSubject, "UTF-8");

		// �]�w�^�H������H�A�i���]�A�w�]���H��H
		if (strReplyTo != null)
			ms_msg.setReplyTo(new InternetAddress[] { new InternetAddress(strReplyTo) });
	}

	/**
	 * �]�w�����\��H/�C�L
	 **/
	public void setPrivate() {
		try {
			ms_msg.setHeader("Sensitivity", "Private");
		} catch (Exception ex) {
		}
	}

	/**
	 * �]�w�����\��H/�C�L
	 **/
	public void setMailHeader(String key, String value) {
		try {
			ms_msg.setHeader(key, value);
		} catch (Exception ex) {
		}
	}

	// ����榡�ѼơA�w�]�Ȭ��¤�r����
	private boolean sendAsHTML = false;

	/**
	 * �]�w����榡
	 * 
	 * @param value
	 *            true��HTML�榡�Ffalse���¤�r�榡
	 */
	public void ms_setSendAsHTML(boolean value) {
		sendAsHTML = value;
	}

	/**
	 * �s�W����
	 * 
	 * @param strText
	 *            ����A�i��HTML Code
	 */
	public void ms_addText(String strText) {
		ms_strbufMsg.append(strText);
	}

	// ����ѼơA�w�]�Ȭ��L����
	private boolean addAttachment = false;

	/**
	 * �s�W����
	 * 
	 * @param filename
	 *            �����ɮת�������|
	 */
	public void ms_addAttachment(String filename) {
		ms_addAttachment(filename, filename);
		addAttachment = true;
	}

	/**
	 * �s�W����
	 * 
	 * @param filename
	 *            �����ɮת�������|
	 * @param attachmentName
	 *            ������ܦW��
	 */
	public void ms_addAttachment(String filename, String attachmentName) {
		ms_fileAttachment.addElement(new String[] { filename, attachmentName });
		addAttachment = true;
	}

	/**
	 * �s�W����
	 * 
	 * @param attach_Name
	 *            ������ܦW��
	 * @param attach_Data
	 *            ���󤺮e
	 */
	public void ms_addAttachment(ArrayList<String> attach_Name, ArrayList<byte[]> attach_Data) {
		for (int i = 0, listSize = attach_Data.size(); i < listSize; i++) {
			ms_byteAttachment_Name.addElement(attach_Name.get(i));
			ms_byteAttachment_Data.addElement(attach_Data.get(i));
		}
		addAttachment = true;
	}

	/**
	 * �s�W����
	 * 
	 * @param filename
	 *            �����ɮת�������|
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void ms_addFile(String filename) throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line = null;

		try {
			while ((line = br.readLine()) != null)
				ms_addText(line + "\n\r");
		} finally {
			br.close();
		}
	}

	/**
	 * �^�Ǧ��A���o�H���G�T��
	 * 
	 * @return LastServerResponse ���A���^�Ъ��o�H���G�T���A�p 250 message OK
	 * @throws MessagingException
	 */
	public String ms_send() throws MessagingException {
		String serverResponse = "";
		SMTPTransport smtpTransport = null;
		try {
			// �]�w�o�e�ɶ�
			ms_msg.setSentDate(new Date());

			if (addAttachment) {
				// �]�w����P����
				ms_processAttachment();
			} else if (!sendAsHTML) {
				// �]�w�¤�r����
				ms_msg.setContent(new String(ms_strbufMsg), "text/plain; charset=Big5");
			} else {
				// �]�wHTML����
				ms_msg.setContent(new String(ms_strbufMsg), "text/html; charset=Big5");
			}

			// �Nsession�]�J�s�u
			smtpTransport = (SMTPTransport) session.getTransport("smtp");
			// �إ߳s�u
			smtpTransport.connect();
			smtpTransport.sendMessage(ms_msg, ms_msg.getAllRecipients());
			// �^�ǽX�A�Ȥ��ϥΡA�^�ǰT�����e3�r���Y���^�ǽX
			// int returnCode = smtpTransport.getLastReturnCode();
			serverResponse = smtpTransport.getLastServerResponse();
			// ���N����Ÿ�
			serverResponse = serverResponse.replace("\r", " ").replace("\n", " ");
			serverResponse = serverResponse + " (SMTP:" + session.getProperty("mail.smtp.host") + ")";
		} finally {
			if (smtpTransport != null) {
				try {
					smtpTransport.close();
				} catch (Exception e) {
				}
			}
		}
		return serverResponse;
	}

	/**
	 * �ϥ�MimeMultipart�إߧt���󪺶l�󤺮e
	 * 
	 * @throws MessagingException
	 */
	public void ms_processAttachment() throws MessagingException {
		if ((ms_fileAttachment.size() > 0) || (ms_byteAttachment_Data.size() > 0)) {
			// �إ�MimeMultipart�A�ΨӦs��MimeBodyPart
			Multipart multipart = new MimeMultipart();

			// �إߤ���MimeBodyPart
			MimeBodyPart messageBodyPart = new MimeBodyPart();

			// �]�w����
			messageBodyPart.setText(new String(ms_strbufMsg), "Big5");
			if (sendAsHTML) {
				messageBodyPart.setHeader("Content-Type", "text/html; charset=Big5");
			}

			multipart.addBodyPart(messageBodyPart);

			// �إߪ���MimeBodyPart
			if (ms_fileAttachment.size() > 0) {
				for (int i = 0; i < ms_fileAttachment.size(); i++) {
					messageBodyPart = new MimeBodyPart();
					String[] fileAttachment = ms_fileAttachment.elementAt(i);

					FileDataSource source = new FileDataSource(fileAttachment[0]) {
						@Override
						public String getContentType() {
							return "application/octet-stream";
						}
					};
					messageBodyPart.setDataHandler(new DataHandler(source));

					try {
						messageBodyPart.setFileName(MimeUtility.encodeText(fileAttachment[1], "Big5", "B"));
						// messageBodyPart.setFileName(new
						// String(fileAttachment[1]
						// .getBytes("Big5"), "iso-8859-1"));
					} catch (UnsupportedEncodingException e) {
						messageBodyPart.setFileName(fileAttachment[1]);
					}
					multipart.addBodyPart(messageBodyPart);
				}
			} else if (ms_byteAttachment_Data.size() > 0) {
				for (int i = 0; i < ms_byteAttachment_Data.size(); i++) {
					messageBodyPart = new MimeBodyPart();

					ByteArrayDataSource source = new ByteArrayDataSource(ms_byteAttachment_Data.get(i), "application/octet-stream") {
						@Override
						public String getContentType() {
							return "application/octet-stream";
						}
					};
					messageBodyPart.setDataHandler(new DataHandler(source));

					try {
						messageBodyPart.setFileName(MimeUtility.encodeText(ms_byteAttachment_Name.get(i), "Big5", "B"));
						// messageBodyPart.setFileName(new
						// String(fileAttachment[1]
						// .getBytes("Big5"), "iso-8859-1"));
					} catch (UnsupportedEncodingException e) {
						messageBodyPart.setFileName(ms_byteAttachment_Name.get(i));
					}
					multipart.addBodyPart(messageBodyPart);
				}
			}
			// �NMimeMultipart�ǤJ�l��H�إߤ��e
			ms_msg.setContent(multipart);
		}
	}
}