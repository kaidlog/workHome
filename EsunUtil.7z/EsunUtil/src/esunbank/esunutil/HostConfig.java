package esunbank.esunutil;

public class HostConfig {

	private String TTPCD; // �N�X�j��
	private String STPCD; // �N�X����
	private String NOCD; // �N�X
	private String NMCDD; // �N�X�W��
	private String DMARK; // ���P���O

	public String getTTPCD() {
		return TTPCD;
	}

	public void setTTPCD(String tTPCD) {
		TTPCD = tTPCD;
	}

	public String getSTPCD() {
		return STPCD;
	}

	public void setSTPCD(String sTPCD) {
		STPCD = sTPCD;
	}

	public String getNOCD() {
		return NOCD;
	}

	public void setNOCD(String nOCD) {
		NOCD = nOCD;
	}

	public String getNMCDD() {
		return NMCDD;
	}

	public void setNMCDD(String nMCDD) {
		NMCDD = nMCDD;
	}

	public String getDMARK() {
		return DMARK;
	}

	public void setDMARK(String dMARK) {
		DMARK = dMARK;
	}

}
