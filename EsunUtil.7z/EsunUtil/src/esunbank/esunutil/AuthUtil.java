package esunbank.esunutil;

import java.sql.*;
import java.util.*;

public class AuthUtil {

	private Connection conn;

	public AuthUtil(Connection conn) throws Exception {
		this.conn = conn;
	}

	/**
	 * �P�_userID�bsystemID�t�Τ��O�_��authID��authValue�v��
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param userID
	 *            �ϥΪ�
	 * @param authID
	 *            �v���N�X
	 * @param authValue
	 *            �v����
	 * @return boolean
	 */
	public boolean isAuth(String systemID, String userID, String authID,
			String authValue) throws Exception {
		return getUserAuth(systemID, userID).get(authID).contains(authValue);
	}

	/**
	 * ���ouserID�bsystemID��authID����
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param userID
	 *            �ϥΪ�
	 * @param authID
	 *            �v���N�X
	 * 
	 * @return HashSet<String> of AuthValue
	 */
	public HashSet<String> getUserAuth(String systemID, String userID,
			String authID) throws Exception {
		return getUserAuth(systemID, userID).get(authID);
	}

	/**
	 * ���ouserID�bsystemID�t�Ϊ��v��
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param userID
	 *            �ϥΪ�
	 * 
	 * @return HashMap<�v���N�X, HashSet<�v����>> <br>
	 *         Key=AuthID<br>
	 *         Value= HashSet<String> of AuthValue
	 */
	public HashMap<String, HashSet<String>> getUserAuth(String systemID,
			String userID) throws Exception {
		CacheData cacheData = null;
		if ((cacheData = userCache.get(userID)) == null
				|| ((System.currentTimeMillis()
						- cacheData.getCacheTime()) >= 60 * 60 * 1000L)) {
			procUserAuth(systemID, userID);
		}
		return userCache.get(userID).getUserAuth();
	}

	private void procUserAuth(String systemID, String userID) throws Exception {

		HashMap<String, HashSet<String>> auths = null;
		HashSet<String> set = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;

		sql = "SELECT DISTINCT EsunAuth.dbo.UserAuth.UserID, EsunAuth.dbo.UserAuth.SystemID, EsunAuth.dbo.SystemCtl.SysCName, EsunAuth.dbo.UserAuth.UserGroupID, EsunAuth.dbo.UserGroupCtl.UserGroupName, "
				+ "EsunAuth.dbo.UserGroupCtl.UserGroupStatus, EsunAuth.dbo.UserGroupDtl.UserStatus, EsunAuth.dbo.SystemCtl.SystemStatus, EsunAuth.dbo.AuthCtl.AuthStatus, EsunAuth.dbo.UserAuth.AuthID,"
				+ "EsunAuth.dbo.AuthCtl.AuthName, EsunAuth.dbo.UserAuth.AuthValue, EsunAuth.dbo.AuthDtl.AuthContent FROM EsunAuth.dbo.UserAuth LEFT OUTER JOIN EsunAuth.dbo.UserGroupCtl ON "
				+ "EsunAuth.dbo.UserAuth.UserGroupID = EsunAuth.dbo.UserGroupCtl.UserGroupID LEFT OUTER JOIN EsunAuth.dbo.UserGroupDtl ON EsunAuth.dbo.UserAuth.UserGroupID = EsunAuth.dbo.UserGroupDtl.UserGroupID "
				+ "AND EsunAuth.dbo.UserAuth.UserID = EsunAuth.dbo.UserGroupDtl.UserID INNER JOIN EsunAuth.dbo.SystemCtl ON EsunAuth.dbo.UserAuth.SystemID = EsunAuth.dbo.SystemCtl.SystemID AND "
				+ "EsunAuth.dbo.SystemCtl.SystemStatus = 'Y' INNER JOIN EsunAuth.dbo.AuthCtl ON EsunAuth.dbo.AuthCtl.AuthID=EsunAuth.dbo.UserAuth.AuthID and EsunAuth.dbo.AuthCtl.AuthStatus='Y' "
				+ "INNER JOIN EsunAuth.dbo.AuthDtl ON EsunAuth.dbo.UserAuth.AuthID = EsunAuth.dbo.AuthDtl.AuthID AND EsunAuth.dbo.UserAuth.AuthValue = EsunAuth.dbo.AuthDtl.AuthValue WHERE "
				+ "EsunAuth.dbo.UserAuth.SystemID= ? AND EsunAuth.dbo.UserAuth.UserID = ? AND (EsunAuth.dbo.UserGroupCtl.UserGroupStatus IS null OR EsunAuth.dbo.UserGroupCtl.UserGroupStatus = 'Y') "
				+ "AND (EsunAuth.dbo.UserGroupDtl.UserStatus IS null OR EsunAuth.dbo.UserGroupDtl.UserStatus = 'Y')";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, userID);
			rs = ps.executeQuery();

			auths = new HashMap<String, HashSet<String>>();

			String key;
			String value;
			while (rs.next()) {
				key = rs.getString("AuthID");
				value = rs.getString("AuthValue");
				if (auths.containsKey(key)) {
					auths.get(key).add(value);
				} else {
					set = new HashSet<String>();
					set.add(value);
					auths.put(key, set);
				}
			}
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ex) {
			}
		}
		userCache.put(userID, new CacheData(auths));

	}

	/*
	 * �ϥΪ��v���Ȧs, Key=userID
	 */
	private static HashMap<String, CacheData> userCache = new HashMap<String, CacheData>();

	private class CacheData {

		long cacheTime;
		HashMap<String, HashSet<String>> userAuth;

		/**
		 * @return Key=AuthID, Value=HashSet<String> of authValue
		 */
		CacheData(HashMap<String, HashSet<String>> userAuth) {
			this.userAuth = userAuth;
			this.cacheTime = System.currentTimeMillis();
		}

		/***
		 * @return cache���ɶ�
		 */
		long getCacheTime() {
			return this.cacheTime;
		}

		HashMap<String, HashSet<String>> getUserAuth() {
			return this.userAuth;
		}
	}

	private static HashMap<String, SystemData> sysCache = new HashMap<String, SystemData>();

	/**
	 * ���osystemID���t�Τ���W��
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @return �t�Τ���W��
	 */
	public String getSystemName(String systemID) throws Exception {
		if (sysCache.get(systemID) == null) {
			procSystem(systemID);
		}
		return sysCache.get(systemID).SysCName;
	}

	/**
	 * ���oAuthCtl��AuthName
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @return ArrayList(Entry<�v���N�X,�v���W�� >)<br>
	 */
	public ArrayList<AbstractMap.SimpleEntry<String, String>> getAuthCtl(
			String systemID) throws Exception {
		if (sysCache.get(systemID) == null) {
			procSystem(systemID);
		}
		return sysCache.get(systemID).getAuthCtl();
	}

	/**
	 * ���oAuthDetail
	 * 
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * 
	 * @return HashMap Key=AuthID,<br>
	 *         Vaule=ArrayList<�v������>{AuthValue,AuthContent,Memo}
	 * @throws Exception
	 */
	public HashMap<String, ArrayList<AuthDetail>> getAuthDtl(String systemID)
			throws Exception {
		if (sysCache.get(systemID) == null) {
			procSystem(systemID);
		}
		return sysCache.get(systemID).getAuthDtl();
	}

	private void procSystem(String systemID) throws Exception {
		ArrayList<AbstractMap.SimpleEntry<String, String>> ctls = null;
		String systemname = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;

		sql = "SELECT DISTINCT EsunAuth.dbo.AuthCtl.AuthID, EsunAuth.dbo.AuthCtl.AuthName, EsunAuth.dbo.SystemCtl.SysCName "
				+ "FROM EsunAuth.dbo.AuthDtl INNER JOIN "
				+ "(EsunAuth.dbo.AuthCtl INNER JOIN EsunAuth.dbo.SystemCtl ON EsunAuth.dbo.AuthCtl.systemID = EsunAuth.dbo.SystemCtl.systemID ) "
				+ "ON EsunAuth.dbo.SystemCtl.systemID = ? WHERE EsunAuth.dbo.SystemCtl.SystemStatus = 'Y' AND EsunAuth.dbo.AuthCtl.AuthStatus = 'Y'";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			rs = ps.executeQuery();

			ctls = new ArrayList<AbstractMap.SimpleEntry<String, String>>();

			while (rs.next()) {
				ctls.add(new AbstractMap.SimpleEntry<String, String>(
						rs.getString("AuthID"), rs.getString("AuthName")));
				systemname = rs.getString("SysCName");
			}

		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ex) {
			}
		}
		SystemData systemData = new SystemData();
		systemData.SysCName = systemname;
		systemData.setAuthCtl(ctls);
		systemData.setAuthDtl(procSystemDtl(systemID));
		sysCache.put(systemID, systemData);
	}

	/***
	 * �v������
	 */
	public class AuthDetail {
		private String authValue;
		private String authContent;
		private String memo;

		public String getAuthValue() {
			return authValue;
		}

		public void setAuthValue(String authValue) {
			this.authValue = authValue;
		}

		public String getAuthContent() {
			return authContent;
		}

		public void setAuthContent(String authContent) {
			this.authContent = authContent;
		}

		public String getMemo() {
			return memo;
		}

		public void setMemo(String memo) {
			this.memo = memo;
		}
	}

	/**
	 * @return <AuthID, ArrayList of AuthDetail>
	 */
	private HashMap<String, ArrayList<AuthDetail>> procSystemDtl(
			String systemID) throws Exception {
		HashMap<String, ArrayList<AuthDetail>> dtls = null;
		ArrayList<AuthDetail> dtl_datas = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;

		sql = "SELECT DISTINCT EsunAuth.dbo.AuthDtl.AuthID, EsunAuth.dbo.AuthDtl.AuthValue, "
				+ "EsunAuth.dbo.AuthDtl.AuthContent, EsunAuth.dbo.AuthDtl.Memo "
				+ "FROM EsunAuth.dbo.AuthDtl INNER JOIN EsunAuth.dbo.SystemCtl ON EsunAuth.dbo.AuthDtl.systemID = ? "
				+ "INNER JOIN EsunAuth.dbo.AuthCtl ON EsunAuth.dbo.AuthCtl.AuthID = EsunAuth.dbo.AuthDtl.AuthID AND "
				+ "EsunAuth.dbo.AuthCtl.SystemID = EsunAuth.dbo.SystemCtl.SystemID "
				+ "WHERE EsunAuth.dbo.SystemCtl.SystemStatus = 'Y' AND EsunAuth.dbo.AuthCtl.AuthStatus = 'Y'";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			rs = ps.executeQuery();

			dtls = new HashMap<String, ArrayList<AuthDetail>>();
			AuthDetail detail;
			String key;
			while (rs.next()) {

				key = rs.getString("AuthID");

				detail = new AuthDetail();
				detail.setAuthValue(rs.getString("AuthValue"));
				detail.setAuthContent(rs.getString("AuthContent"));
				detail.setMemo(rs.getString("Memo"));

				if (dtls.containsKey(key)) {
					dtls.get(key).add(detail);
				} else {
					dtl_datas = new ArrayList<AuthDetail>();
					dtl_datas.add(detail);
					dtls.put(key, dtl_datas);
				}
			}

		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ex) {
			}
		}
		return dtls;
	}

	private class SystemData {

		// �t�ΦW��
		String SysCName;

		// ArrayList of <AuthID,AuthName>
		ArrayList<AbstractMap.SimpleEntry<String, String>> authCtls;

		HashMap<String, ArrayList<AuthDetail>> authDtl;

		ArrayList<AbstractMap.SimpleEntry<String, String>> getAuthCtl() {
			return authCtls;
		}

		void setAuthCtl(
				ArrayList<AbstractMap.SimpleEntry<String, String>> authCtls) {
			this.authCtls = authCtls;
		}

		HashMap<String, ArrayList<AuthDetail>> getAuthDtl() {
			return authDtl;
		}

		void setAuthDtl(HashMap<String, ArrayList<AuthDetail>> authDtl) {
			this.authDtl = authDtl;
		}
	}
}
