package esunbank.esunutil.mq;

import java.util.ResourceBundle;
import java.util.TreeMap;
import javax.jms.*;
import org.apache.activemq.*;
import org.apache.activemq.pool.*;

public class ActiveMQUtil {

	private static ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.mq.config");

	private static String user = dmres.getString("activeMQ_User");
	private static String password = dmres.getString("activeMQ_Password");
	private static String url = dmres.getString("activeMQ_Url");

	private static int maximumActive = Integer.parseInt(dmres
			.getString("activeMQ_maximumActive"));
	private static int maxConnections = Integer.parseInt(dmres
			.getString("activeMQ_maxConnections"));
	private static int idleTimeout = Integer.parseInt(dmres
			.getString("activeMQ_idleTimeout"));

	private static TreeMap<String, PooledConnectionFactory> poolConnectionFactories = new TreeMap<String, PooledConnectionFactory>();

	/**
	 * �]�w�ۭq��MQ�s�u��k
	 * 
	 * @param user
	 * @param password
	 * @param url
	 * @return
	 */
	public PooledConnectionFactory getPoolConnectionFactory(String user,
			String password, String url, int maximumActive, int maxConnections,
			int idleTimeout) {
		PooledConnectionFactory poolConnectionFactory = poolConnectionFactories
				.get(getKey(user, password, url));
		if (poolConnectionFactory == null) {
			poolConnectionFactory = new PooledConnectionFactory(
					new ActiveMQConnectionFactory(user, password, "failover:("
							+ url + ")"));
			poolConnectionFactory
					.setMaximumActive(maximumActive > 0 ? maximumActive
							: ActiveMQUtil.maximumActive);
			poolConnectionFactory
					.setMaxConnections(maxConnections > 0 ? maxConnections
							: ActiveMQUtil.maxConnections);
			poolConnectionFactory.setIdleTimeout(idleTimeout > 0 ? idleTimeout
					: ActiveMQUtil.idleTimeout);
			poolConnectionFactories.put(getKey(user, password, url),
					poolConnectionFactory);
		}
		return poolConnectionFactory;
	}

	/**
	 * ���o�ۭq��MQ�s�u��k
	 * 
	 * @param user
	 * @param password
	 * @param url
	 * @return
	 */
	public PooledConnectionFactory getPoolConnectionFactory(String user,
			String password, String url) {
		return getPoolConnectionFactory(user, password, url, maximumActive,
				maxConnections, idleTimeout);
	}

	/**
	 * ���o�w�]��MQ�s�u��k
	 * 
	 * @return
	 */
	public PooledConnectionFactory getPoolConnectionFactory() {
		return getPoolConnectionFactory(user, password, url, maximumActive,
				maxConnections, idleTimeout);
	}

	/**
	 * �ϥΫ��w��MQ�s�u��k�i��s�u
	 * 
	 * @param poolConnectionFactory
	 * @return
	 * @throws Exception
	 */
	public javax.jms.Connection getMQConnection(
			PooledConnectionFactory poolConnectionFactory) throws Exception {
		return poolConnectionFactory.createConnection();
	}

	/**
	 * ���o�w�]��MQ Connection
	 * 
	 * @return
	 * @throws Exception
	 */
	public javax.jms.Connection getMQConnection() throws Exception {
		return getPoolConnectionFactory().createConnection();
	}

	/**
	 * �ϥγs�u���oSession
	 * 
	 * @param connection
	 * @return
	 * @throws Exception
	 */
	public Session getMQSession(javax.jms.Connection connection)
			throws Exception {
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		connection.start();
		return session;
	}

	/**
	 * ���oMessageProducer
	 * 
	 * @param session
	 * @param queueName
	 * @param isPersistent
	 * @return
	 * @throws Exception
	 */
	public MessageProducer getMessageProducer(Session session,
			String queueName, boolean isPersistent) throws Exception {
		MessageProducer producer = session.createProducer(session
				.createQueue(queueName));
		producer.setDeliveryMode(isPersistent ? DeliveryMode.PERSISTENT
				: DeliveryMode.NON_PERSISTENT);
		return producer;
	}

	/**
	 * ���oMessageConsumer
	 * 
	 * @param session
	 * @param queueName
	 * @return
	 * @throws Exception
	 */
	public MessageConsumer getMessageConsumer(Session session, String queueName)
			throws Exception {
		MessageConsumer consumer = session.createConsumer(session
				.createQueue(queueName));
		return consumer;
	}

	/**
	 * �̱������Queue���
	 * */
	public MessageConsumer getMessageConsumer(Session session,
			String queueName, String messageSelector) throws Exception {
		MessageConsumer consumer = session.createConsumer(
				session.createQueue(queueName), messageSelector);
		return consumer;
	}

	/**
	 * �g�J��ƨ�MQ
	 * 
	 * @param producer
	 * @param data
	 * @throws Exception
	 */
	public void writeQ(MessageProducer producer, TextMessage data)
			throws Exception {
		producer.send(data);
	}

	/**
	 * ���oActiveMQConnectionFactory�̪��s�u�ؼ�User�b��
	 */
	public static String getUser(ActiveMQConnectionFactory confactory) {
		return confactory.getUserName();
	}

	/**
	 * ���oActiveMQConnectionFactory�̪��s�u�ؼ�Password
	 */
	public static String getPassword(ActiveMQConnectionFactory confactory) {
		return confactory.getPassword();
	}

	/**
	 * ���oActiveMQConnectionFactory�̪��s�u�ؼ�URL
	 */
	public static String getUrl(ActiveMQConnectionFactory confactory) {
		String brokerURL = confactory.getBrokerURL();
		if (brokerURL != null && brokerURL.contains("failover:(")
				&& brokerURL.contains(")")) {
			brokerURL = brokerURL.substring(10, brokerURL.length() - 1);
		}
		return brokerURL;
	}

	/**
	 * �NActiveMQConnectionFactory�]�JPooledConnectionFactory
	 */
	public static void setConnectionFactory(
			PooledConnectionFactory poolConnectionFactory,
			ActiveMQConnectionFactory confactory) {
		poolConnectionFactory.setConnectionFactory(confactory);
	}

	private String getKey(String user, String password, String url) {
		return user + "??" + password + "??" + url;
	}
}