package esunbank.esunutil.mq;

import java.util.*;
import java.util.concurrent.*;
import javax.servlet.http.HttpServletRequest;

import com.ibm.mq.*;
import com.ibm.mq.constants.*;

import esunbank.esunutil.StringUtil;
import esunbank.esunutil.io.*;

/**
 * �g�J�D������q��Log�@�ε{���A��FileGWProject\esunbank\mq\MQLog.java�B�zLog
 * 
 */
public class MQLogUtil {

	private static LogUtil logUtil_worker = null;
	private static LogUtil logUtil_log = null;
	private static LogUtil logUtil_local = null;

	private static ConcurrentLinkedQueue<String> logQueue = new ConcurrentLinkedQueue<String>();

	private static boolean isMQLog = false;

	static {
		logUtil_worker = new LogUtil("MQLogUtil_Worker", LogUtil.LOGBYSIZE);
		logUtil_log = new LogUtil("MQLogUtil_Log", LogUtil.LOGBYSIZE);
		logUtil_local = new LogUtil("MQLogUtil_Local", LogUtil.LOGBYSIZE);
		new MQLogUtil.LocalLogWriter().start();
		new MQLogUtil.MQUtil().start();
	}

	/**
	 * �W��q��Log
	 */
	public final boolean sendMQLog(long currentTimeMillis, String ProjectID, String mqData) {
		return doMQLog(currentTimeMillis, ProjectID, "Snd", mqData);
	}

	/**
	 * �U��q��Log
	 */
	public final boolean rcvMQLog(long currentTimeMillis, String ProjectID, String mqData) {
		return doMQLog(currentTimeMillis, ProjectID, "Rcv", mqData);
	}

	/**
	 * ���Log
	 */
	public final boolean doLog(long currentTimeMillis, String ProjectID, String ip, String mode, String logData) {
		return doMQLog(currentTimeMillis, ProjectID + "(" + ip + ")", mode, logData);
	}

	public final boolean doLog(long currentTimeMillis, String ProjectID, String ip, String mode, Throwable logData) {
		return doMQLog(currentTimeMillis, ProjectID + "(" + ip + ")", mode, esunbank.esunutil.StringUtil.getStackTraceASString(logData));
	}

	public final boolean doLog(long currentTimeMillis, String ProjectID, String ip, String mode, HttpServletRequest logData) {
		String requestValue = "AuthType: " + logData.getAuthType() + " / " + "ContextPath: " + logData.getContextPath() + " / " + "Method: " + logData.getMethod() + " / " + "PathInfo: "
				+ logData.getPathInfo() + " / " + "PathTranslated: " + logData.getPathTranslated() + " / " + "QueryString: " + logData.getQueryString() + " / " + "RemoteUser: "
				+ logData.getRemoteUser() + " / " + "RequestedSessionId: " + logData.getRequestedSessionId() + " / " + "RequestURI: " + logData.getRequestURI() + " / " + "ServletPath: "
				+ logData.getServletPath();
		return doMQLog(currentTimeMillis, ProjectID + "(" + ip + ")", mode, requestValue);
	}

	/**
	 * doMQLog
	 */
	private boolean doMQLog(long currentTimeMillis, String ProjectID, String mode, String mqData) {
		boolean rslt = false;
		String sendStr = "";
		try {
			sendStr = currentTimeMillis + "@|" + ProjectID + "@|" + mode + "@|" + mqData;
			logQueue.add(sendStr);
			rslt = true;
		} catch (Exception ex) {
			logUtil_log.Error("�g�JConcurrentLinkedQueue����:" + sendStr);
			logUtil_worker.Error("�g�JConcurrentLinkedQueue�ɲ��Ͳ��`:" + ex.toString());
			logUtil_worker.Error(ex);
		}
		return rslt;
	}

	/**
	 * For�O��MQ����ϥ�
	 */
	public final boolean doMQLog_TxnSend(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Snd", ProjectID, ProjectID2, key1, key2, mqData);
	}

	/**
	 * For�O��MQ����ϥ�
	 */
	public final boolean doMQLog_TxnRcv(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Rcv", ProjectID, ProjectID2, key1, key2, mqData);
	}

	/**
	 * For�O��log
	 */
	public final boolean doMQLog_Log(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Log", ProjectID, ProjectID2, key1, key2, mqData);
	}

	/**
	 * For�O��log
	 */
	public final boolean doMQLog_Info(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Info", ProjectID, ProjectID2, key1, key2, mqData);
	}

	/**
	 * For�O��log
	 */
	public final boolean doMQLog_Error(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Error", ProjectID, ProjectID2, key1, key2, mqData);
	}

	/**
	 * For�O��log
	 */
	public final boolean doMQLog_Error(long currentTimeMillis, String SrcIP, String DstIP, String ProjectID, String ProjectID2, String key1, String key2, Throwable mqData) {
		return doMQLog(currentTimeMillis, SrcIP, DstIP, "Error", ProjectID, ProjectID2, key1, key2, StringUtil.getStackTraceASString(mqData));
	}

	// 201701 doMQLog
	private boolean doMQLog(long currentTimeMillis, String SrcIP, String DstIP, String mode, String ProjectID, String ProjectID2, String key1, String key2, String mqData) {

		boolean rslt = false;
		String sendStr = "";

		try {
			// 201701 9�� (�s��)
			if (SrcIP == null || SrcIP.equals(""))
				SrcIP = " ";
			if (DstIP == null || DstIP.equals(""))
				DstIP = " ";
			if (ProjectID == null || ProjectID.equals(""))
				ProjectID = " ";
			if (ProjectID2 == null || ProjectID2.equals(""))
				ProjectID2 = " ";
			if (key1 == null || key1.equals(""))
				key1 = " ";
			if (key2 == null || key2.equals(""))
				key2 = " ";
			sendStr = currentTimeMillis + "@|" + SrcIP + "@|" + DstIP + "@|" + mode + "@|" + ProjectID + "@|" + ProjectID2 + "@|" + key1 + "@|" + key2 + "@|" + mqData;
			logQueue.add(sendStr);
			rslt = true;

		} catch (Exception ex) {
			logUtil_log.Error("�g�JConcurrentLinkedQueue����:" + sendStr);
			logUtil_worker.Error("�g�JConcurrentLinkedQueue�ɲ��Ͳ��`:" + ex.toString());
			logUtil_worker.Error(ex);
		}
		return rslt;
	}

	private static class MQUtil extends Thread {

		private static MQSimpleConnectionManager myConnMan;

		private String MQ_QMANAGER = "";
		private String MQ_Qq = "";
		private final int openOptions_S = MQConstants.MQOO_OUTPUT;
		private final MQPutMessageOptions mqpo = new MQPutMessageOptions();

		public static Hashtable properties = new Hashtable();

		private MQQueueManager qMgr = null;
		private MQQueue send_queue = null;

		private MQUtil() {
			initialize();
			createConnection();
		}

		private void initialize() {
			try {
				ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.mq.config");
				MQ_QMANAGER = dmres.getString("MQ_QManager");
				MQ_Qq = dmres.getString("MQ_Qq");

				// Host
				properties.put(MQConstants.HOST_NAME_PROPERTY, dmres.getString("MQ_Host"));
				// Port
				properties.put(MQConstants.PORT_PROPERTY, Integer.parseInt(dmres.getString("MQ_Port")));
				// Channel
				properties.put(MQConstants.CHANNEL_PROPERTY, dmres.getString("MQ_Channel"));
			} catch (Exception ex) {
				logUtil_worker.Error("MQ�s�u�ѼƳ]�w�ɲ��Ͳ��`:" + ex.toString());
				logUtil_worker.Error(ex);
			}
		}

		private void createConnection() {
			while (true) {
				try {
					myConnMan = new MQSimpleConnectionManager();
					myConnMan.setActive(MQSimpleConnectionManager.MODE_ACTIVE);
					myConnMan.setMaxConnections(5);
					myConnMan.setMaxUnusedConnections(5);
					myConnMan.setTimeout(30 * 60 * 1000);// 30����
					qMgr = new MQQueueManager(MQ_QMANAGER, properties, myConnMan);
					send_queue = qMgr.accessQueue(MQ_Qq, openOptions_S);
					isMQLog = true;
					break;
				} catch (Exception ex1) {
					logUtil_worker.Error("MQ�إ߳s�u�ɲ��Ͳ��`:" + ex1.toString());
					logUtil_worker.Error(ex1);
					isMQLog = false;
					disconnectConnection();
					try {
						Thread.sleep(30000L);
					} catch (Exception ex2) {
						logUtil_worker.Error("MQLogUtil Thread Sleep(createConnection)�ɲ��Ͳ��`:" + ex2.toString());
						logUtil_worker.Error(ex2);
					}
				}
			}
		}

		private void disconnectConnection() {
			try {
				if (send_queue != null) {
					send_queue.close();
				}
			} catch (Exception ex) {
				logUtil_worker.Error("MQ�����ǰequeue�ɲ��Ͳ��`:" + ex.toString());
				logUtil_worker.Error(ex);
			}
			try {
				if (qMgr != null) {
					qMgr.disconnect();
				}
			} catch (Exception ex) {
				logUtil_worker.Error("MQ����queue manager���s�u�ɲ��Ͳ��`:" + ex.toString());
				logUtil_worker.Error(ex);
			}
		}

		public void run() {
			String sendStr = null;
			while (true) {
				try {
					while ((sendStr = logQueue.poll()) != null) {
						MQMessage msgSend = new MQMessage();
						msgSend.characterSet = 950;
						msgSend.writeString(sendStr);
						send_queue.put(msgSend, mqpo);
					}
				} catch (Exception ex) {
					logUtil_log.Error("�g�JMQ Log Queue����:" + sendStr);
					logUtil_worker.Error("�g�JMQ Log Queue�ɲ��Ͳ��`:" + ex.toString());
					logUtil_worker.Error(ex);
					isMQLog = false;
					disconnectConnection();
					createConnection();
				} finally {
					try {
						Thread.sleep(1L);
					} catch (Exception ex) {
						logUtil_worker.Error("MQLogUtil Thread Sleep(run)�ɲ��Ͳ��`:" + ex.toString());
						logUtil_worker.Error(ex);
					}
				}
			}
		}
	}

	private static class LocalLogWriter extends Thread {
		public void run() {
			String sendStr = null;
			while (true) {
				try {
					if (!isMQLog && (sendStr = logQueue.poll()) != null) {
						logUtil_local.Info(sendStr);
					}
				} finally {
					try {
						Thread.sleep(1L);
					} catch (Exception ex) {

					}
				}
			}
		}
	}
}
