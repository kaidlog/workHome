package esunbank.esunutil.monitor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.util.ResourceBundle;

import esunbank.esunutil.io.LogUtil;

public class MonitorLog {

	private static ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.monitor.config");

	private static String eventID = dmres.getString("eventID");

	private static String eventSource = dmres.getString("eventSource");

	// �ʱ��ɮ׸��|
	private static String logPath = dmres.getString("logPath");

	private static String logFilter = dmres.getString("logFilter");
	// �h�֮ɶ����`��
	private static int cycle = Integer.parseInt(dmres.getString("cycle"));
	// �����h�j��ĵ�i
	private static int alertSize = Integer.parseInt(dmres.getString("size"));

	private LogUtil logUtil;

	public static void main(String[] args) {

		MonitorLog monitor = new MonitorLog();
		monitor.doJob();
	}

	private void doJob() {
		logUtil = new LogUtil("MonitorLog");
		long initSize = 0;
		long endSize = 0;
		while (true) {
			try {
				File[] file = new File(logPath).listFiles(getFilter(logFilter));
				endSize = getFileSize(file[0]) / 1024;
				logUtil.Info(logPath + " SIZE=" + endSize + "KB");
				if (initSize != 0) {
					long diff = isOverSize(initSize, endSize);
					if (diff > 0) {
						logUtil.Error("�W�L�j�p" + diff + "KB");
						alertEvent();
					}
				}
				initSize = endSize;
				endSize = 0;
			} catch (Exception e) {
				logUtil.Error(e);
			} finally {
				try {
					Thread.sleep(cycle * 60 * 1000L);
				} catch (Exception e) {
				}
			}
		}
	}

	private FilenameFilter getFilter(final String filterName) {
		FilenameFilter filter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if ((new File(dir, name)).isFile() && name.toUpperCase().startsWith(filterName)) {
					return true;
				} else {
					return false;
				}
			}
		};
		return filter;
	}
	// �P�_�O�_�W�L
	private long isOverSize(long init, long end) {
		return ((end - init)) - (alertSize * 1024L);
	}
	// ��o�ɮפj�p
	private long getFileSize(File file) throws Exception {
		FileInputStream fis = null;
		long size = 0;
		try {
			if (file.exists()) {
				fis = new FileInputStream(file);
				size = fis.available();
			} else {
				throw new Exception("�䤣��ʱ��ɮ�");
			}
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
				}
			}
		}
		return size;
	}

	private void alertEvent() {
		try {
			new SendEvent().sendEvent(eventID, eventSource);
		} catch (Exception e1) {
			logUtil.Error(e1);
		}
	}
}
