package esunbank.esunutil.monitor;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import esunbank.esunutil.info.HostInfoUtil;

public class SendEvent {

	private static ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.config");

	private static String eventServiceHost = dmres.getString("ssoHost")
			+ dmres.getString("eventService");

	//20130815 @eileen ���`�H�H
	private static String eventDefaultGroup = dmres.getString("eventDefaultGroup");

	/**
	 * �I�sEsunMonitor EventService�ǰeEvent
	 * 
	 * @author jane 20111228
	 * @param eventID
	 *            ĵ�T�N�X
	 * @param eventSource
	 *            �ӷ��t��
	 * @throws Exception
	 */
	public boolean sendEvent(String eventID, String eventSource)
			throws Exception {
		return sendEvent(eventID, eventSource, null);
	}

	/**
	 * �I�sEsunMonitor EventService�ǰeEvent
	 * 
	 * @author jane 20111228
	 * @param eventID
	 *            ĵ�T�N�X
	 * @param eventSource
	 *            �ӷ��t��
	 * @param paramsMap
	 *            �Ѽ�(�Ω�m��ĵ�ܰT�������Ѽ�)
	 * @throws Exception
	 */
	public boolean sendEvent(String eventID, String eventSource,
			TreeMap<String, String> paramsMap) throws Exception {
		HttpURLConnection http = null;
		InputStream in = null;
		String paramStr="";
		try {
			if (eventID == null || eventID.equals("")) {
				throw new Exception("�����wĵ�T�N�X");
			}
			if (eventSource == null || eventSource.equals("")) {
				throw new Exception("�����wĵ�T�ӷ��t��");
			}
			byte[] data = new byte[1024];
			String url = eventServiceHost + "?EventID="
					+ URLEncoder.encode(eventID, "UTF-8") + "&EventSource="
					+ URLEncoder.encode(eventSource, "UTF-8");
			if (paramsMap != null) {
				for (Map.Entry<String, String> paramsEntry : paramsMap
						.entrySet()) {
					url = url
							+ "&"
							+ paramsEntry.getKey()
							+ "="
							+ URLEncoder.encode(paramsEntry.getValue()
									.toString(), "UTF-8");
					paramStr+=paramsEntry.getKey()+"=" + paramsEntry.getValue().toString() + "<br>";
				}
			}
			URL u = new URL(url);
			http = (HttpURLConnection) u.openConnection();
			http.setRequestMethod("POST");
			in = http.getInputStream();
			int idx = in.read(data);
			String str = "";
			if (idx >= 0) {
				str = new String(data, 0, idx);
			}
			if (str.trim().toUpperCase().startsWith("OK")) {
				// ��ƥ��`
				return str.trim().substring(2, str.trim().length()).equals(
						"SUCCESS");
			} else {
				// ��Ʋ��`
				//20130815 @eileen ���`�H�H
				new HostInfoUtil().sendMailToGroupUser(eventDefaultGroup, "�iEsunMonitor�j�^�и�Ʋ��`",
						"ĵ�T�N�X�G"+ eventID+ "<br>�ӷ��t�ΡG"+ eventSource+ "<br>�ѼơG"+  paramStr  +  "<br>�T���G"+str);
				throw new Exception("EsunMonitor�^�и�Ʋ��` " + str);
			}
		} finally {
			try {
				in.close();
			} catch (Exception e) {
			}
			try {
				http.disconnect();
			} catch (Exception e) {
			}
		}
	}

}
