package esunbank.esunutil;

public class SSBANKDATA {

	private String BANKNO; // �Ȧ�N�X
	private String BANKNAME; // �Ȧ椤��W��
	private String BANKTEL1; // �Ȧ�q��
	private String BANKTEL2;
	private String BANKTEL3;
	private String BANKTEL4;
	private String BANKFAX; // �Ȧ�ǯu
	private int BATCHNO;
	private String NOWDATE;

	public String getBANKNO() {
		return BANKNO;
	}

	public void setBANKNO(String bANKNO) {
		BANKNO = bANKNO;
	}

	public String getBANKNAME() {
		return BANKNAME;
	}

	public void setBANKNAME(String bANKNAME) {
		BANKNAME = bANKNAME;
	}

	public String getBANKTEL1() {
		return BANKTEL1;
	}

	public void setBANKTEL1(String bANKTEL1) {
		BANKTEL1 = bANKTEL1;
	}

	public String getBANKTEL2() {
		return BANKTEL2;
	}

	public void setBANKTEL2(String bANKTEL2) {
		BANKTEL2 = bANKTEL2;
	}

	public String getBANKTEL3() {
		return BANKTEL3;
	}

	public void setBANKTEL3(String bANKTEL3) {
		BANKTEL3 = bANKTEL3;
	}

	public String getBANKTEL4() {
		return BANKTEL4;
	}

	public void setBANKTEL4(String bANKTEL4) {
		BANKTEL4 = bANKTEL4;
	}

	public String getBANKFAX() {
		return BANKFAX;
	}

	public void setBANKFAX(String bANKFAX) {
		BANKFAX = bANKFAX;
	}

	public int getBATCHNO() {
		return BATCHNO;
	}

	public void setBATCHNO(int bATCHNO) {
		BATCHNO = bATCHNO;
	}

	public String getNOWDATE() {
		return NOWDATE;
	}

	public void setNOWDATE(String nOWDATE) {
		NOWDATE = nOWDATE;
	}
}
