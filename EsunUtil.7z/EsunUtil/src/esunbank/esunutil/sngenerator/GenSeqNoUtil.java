package esunbank.esunutil.sngenerator;

import java.util.ResourceBundle;

import org.json.JSONObject;

import esunbank.esunutil.io.ssl.RestfulUtil;

public class GenSeqNoUtil {

	private static final String address;
	private static final String port;
	private static final String url;

	static {
		ResourceBundle res = ResourceBundle.getBundle("esunbank.esunutil.sngenerator.config");
		address = res.getString("address");
		port = res.getString("port");
		url = address + ":" + port + "/EsunSnGenerator/SnGenerator/SnServlet";
	}

	public JSONObject getSeqNo(String sysId, String funcId, String sourceKey) throws Exception {
		RestfulUtil r = new RestfulUtil();
		JSONObject sndObj = null;
		JSONObject rtnObj = null;
		if (sysId == null || "".equals(sysId) || funcId == null || "".equals(funcId)) {
			throw new Exception("SysId �� FuncId ���i���šI");
		}
		sndObj = new JSONObject();
		sndObj.put("SysId", sysId);
		sndObj.put("FuncId", funcId);
		sndObj.put("SourceKey", sourceKey == null ? "" : sourceKey);
		rtnObj = new JSONObject(r.postData(url, sndObj.toString()));
		return rtnObj;
	}
}
