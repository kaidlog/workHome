package esunbank.esunutil.cacheServer;

import org.json.JSONArray;

public class CacheDataEntity {

	private String prjcd;
	private JSONArray data;
	private long aliveTime; // �s���ɶ�

	public CacheDataEntity(String prjcd, JSONArray data, long aliveTime) {
		this.prjcd = prjcd;
		this.data = data;
		this.aliveTime = aliveTime;
	}

	public String getPrjcd() {
		return prjcd;
	}

	public JSONArray getData() {
		return data;
	}

	public long getaliveTime() {
		return aliveTime;
	}
}
