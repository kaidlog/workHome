package esunbank.esunutil.cacheServer;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.ResourceBundle;
import org.apache.commons.httpclient.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;

import esunbank.esunutil.StringUtil;

public class CacheServerUtil {

	private static final ResourceBundle bundle = ResourceBundle.getBundle("esunbank.esunutil.cacheServer.config");
	// �A�Ȧ�m��
	private static String dataService = bundle.getString("DataService"); // ServiceIP
	private static String keyService = bundle.getString("KeyService");
	private static String keepService = bundle.getString("KeepService");
	private static String idService = bundle.getString("IDService");

	// �ɮפW�Ǩϥ�
	public static String sysName_upload = bundle.getString("sysName_upload");
	public static String hostIP_upload = bundle.getString("hostIP_upload");

	private static final String separator = "#|";
	private static final String enCodingStyle_UTF8 = "utf-8";

	/**
	 * Cache�A�����O:���oCache���
	 */
	public static final String ServiceCode_CacheData = "cacheData";

	/**
	 * Cache�A�����O:���o�Ǹ�
	 */
	public static final String ServiceCode_GetKey = "getKey";

	/**
	 * Cache�A�����O:�]�w�ȦsCache���
	 */
	public static final String ServiceCode_GetKeepData = "getKeepData";

	/**
	 * Cache�A�����O:���o�ȦsCache���
	 */
	public static final String ServiceCode_SetKeepData = "setKeepData";

	/**
	 * IDService���O:�]�w�y�����̤j��
	 */
	public static final String ServiceCode_SetMaxID = "setMaxID";

	/**
	 * IDService���O:���o�y����
	 */
	public static final String ServiceCode_GetID = "getID";

	private static final String integerFlag = "I#|";
	private static final String timeStampFlag = "T#|";
	private static final String stringFlag = "S#|";

	/**
	 * @parm prjcd
	 * @return JSONArray
	 */
	public JSONArray getCacheData(String prjcd) throws Exception {
		return getCacheData(prjcd, null);
	}

	private static final Object lock = new Object();

	private CacheData cacheDataConst = new CacheData();

	/**
	 * @parm prjcd
	 * @parm sqlParams �ޤJSQL�Ѽƪ�ArrayList(�S�Ѽ�=null)
	 * @return JSONArray
	 */
	public JSONArray getCacheData(String prjcd, ArrayList<Object> sqlParams) throws Exception {

		ArrayList<String> strParm = null;
		String parameter = (sqlParams == null) ? "" : sqlParams.toString();
		// �P�M�ץi�a���P�ѼơA�]����arr�]��Key
		String key = prjcd + separator + parameter;

		// �d�ߤ���s����Cache�A�Vserver�ݭn�D�s�����
		if (!cacheDataConst.isCacheDataAlive(key)) {
			synchronized (lock) {
				if (!cacheDataConst.isCacheDataAlive(key)) {
					if (sqlParams != null && sqlParams.size() > 0) {
						strParm = new ArrayList<String>(); // �ǤJ�d�ߪ��Ѽ�
						for (int i = 0; i < sqlParams.size(); i++) {
							if (sqlParams.get(i) instanceof Integer) {
								strParm.add(integerFlag + sqlParams.get(i)); // int�h�e���[I
							} else if (sqlParams.get(i) instanceof Timestamp) {
								Timestamp tmpTime = (Timestamp) sqlParams.get(i);
								strParm.add(timeStampFlag + tmpTime.getTime()); // timestamp�e���[T
							} else {
								strParm.add(URLEncoder.encode(stringFlag + (String) sqlParams.get(i), enCodingStyle_UTF8)); // string�e���[S
							}
						}
					}

					int NameValuePairsize = strParm == null ? 0 : strParm.size();
					String output = "service=" + ServiceCode_CacheData + "&prjcd=" + prjcd + "&parmsize=" + "" + NameValuePairsize;
					if (strParm != null && strParm.size() > 0) {
						for (int i = 0; i < strParm.size(); i++) {
							output = output + "&parm" + i + "=" + strParm.get(i);
						}
					}
					String response = getService(dataService, output);
					String[] result = response.split("#\\|");
					cacheDataConst.putCacheData(key, new CacheDataEntity(prjcd, new JSONArray(java.net.URLDecoder.decode(result[0], enCodingStyle_UTF8)),
							System.currentTimeMillis() + (60 * 1000L * Integer.parseInt(java.net.URLDecoder.decode(result[1], enCodingStyle_UTF8)))));
				}
			}
		}
		return cacheDataConst.getCacheData(key).getData();
	}

	/**
	 * ���o�Ǹ�
	 * 
	 * @parm prjcd
	 * @return key��
	 */
	public String getCacheKey(String prjcd) throws Exception {
		String output = "service=" + ServiceCode_GetKey + "&prjcd=" + prjcd;
		return getService(keyService, output);
	}

	/**
	 * 20151203 ESB16510 sendKeep sendKeep:�ǰe�@���ʸ�ƨ���A���W
	 * 
	 * @param systemName
	 *            �t�ΦW��
	 * @param keepData_Key
	 *            Key of Keep Data
	 * @param keepData
	 *            ���e
	 * @return ���\�P�_
	 */
	public boolean setKeepData(String systemName, String keepData_Key, String keepData) throws Exception {
		return setKeepData(systemName, keepData_Key, keepData, "", "Y", 0);
	}

	/**
	 * 20170713 ESB16725 sendKeep sendKeep:�ǰe�@���ʸ�ƨ���A���W
	 * 
	 * @param systemName
	 *            �t�ΦW��
	 * @param keepData_Key
	 *            Key of Keep Data
	 * @param keepData
	 *            ���e
	 * @param allowReplace
	 *            Y:�����g�J / N:�Y�w����ƴN���g�J
	 * @return ���\�P�_
	 */
	public boolean setKeepData(String systemName, String keepData_Key, String keepData, String allowReplace) throws Exception {
		return setKeepData(systemName, keepData_Key, keepData, "", allowReplace, 0);
	}

	/**
	 * 20171128 ESB17430 setKeepData:�ǰe�@���ʸ�ƨ���A���W
	 * 
	 * @param systemName
	 * 				�t�ΦW��
	 * @param keepData_Key
	 * 				Key of Keep Data
	 * @param keepData
	 * 				���e
	 * @param seconds
	 *				�n�s�񪺮ɶ�(��)
	 * @return boolean
	 * @throws Exception
	 */
	public boolean setKeepData(String systemName, String keepData_Key, String keepData, long seconds) throws Exception {
		return setKeepData(systemName, keepData_Key, keepData, "", "Y", seconds);
	}

	/**
	 * 20171128 ESB17430 setKeepData:�ǰe�@���ʸ�ƨ���A���W
	 * 
	 * @param systemName
	 * 				�t�ΦW��
	 * @param keepData_Key
	 * 				Key of Keep Data
	 * @param keepData
	 * 				���e
	 * @param keepDataMask
	 *				�B�n���(�slog)
	 * @return boolean
	 * @throws Exception
	 */

	public boolean setKeepDataMask(String systemName, String keepData_Key, String keepData, String keepDataMask) throws Exception {
		return setKeepData(systemName, keepData_Key, keepData, keepDataMask, "Y", 0);
	}

	/**
	 * 20171128 ESB17430 setKeepData:�ǰe�@���ʸ�ƨ���A���W
	 * 
	 * @param systemName
	 * 				�t�ΦW��
	 * @param keepData_Key
	 * 				Key of Keep Data
	 * @param keepData
	 * 				���e
	 * @param keepDataMask
	 *				�B�n���(�slog)
	 * @param allowReplace
	 *            Y:�����g�J / N:�Y�w����ƴN���g�J
	 * @param seconds
	 *				�n�s�񪺮ɶ�(��)
	 * @return boolean
	 * @throws Exception
	 */
	public boolean setKeepData(String systemName, String keepData_Key, String keepData, String keepDataMask, String allowReplace, long seconds) throws Exception {
		keepData = keepData.replaceAll("%(?![0-9a-fA-F]{2})", "%25").replaceAll("\\+(?![0-9a-fA-F]{2})", "%2B");
		keepDataMask = keepDataMask.replaceAll("%(?![0-9a-fA-F]{2})", "%25").replaceAll("\\+(?![0-9a-fA-F]{2})", "%2B");
		String output = "service=" + ServiceCode_SetKeepData + "&systemName=" + systemName + "&prjcd=" + keepData_Key + "&keepData=" + URLEncoder.encode(keepData.toString(), enCodingStyle_UTF8)
				+ "&keepDataMask=" + URLEncoder.encode(keepDataMask.toString(), enCodingStyle_UTF8) + "&allowReplace=" + allowReplace + "&setSeconds=" + seconds;
		return getService(keepService, output).equals("00");
	}

	/**
	 * 20151203 ESB16510 getKeep getKeep:�o����A���W���@���ʸ��
	 * 
	 * @param systemName
	 *            �t�ΦW��
	 * @param prjcd
	 *            �M�ץN��
	 * @return JSONArray
	 */
	public String getKeepData(String systemName, String prjcd) throws Exception {
		return getKeepData(systemName, prjcd, true);
	}

	/**
	 * 20171128 ESB17430 getKeep �o����A���W���@���ʸ��
	 * 
	* @param systemName
	 *            �t�ΦW��
	 * @param prjcd
	 *            �M�ץN��
	 * @param isDel
	 *            ����R�� true: �R�� false: ���R��
	 * @return String
	 * @throws Exception
	 */
	public String getKeepData(String systemName, String prjcd, boolean isDel) throws Exception {

		return getService(keepService, "service=" + ServiceCode_GetKeepData + "&systemName=" + systemName + "&prjcd=" + prjcd + "&isDel=" + isDel);
	}

	/**
	 * 20170320 ESB16930 setMaxID : �]�w�y�����̤j�ȡA��IDService�Τ@�޲z����
	 * 
	 * @param prjcd
	 *            �M�צW��(Key of ID)
	 * @param idname
	 *            ID�W��(Key of ID)
	 * @param idType
	 *            �y��������:LITTER(36�i��)/HEXNUM(16�i��)/NUM(10�i��)
	 * @param maxid
	 *            �ثe�y�����̤j��
	 * @param length
	 *            �y��������
	 * @return ���\�P�_
	 */
	// public boolean setMaxID(String prjcd, String idname, String idType,
	// String maxid, int length) throws Exception {
	// String output = "service=" + ServiceCode_SetMaxID + "&prjcd=" + prjcd +
	// "&idname=" + idname + "&idType=" + idType + "&maxid=" + maxid +
	// "&length=" + length;
	// return getService(idService, output).equals("00");
	// }

	/**
	 * 20170320 ESB16930 getID : ��IDService���o�y����
	 * 
	 * @param prjcd
	 *            �M�צW��(Key of ID)
	 * @param idname
	 *            ID�W��(Key of ID)
	 * @param currentID
	 *            �ثe�y������(�i�Ǫť�)
	 * @return �s���y����
	 */
	public String getID(String prjcd, String idname, String currentID) throws Exception {

		return getService(idService, "service=" + ServiceCode_GetID + "&prjcd=" + prjcd + "&idname=" + idname + "&currentID=" + currentID);
	}

	/**
	 * 20160122
	 * 
	 * @ESB16510
	 * 
	 * @param �A�Ȧ�mURL
	 * @param �n�ǥX�h��request�r��
	 * @return �^�Ǫ��r��
	 */
	private String getService(String action, String output) throws Exception {
		URL url = new URL(action);
		HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		((HttpURLConnection) urlConn).setRequestMethod("POST");
		urlConn.setRequestProperty("Accept-Charset", enCodingStyle_UTF8);
		urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + enCodingStyle_UTF8);
		urlConn.setUseCaches(false);
		urlConn.setAllowUserInteraction(true);
		HttpURLConnection.setFollowRedirects(true);
		urlConn.setInstanceFollowRedirects(true);
		DataOutputStream dos = new DataOutputStream(urlConn.getOutputStream());
		dos.writeBytes(output);
		dos.flush();
		dos.close();
		int responseCode = urlConn.getResponseCode();
		BufferedReader in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
		String inputLine = "";
		String resp = "";
		if (responseCode == HttpStatus.SC_OK) {
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			resp = java.net.URLDecoder.decode(response.toString(), enCodingStyle_UTF8);// ��r��즳����n�ѽX
		} else {
			throw new Exception("�s�u�o�Ϳ��~�A�N�X�G" + responseCode);
		}
		return resp.trim();
	}

	/**
	 * 20170531 ESB17430 getEsunOFU_URL : �]�w�ɮפW�Ǯɪ��Ȧs���
	 * 
	 * @param userID
	 *            �U��ID
	 * @param userName
	 *            �U�ȩm�W
	 * @param projectID
	 *            �M�צW��
	 * @param projectName
	 *            �M�פ���W��
	 * @param srcIP
	 *            �ӷ�IP
	 * @param subject
	 *            ���b�H����D�᪺���e
	 * @param content
	 *            ���b�H�󤺤�᪺���e
	 * @param other
	 *            �O�d���(�Ȩ�DB���d�s��ƨϥ�)
	 * @param mailGroup
	 *            �H�e�s��
	 * @param key
	 *            uniqueKey
	 * @return URL
	 */

	public String getEsunOFU_URL(String userID, String userName, String projectID, String projectName, String srcIP, String subject, String content, String other, String mailGroup, String key)
			throws Exception {
		if (userID == null || userName == null || projectID == null || projectID.equals("") || projectName == null || projectName.equals("") || srcIP == null || srcIP.equals("") || mailGroup == null
				|| mailGroup.equals("") || key == null || key.equals("")) {
			throw new Exception("�Ѽƿ��~");
		} else if (userID.length() != 10 && userID.length() != 8 && userID.length() != 11 && userID.length() != 0) {
			throw new Exception("ID���׿��~");
		} else {
			String keepData = userID + "#|" + userName + "#|" + projectID + "#|" + projectName + "#|" + srcIP + "#|" + mailGroup;

			JSONObject jsonObj = new JSONObject();
			jsonObj.put("subject", subject);
			jsonObj.put("content", content);
			jsonObj.put("other", other);
			keepData = keepData + "#|" + jsonObj.toString();

			// �Ĥ@���e���ϥ�
			setKeepData(sysName_upload, projectID + key + "00", keepData);
			// �sDB�ɨϥ�
			setKeepData(sysName_upload, projectID + key, keepData);
		}
		return hostIP_upload + "?k=" + StringUtil.getIptStringEncoding(projectID + key);
	}
}
