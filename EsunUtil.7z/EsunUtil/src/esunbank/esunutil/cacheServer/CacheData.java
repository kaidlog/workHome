package esunbank.esunutil.cacheServer;

import java.util.HashMap;

public class CacheData {
	/**
	 * �s��d�ߦ^�Ӫ�CacheData
	 */
	private HashMap<String, CacheDataEntity> Cache = new HashMap<String, CacheDataEntity>();

	/**
	 * �P�_��key�Ҧs����ƬO�_�L��
	 */
	protected boolean isCacheDataAlive(String key) {

		return Cache.containsKey(key)
				&& (System.currentTimeMillis() > Cache.get(key).getaliveTime());
	}

	/**
	 * �s�WCacheData
	 */
	protected void putCacheData(String key, CacheDataEntity data) {
		if (key != null && data != null) {
			Cache.put(key, data);
		}
	}

	/**
	 * ��oCacheData
	 */
	protected CacheDataEntity getCacheData(String key) {
		return Cache.get(key);
	}
}
