package esunbank.esunutil.crypt;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class CryptUtil {
	// �[�K��k
	private static final String DESede = "DESede";
	private static final String AES = "AES";
	// Hash��k
	public static final String Hash_MD5 = "MD5";
	public static final String Hash_SHA1 = "SHA-1";
	public static final String Hash_SHA256 = "SHA-256";
	public static final String Hash_SHA384 = "SHA-384";
	public static final String Hash_SHA512 = "SHA-512";
	public static final String Hmac_MD5 = "HmacMD5";
	public static final String Hmac_SHA1 = "HmacSHA1";
	public static final String Hmac_SHA256 = "HmacSHA256";
	public static final String Hmac_SHA512 = "HmacSHA512";
	// RSAñ����k
	public static final String Signature_NONEwithRSA = "NONEwithRSA";
	public static final String Signature_MD2withRSA = "MD2withRSA";
	public static final String Signature_MD5withRSA = "MD5withRSA";
	public static final String Signature_SHA1withRSA = "SHA1withRSA";
	public static final String Signature_SHA256withRSA = "SHA256withRSA";
	public static final String Signature_SHA384withRSA = "SHA384withRSA";
	public static final String Signature_SHA512withRSA = "SHA512withRSA";
	// AES�[�K�Ҧ�
	public static final String CipherMode_AES_CBC_NoPadding = "AES/CBC/NoPadding";
	public static final String CipherMode_AES_CBC_PKCS5Padding = "AES/CBC/PKCS5Padding";
	public static final String CipherMode_AES_CBC_PKCS7Padding = "AES/CBC/PKCS7Padding";
	public static final String CipherMode_AES_ECB_NoPadding = "AES/ECB/NoPadding";
	public static final String CipherMode_AES_ECB_PKCS5Padding = "AES/ECB/PKCS5Padding";
	public static final String CipherMode_AES_ECB_PKCS7Padding = "AES/ECB/PKCS7Padding";
	// TripleDES�[�K�Ҧ�
	public static final String CipherMode_DESede_CBC_NoPadding = "DESede/CBC/NoPadding";
	public static final String CipherMode_DESede_CBC_PKCS5Padding = "DESede/CBC/PKCS5Padding";
	public static final String CipherMode_DESede_CBC_PKCS7Padding = "DESede/CBC/PKCS7Padding";
	public static final String CipherMode_DESede_ECB_NoPadding = "DESede/ECB/NoPadding";
	public static final String CipherMode_DESede_ECB_PKCS5Padding = "DESede/ECB/PKCS5Padding";
	public static final String CipherMode_DESede_ECB_PKCS7Padding = "DESede/ECB/PKCS7Padding";
	// RSA�[�K�Ҧ�
	public static final String CipherMode_RSA_ECB_PKCS1Padding = "RSA/ECB/PKCS1Padding";
	public static final String CipherMode_RSA_ECB_OAEPWithSHA1AndMGF1Padding = "RSA/ECB/OAEPWithSHA-1AndMGF1Padding";
	public static final String CipherMode_RSA_ECB_OAEPWithSHA256AndMGF1Padding = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";

	/**
	 * <pre>
	 * ���w���_�i��TripleDES�[�K
	 * CBC�Ҧ��۰ʹw�]iv��{0,0,0,0,0,0,0,0}
	 * </pre>
	 * 
	 * @param cipherMode
	 *            �[�K�Ҧ�
	 * @param plainByte
	 *            ����
	 * @param secretKey
	 *            ���K���_
	 * @return byte[]�K��
	 * @throws Exception
	 * 
	 */
	public byte[] tripleDESEncrypt(String cipherMode, byte[] plainByte, byte[] secretKey) throws Exception {
		return tripleDESEncrypt(cipherMode, plainByte, secretKey, new byte[8]);
	}

	/**
	 * <pre>
	 * ���w���_��iv�i��TripleDES�[�K
	 * </pre>
	 * 
	 * @param cipherMode
	 *            �[�K�Ҧ�
	 * @param plainByte
	 *            ����
	 * @param secretKey
	 *            ���K���_
	 * @param iv
	 *            ��l��
	 * @return byte[]�K��
	 * @throws Exception
	 * 
	 */
	public byte[] tripleDESEncrypt(String cipherMode, byte[] plainByte, byte[] secretKey, byte[] iv) throws Exception {
		return doEncrypt(cipherMode, plainByte, getSecretKey(DESede, secretKey), new IvParameterSpec(iv));
	}

	/**
	 * <pre>
	 * ���w���_�i��TripleDES�ѱK
	 * CBC�Ҧ��۰ʹw�]iv��{0,0,0,0,0,0,0,0}
	 * </pre>
	 * 
	 * @param cipherMode
	 *            �[�K�Ҧ�
	 * @param cipherByte
	 *            �K��
	 * @param secretKey
	 *            ���K���_
	 * @return byte[]����
	 * @throws Exception
	 * 
	 */
	public byte[] tripleDESDecrypt(String cipherMode, byte[] cipherByte, byte[] secretKey) throws Exception {
		return tripleDESDecrypt(cipherMode, cipherByte, secretKey, new byte[8]);
	}

	/**
	 * <pre>
	 * �ϥΫ��w���_��iv�i��TripleDES�ѱK
	 * </pre>
	 * 
	 * @param cipherMode
	 *            �[�K�Ҧ�
	 * @param cipherByte
	 *            �K��
	 * @param secretKey
	 *            ���K���_
	 * @param iv
	 *            ��l��
	 * @return byte[]����
	 * @throws Exception
	 * 
	 */
	public byte[] tripleDESDecrypt(String cipherMode, byte[] cipherByte, byte[] secretKey, byte[] iv) throws Exception {
		return doDecrypt(cipherMode, cipherByte, getSecretKey(DESede, secretKey), new IvParameterSpec(iv));
	}

	/**
	 * <pre>
	 * ���w���_�i��AES�[�K
	 * CBC�Ҧ��۰ʹw�]iv��{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	 * </pre>
	 * 
	 * @param cipherMode
	 * @param plainByte
	 * @param secretKey
	 * @return byte[]�K��
	 * @throws Exception
	 * 
	 */
	public byte[] aesEncrypt(String cipherMode, byte[] plainByte, byte[] secretKey) throws Exception {
		return aesEncrypt(cipherMode, plainByte, secretKey, new byte[16]);
	}

	/**
	 * <pre>
	 * ���w���_��iv�ȶi��AES�[�K
	 * </pre>
	 * 
	 * @param cipherMode
	 * @param plainByte
	 * @param secretKey
	 * @param iv
	 * @return byte[]�K��
	 * @throws Exception
	 * 
	 */
	public byte[] aesEncrypt(String cipherMode, byte[] plainByte, byte[] secretKey, byte[] iv) throws Exception {
		return doEncrypt(cipherMode, plainByte, getSecretKey(AES, secretKey), new IvParameterSpec(iv));
	}

	/**
	 * <pre>
	 * ���w���_�i��AES�ѱK
	 * CBC�Ҧ��۰ʹw�]iv��{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	 * </pre>
	 * 
	 * @param cipherMode
	 * @param cipherByte
	 * @param secretKey
	 * @return byte[]����
	 * @throws Exception
	 */
	public byte[] aesDecrypt(String cipherMode, byte[] cipherByte, byte[] secretKey) throws Exception {
		return aesDecrypt(cipherMode, cipherByte, secretKey, new byte[16]);
	}

	/**
	 * 
	 * @param cipherMode
	 * @param cipherByte
	 * @param secretKey
	 * @param iv
	 * @return
	 * @throws Exception
	 */
	public byte[] aesDecrypt(String cipherMode, byte[] cipherByte, byte[] secretKey, byte[] iv) throws Exception {
		return doDecrypt(cipherMode, cipherByte, getSecretKey(AES, secretKey), new IvParameterSpec(iv));
	}

	/**
	 * ��J���_�i��RSA�[�K
	 * 
	 * @param publicKey
	 * @param iptByte
	 * @return �K�� byte[]
	 * @throws Exception
	 */
	public byte[] rsaEncrypt(String cipherMode, PublicKey publicKey, byte[] iptByte) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] cipherText = cipher.doFinal(iptByte);
		return cipherText;
	}

	/**
	 * ��J���_�i��RSA�[�K
	 * 
	 * @param publicKey
	 * @param iptString
	 * @return �K�� HexString
	 * @throws Exception
	 */
	public String rsaEncrypt(String cipherMode, PublicKey publicKey, String iptString) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] cipherText = cipher.doFinal(iptString.getBytes());
		return Hex.encodeHexString(cipherText);
	}

	/**
	 * ��J�p�_�i��RSA�ѱK
	 * 
	 * @param privateKey
	 * @param iptByte
	 * @return ���� byte[]
	 * @throws Exception
	 */
	public byte[] rsaDecrypt(String cipherMode, PrivateKey privateKey, byte[] iptByte) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] plainText = cipher.doFinal(iptByte);
		return plainText;
	}

	/**
	 * ��J�p�_�i��RSA�ѱK
	 * 
	 * @param privateKey
	 * @param iptHexString
	 * @return ����String
	 * @throws Exception
	 */
	public String rsaDecrypt(String cipherMode, PrivateKey privateKey, String iptHexString) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] plainText = cipher.doFinal(Hex.decodeHex(iptHexString.toCharArray()));
		return new String(plainText);
	}

	/**
	 * ��J�p�_�i��RSA�Ʀ�ñ��
	 * 
	 * @param signMethod
	 * @param privateKey
	 * @param plainByte
	 * @return byte[]�Ʀ�ñ��
	 * @throws Exception
	 */
	public byte[] rsaSign(String signMethod, PrivateKey privateKey, byte[] plainByte) throws Exception {
		Signature signature = Signature.getInstance(signMethod);
		signature.initSign(privateKey);
		signature.update(plainByte);
		byte[] sign = signature.sign();
		return sign;
	}

	/**
	 * ��J���_�B�����ñ���i������
	 * 
	 * @param signMethod
	 * @param publicKey
	 * @param plainByte
	 * @param signByte
	 * @return �O�_���\
	 * @throws Exception
	 */
	public boolean rsaVerify(String signMethod, PublicKey publicKey, byte[] plainByte, byte[] signByte) throws Exception {
		Signature publicSignature = Signature.getInstance(signMethod);
		publicSignature.initVerify(publicKey);
		publicSignature.update(plainByte);
		return publicSignature.verify(signByte);
	}

	/**
	 * ���w������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hash(String algorithm, String iptString) throws Exception {
		MessageDigest md = MessageDigest.getInstance(algorithm);
		md.update(iptString.getBytes());
		return Hex.encodeHexString(md.digest());
	}

	/**
	 * MD5������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hashMD5(String iptString) throws Exception {
		return hash(Hash_MD5, iptString);
	}

	/**
	 * SHA1������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hashSHA1(String iptString) throws Exception {
		return hash(Hash_SHA1, iptString);
	}

	/**
	 * SHA256������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hashSHA256(String iptString) throws Exception {
		return hash(Hash_SHA256, iptString);
	}

	/**
	 * SHA384������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hashSHA384(String iptString) throws Exception {
		return hash(Hash_SHA384, iptString);
	}

	/**
	 * SHA512������
	 * 
	 * @param iptString
	 * @return HexString
	 */
	public String hashSHA512(String iptString) throws Exception {
		return hash(Hash_SHA512, iptString);
	}

	/**
	 * ���w������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hash(String algorithm, byte[] iptByte) throws Exception {
		MessageDigest md = MessageDigest.getInstance(algorithm);
		md.update(iptByte);
		return md.digest();
	}

	/**
	 * MD5������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hashMD5(byte[] iptByte) throws Exception {
		return hash(Hash_MD5, iptByte);
	}

	/**
	 * SHA1������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hashSHA1(byte[] iptByte) throws Exception {
		return hash(Hash_SHA1, iptByte);
	}

	/**
	 * SHA256������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hashSHA256(byte[] iptByte) throws Exception {
		return hash(Hash_SHA256, iptByte);
	}

	/**
	 * SHA384������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hashSHA384(byte[] iptByte) throws Exception {
		return hash(Hash_SHA384, iptByte);
	}

	/**
	 * SHA512������
	 * 
	 * @param byte[]
	 * @return byte[]
	 */
	public byte[] hashSHA512(byte[] iptByte) throws Exception {
		return hash(Hash_SHA512, iptByte);
	}

	/**
	 * hMac������
	 * 
	 * @param algorithm
	 *            hash�t��k
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return �[�K�� ByteArray
	 */
	public static byte[] hMac(String algorithm, String key, String data) throws Exception {

		if (key == null || data == null) {
			throw new NullPointerException();
		}
		final Mac hMac = Mac.getInstance(algorithm);
		byte[] hmacKeyBytes = key.getBytes();
		final SecretKeySpec secretKey = new SecretKeySpec(hmacKeyBytes, algorithm);
		hMac.init(secretKey);
		byte[] dataBytes = data.getBytes();
		return hMac.doFinal(dataBytes);

	}

	/**
	 * HmacMD5������
	 * 
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return �[�K�� ByteArray
	 */
	public static byte[] hMacMD5(String key, String data) throws Exception {
		return hMac(Hmac_MD5, key, data);
	}

	/**
	 * HmacSHA1������
	 * 
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return �[�K�� ByteArray
	 */
	public static byte[] hMacSHA1(String key, String data) throws Exception {
		return hMac(Hmac_SHA1, key, data);
	}

	/**
	 * HmacSHA256������
	 * 
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return �[�K�� ByteArray
	 */
	public static byte[] hMacSHA256(String key, String data) throws Exception {
		return hMac(Hmac_SHA256, key, data);
	}

	/**
	 * HmacSHA512������
	 * 
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return �[�K�� ByteArray
	 */
	public static byte[] hMacSHA512(String key, String data) throws Exception {
		return hMac(Hmac_SHA512, key, data);
	}

	/**
	 * hMac��������base64
	 * 
	 * @param key
	 *            ���K���_
	 * @param data
	 *            �[�K�r��
	 * @return Base64�[�K��r��
	 */
	public static String hMacToBase64(String algorithm, String key, String data) throws Exception {

		byte[] res = hMac(algorithm, key, data);
		return Base64.encodeBase64String(res).replace("\r\n", "");

	}

	/**
	 * ��J.cer�ɡA���oX.509����
	 * 
	 */
	public X509Certificate getX509Certificate(File certFile) throws Exception {
		X509Certificate rslt = null;
		FileInputStream fis = null;
		try {
			byte[] certByte = new byte[(int) certFile.length()];
			fis = new FileInputStream(certFile);
			fis.read(certByte);
			rslt = getX509Certificate(certByte);
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (Exception ex) {
			}
		}
		return rslt;
	}

	/**
	 * ��Jcer byte��ƨ��oX.509����
	 * 
	 * @param cert
	 */
	public X509Certificate getX509Certificate(byte[] certByte) throws Exception {
		X509Certificate rslt = null;
		ByteArrayInputStream in = null;
		try {
			CertificateFactory fac = CertificateFactory.getInstance("X509");
			in = new ByteArrayInputStream(certByte);
			rslt = (X509Certificate) fac.generateCertificate(in);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception ex) {
			}
		}
		return rslt;
	}

	/**
	 * ��J.jks�ɡBalias�W�٩Mkeystore�K�X���o���}���_
	 * 
	 */
	public PublicKey getPublicKey(File jksFile, String aliasName, String keyStorePWD) throws Exception {
		PublicKey publicKey = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(jksFile);
			KeyStore keystore = KeyStore.getInstance("JKS");
			keystore.load(fis, keyStorePWD.toCharArray());
			publicKey = keystore.getCertificate(aliasName).getPublicKey();
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (Exception ex) {
			}
		}
		return publicKey;
	}

	/**
	 * ��J.jks�ɡB�Balias�W�١Bkeystore�K�X�M�p�_�K�X���o�p�K���_
	 * 
	 */
	public PrivateKey getPrivateKey(File jksFile, String aliasName, String keyStorePWD, String privateKeyPWD) throws Exception {
		PrivateKey privateKey = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(jksFile);
			KeyStore keystore = KeyStore.getInstance("JKS");
			keystore.load(fis, keyStorePWD.toCharArray());
			privateKey = (PrivateKey) keystore.getKey(aliasName, privateKeyPWD.toCharArray());
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (Exception ex) {
			}
		}
		return privateKey;
	}

	private SecretKeySpec getSecretKey(String cipherMethod, byte[] keyBytes) throws Exception {
		return new SecretKeySpec(keyBytes, cipherMethod);
	}

	private byte[] doEncrypt(String cipherMode, byte[] orgData, SecretKeySpec secretKey, IvParameterSpec ivParameterSpec) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		// CBC�Ҧ��~�ݭniv
		if (cipherMode.contains("CBC")) {
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
		} else {
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		}
		return cipher.doFinal(orgData);
	}

	private byte[] doDecrypt(String cipherMode, byte[] orgData, SecretKey secretKey, IvParameterSpec ivParameterSpec) throws Exception {
		Cipher cipher = Cipher.getInstance(cipherMode);
		// CBC�Ҧ��~�ݭniv
		if (cipherMode.contains("CBC")) {
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
		} else {
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
		}
		return cipher.doFinal(orgData);
	}
}
