package esunbank.esunutil;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ResourceBundle;

import org.json.JSONObject;

public class ShortURLUtil {
	private static ResourceBundle rb = ResourceBundle.getBundle("esunbank.esunutil.config");
	private static String webService_shortURL = rb.getString("webService_shortURL");
	private static String webService_getOrgURL = rb.getString("webService_getOrgURL");

	/**
	 * ���o�u���}(���o���Ѧ^��NULL)
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param url
	 *            ���}
	 * 
	 * @return �ثe�Ǹ�
	 */
	public String convertToShortURL(String systemID, String url) throws Exception {
		String shortURL = "";
		JSONObject data = new JSONObject();
		data.put("URL", url);
		data.put("SystemID", systemID);
		shortURL = postHttps(data, webService_shortURL);
		return shortURL.equals("ERROR") || shortURL.equals("") ? null : shortURL;
	}

	/**
	 * ���o����}(���o���Ѧ^��NULL)
	 * 
	 * @param uri
	 *            �u���}�ýX
	 * 
	 * @return ����}
	 */
	public String getOrgURL(String uri) throws Exception {
		String orgURL = "";
		JSONObject data = new JSONObject();
		data.put("ShortURL", uri);
		orgURL = postHttps(data, webService_getOrgURL);
		return orgURL.equals("ERROR") || orgURL.equals("") ? null : orgURL;
	}

	private String postHttps(JSONObject request, String url) {
		OutputStream os = null;
		InputStream response_is = null;
		String response = "";
		BufferedReader br = null;
		HttpURLConnection conn = null;

		try {
			conn = (HttpURLConnection) new URL(url).openConnection();

			conn.setRequestProperty("Connection", "close");
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(300000);
			conn.setReadTimeout(300000);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Type", "application/json");
			os = conn.getOutputStream();
			os.write(request.toString().getBytes());
			os.flush();

			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				response_is = conn.getInputStream();
			}
			if (response_is != null) {
				// Process the response
				String line = "";
				br = new BufferedReader(new InputStreamReader(response_is));
				while ((line = br.readLine()) != null) {
					response += line;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (Exception e) {
			}
			try {
				if (response_is != null) {
					response_is.close();
				}
			} catch (Exception e) {
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.disconnect();
				}
			} catch (Exception e) {
			}
		}
		return response;
	}

}
