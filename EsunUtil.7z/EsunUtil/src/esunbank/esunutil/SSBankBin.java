package esunbank.esunutil;

public class SSBankBin {

	String binNo; // �H�Υd���e���X
	String bankNo; // �Ȧ�N�X
	String bankType; // ��w�O
	String brand; // �H�Υd��´
	String cardType; // �d������(�H�Υd�Bdebit...) 
	/**
	 *  cardType 'C':�H�Υd  'D':��b�d  'P': prepaid card  'G': gift card
	 **/
	

	public String getBinNo() {
		return binNo;
	}

	public void setBinNo(String binNo) {
		this.binNo = binNo;
	}

	public String getBankNo() {
		return bankNo;
	}

	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

}
