package esunbank.esunutil;

public class BankDataCtl {

	private String BANKID;// �Ȧ�N�X
	private String BANKCNAME;// �Ȧ�^��W��
	private String BANKENAME;// �Ȧ椤��W��
	private String STATUS;// �Ȧ�N�X�O�_�w���P 0:���� ; 9:�L��
	private String CHANNEL;// �����b�D�n�q��-0:RMT ; 1:FEDI ; 2:FXML
	private String SALBANK;// FXML�~���-0:���}��(�_) ; 1:�}��(�O)
	private boolean isATM;// ATM�q��
	private boolean isRMT;// RMT�q��
	private boolean isFEDI;// FEDI�q��
	private boolean isFXML;// FXML�q��

	public String getBANKID() {
		return BANKID;
	}

	public void setBANKID(String bANKID) {
		BANKID = bANKID;
	}

	public String getBANKCNAME() {
		return BANKCNAME;
	}

	public void setBANKCNAME(String bANKCNAME) {
		BANKCNAME = bANKCNAME;
	}

	public String getBANKENAME() {
		return BANKENAME;
	}

	public void setBANKENAME(String bANKENAME) {
		BANKENAME = bANKENAME;
	}

	public String getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}

	public String getCHANNEL() {
		return CHANNEL;
	}

	public void setCHANNEL(String cHANNEL) {
		CHANNEL = cHANNEL;
	}

	public String getSALBANK() {
		return SALBANK;
	}

	public void setSALBANK(String sALBANK) {
		SALBANK = sALBANK;
	}

	public boolean isATM() {
		return isATM;
	}

	public void setATM(boolean isATM) {
		this.isATM = isATM;
	}

	public boolean isRMT() {
		return isRMT;
	}

	public void setRMT(boolean isRMT) {
		this.isRMT = isRMT;
	}

	public boolean isFEDI() {
		return isFEDI;
	}

	public void setFEDI(boolean isFEDI) {
		this.isFEDI = isFEDI;
	}

	public boolean isFXML() {
		return isFXML;
	}

	public void setFXML(boolean isFXML) {
		this.isFXML = isFXML;
	}

}
