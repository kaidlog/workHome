package esunbank.esunutil;

import java.io.IOException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;

import esunbank.esunutil.db.DBUtil;

public class SSOUtil {

	public static void main(String args[]) throws Exception {
		SSOUtil ssoUtil = new SSOUtil();
		TreeMap<String, String> parms = new TreeMap<String, String>();
		parms.put("parm1", "aaa");
		parms.put("parm2", "bbb");
		String tt = ssoUtil.getVerifyMailLink("http://127.0.0.1:8080/Webtest6", parms);
		System.out.println(tt);

		String tt1 = ssoUtil.getVerifyMailLink("http://172.19.203.18/DBQueryHost/common/login.jsp?mail=Y&UserId=SANDRA-03297&viewBillID=C81531102747007&uid=WYTt-Xx50MZ8x68X0w0zo6x66xsW027Xx30135");
		System.out.println(tt1);
	}

	public static final String SSO_TRUE = "RC=Y";

	public static final String SSO_FALSE = "RC=N";

	public static final String SSO_DataBaseName = "SSO";

	private static final ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.config");

	private static final String esunSSO = dmres.getString("ssoPortal") + dmres.getString("ssoLogin");

	private static final String ssoPortal = dmres.getString("ssoPortal");

	private static final String mailLinkVerifyKey = dmres.getString("mailLinkVerifyKey");

	private static final String commonDBAdress = dmres.getString("commonDBAdress");

	private static final String commonDBPort = dmres.getString("commonDBPort");

	private static final String commonDBID = dmres.getString("commonDBID");

	private static final String commonDBPassword = dmres.getString("commonDBPassword");

	/***
	 * ���o�J�f��������
	 */
	public static String getSSOProtal() {
		return ssoPortal;
	}

	/**
	 * ���o�����W�ϥΪ�<title>��
	 */
	public static String getSSOTitle() {
		return "�ɤs�Ȧ�";
	}

	/**
	 * ���o���ҫH�W�쵲
	 * 
	 * @param service
	 *            :�t�ΪA�Ȧ�m(doGet)
	 * @param parms
	 *            :���}�Ѽ�
	 * @return ���ҶW�s��
	 **/
	public String getVerifyMailLink(String service, TreeMap<String, String> parms) throws Exception {
		String rslt = service + "?";
		if (parms != null) {
			for (Map.Entry<String, String> parm : parms.entrySet()) {
				rslt += "&" + parm.getKey() + "=" + URLEncoder.encode(parm.getValue(), "UTF-8");
			}
		}
		String s = String.valueOf(System.currentTimeMillis());
		rslt += "&@s=" + s + "&@m=" + macData(getMapString(parms) + s);
		return rslt;
	}

	/**
	 * ���o���ҫH�W�쵲
	 * 
	 * @param link
	 *            :��l�s��
	 * @return ���ҶW�s��
	 **/
	public String getVerifyMailLink(String link) throws Exception {
		boolean isParm = link.indexOf("?") != -1 && (link.length() > link.indexOf("?") + 1) && link.indexOf("=", link.indexOf("?") + 1) != -1;
		String service = link.substring(0, isParm ? link.indexOf("?") : link.length());
		TreeMap<String, String> parms = null;
		if (isParm) {
			String[] _parms = link.substring(link.indexOf("?") + 1).split("&");
			if (_parms != null && _parms.length > 0) {
				parms = new TreeMap<String, String>();
				for (int i = 0; i < _parms.length; i++) {
					String[] _map = _parms[i].split("=");
					parms.put(_map[0], _map[1]);
				}
			}
		}
		return getVerifyMailLink(service, parms);
	}

	/**
	 * ���ҶW�쵲�O�_���T�A �������������P�_
	 * 
	 * <pre>
	 * if (!new SSOUtil().verifyMailLink(request)) {
	 * 	response.sendRedirect(SSOUtil.getSSOProtal());
	 * 	return;
	 * }
	 * </pre>
	 */
	public boolean verifyMailLink(HttpServletRequest request) throws Exception {
		TreeMap<String, String> parms = new TreeMap<String, String>();
		Enumeration keys = request.getParameterNames();
		String key = null;
		while (keys.hasMoreElements()) {
			key = (String) keys.nextElement();
			parms.put(key, request.getParameter(key));
		}

		if (parms.get("@s") == null || parms.get("@m") == null) {
			return false;
		}
		return macData(getMapString(parms) + parms.get("@s")).equals(parms.get("@m"));
	}

	private String getMapString(TreeMap<String, String> parms) throws Exception {
		String rslt = "";
		if (parms != null) {
			for (Map.Entry<String, String> parm : parms.entrySet()) {
				if (!parm.getKey().equals("@s") && !parm.getKey().equals("@m")) {
					rslt += URLEncoder.encode(parm.getValue(), "UTF-8");
				}
			}
		}
		return rslt;
	}

	private static MessageDigest md5;
	static {
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (Exception ex) {
		}
	}

	private String macData(String org) {
		return new String(Hex.encodeHex(md5.digest((org + mailLinkVerifyKey).getBytes())));
	}

	/**
	 * @param userAD
	 *            :�ϥΪ�AD�b��
	 * @param sysID
	 *            :�t�ΧO
	 * @param subSysID
	 *            :�l�t�αb��
	 * 
	 * @return �O�_��SSO�v��
	 * 
	 */
	public boolean isSSOLogin(String userAD, String sysID, String subSysID) {
		PostMethod post = null;
		HttpClient httpclient;
		String tempResult = "";
		try {

			if (userAD == null || userAD.equals("")) {
				return false;
			}
			if (sysID == null || sysID.equals("")) {
				return false;
			}

			String pars = "?userAD=" + userAD + "&sysID=" + sysID;

			if (subSysID != null && !subSysID.equals("")) {
				pars = pars + "&subSysID=" + subSysID;
			}

			// �s��
			httpclient = new HttpClient();
			post = new PostMethod(esunSSO + pars);
			httpclient.executeMethod(post);
			// ���o�^�ǵ��G
			tempResult = post.getResponseBodyAsString();
		} catch (HttpException e) {
			return false;
		} catch (IOException e) {
			return false;
		} finally {
			if (post != null) {
				post.releaseConnection();
			}
		}
		return tempResult != null && tempResult.contains(SSO_TRUE);
	}

	/** FTP */
	static public String FTPType_FTP = "0";

	/** FTPES(�~��) */
	static public String FTPType_FTPES = "1";

	/** SFTP */
	static public String FTPType_SFTP = "2";

	/** FTPS(���t) */
	static public String FTPType_FTPS = "3";

	/** SFTP(�K�X�ɮ�) */
	static public String FTPType_SFTP_File = "4";
	
	/** HTTPS */
	static public String FTPType_HTTPS = "5";
	
	/** SOCKET */
	static public String FTPType_SOCKET = "6";

	/**
	 * �NFTP�ǿ�O���g�JDB
	 * 
	 * @param Source
	 *            �ӷ��ɮ׸��|
	 * @param Destination
	 *            �ت��ɮ׸��|
	 * @param FileSize
	 *            �ɮפj�p
	 * @param Type
	 *            �ǿ��V�AU(�W��)/D(�U��)
	 * @param isSuccess
	 *            �O�_���\
	 * @param Flag
	 *            �t���ѧO�X�A�Ҧp�GDTP
	 * @param FTPType
	 *            FTP�����A�Ԩ�FTPType�Ѽ�(FTPType_FTP/FTPType_FTPES/FTPType_SFTP/FTPType_FTPS/FTPType_SFTP_File/FTPType_HTTPS/FTPType_SOCKET)
	 */
	public void ftpInfoToDB(String Source, String Destination, long FileSize, String Type, boolean isSuccess, String Flag, String FTPType) throws Exception {
		Connection conn = null;
		CallableStatement smt = null;
		try {
			conn = new DBUtil().getSQLConn(commonDBAdress, commonDBPort, "SSO", commonDBID, commonDBPassword, false);
			smt = conn.prepareCall("{call AddFTPFileLog(?,?,?,?,?,?,?,?)}");
			smt.setString(1, Source);
			smt.setString(2, Destination);
			smt.setLong(3, FileSize);
			smt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			smt.setString(5, Type);
			smt.setString(6, isSuccess ? "S" : "F");
			smt.setString(7, Flag);
			smt.setString(8, FTPType);
			smt.execute();
		} finally {
			try {
				if (smt != null) {
					smt.close();
				}
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}
}