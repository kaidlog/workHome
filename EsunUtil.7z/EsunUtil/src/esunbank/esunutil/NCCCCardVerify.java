package esunbank.esunutil;

public class NCCCCardVerify {

	private String BANKID;// �Ȧ�N�X
	private String BANKCNAME;// �Ȧ椤��W��

	public String getBANKID() {
		return BANKID;
	}

	public void setBANKID(String bANKID) {
		BANKID = bANKID;
	}

	public String getBANKCNAME() {
		return BANKCNAME;
	}

	public void setBANKCNAME(String bANKCNAME) {
		BANKCNAME = bANKCNAME;
	}

}
