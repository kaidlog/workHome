package esunbank.esunutil;

public class UserDept {

	private String DEPT;
	private String DEPT_INFO;
	private int DEPT_CNT;

	public String getDEPT() {
		return DEPT;
	}

	public void setDEPT(String dEPT) {
		DEPT = dEPT;
	}

	public String getDEPT_INFO() {
		return DEPT_INFO;
	}

	public void setDEPT_INFO(String dEPT_INFO) {
		DEPT_INFO = dEPT_INFO;
	}

	public int getDEPT_CNT() {
		return DEPT_CNT;
	}

	public void setDEPT_CNT(int dEPT_CNT) {
		DEPT_CNT = dEPT_CNT;
	}

}
