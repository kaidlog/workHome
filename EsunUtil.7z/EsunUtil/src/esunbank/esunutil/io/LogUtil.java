package esunbank.esunutil.io;

import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

import esunbank.esunutil.DateUtil;

/**
 * Log�@�ε{��<br>
 * �C���slog��<br>
 * �ɦW�W�h:���O_���(_�Ǹ�).log(ex:A_20110125.log,A_20110125_1.log,A_20110125_2.log...)
 */

public class LogUtil extends LogParams {

	private LogEntity logEntity;

	private String logType;

	private static long flushTime = Long.parseLong(dmres.getString("flushTime"));
	/** Info�r�� */
	protected static final String text_Info = "Info";
	/** Error�r�� */
	protected static final String text_Error = "Error";
	/** Log�r�� */
	protected static final String text_Log = "Log";

	private static TreeMap<String, LogEntity> logs = new TreeMap<String, LogEntity>();

	static {
		if (!logFolder.endsWith(File.separator)) {
			logFolder += File.separator;
		}
		if (!new File(logFolder).exists() && !new File(logFolder).mkdirs()) {
			System.err.println("�إ�Log�ؿ����`");
		}
		logHisFolder = logFolder + "history";
		if (!new File(logHisFolder).exists() && !new File(logHisFolder).mkdirs()) {
			System.err.println("�إ�Log���v�ؿ����`");
		}
		new LogUtil.BakLog().start();
	}

	/**
	 * �ϥιw�](���ɮפj�p)LOG
	 * 
	 * @param logType
	 *            LOG���O�ɦW��
	 */
	public LogUtil(String logType) {
		initLog(logType, LogUtil.LOGBYSIZE);
	}

	/**
	 * ���wLOG�覡
	 * 
	 * @param logType
	 *            LOG���O�ɦW��
	 * @param logMod
	 *            LOG�ɳƥ��Ҧ�
	 */
	public LogUtil(String logType, int logMod) {
		initLog(logType, logMod);
	}

	private int logMod = LogUtil.LOGBYDATE;

	private void initLog(String logType, int logMod) {

		this.logType = logType;

		if (logMod != LogUtil.LOGBYDATE && logMod != LogUtil.LOGBYSIZE) {
			IOUtil.printInfo("logMod���~�A�ϥιw�]��LOGBYDATE");
		} else {
			this.logMod = logMod;
		}
	}

	FilenameFilter fileNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.toLowerCase().endsWith(".log") && name.contains("_") && name.length() > 13) {
				return true;
			}
			return false;
		}
	};

	// ���o�ثeLog�ɦW
	private String getNowFileName(String logType) {
		String nowDate = DateUtil.getNowDate();
		String rslt = logFolder + logType + "_" + nowDate + ".log";
		File[] list = new File(logFolder).listFiles(fileNameFilter);
		Arrays.sort(list);
		Pattern pattern = Pattern.compile(logType + "_[0-9]{8}_?[0-9]*.log");
		for (int i = list.length - 1; i >= 0; i--) {
			if (pattern.matcher(list[i].getName()).matches()) {
				rslt = list[i].getAbsolutePath();
				break;
			}
		}
		return rslt;
	}

	public void Log(String msg) {
		// Log�w�]���L�b�e���W
		doLog(LogUtil.text_Log, msg, false);
	}

	public void Info(String msg) {
		// Info�w�]���L�b�e���W
		doLog(LogUtil.text_Info, msg, false);
	}

	public void Error(String msg) {
		// Error�w�]���L�b�e���W
		doLog(LogUtil.text_Error, msg, false);
	}

	public void Error(Exception ex) {
		// Error�w�]���L�b�e���W
		try {
			// ��log.Error�L�X�o�Ϳ��~�ɶ�
			doLog(LogUtil.text_Error, ex.toString(), false);
			ex.printStackTrace(new PrintWriter(getLogFileWriter()));
		} catch (Exception e) {
			System.out.println("�L�k����LOG[" + e.getMessage() + "]" + ex.toString());
			ex.printStackTrace();
		}
	}

	public void Log(String msg, boolean isConsole) {
		doLog(LogUtil.text_Log, msg, isConsole);
	}

	public void Info(String msg, boolean isConsole) {
		doLog(LogUtil.text_Info, msg, isConsole);
	}

	public void Error(String msg, boolean isConsole) {
		doLog(LogUtil.text_Error, msg, isConsole);
	}

	public void Error(Exception ex, boolean isConsole) {
		try {
			if (isConsole) {
				ex.printStackTrace();
			}
			doLog(LogUtil.text_Error, ex.toString(), isConsole);
			ex.printStackTrace(new PrintWriter(getLogFileWriter()));
		} catch (Exception e) {
			System.out.println("�L�k����LOG[" + e.getMessage() + "]" + ex.toString());
			ex.printStackTrace();
		}
	}

	/**
	 * �I�sdoLog�@�w�O�g�ɮ�
	 */
	public final void doLog(String logType, String msg, boolean isConsole) {
		try {
			msg = "�i" + logType + "�j" + DateUtil.getNowDateTime("/", ":", " ", DateUtil.DateFmt_Mode_Datetime_Millisecond) + ":" + msg + "\r\n";
			if (isConsole) {
				System.out.println(msg);
			}
			getLogFileWriter().write(msg);
		} catch (Exception e) {
			System.out.println("�L�k����LOG[" + e.getMessage() + "]�AMSG=" + msg);
		}
	}

	/**
	 * ���oLog�ɪ�FileWriter
	 * 
	 * @param logType
	 *            LOG���O�ɦW��
	 */
	public FileWriter getLogFileWriter() {
		// ���O���s�b�~�s�W����
		if (logs.get(logType) == null) {
			isLogOn();
		}
		return logs.get(this.logType).fWrite;
	}

	/**
	 * �P�B�B�z�A�קKLOG�@���j�q�i�ӡA�S�s�W����
	 */
	private static Object lock = new Object();

	private void isLogOn() {
		synchronized (lock) {
			if (logs.get(logType) == null) {
				try {
					// ���o�ثe�Ǹ����ɦW
					logEntity = new LogEntity(new File(getNowFileName(logType)), this.logMod);
					logs.put(logType, logEntity);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	private static class LogEntity {
		private FileWriter fWrite;

		private File logFile;

		private int logMode;

		private String logDate;

		private LogEntity(File logFile, int logMod) throws Exception {
			this.fWrite = new FileWriter(logFile, true);
			this.logFile = logFile;
			this.logMode = logMod;
			this.logDate = DateUtil.getNowDate();
		}
	}

	private static class BakLog extends Thread {

		public void run() {
			String nowDate;
			LogEntity oldLog = null;
			String oldName;
			String name;
			int idx;
			LogEntity newLog;
			while (true) {
				try {
					nowDate = DateUtil.getNowDate();
					for (Map.Entry<String, LogEntity> log : logs.entrySet()) {
						try {
							log.getValue().fWrite.flush();
							if ((log.getValue().logMode == LogUtil.LOGBYDATE && !log.getValue().logDate.equals(nowDate))
									|| (log.getValue().logMode == LogUtil.LOGBYSIZE && log.getValue().logFile.length() >= logSize)) {
								oldLog = log.getValue();
								// ���o���v�ƥ��Ǹ�
								oldName = logHisFolder + File.separator + log.getKey() + "_" + nowDate + ".log.ZIP";
								name = nowDate + ".log";
								idx = 0;
								while (new File(oldName + ".XXX").exists() || new File(oldName).exists()) {
									idx += 1;
									oldName = logHisFolder + File.separator + log.getKey() + "_" + nowDate + "_" + idx + ".log.ZIP";
									name = nowDate + "_" + idx + ".log";
								}
								newLog = new LogEntity(new File(logFolder + File.separator + log.getKey() + "_" + name), oldLog.logMode);
								logs.put(log.getKey(), newLog);
								oldLog.fWrite.close();// �����e��
								// ���ܾ��v��
								new BakFile(oldLog.logFile).start();
							}
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					try {
						Thread.sleep(flushTime);
					} catch (Exception ex) {
					}
				}
			}
		}
	}

	private static class BakFile extends Thread {
		File tmpFile = null;

		private BakFile(File tmpFile) {
			this.tmpFile = tmpFile;
		}

		public void run() {
			try {
				IOUtil.zipFile(tmpFile, logHisFolder);
				tmpFile.delete();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}
