package esunbank.esunutil.io.ssl;

import javax.net.ssl.*;
import java.security.cert.*;

public class SelfTrustManager implements X509TrustManager {
	public X509Certificate[] getAcceptedIssuers() {
		return null;
	}

	public void checkClientTrusted(X509Certificate[] certs, String authType) {
	}

	public void checkServerTrusted(X509Certificate[] certs, String authType) {
	}
}
