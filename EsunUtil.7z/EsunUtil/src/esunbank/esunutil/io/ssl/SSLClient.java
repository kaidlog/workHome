package esunbank.esunutil.io.ssl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.ResourceBundle;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import org.json.JSONArray;
import org.json.JSONObject;

import esunbank.esunutil.info.HostInfoUtil;

public class SSLClient {

	private static final String serverIP = ResourceBundle.getBundle("esunbank.esunutil.io.ssl.config").getString("serverIP");
	private static final int serverPort = Integer.parseInt(ResourceBundle.getBundle("esunbank.esunutil.io.ssl.config").getString("serverPort"));

	// 201707 ��������
	private static final String environment = ResourceBundle.getBundle("esunbank.esunutil.io.ssl.config").getString("environment");

	private static final String mailGroup = ResourceBundle.getBundle("esunbank.esunutil.io.ssl.config").getString("mailGroup");
	private static final String unique = "%U%NiQ%ue";
	private static final String splitStr = "#|";
	private static final String splitStr_Arr = "$|";
	private static final String querySuccessRSCode = "00";
	public static final String queryRSCode = splitStr + "paramQueryRSCode" + splitStr_Arr;
	private static final String queryExceptionRSCode = "-99";

	/**
	 * ���o�[�K���Ѽƭ�
	 * 
	 * @param systemID
	 *            :�t�ΦW��
	 * @param paramIVPairList
	 *            :�Ѽ����+IV
	 * 
	 * @return �Ѽƭ�
	 * 
	 **/

	public Hashtable<String, String> getParamEncrypt(String systemID, ArrayList<String[]> paramIVPairList) throws Exception {
		return environment.equals("T") ? getParam(paramIVPairList) : getParamEncrypt(serverIP, serverPort, systemID, paramIVPairList);
	}

	public Hashtable<String, String> getParamEncrypt(String serverIP, int serverPort, String systemID, ArrayList<String[]> paramIVPairList) throws Exception {
		Hashtable<String, String> retParamTable = new Hashtable<String, String>();
		JSONObject sendData = new JSONObject();
		sendData.put("type", "01");
		sendData.put("systemID", systemID);
		sendData.put("paramList", paramIVPairList);
		String[] tmpServerIP = serverIP.split("[#][|]");
		boolean isSuccess = true;
		ArrayList<String> errorMsg = new ArrayList<String>();
		for (int i = 0; i < tmpServerIP.length; i++) {
			try {
				String result_Str = sendData(tmpServerIP[i], serverPort, sendData.toString());
				ArrayList result_Arr = parseQData(result_Str);
				if (result_Arr.get(0).equals("OK")) {
					retParamTable.put(queryRSCode, querySuccessRSCode);
					ArrayList<String[]> resultParamList = (ArrayList<String[]>) result_Arr.get(2);
					for (int j = 0, listSize = resultParamList.size(); j < listSize; j++) {
						retParamTable.put(paramIVPairList.get(j)[0], resultParamList.get(j)[0]);
					}
					break;
				} else {
					String detail = (String) result_Arr.get(3);
					retParamTable.put(queryRSCode, (String) result_Arr.get(2));
					isSuccess = false;
					String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƥ��ѡAIP=" + tmpServerIP[i];
					if (i != (tmpServerIP.length - 1)) {
						errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
					}
					if (detail != null && !detail.equals("")) {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)) + ", " + detail);
					} else {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)));
					}
					System.out.println(errorMessage);
				}
			} catch (Exception e) {
				isSuccess = false;
				String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƿ��~�AIP=" + tmpServerIP[i] + "�AException=" + e.toString();
				if (i != (tmpServerIP.length - 1)) {
					errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
				}
				errorMsg.add(errorMessage + ", ���~�N�X : " + queryExceptionRSCode + ", " + errorMsg(queryExceptionRSCode));
				System.out.println(errorMessage);
			}
		}
		if (!isSuccess && isGetParamSuccess(retParamTable)) {
			System.out.println("�w���\���o�Ѽƭ�");
		}
		if (!isGetParamSuccess(retParamTable)) {
			String content = "";
			for (int i = 0; i < errorMsg.size(); i++) {
				content += errorMsg.get(i) + "<br>";
			}
			content += "<br>�ӷ�:<br>";
			StackTraceElement[] stackTraceArr = Thread.currentThread().getStackTrace();
			for (int i = 1; i < stackTraceArr.length; i++) {
				content += "-> " + stackTraceArr[i].toString() + "<br>";
			}
			new HostInfoUtil().sendMailToGroupUser(mailGroup, "�iEsunParm�j���o�ѼƤ��߰Ѽ�" + "(IP:" + serverIP + ", port:" + serverPort + ")���ѡA�t�ΥN��:" + systemID, "���浲�G:<br>" + content);
		}
		return retParamTable;
	}

	/**
	 * 201707 for��������(���A���ѼƤ��߮�passWD)
	 *
	 */
	public Hashtable<String, String> getParam(ArrayList<String[]> paramIVPairList) throws Exception {
		Hashtable<String, String> retParamTable = new Hashtable<String, String>();
		retParamTable.put(queryRSCode, querySuccessRSCode);
		for (int i = 0, listSize = paramIVPairList.size(); i < listSize; i++) {
			retParamTable.put(paramIVPairList.get(i)[0], paramIVPairList.get(i)[1]);
		}
		return retParamTable;
	}

	/**
	 * ���o���[�K���Ѽƭ�
	 * 
	 * @param systemID
	 *            :�t�ΦW��
	 * @param paramList
	 *            :�Ѽ����
	 * 
	 * @return �Ѽƭ�
	 * 
	 */
	public Hashtable<String, String> getParamPlainText(String systemID, ArrayList<String> paramList) throws Exception {
		return getParamPlainText(serverIP, serverPort, systemID, paramList);
	}

	public Hashtable<String, String> getParamPlainText(String serverIP, int serverPort, String systemID, ArrayList<String> paramList) throws Exception {
		Hashtable<String, String> retParamTable = new Hashtable<String, String>();
		JSONObject sendData = new JSONObject();
		sendData.put("type", "02");
		sendData.put("systemID", systemID);
		sendData.put("paramList", paramList);
		String[] tmpServerIP = serverIP.split("[#][|]");
		boolean isSuccess = true;
		ArrayList<String> errorMsg = new ArrayList<String>();
		for (int i = 0; i < tmpServerIP.length; i++) {
			try {
				String result_Str = sendData(tmpServerIP[i], serverPort, sendData.toString());
				ArrayList result_Arr = parseQData(result_Str);
				if (result_Arr.get(0).equals("OK")) {
					retParamTable.put(queryRSCode, querySuccessRSCode);
					ArrayList<String[]> resultParamList = (ArrayList<String[]>) result_Arr.get(2);
					for (int j = 0, listSize = resultParamList.size(); j < listSize; j++) {
						retParamTable.put(paramList.get(j), resultParamList.get(j)[0]);
					}
					break;
				} else {
					String detail = (String) result_Arr.get(3);
					retParamTable.put(queryRSCode, (String) result_Arr.get(2));
					isSuccess = false;
					String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƥ��ѡAIP=" + tmpServerIP[i];
					if (i != (tmpServerIP.length - 1)) {
						errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
					}
					if (detail != null && !detail.equals("")) {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)) + ", " + detail);
					} else {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)));
					}
					System.out.println(errorMessage);
				}
			} catch (Exception e) {
				isSuccess = false;
				String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƿ��~�AIP=" + tmpServerIP[i] + "�AException=" + e.toString();
				if (i != (tmpServerIP.length - 1)) {
					errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
				}
				errorMsg.add(errorMessage + ", ���~�N�X : " + queryExceptionRSCode + ", " + errorMsg(queryExceptionRSCode));
				System.out.println(errorMessage);
			}
		}
		if (!isSuccess && isGetParamSuccess(retParamTable)) {
			System.out.println("�w���\���o�Ѽƭ�");
		}
		if (!isGetParamSuccess(retParamTable)) {
			String content = "";
			for (int i = 0; i < errorMsg.size(); i++) {
				content += errorMsg.get(i) + "<br>";
			}
			content += "<br>�ӷ�:<br>";
			StackTraceElement[] stackTraceArr = Thread.currentThread().getStackTrace();
			for (int i = 1; i < stackTraceArr.length; i++) {
				content += "-> " + stackTraceArr[i].toString() + "<br>";
			}	
			new HostInfoUtil().sendMailToGroupUser(mailGroup, "�iEsunParm�j���o�ѼƤ��߰Ѽ�" + "(IP:" + serverIP + ", port:" + serverPort + ")���ѡA�t�ΥN��:" + systemID, "���浲�G:<br>" + content);
		}
		return retParamTable;
	}

	/**
	 * ���o�@��Ѽƪ��Ѽƭ�
	 * 
	 * @param systemID:�t�ΦW��
	 * 
	 * @param paramPairList:�Ѽ����
	 * 
	 * @return �Ѽƭ�
	 **/

	public Hashtable<String, String> getCommonParam(String systemID, ArrayList<String> paramList) throws Exception {
		return getCommonParam(serverIP, serverPort, systemID, paramList);
	}

	public Hashtable<String, String> getCommonParam(String serverIP, int serverPort, String systemID, ArrayList<String> paramList) throws Exception {
		Hashtable<String, String> retParamTable = new Hashtable<String, String>();
		JSONObject sendData = new JSONObject();
		sendData.put("type", "03");
		sendData.put("systemID", systemID);
		sendData.put("paramList", paramList);
		String[] tmpServerIP = serverIP.split("[#][|]");
		boolean isSuccess = true;
		ArrayList<String> errorMsg = new ArrayList<String>();
		for (int i = 0; i < tmpServerIP.length; i++) {
			try {
				String result_Str = sendData(tmpServerIP[i], serverPort, sendData.toString());
				ArrayList result_Arr = parseQData(result_Str);
				if (result_Arr.get(0).equals("OK")) {
					retParamTable.put(queryRSCode, querySuccessRSCode);
					ArrayList<String[]> resultParamList = (ArrayList<String[]>) result_Arr.get(2);
					for (int j = 0, listSize = resultParamList.size(); j < listSize; j++) {
						retParamTable.put(paramList.get(j), resultParamList.get(j)[0]);
					}
					break;
				} else {
					String detail = (String) result_Arr.get(3);
					retParamTable.put(queryRSCode, (String) result_Arr.get(2));
					isSuccess = false;
					String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƥ��ѡAIP=" + tmpServerIP[i];
					if (i != (tmpServerIP.length - 1)) {
						errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
					}
					if (detail != null && !detail.equals("")) {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)) + ", " + detail);
					} else {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)));
					}
					
					System.out.println(errorMessage);
				}
			} catch (Exception e) {
				isSuccess = false;
				String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƿ��~�AIP=" + tmpServerIP[i] + "�AException=" + e.toString();
				if (i != (tmpServerIP.length - 1)) {
					errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
				}
				errorMsg.add(errorMessage + ", ���~�N�X : " + queryExceptionRSCode + ", " + errorMsg(queryExceptionRSCode));
				System.out.println(errorMessage);
			}
		}
		if (!isSuccess && isGetParamSuccess(retParamTable)) {
			System.out.println("�w���\���o�Ѽƭ�");
		}
		if (!isGetParamSuccess(retParamTable)) {
			String content = "";
			for (int i = 0; i < errorMsg.size(); i++) {
				content += errorMsg.get(i) + "<br>";
			}
			content += "<br>�ӷ�:<br>";
			StackTraceElement[] stackTraceArr = Thread.currentThread().getStackTrace();
			for (int i = 1; i < stackTraceArr.length; i++) {
				content += "-> " + stackTraceArr[i].toString() + "<br>";
			}			
			new HostInfoUtil().sendMailToGroupUser(mailGroup, "�iEsunParm�j���o�ѼƤ��߰Ѽ�" + "(IP:" + serverIP + ", port:" + serverPort + ")���ѡA�t�ΥN��:" + systemID, "���浲�G:<br>" + content);
		}
		return retParamTable;
	}

	/**
	 * ���o��������IP�M�t�ΦW�٪��D�[�K�S���Ѽƪ��Ѽ� :04 ���o���������t�ΦW�٪��D�@��Ѽƪ��Ѽƭ� :05
	 * 
	 * @param systemID:�t�ΦW��
	 * 
	 * @return �Ѽƭ�
	 **/

	public Hashtable<String, String> getParamPlainTextList(String systemID) throws Exception {
		return getListParam(serverIP, serverPort, systemID, "04");
	}

	public Hashtable<String, String> getCommonParamList(String systemID) throws Exception {
		return getListParam(serverIP, serverPort, systemID, "05");
	}

	public Hashtable<String, String> getListParam(String serverIP, int serverPort, String systemID, String type) throws Exception {
		Hashtable<String, String> retParamTable = new Hashtable<String, String>();
		JSONObject sendData = new JSONObject();
		sendData.put("type", type);
		sendData.put("systemID", systemID);
		String[] tmpServerIP = serverIP.split("[#][|]");
		boolean isSuccess = true;
		ArrayList<String> errorMsg = new ArrayList<String>();
		for (int i = 0; i < tmpServerIP.length; i++) {
			try {
				String result_Str = sendData(tmpServerIP[i], serverPort, sendData.toString());
				ArrayList result_Arr = parseQData(result_Str);
				if (result_Arr.get(0).equals("OK")) {
					retParamTable.put(queryRSCode, querySuccessRSCode);
					ArrayList<String[]> resultParamList = (ArrayList<String[]>) result_Arr.get(2);
					for (int j = 0, listSize = resultParamList.size(); j < listSize; j++) {
						retParamTable.put(resultParamList.get(j)[0].split(unique)[0], resultParamList.get(j)[0].split(unique)[1]);
					}
					break;
				} else {
					String detail = (String) result_Arr.get(3);
					retParamTable.put(queryRSCode, (String) result_Arr.get(2));
					isSuccess = false;
					String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƥ��ѡAIP=" + tmpServerIP[i];
					if (i != (tmpServerIP.length - 1)) {
						errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
					}					
					if (detail != null && !detail.equals("")) {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)) + ", " + detail);
					} else {
						errorMsg.add(errorMessage + ", ���~�N�X : " + (String) result_Arr.get(2) + ", " + errorMsg((String) result_Arr.get(2)));
					}
					System.out.println(errorMessage);
				}
			} catch (Exception e) {
				isSuccess = false;
				String errorMessage = "�@" + tmpServerIP.length + "�ճ]�w�A��" + (i + 1) + "�ճ]�w���Ѽƿ��~�AIP=" + tmpServerIP[i] + "�AException=" + e.toString();
				if (i != (tmpServerIP.length - 1)) {
					errorMessage += "�A���եΤU�@�ճ]�w���Ѽ�";
				}
				errorMsg.add(errorMessage + ", ���~�N�X : " + queryExceptionRSCode + ", " + errorMsg(queryExceptionRSCode));
				System.out.println(errorMessage);
			}
		}
		if (!isSuccess && isGetParamSuccess(retParamTable)) {
			System.out.println("�w���\���o�Ѽƭ�");
		}
		if (!isGetParamSuccess(retParamTable)) {
			String content = "";
			for (int i = 0; i < errorMsg.size(); i++) {
				content += errorMsg.get(i) + "<br>";
			}
			content += "<br>�ӷ�:<br>";
			StackTraceElement[] stackTraceArr = Thread.currentThread().getStackTrace();
			for (int i = 1; i < stackTraceArr.length; i++) {
				content += "-> " + stackTraceArr[i].toString() + "<br>";
			}
			new HostInfoUtil().sendMailToGroupUser(mailGroup, "�iEsunParm�j���o�ѼƤ��߰Ѽ�" + "(IP:" + serverIP + ", port:" + serverPort + ")���ѡA�t�ΥN��:" + systemID, "���浲�G:<br>" + content);
		}
		return retParamTable;
	}

	private String sendData(String serverIP, int serverPort, String data) throws Exception {
		String rtnData_Str = "";
		SSLSocket sslSocket = null;
		try {
			SSLContext sslContext = null;
			TrustManager[] trustManagers = new TrustManager[] { new SelfTrustManager() };
			sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(null, trustManagers, null);
			SSLSocketFactory sslsocketfactory = sslContext.getSocketFactory();
			sslSocket = (SSLSocket) sslsocketfactory.createSocket(serverIP, serverPort);

			// �ǰe���
			OutputStream outputstream = sslSocket.getOutputStream();
			outputstream.write(data.getBytes());

			// �����^�е��G
			InputStream inputstream = sslSocket.getInputStream();
			byte[] dataIn_Bytes = new byte[4096];
			int dataIn_Read = 0;
			while ((dataIn_Read = inputstream.read(dataIn_Bytes)) != -1) {
				rtnData_Str += new String(dataIn_Bytes, 0, dataIn_Read);
			}
		} finally {
			if (sslSocket != null) {
				try {
					sslSocket.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
		return rtnData_Str;
	}

	public String errorMsg(String code) throws Exception {
		String result = "���~��] : ";
		if (code.equals("01")) {
			result += "�榡���`";
		} else if (code.equals("02")) {
			result += "�ǰe���ѼƼƶq�P�q��Ʈw���X���ѼƼƶq�۲�";
		} else if (code.equals("03")) {
			result += "��Ʈw�s�u���`";
		} else if (code.equals("04")) {
			result += "�զ��^�е��G�ɲ��`";
		} else {
			result += "��l���~";
		}
		return result;
	}

	public boolean isGetParamSuccess(Hashtable<String, String> paramTable) {
		return (querySuccessRSCode.equals(paramTable.get(queryRSCode))) ? true : false;
	}

	private ArrayList parseQData(String qData) throws Exception {
		ArrayList result = null;
		if (qData != null) {
			result = new ArrayList();
			JSONObject json = new JSONObject(qData);
			String rlt = json.optString("result");
			String sid = json.optString("systemID");
			result.add(rlt);
			result.add(sid);
			if (rlt.equals("OK")) {
				ArrayList<String[]> loop = new ArrayList<String[]>();
				JSONArray jarray = (JSONArray) json.get("retParamValueList");
				for (int i = 0; i < jarray.length(); i++) {
					String jdata = (String) jarray.get(i);
					String[] sdata = { jdata };
					loop.add(sdata);
				}
				result.add(loop);
			} else {
				String rtnCode = json.optString("rtnCode");
				String detail = json.optString("detail");
				result.add(rtnCode);
				result.add(detail);
			}
		}
		return result;
	}
}
