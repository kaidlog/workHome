package esunbank.esunutil.io.filetransfer;

import java.util.ResourceBundle;

public class SocketParams {
	protected static ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.io.config");
	protected static String ID = dmres.getString("filetransfer_ID");
	protected static String PASSWD = dmres.getString("filetransfer_PASSWD");
}