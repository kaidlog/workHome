package esunbank.esunutil.io.filetransfer;

import java.net.*;
import java.io.*;

import esunbank.esunutil.io.IOUtil;

/**
 * Socket Client�A�N���w�ɮ׶ǰe�ܻ��ݥD��
 * 
 * @author drinkin-06751
 * */
public class TransferFile extends SocketParams {

	/**
	 * <pre>
	 * ���ե�
	 * args[0]:FolderPath (to Send the listFiles)
	 * args[1]:ip
	 * args[2]:port
	 * </pre>
	 **/
	public static void main(String[] args) throws Exception {
		File[] list = new File(args[0]).listFiles();
		for (int i = 0; i < list.length; i++) {
			new ForTest(list[i], args[1], Integer.parseInt(args[2])).start();
		}
	}

	private static class ForTest extends Thread {
		File f = null;
		String ip;
		int port;

		ForTest(File f, String ip, int port) {
			this.f = f;
			this.ip = ip;
			this.port = port;
		}

		public void run() {
			try {
				TransferFile t = new TransferFile(ip, port);
				t.doService(f);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	private String host;
	private int port;

	public TransferFile(String host, int port) {
		this.host = host;
		this.port = port;
	}

	public void doService(File file) throws Exception {
		Socket socket = null;
		PrintStream printStream = null;
		BufferedReader bufferedReader = null;
		BufferedInputStream bufferedInputStream = null;
		FileInputStream fileInputStream = null;
		InputStreamReader inputStreamReader = null;

		try {
			if (!file.isFile() || file.length() == 0) {
				throw new Exception("�ɮ׿��~�Τ��s�b");
			}

			IOUtil.printInfo("�����ݰT���G���ջP " + host + ":" + port + " �s�u��....");
			socket = new Socket(host, port);

			IOUtil.printInfo("�����ݰT���G���\�P " + socket.getInetAddress() + ":"
					+ socket.getPort() + " �s�u");

			printStream = new PrintStream(socket.getOutputStream());
			printStream.println(ID);// �g�J�b��
			printStream.println(PASSWD);// �g�J�K�X
			printStream.println(file.getName());// �g�J�ɦW
			printStream.flush();

			inputStreamReader = new InputStreamReader(socket.getInputStream());
			bufferedReader = new BufferedReader(inputStreamReader);
			String conStr = bufferedReader.readLine();
			IOUtil.printInfo("�����ݦ^�СG" + conStr);
			if (conStr.startsWith("E")) {
				throw new Exception(conStr);
			}

			IOUtil.printInfo("�����ݰT���G�ɮסi" + file.getName() + "�j�ǰe��....");
			fileInputStream = new FileInputStream(file);
			bufferedInputStream = new BufferedInputStream(fileInputStream);
			byte[] data = new byte[1024];
			int idx = 0;
			while ((idx = bufferedInputStream.read(data)) != -1) {
				printStream.write(data, 0, idx);
			}
			printStream.flush();
			IOUtil.printInfo("�����ݰT���G�ɮסi" + file.getName() + "�j�ǰe����");
		} finally {
			try {
				if (fileInputStream != null) {
					fileInputStream.close();
				}
			} catch (Exception ex) {
			}
			try {
				if (bufferedInputStream != null) {
					bufferedInputStream.close();
				}
			} catch (Exception ex) {
			}

			try {
				if (printStream != null) {
					printStream.close();
				}
			} catch (Exception ex) {
			}

			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			} catch (Exception ex) {
			}
			try {
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
			} catch (Exception ex) {
			}
			try {
				if (socket != null) {
					socket.close();
					IOUtil.printInfo("�����ݰT���G���\�P " + socket.getInetAddress()
							+ ":" + socket.getPort() + " �פ�s�u");
				}
			} catch (Exception ex) {
				IOUtil.printInfo("�����ݰT���G���`�P " + socket.getInetAddress() + ":"
						+ socket.getPort() + " �פ�s�u�G" + ex.toString());
			}
		}
	}
}