package esunbank.esunutil.io.filetransfer;

import java.net.*;
import java.io.*;

import esunbank.esunutil.io.IOUtil;

/**
 * Socket Client�A�����ɮ׫��m�Y�ؿ�
 * 
 * @author drinkin-06751
 * */
public class ReceiveFileAsClient extends SocketParams {

	/**
	 * <pre>
	 * args[0]:host
	 * args[1]:port
	 * args[2]:loaclFolder
	 * args[3]:sleepTime(��)
	 * args[4]:localPort
	 * </pre>
	 */
	public static void main(String[] args) throws Exception {

		File root = new File(args[2]);
		// Check Data
		if (!root.isDirectory()) {
			throw new Exception("�D���T�ؿ�" + args[2]);
		}
		long sleepTime = Long.parseLong(args[3]) * 1000L;

		ReceiveFileAsClient client = new ReceiveFileAsClient(args[0],
				Integer.parseInt(args[1]), args[2], Integer.parseInt(args[4]));

		while (true) {
			try {
				while (client.doService())
					;
			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				try {
					Thread.sleep(sleepTime);
				} catch (Exception ex) {
				}
			}
		}
	}

	private String host;
	private int port;
	private File root;
	private int localPort;

	private ReceiveFileAsClient(String host, int port, String root,
			int localPort) {
		this.host = host;
		this.port = port;
		this.root = new File(root);
		this.localPort = localPort;
	}

	public boolean doService() throws Exception {
		String fileName;
		boolean isSuccess = false;
		File localFile = null;
		File localFileTmp = null;
		Socket clientSocket = null;
		PrintStream printStream = null;
		BufferedInputStream fileReader = null;
		BufferedOutputStream fileWriter = null;
		BufferedReader bufferedReader = null;
		InputStreamReader inputStreamReader = null;
		FileOutputStream fileOutputStream = null;
		try {
			IOUtil.printInfo("�����ݰT���G���ջP " + host + ":" + port + " �s�u��....");
			clientSocket = new Socket(host, port, InetAddress.getLocalHost(),
					localPort);
			IOUtil.printInfo("�����ݰT���G���\�P " + clientSocket.getInetAddress() + ":"
					+ clientSocket.getPort() + " �إ߳s�u");
			printStream = new PrintStream(clientSocket.getOutputStream());
			printStream.println(ID);// �g�J�b��
			printStream.println(PASSWD);// �g�J�K�X
			printStream.flush();

			inputStreamReader = new InputStreamReader(
					clientSocket.getInputStream());
			bufferedReader = new BufferedReader(inputStreamReader);
			fileName = bufferedReader.readLine();// ���o�ɮצW��
			if (fileName == null || fileName.equals("")) {
				throw new Exception("�s�u���`");
			}
			if (fileName.startsWith("E")) {
				throw new Exception(fileName);
			}
			if (fileName.equals("NODATA")) {
				IOUtil.printInfo("�ǰe�ݦ^�СG�L�ɮ׻ݱ���");
			} else {
				IOUtil.printInfo("�ǰe�ݦ^�СG�ɮסi" + fileName + "�j�w�Ƨ��A�ݶǰe");
				localFile = new File(root.getAbsolutePath() + File.separator
						+ fileName);
				localFileTmp = new File(localFile.getAbsolutePath() + ".xxx");

				// �Y�P�ɦW�ɮפw�s�b�A������
				if (localFile.exists()) {
					printStream.println("E_�ɮסi" + fileName + "�j�w�s�b�A��������");
					printStream.flush();
					IOUtil.printInfo("�����ݰT���G�ɮסi" + fileName + "�j�w�s�b�A��������");
				} else {
					if (localFileTmp.exists()) {
						// �R���ݯd���Ȧs��
						localFileTmp.delete();
					}
					printStream.println("�ɮסi" + fileName + "�j���s�b�A�i����");
					printStream.flush();
					IOUtil.printInfo("�����ݰT���G�ɮסi" + fileName + "�j������....");
					// �ǳƱ����ɮצ�y
					fileReader = new BufferedInputStream(
							clientSocket.getInputStream());
					fileOutputStream = new FileOutputStream(localFileTmp);
					fileWriter = new BufferedOutputStream(fileOutputStream);

					byte[] data = new byte[1024];
					int idx = 0;
					while ((idx = fileReader.read(data)) != -1) {
						fileWriter.write(data, 0, idx);
					}
					fileWriter.flush();
					isSuccess = true;
				}
			}
		} finally {
			try {
				if (fileWriter != null) {
					fileWriter.close();
				}
			} catch (Exception e) {
			}
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			} catch (Exception e) {
			}

			try {
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
			} catch (Exception e) {
			}

			try {
				if (clientSocket != null) {
					clientSocket.setSoLinger(true, 0);
				}
			} catch (Exception ex) {
			}

			if (isSuccess && localFileTmp != null && localFileTmp.isFile()) {
				if (isSuccess = localFileTmp.renameTo(localFile)) {
					IOUtil.printInfo("�����ݰT���G�ɮסi" + localFile.getName()
							+ "�j��������");
				} else {
					IOUtil.printInfo("�����ݰT���G�ɮסi" + localFileTmp.getName()
							+ ".xxx�j����������A��W����");
				}
			}

			try {
				if (clientSocket != null) {
					clientSocket.close();
					IOUtil.printInfo("�����ݰT���G���\�P "
							+ clientSocket.getInetAddress() + ":"
							+ clientSocket.getPort() + " �פ�s�u");
				}
			} catch (Exception ex) {
				IOUtil.printInfo("�����ݰT���G���`�P " + clientSocket.getInetAddress()
						+ ":" + clientSocket.getPort() + " �פ�s�u�G"
						+ ex.toString());
			}
		}
		return isSuccess;
	}
}
