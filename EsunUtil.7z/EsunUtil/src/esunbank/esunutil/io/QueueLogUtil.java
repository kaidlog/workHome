package esunbank.esunutil.io;

import java.util.ResourceBundle;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Session;

import esunbank.esunutil.DateUtil;
import esunbank.esunutil.StringUtil;
import esunbank.esunutil.mq.ActiveMQUtil;

public class QueueLogUtil {

	private Connection connection;

	private Session session;

	private MessageProducer producer;

	private ActiveMQUtil activeMQUtil = new ActiveMQUtil();

	private ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.io.config");

	private String mqLogQueueName = dmres.getString("mqLogQueueName");

	private LogUtil logUtil = new LogUtil(dmres.getString("mqErrorlogName"));

	private String[] mailList = ResourceBundle
			.getBundle("esunbank.esunutil.info.config")
			.getString("AlertMailList").split(",");

	private long connRetrySleepTime = Long.parseLong(dmres
			.getString("sleepTimeInSecond")) * 1000;

	private String project;

	private int logMod = LogUtil.LOGBYSIZE;

	public QueueLogUtil(String project) {
		this.project = project;
		mqConn(true);
	}

	public QueueLogUtil(String project, int logMod) {
		this.project = project;
		this.logMod = logMod;
		mqConn(true);
	}

	private void mqConn(boolean restart) {
		for (int i = 0; true; i++) {
			try {
				if (restart || i != 0 || connection == null || session == null
						|| producer == null) {
					connection = activeMQUtil.getMQConnection();
					session = activeMQUtil.getMQSession(connection);
					producer = activeMQUtil.getMessageProducer(session,
							mqLogQueueName, false);
				}
				break;
			} catch (Exception e) {
				logUtil.Error("���oMQ�s�u���`(project=" + project + ")�G" + e);
				logUtil.Error(e);
				// �C3�����o�@���H
				if (i % ((3 * 60 * 1000) / connRetrySleepTime) == 0) {
					new esunbank.esunutil.info.MailUtil().sendMail(mailList,
							null, null, null, "[MQLogUtil(project=" + project
									+ ")]MQ�s�u�o�Ͳ��`,����s�u����"
									+ ((i + 1) * connRetrySleepTime / 1000)
									+ "���A�ХߧY�T�{", e.toString(), null);
				} else {
					try {
						Thread.sleep(connRetrySleepTime);
					} catch (Exception exx) {
					}
				}
			}
		}
	}

	public void Log(String msg) {
		Log(msg, false);
	}

	public void Info(String msg) {
		Info(msg, true);
	}

	public void Error(String msg) {
		Error(msg, true);
	}

	public void Error(Exception ex) {
		Error(ex, true);
	}

	public void Log(String msg, boolean isConsole) {
		writeQ("Log", msg, logMod, isConsole);
	}

	public void Info(String msg, boolean isConsole) {
		writeQ("Info", msg, logMod, isConsole);
	}

	public void Error(String msg, boolean isConsole) {
		writeQ("Error", msg, logMod, isConsole);
	}

	public void Error(Exception ex, boolean isConsole) {
		writeQ("Error", StringUtil.getStackTraceASString(ex), logMod, isConsole);
	}

	/**
	 * @param logType
	 *            Log�BInfo�BError
	 * @param logText
	 *            LOG���e
	 * @param logMode
	 *            log�ƥ��Ҧ�
	 * */
	private void writeQ(String logType, String logText, int logMod,
			boolean isConsole) {
		String text = "";
		try {
			/**
			 * �M�����O@|logType@|LOG���e@|logMod(logMod����ܩʡA�i�����w)
			 */
			text = project
					+ "@|"
					+ logType
					+ "@|"
					+ DateUtil.getNowDateTime("/", ":", " ",
							DateUtil.DateFmt_Mode_Datetime) + " " + logText
					+ "@|" + logMod;
			if (isConsole) {
				IOUtil.printInfo(logText);
			}
			mqConn(false);
			activeMQUtil.writeQ(producer, session.createTextMessage(text));
		} catch (Exception e) {
			logUtil.Error("writeQ���`�G" + e + ",text=" + text);
			logUtil.Error(e);
			mqConn(true);
		}
	}
}
