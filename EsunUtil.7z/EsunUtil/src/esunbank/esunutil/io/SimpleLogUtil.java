package esunbank.esunutil.io;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import esunbank.esunutil.DateUtil;

public class SimpleLogUtil extends LogParams {

	private FileWriter FWrite;

	private String logFileName = null;

	private int logMod;

	private File logFile = null;

	public SimpleLogUtil(String logType) {
		initLog(logType, LOGBYSIZE);
	}

	public SimpleLogUtil(String logType, int logMod) {
		initLog(logType, logMod);
	}

	private void initLog(String logType, int logMod) {
		try {
			logFileName = logFolder + logType + ".log";
			this.logMod = logMod;
			logFile = new File(logFileName);
			if (!logFile.exists()) {
				logFile.createNewFile();
			}
			FWrite = new FileWriter(logFile, true);
			chkCrtNewLogFile();
		} catch (Exception e) {
			System.out.println("�L�k�_�lLOG[" + e.getMessage() + "]");
		}
	}

	private static final Object lock = new Object();

	public void Log(String msg) {
		// Log�w�]���L�b�e���W
		Log(msg, false);
	}

	public void Info(String msg) {
		// Info�w�]�L�b�e���W
		Info(msg, true);
	}

	public void Error(String msg) {
		// Error�w�]�L�b�e���W
		Error(msg, true);
	}

	public void Error(Exception ex) {
		// Error�w�]�L�b�e���W
		Error(ex, true);
	}

	public void Log(String msg, boolean isConsole) {
		doLog("Log", msg, isConsole);
	}

	public void Info(String msg, boolean isConsole) {
		doLog("Info", msg, isConsole);
	}

	public void Error(String msg, boolean isConsole) {
		doLog("Error", msg, isConsole);
	}

	public void Error(Exception ex, boolean isConsole) {
		synchronized (lock) {
			try {
				if (isConsole) {
					ex.printStackTrace();
				}
				ex.printStackTrace(new PrintWriter(FWrite));
				chkCrtNewLogFile();
			} catch (Exception e) {
				System.out.println("�L�k����LOG[" + e.getMessage() + "]"
						+ ex.toString());
				ex.printStackTrace();
			}
		}
	}
	
	private void doLog(String logType, String msg, boolean isConsole) {
		synchronized (lock) {
			try {
				msg = "�i"
						+ logType
						+ "�j"
						+ DateUtil.getNowDateTime("/", ":", " ",
								DateUtil.DateFmt_Mode_Datetime) + ":" + msg
						+ "\r\n";
				if (isConsole) {
					System.out.println(msg);
				}
				FWrite.write(msg);
				chkCrtNewLogFile();
			} catch (Exception e) {
				System.out
						.println("�L�k����LOG[" + e.getMessage() + "]�AMSG=" + msg);
			}
		}
	}

	private void chkCrtNewLogFile() throws Exception {
		if (logMod == LOGBYSIZE && logFile.length() > logSize) {
			crtNewLogFile();
		} else if (logMod == LOGBYLINENUMBER) {
			if (IOUtil.getFileLineNumber(logFile) > logLine) {
				crtNewLogFile();
			}
		}
	}

	private void crtNewLogFile() throws Exception {
		FWrite.close();
		IOUtil.zipFile(logFile, logHisFolder);
		// �R���w�ƥ������ɨëإ߷s��
		if (!logFile.delete() || !logFile.createNewFile()) {
			throw new Exception("�L�k�إ�LOG��");
		}
		FWrite = new FileWriter(logFileName, true);
	}

}
