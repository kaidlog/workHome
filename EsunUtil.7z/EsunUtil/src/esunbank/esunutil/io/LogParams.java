package esunbank.esunutil.io;

import java.io.File;
import java.util.ResourceBundle;

public class LogParams {

	protected static ResourceBundle dmres = ResourceBundle
			.getBundle("esunbank.esunutil.io.config");
	
	protected static String logDirectory = dmres.getString("logDirectory");
	
	protected static String baklogDirectory = dmres.getString("baklogDirectory");

	protected static String logFolder = new File(logDirectory).isDirectory() ? logDirectory
			: baklogDirectory;

	protected static String logHisFolder = logFolder + "history";;

	protected static long logSize = Long.parseLong(dmres.getString("logSize")) * 1024 * 1024;

	protected static int logLine = Integer.parseInt(dmres.getString("logLine"));

	/**
	 * �̤���B�zLog��(LogUtil�ϥ�)
	 */
	public static final int LOGBYDATE = 1;

	/**
	 * ���ɮפj�p�B�zLog��(SimpleLogUtil�BLogUtil�ϥ�)
	 */
	public static final int LOGBYSIZE = 2;

	/**
	 * �̦�ƳB�zLog��(SimpleLogUtil�ϥ�)
	 */
	public static final int LOGBYLINENUMBER = 3;

}
