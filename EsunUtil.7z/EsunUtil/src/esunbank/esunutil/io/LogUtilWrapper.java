package esunbank.esunutil.io;

import esunbank.esunutil.StringUtil;
import esunbank.esunutil.mq.MQLogUtil;

public class LogUtilWrapper extends LogUtil {

	private final boolean isLog2MQ = (dmres.getString("isLog2MQ").equalsIgnoreCase("Y")) ? true : false;
	String logType1 = null;
	String logType2 = null;
	String logKey1 = null;
	String logKey2 = null;

	MQLogUtil mqLog = new MQLogUtil();

	/**
	 * @param ProjectID1
	 *            ������MQLog Project1
	 */
	public LogUtilWrapper(String ProjectID1) {
		super(ProjectID1);
		this.logType1 = ProjectID1;
	}

	/**
	 * @param ProjectID1
	 *            ������MQLog Project1
	 * @param ProjectID2
	 *            ������MQLog Project2
	 */
	public LogUtilWrapper(String ProjectID1, String ProjectID2) {
		super(ProjectID1);
		this.logType1 = ProjectID1;
		this.logType2 = ProjectID2;
	}

	/**
	 * @param ProjectID1
	 *            ������MQLog Project1
	 * @param ProjectID2
	 *            ������MQLog Project2
	 * @param Key1
	 *            ������MQLog key1
	 */
	public LogUtilWrapper(String ProjectID1, String ProjectID2, String key1) {
		super(ProjectID1);
		this.logType1 = ProjectID1;
		this.logType2 = ProjectID2;
		this.logKey1 = key1;
	}

	/**
	 * @param ProjectID1
	 *            ������MQLog Project1
	 * @param ProjectID2
	 *            ������MQLog Project2
	 * @param Key1
	 *            ������MQLog key1
	 * @param Key2
	 *            ������MQLog key2
	 */
	public LogUtilWrapper(String ProjectID1, String ProjectID2, String key1, String key2) {
		super(ProjectID1);
		this.logType1 = ProjectID1;
		this.logType2 = ProjectID2;
		this.logKey1 = key1;
		this.logKey2 = key2;
	}

	public final void doWrapperLog(String logType, String msg, boolean isConsole) {
		String iMsg = null;

		try {
			iMsg = msg + "\r\n";
			if (isLog2MQ) {
				try {
					if (logType.equals(LogUtil.text_Info)) {
						mqLog.doMQLog_Info(System.currentTimeMillis(), null, null, this.logType1, this.logType2, this.logKey1, this.logKey2, iMsg);
					} else if (logType.equals(LogUtil.text_Error)) {
						mqLog.doMQLog_Error(System.currentTimeMillis(), null, null, this.logType1, this.logType2, this.logKey1, this.logKey2, iMsg);
					} else {
						mqLog.doMQLog_Log(System.currentTimeMillis(), null, null, this.logType1, this.logType2, this.logKey1, this.logKey2, iMsg);
					}
					if (isConsole) {
						System.out.println(iMsg);
					}
				} catch (Exception e) {
					if (logType.equals(LogUtil.text_Info)) {
						super.Info(msg, isConsole);
					} else if (logType.equals(LogUtil.text_Error)) {
						super.Error(msg, isConsole);
					} else {
						super.Log(msg, isConsole);
					}
					super.Error(e, isConsole);
				}
			} else {
				if (logType.equals(LogUtil.text_Info)) {
					super.Info(msg, isConsole);
				} else if (logType.equals(LogUtil.text_Error)) {
					super.Error(msg, isConsole);
				} else {
					super.Log(msg, isConsole);
				}
			}
		} catch (Exception e) {
			System.out.println("�L�k����LOG[" + e.getMessage() + "]�AMSG=" + iMsg);
		}
	}

	public void Log(String msg) {
		doWrapperLog(LogUtil.text_Log, msg, false);
	}

	public void Log(String msg, boolean isConsole) {
		doWrapperLog(LogUtil.text_Log, msg, isConsole);
	}

	public void Info(String msg) {
		doWrapperLog(LogUtil.text_Info, msg, false);
	}

	public void Info(String msg, boolean isConsole) {
		doWrapperLog(LogUtil.text_Info, msg, isConsole);
	}

	public void Error(String msg) {
		doWrapperLog(LogUtil.text_Error, msg, false);
	}

	public void Error(String msg, boolean isConsole) {
		doWrapperLog(LogUtil.text_Error, msg, isConsole);
	}

	public void Error(Exception ex) {
		doWrapperLog(LogUtil.text_Error, ex.toString() + " \r\n" + StringUtil.getStackTraceASString(ex), false);
	}

	public void Error(Exception ex, boolean isConsole) {
		try {
			if (isConsole) {
				System.out.println(ex.toString());
				ex.printStackTrace();
			}
			Error(ex);
		} catch (Exception e) {
			System.out.println("�L�k����LOG[" + e.getMessage() + "]" + ex.toString());
			ex.printStackTrace();
		}
	}
}
