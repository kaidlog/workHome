package esunbank.esunutil;

public class CommonAGNO {

	private String AGNO;
	
	private String CMCNM;
	
	private String CMSNM;
	
	private String CMENM;
	
	private String AFCNM;

	public String getAGNO() {
		return AGNO;
	}

	public void setAGNO(String aGNO) {
		AGNO = aGNO;
	}

	public String getCMCNM() {
		return CMCNM;
	}

	public void setCMCNM(String cMCNM) {
		CMCNM = cMCNM;
	}

	public String getCMSNM() {
		return CMSNM;
	}

	public void setCMSNM(String cMSNM) {
		CMSNM = cMSNM;
	}

	public String getCMENM() {
		return CMENM;
	}

	public void setCMENM(String cMENM) {
		CMENM = cMENM;
	}

	public String getAFCNM() {
		return AFCNM;
	}

	public void setAFCNM(String aFCNM) {
		AFCNM = aFCNM;
	}

}
