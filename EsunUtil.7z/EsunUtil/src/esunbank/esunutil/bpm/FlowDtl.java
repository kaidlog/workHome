package esunbank.esunutil.bpm;

public class FlowDtl {

	private String systemID; // �t�ΥN��
	private String flowID; // �y�{�N��
	private int flowPhase; // �y�{���q
	private String groupID; // �s�եN�X
	private String isNotice; // �O�_�q��
	private String exNotice; // �B�~�q���H��
	private String isTop; // �O�_�h�^�̤W�h
	private String memo;
	private int overTimeDay; //���B�z�q���Ѽ�
	private String isSECT; //�P�_�O�_���Ӽh�B�z�H�����P�����ά�O�AA:�P��O�AB:�P�����A�ŭȩ�NULL:�L����

	public int getOverTimeDay() {
		return overTimeDay;
	}

	public void setOverTimeDay(int overTimeDay) {
		this.overTimeDay = overTimeDay;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getFlowID() {
		return flowID;
	}

	public void setFlowID(String flowID) {
		this.flowID = flowID;
	}

	public int getFlowPhase() {
		return flowPhase;
	}

	public void setFlowPhase(int flowPhase) {
		this.flowPhase = flowPhase;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getIsNotice() {
		return isNotice;
	}

	public void setIsNotice(String isNotice) {
		this.isNotice = isNotice;
	}

	public String getExNotice() {
		return exNotice;
	}

	public void setExNotice(String exNotice) {
		this.exNotice = exNotice;
	}

	public String getIsTop() {
		return isTop;
	}

	public void setIsTop(String isTop) {
		this.isTop = isTop;
	}
	public String getIsSECT() {
		return isSECT;
	}

	public void setIsSECT(String isSECT) {
		this.isSECT = isSECT;
	}
}
