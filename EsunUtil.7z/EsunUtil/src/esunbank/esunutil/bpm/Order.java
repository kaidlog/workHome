package esunbank.esunutil.bpm;

import java.sql.Timestamp;
import java.util.*;

public class Order {

	private String systemID; // �t�ΥN��
	private String flowID; // �y�{�N��
	private String orderID; // �q��s��
	private String applyUser; // �ӽФH��
	private int flowPhase = -1; // �y�{���q
	private String preUser; // �e�B�z�H��
	private String nextUser; // ���B�z�H��
	private String modifyUser; // ���ʤH��
	private Timestamp modifyDatetime; // ���ʮɶ�
	private String memo; // �Ƶ�
	private String mailLink;// �W�s���A�Ȧ�m
	private ArrayList<String> processUser;
	private String mailRslt; // �q���H�H�e���G

	public String getMailRslt() {
		return mailRslt;
	}

	public void setMailRslt(String mailRslt) {
		this.mailRslt = mailRslt;
	}

	public ArrayList<String> getProcessUser() {
		return processUser;
	}

	protected void setProcessUser(ArrayList<String> processUser) {
		this.processUser = processUser;
	}

	public String getMailLink() {
		return mailLink;
	}

	public void setMailLink(String mailLink) {
		this.mailLink = mailLink;
	}

	public String getMaillink() {
		return mailLink;
	}

	public void setMaillink(String mailLink) {
		this.mailLink = mailLink;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getFlowID() {
		return flowID;
	}

	public void setFlowID(String flowID) {
		this.flowID = flowID;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getApplyUser() {
		return applyUser;
	}

	public void setApplyUser(String applyUser) {
		this.applyUser = applyUser;
	}

	public int getFlowPhase() {
		return flowPhase;
	}

	public void setFlowPhase(int flowPhase) {
		this.flowPhase = flowPhase;
	}

	public String getPreUser() {
		return preUser;
	}

	public void setPreUser(String preUser) {
		this.preUser = preUser;
	}

	public String getNextUser() {
		return nextUser;
	}

	public void setNextUser(String nextUser) {
		this.nextUser = nextUser;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Timestamp getModifyDatetime() {
		return modifyDatetime;
	}

	public void setModifyDatetime(Timestamp modifyDatetime) {
		this.modifyDatetime = modifyDatetime;
	}
}
