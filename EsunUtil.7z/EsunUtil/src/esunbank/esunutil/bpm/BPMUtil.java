package esunbank.esunutil.bpm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import java.util.Map.Entry;

import esunbank.esunutil.CommonUser;
import esunbank.esunutil.CommonUtil;
import esunbank.esunutil.DateUtil;
import esunbank.esunutil.SSOUtil;
import esunbank.esunutil.StringUtil;
import esunbank.esunutil.db.DBUtil;
import esunbank.esunutil.info.MailUtil;

public class BPMUtil {

	private ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.config");
	private String commonDBAdress_Out = dmres.getString("commonDBAdress_Out"); // PSR070DBN
	private String commonDBAdress_DB = dmres.getString("commonDBAdress_DB"); // PSR071DB
	private String commonDBAdress = dmres.getString("commonDBAdress"); // PSR073DBN
	private String commonDBPort = dmres.getString("commonDBPort");
	private String commonDBName = dmres.getString("commonDBName");
	private String commonDBID = dmres.getString("commonDBID");
	private String commonDBPassword = dmres.getString("commonDBPassword");
	public static final int DBHost_Out = 0;
	public static final int DBHost_In = 1;
	public static final int DBHost_DB = 2;
	private String dbHost = "";
	static Object userlock = new Object();
	static boolean isUserUpdater = false;

	public static final int actionEQ = 0;
	public static final int actionGreaterEQ = 1;
	public static final int actionGreater = 2;
	public static final int actionLessEQ = -1;
	public static final int actionLess = -2;
	public static final int actionLike = 99;

	private HashMap<String, Object> equalMap;
	private HashMap<String, Object> greaterMap;
	private HashMap<String, Object> greaterEQMap;
	private HashMap<String, Object> lessMap;
	private HashMap<String, Object> lessEQMap;
	private HashMap<String, String> likeMap;
	private HashMap<String, Object> orderCondMap; // tbOrder ����
	private Connection conn;
	private String defaultColumn = "OrderID";
	public static final int closeOrder = 99; // �q�浲��
	public static final int cancleOrder = -99; // �q��P��

	/**
	 * �w�]���w��Ʈw DBHost_In
	 */
	public BPMUtil() {

	}

	/**
	 * ���w��Ʈw�D��<br>
	 * CommonUtil.DBHost_Out/CommonUtil.DBHost_In/CommonUtil.DBHost_DB
	 */
	public BPMUtil(int dbAssign) {
		if (dbAssign == DBHost_Out) {
			dbHost = commonDBAdress_Out;
		} else if (dbAssign == DBHost_In) {
			dbHost = commonDBAdress;
		} else if (dbAssign == DBHost_DB) {
			dbHost = commonDBAdress_DB;
		}
	}

	public BPMUtil(Connection conn) throws Exception {
		this.conn = conn;
		equalMap = new HashMap<String, Object>();
		greaterMap = new HashMap<String, Object>();
		greaterEQMap = new HashMap<String, Object>();
		lessMap = new HashMap<String, Object>();
		lessEQMap = new HashMap<String, Object>();
		orderCondMap = new HashMap<String, Object>();
		likeMap = new HashMap<String, String>();
	}

	static TreeMap<String, String> attenDanceList = null; // �C��𰲤H�����
	static TreeMap<String, String> attenDanceList_script = null; // �C��𰲤H�����(Script)

	class AttenDanceUpdater extends Thread {
		private BPMUtil bpmUtil = new BPMUtil();

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					bpmUtil.updAttenDanceList(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	protected void updAttenDanceList(boolean isForceUpdate) {
		if (isForceUpdate || attenDanceList == null) {
			synchronized (userlock) {
				if (isForceUpdate || attenDanceList == null) {
					updUserAttenDance(); // ��s���
				}
				if (!isUserUpdater) { // �u��Server�}�Үɰ���
					new AttenDanceUpdater().start();
					isUserUpdater = true;
				}
			}
		}
	}

	private void updUserAttenDance() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		TreeMap<String, String> tmp_attenDanceList = new TreeMap<String, String>();
		TreeMap<String, String> tmp_attenDanceList_Script = new TreeMap<String, String>();

		String sql = "Select b.EMCNM, b.ADACC, a.EMNO, a.Dept, a.StartDate, a.EndDate From [Common].[dbo].[AttenDance] a With (nolock) "
				+ " Join [Common].[dbo].[tbUserInfo] b With (nolock) On a.EMNO = b.EMNO Where ? Between a.StartDate And a.EndDate";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			SimpleDateFormat dmf1 = new SimpleDateFormat("yyyyMMddHHmmss");
			SimpleDateFormat dmf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");

			int idx = 1;
			ps = conn.prepareStatement(sql);
			ps.setString(idx++, DateUtil.getNowDateTime());
			rs = ps.executeQuery();

			String note = null;
			while (rs.next()) {
				note = " �� �𰲤� " + dmf2.format(dmf1.parse(rs.getString("StartDate"))) + " ~ " + dmf2.format(dmf1.parse(rs.getString("EndDate")));
				tmp_attenDanceList.put(rs.getString("ADACC"), rs.getString("EMCNM") + note);
				tmp_attenDanceList_Script.put(rs.getString("ADACC"), note); // for
																			// getSelectNextUser
																			// Script
			}
			attenDanceList = tmp_attenDanceList;
			attenDanceList_script = tmp_attenDanceList_Script;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * ���o���H���O�_�� for getSelectNextUser
	 * 
	 * @param
	 * @return
	 */
	public String getUserAttenDanceScript(String userID) throws Exception {
		updAttenDanceList(false);
		if (attenDanceList_script.get(userID) != null) {
			return attenDanceList_script.get(userID);
		}
		return "";
	}

	/**
	 * ���o���H���O�_��
	 * 
	 * @param
	 * @return
	 */
	public ArrayList<String> getUserAttenDanceList(ArrayList<String> approver) throws Exception {
		updAttenDanceList(false);
		CommonUtil cu = new CommonUtil();
		ArrayList<String> approverList = new ArrayList<String>();
		for (int i = 0; i < approver.size(); i++) {
			if (attenDanceList.get(approver.get(i)) == null) {
				approverList.add(cu.getCommonUser(approver.get(i)).getEMCNM()); // �d�L���H�𰲮ɩ�J�H�W
			} else {
				approverList.add(attenDanceList.get(approver.get(i)));
			}
		}
		return approverList;
	}

	/**
	 * ���o���H���O�_��
	 * 
	 * @param
	 * @return
	 */
	public HashMap<String, String> getUserAttenDanceMap(ArrayList<String> approver) throws Exception {
		updAttenDanceList(false);
		CommonUtil cu = new CommonUtil();
		HashMap<String, String> approverMap = new HashMap<String, String>();
		for (int i = 0; i < approver.size(); i++) {
			if (attenDanceList.get(approver.get(i)) == null) {
				approverMap.put(approver.get(i), cu.getCommonUser(approver.get(i)).getEMCNM()); // �d�L���H�𰲮ɩ�J�H�W
			} else {
				approverMap.put(approver.get(i), attenDanceList.get(approver.get(i)));
			}
		}
		return approverMap;
	}

	/**
	 * ���o�ϥΪ̽s�褤���q����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @param nextUser
	 *            �i�B�z�ϥΪ�
	 * @return ArrayList<HashMap<String, Object>>
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getUserOrder(String systemID, String flowID, String tableName, String condiColumn, String nextUser) throws Exception {

		setTbOrderQryCondition("NextUser", nextUser);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, false, null, null);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<HashMap<String, Object>> getUserOrder(String systemID, String flowID, String tableName, String condiColumn, String nextUser, String orderby) throws Exception {

		setTbOrderQryCondition("NextUser", nextUser);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, orderby);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * ���ƧǪ�
	 **/
	public ArrayList<HashMap<String, Object>> getUserOrder(String systemID, String flowID, String tableName, String condiColumn, String nextUser, String orderby, String order) throws Exception {

		setTbOrderQryCondition("NextUser", nextUser);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, orderby, order);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * ���o�PrelationUser�������q����
	 * 
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @param relationUser
	 *            (applyUser/�q��ӽФH+nextUser/�q��f�֤H)
	 * @return ArrayList<HashMap<String, Object>>
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getRelationOrder(String systemID, String flowID, String tableName, String condiColumn, String relationUser) throws Exception {

		setTbOrderQryCondition("$relationUser&", relationUser);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, false, null, null);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<OrderListDetail> getUserOrderDetail(String systemID, String flowID, String tableName, String condiColumn, String nextUser) throws Exception {

		setTbOrderQryCondition("NextUser", nextUser);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * ���ƧǪ�
	 */
	public ArrayList<OrderListDetail> getUserOrderDetail(String systemID, String flowID, String tableName, String condiColumn, String nextUser, String orderby, String order) throws Exception {

		setTbOrderQryCondition("NextUser", nextUser);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn, orderby, order);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * ���o���׭q����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @return ArrayList<HashMap<String, Object>>
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getCloseOrder(String systemID, String flowID, String tableName, String condiColumn) throws Exception {
		setTbOrderQryCondition("FlowPhase", closeOrder);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, false, null, null);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<OrderListDetail> getCloseOrderDetail(String systemID, String flowID, String tableName, String condiColumn) throws Exception {
		setTbOrderQryCondition("FlowPhase", closeOrder);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<OrderListDetail> getCloseOrderDetail(String systemID, String flowID, String tableName, String condiColumn, String orderby, String order) throws Exception {
		setTbOrderQryCondition("FlowPhase", closeOrder);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn, orderby, order);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * �P�׭q����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @return ArrayList<HashMap<String, Object>>
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getCancelOrder(String systemID, String flowID, String tableName, String condiColumn) throws Exception {
		setTbOrderQryCondition("FlowPhase", cancleOrder);
		ArrayList<HashMap<String, Object>> rslt = getOrderList(systemID, flowID, tableName, condiColumn, false, null, null);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<OrderListDetail> getCancelOrderDetail(String systemID, String flowID, String tableName, String condiColumn) throws Exception {
		setTbOrderQryCondition("FlowPhase", cancleOrder);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn);
		orderCondMap.clear();
		return rslt;
	}

	public ArrayList<OrderListDetail> getCancelOrderDetail(String systemID, String flowID, String tableName, String condiColumn, String orderby, String order) throws Exception {
		setTbOrderQryCondition("FlowPhase", cancleOrder);
		ArrayList<OrderListDetail> rslt = getOrderListDetail(systemID, flowID, tableName, condiColumn, orderby, order);
		orderCondMap.clear();
		return rslt;
	}

	/**
	 * �d�߭q����v����
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param orderID
	 *            �q��s��
	 * @return ArrayList<Order>
	 * @throws Exception
	 */
	public ArrayList<Order> getOrderHistory(String systemID, String flowID, String orderID) throws Exception {
		return getOrderHistory(systemID, flowID, orderID, null);
	}

	/**
	 * �d�߭q����v����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param orderID
	 *            �q��s��
	 * @param userID
	 *            �B�z�H��
	 * @return ArrayList<Order>
	 * @throws Exception
	 */
	public ArrayList<Order> getOrderHistory(String systemID, String flowID, String orderID, String userID) throws Exception {
		ArrayList<Order> orderList = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from EsunBPM.dbo.tbOrderHistory " + "where SystemID = ? and FlowID = ? and";

		if (orderID != null) {
			sql += " OrderID = ? and";
		}
		if (userID != null) {
			sql += " (ApplyUser = ? or PreUser = ? or NextUser = ?  ) and";
		}
		sql = sql.substring(0, sql.length() - 3);

		sql += " order by sn desc";

		try {
			orderList = new ArrayList<Order>();

			int idx = 1;
			ps = conn.prepareStatement(sql);
			ps.setString(idx++, systemID);
			ps.setString(idx++, flowID);

			if (orderID != null) {
				ps.setString(idx++, orderID);
			}
			if (userID != null) {
				ps.setString(idx++, userID);
				ps.setString(idx++, userID);
				ps.setString(idx++, userID);
			}

			rs = ps.executeQuery();

			Order order = null;
			while (rs.next()) {
				order = new Order();
				order.setSystemID(rs.getString("SystemID"));
				order.setFlowID(rs.getString("FlowID"));
				order.setOrderID(rs.getString("OrderID"));
				order.setFlowPhase(rs.getInt("FlowPhase"));
				order.setApplyUser(rs.getString("ApplyUser"));
				order.setPreUser(rs.getString("PreUser"));
				order.setNextUser(rs.getString("NextUser"));
				order.setModifyUser(rs.getString("ModifyUser"));
				order.setModifyDatetime(rs.getTimestamp("ModifyDatetime"));
				order.setMemo(rs.getString("Memo"));
				order.setMaillink(rs.getString("maillink"));
				order.setProcessUser(strToList(rs.getString("ProcessUser")));

				orderList.add(order);
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return orderList;
	}

	/**
	 * ���o�q���ơA�ϥιw�]���(OrderID) join tableName�PtbOrder
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N�X
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @return ArrayList<HashMap<String, Object>>
	 * 
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getOrderList(String systemID, String flowID, String tableName) throws Exception {
		return getOrderList(systemID, flowID, tableName, defaultColumn, false, null, null);
	}

	public class OrderListDetail {
		Order ord;
		HashMap<String, Object> other_columns;
	}

	public ArrayList<OrderListDetail> getOrderListDetail(String systemID, String flowID, String tableName, String condiColumn) throws Exception {

		ArrayList<OrderListDetail> orderList = new ArrayList<OrderListDetail>();
		ArrayList<HashMap<String, Object>> other = null;
		other = getOrderList(systemID, flowID, tableName, condiColumn, true, null, null);

		for (int i = 0; i < other.size(); i++) {

			for (Entry<String, Object> params : other.get(i).entrySet()) {

				if (params.getKey().startsWith("ord_SystemID")) {
					orderList.get(i).ord.setSystemID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_FlowID")) {
					orderList.get(i).ord.setFlowID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_OrderID")) {
					orderList.get(i).ord.setOrderID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_FlowPhase")) {
					orderList.get(i).ord.setFlowPhase((Integer) params.getValue());
				}
				if (params.getKey().startsWith("ord_ApplyUser")) {
					orderList.get(i).ord.setApplyUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_PreUser")) {
					orderList.get(i).ord.setPreUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_NextUser")) {
					orderList.get(i).ord.setNextUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ModifyUser")) {
					orderList.get(i).ord.setModifyUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ModifyDatetime")) {
					orderList.get(i).ord.setModifyDatetime((Timestamp) params.getValue());
				}
				if (params.getKey().startsWith("ord_Memo")) {
					orderList.get(i).ord.setMemo((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_Maillink")) {
					orderList.get(i).ord.setMaillink((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ProcessUser")) {
					ArrayList<String> tmp = new ArrayList<String>();
					tmp.add((String) params.getValue());
					orderList.get(i).ord.setProcessUser(tmp);
				}

				if (!params.getKey().startsWith("ord_")) {
					orderList.get(i).other_columns.put(params.getKey(), params.getValue());

				}
			}
		}
		return orderList;
	}

	public ArrayList<OrderListDetail> getOrderListDetail(String systemID, String flowID, String tableName, String condiColumn, String orderby, String order) throws Exception {

		ArrayList<OrderListDetail> orderList = new ArrayList<OrderListDetail>();
		ArrayList<HashMap<String, Object>> other = null;
		other = getOrderList(systemID, flowID, tableName, condiColumn, true, orderby, order);
		for (int i = 0; i < other.size(); i++) {

			for (Entry<String, Object> params : other.get(i).entrySet()) {

				if (params.getKey().startsWith("ord_SystemID")) {
					orderList.get(i).ord.setSystemID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_FlowID")) {
					orderList.get(i).ord.setFlowID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_OrderID")) {
					orderList.get(i).ord.setOrderID((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_FlowPhase")) {
					orderList.get(i).ord.setFlowPhase((Integer) params.getValue());
				}
				if (params.getKey().startsWith("ord_ApplyUser")) {
					orderList.get(i).ord.setApplyUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_PreUser")) {
					orderList.get(i).ord.setPreUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_NextUser")) {
					orderList.get(i).ord.setNextUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ModifyUser")) {
					orderList.get(i).ord.setModifyUser((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ModifyDatetime")) {
					orderList.get(i).ord.setModifyDatetime((Timestamp) params.getValue());
				}
				if (params.getKey().startsWith("ord_Memo")) {
					orderList.get(i).ord.setMemo((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_Maillink")) {
					orderList.get(i).ord.setMaillink((String) params.getValue());
				}
				if (params.getKey().startsWith("ord_ProcessUser")) {
					ArrayList<String> tmp = new ArrayList<String>();
					tmp.add((String) params.getValue());
					orderList.get(i).ord.setProcessUser(tmp);
				}

				if (!params.getKey().startsWith("ord_")) {
					orderList.get(i).other_columns.put(params.getKey(), params.getValue());

				}
			}
		}
		return orderList;
	}

	/**
	 * ���o�q���ơA�ϥ�condiColumn join tableName�PtbOrder(���ϥαƧ�)
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N�X
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @return ArrayList<HashMap<String, Object>><br>
	 *         Return ArrayList of OrderNo, each Order raw in HashMap<String,
	 *         Object>. The HashMap key is column name, value is column value.
	 * 
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getOrderList(String systemID, String flowID, String tableName, String condiColumn) throws Exception {
		return getOrderList(systemID, flowID, tableName, condiColumn, false, null, null);
	}

	/**
	 * ���o�q���ơA�ϥ�condiColumn join tableName�PtbOrder(�ϥαƧǡA�w�]ASC)
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N�X
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @param orderby
	 *            �Ƨ����A�е��������W�١A�Ҧp[common].[dbo].[tbUserInfo].[USRID]
	 * @return ArrayList<HashMap<String, Object>><br>
	 *         Return ArrayList of OrderNo, each Order raw in HashMap<String,
	 *         Object>. The HashMap key is column name, value is column value.
	 * 
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getOrderList(String systemID, String flowID, String tableName, String condiColumn, String orderby) throws Exception {
		return getOrderList(systemID, flowID, tableName, condiColumn, false, orderby, null);
	}

	public final static String orderASC = "ASC";

	public final static String orderDESC = "DESC";

	/**
	 * ���o�q���ơA�ϥ�condiColumn join tableName�PtbOrder(�ϥαƧǡA�æۦ���worderASC/orderDESC)
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N�X
	 * @param tableName
	 *            �X�ָ�ƪ�(�U�t��Table�W��)
	 * @param condiColumn
	 *            �X�ֱ������
	 * @param orderby
	 *            �Ƨ����A�е��������W�١A�Ҧp[common].[dbo].[tbUserInfo].[USRID]
	 * @param order
	 *            �ƧǤ覡�A�Ы��wASC��DESC
	 * @return ArrayList<HashMap<String, Object>><br>
	 *         Return ArrayList of OrderNo, each Order raw in HashMap<String,
	 *         Object>. The HashMap key is column name, value is column value.
	 * 
	 * @throws Exception
	 */
	public ArrayList<HashMap<String, Object>> getOrderList(String systemID, String flowID, String tableName, String condiColumn, String orderby, String order) throws Exception {
		return getOrderList(systemID, flowID, tableName, condiColumn, false, orderby, order);
	}

	private ArrayList<HashMap<String, Object>> getOrderList(String systemID, String flowID, String tableName, String condiColumn, boolean isPrefix, String orderby, String order) throws Exception {
		// format "[DataBase].[dbo].[TableName]" to "TableName"
		String tableNameTemp = tableName;
		if (tableNameTemp != null) {
			if (tableNameTemp.indexOf(".") >= 0) {
				tableNameTemp = tableNameTemp.substring(tableName.lastIndexOf(".") + 1);
			}
			if (tableNameTemp.indexOf("[") >= 0) {
				tableNameTemp = tableNameTemp.substring(tableNameTemp.lastIndexOf("[") + 1, tableNameTemp.lastIndexOf("]"));
			}
		}

		ArrayList<HashMap<String, Object>> orderNoList = new ArrayList<HashMap<String, Object>>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = null;

		// ��XtableName���A��ƫ��A����binary�Mvarbinary��column
		String sqlForColumn = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME=? AND DATA_TYPE not in ('binary', 'varbinary')";
		ps = conn.prepareStatement(sqlForColumn);
		ps.setString(1, tableNameTemp);
		rs = ps.executeQuery();
		String columnNames = "";
		while (rs.next()) {
			columnNames = columnNames + ", tb." + rs.getString("COLUMN_NAME");
		}

		if (isPrefix) {
			sql = "select ord.SystemID as ord_SystemID,  ord.FlowID as ord_FlowID, " + "ord.OrderID as ord_OrderID, ord.FlowPhase as ord_FlowPhase, "
					+ "ord.ApplyUser as ord_ApplyUser, ord.PreUser as ord_PreUser, " + "ord.NextUser as ord_NextUser, ord.ModifyUser as ord_ModifyUser, "
					+ "ord.ModifyDatetime as ord_ModifyDatetime, ord.Memo as ord_Memo, " + "ord.Maillink as ord_Maillink, ord.ProcessUser as ord_ProcessUser " + columnNames
					+ " from EsunBPM.dbo.tbOrder ord, " + tableName + " tb where ord.OrderID = tb." + condiColumn + " and";
		} else {
			sql = "select ord.* " + columnNames + " from EsunBPM.dbo.tbOrder ord, " + tableName + " tb where ord.OrderID = tb." + condiColumn + " and";
		}

		if (systemID != null) {
			sql += " ord.SystemID = ? and";
		}
		if (flowID != null) {
			sql += " ord.FlowID = ? and";
		}

		// -----------------------------
		// Order�ȴ���'='����
		// -----------------------------
		// tbOrder ����
		if (orderCondMap != null) {
			Iterator<String> itrKey = orderCondMap.keySet().iterator();
			String key = null;
			while (itrKey.hasNext()) {
				key = itrKey.next();
				if (key.equalsIgnoreCase("$relationUser&")) {
					sql += " (ord.ApplyUser = ? or ord.NextUser = ?) and";
				} else {
					sql += " ord." + key + " = ? and";
				}
			}
		}

		// -----------------------------
		// �H�U���Qjoin table������
		// -----------------------------
		// ����G�۵�
		if (getEqualMap() != null) {
			Iterator<String> itrKey = getEqualMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " = ? and";
			}
		}

		// ����G�j��
		if (getGreaterMap() != null) {
			Iterator<String> itrKey = getGreaterMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " > ? and";
			}
		}

		// ����G�j�󵥩�
		if (getGreaterEQMap() != null) {
			Iterator<String> itrKey = getGreaterEQMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " >= ? and";
			}
		}

		// ����G�p��
		if (getLessMap() != null) {
			Iterator<String> itrKey = getLessMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " < ? and";
			}
		}

		// ����G�p�󵥩�
		if (getLessEQMap() != null) {
			Iterator<String> itrKey = getLessEQMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " <= ? and";
			}
		}

		// ����G�ۦ�
		if (getLikeMap() != null) {
			Iterator<String> itrKey = getLikeMap().keySet().iterator();
			while (itrKey.hasNext()) {
				sql += " tb." + itrKey.next() + " like ? and";
			}
		}
		sql = sql.substring(0, sql.length() - 3);

		if (orderby != null && !orderby.equals("")) {
			sql += "order by " + orderby;
			if (order != null && !order.equals("")) {
				sql += " " + order;

			}
		}

		try {
			int idx = 1;
			ps = conn.prepareStatement(sql);

			if (systemID != null) {
				ps.setString(idx++, systemID);
			}
			if (flowID != null) {
				ps.setString(idx++, flowID);
			}

			// tbOrder ����
			if (orderCondMap != null) {
				Iterator<Map.Entry<String, Object>> itrValue = orderCondMap.entrySet().iterator();
				Map.Entry<String, Object> entry = null;
				while (itrValue.hasNext()) {
					entry = itrValue.next();
					if (entry.getValue() instanceof Integer) {
						ps.setInt(idx++, (Integer) entry.getValue());
					} else if (entry.getValue() instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) entry.getValue());
					} else {
						ps.setString(idx++, (String) entry.getValue());
						if (entry.getKey().equals("$relationUser&")) {
							ps.setString(idx++, (String) entry.getValue());
						}
					}
				}
			}

			// ����G�۵�
			if (getEqualMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getEqualMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, (String) value);
					}
				}
			}

			// ����G�j��
			if (getGreaterMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getGreaterMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, (String) value);
					}
				}
			}

			// ����G�j�󵥩�
			if (getGreaterEQMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getGreaterEQMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, (String) value);
					}
				}
			}

			// ����G�p��
			if (getLessMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getLessMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, (String) value);
					}
				}
			}

			// ����G�p�󵥩�
			if (getLessEQMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getLessEQMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, (String) value);
					}
				}
			}

			// ����G�ۦ�
			if (getLikeMap() != null) {
				@SuppressWarnings("rawtypes")
				Iterator itrValue = getLikeMap().values().iterator();
				Object value = null;
				while (itrValue.hasNext()) {
					value = itrValue.next();
					if (value instanceof Integer) {
						ps.setInt(idx++, (Integer) value);
					} else if (value instanceof Timestamp) {
						ps.setTimestamp(idx++, (Timestamp) value);
					} else {
						ps.setString(idx++, '%' + (String) value + '%');
					}
				}
			}

			rs = ps.executeQuery();
			rsmd = rs.getMetaData();

			HashMap<String, Object> columnMap = null;
			while (rs.next()) {
				columnMap = new HashMap<String, Object>();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {

					// �P�_���榡
					if (java.sql.Types.TIMESTAMP == rsmd.getColumnType(i)) {
						columnMap.put(rsmd.getColumnName(i).toUpperCase(), rs.getTimestamp(rsmd.getColumnName(i)));
					} else if (java.sql.Types.INTEGER == rsmd.getColumnType(i)) {
						columnMap.put(rsmd.getColumnName(i).toUpperCase(), rs.getInt(rsmd.getColumnName(i)));
					} else {
						columnMap.put(rsmd.getColumnName(i).toUpperCase(), rs.getString(rsmd.getColumnName(i)));
					}
				}
				orderNoList.add(columnMap);
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return orderNoList;
	}

	/**
	 * �U�@�hFlowPhase(�f��/���)
	 */
	public static final String Action_Approve = "A";

	/**
	 * �W�@�hFlowPhase(�h�^)
	 */
	public static final String Action_Reject = "R";

	/**
	 * �P�@�hFlowPhase(����)
	 */
	public static final String Action_Transfer = "T";

	/**
	 * ���o�ϥΪ̦W��G�֭�W��B�h�^�W��B����W��<br>
	 * 
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N��
	 * @param flowPhase
	 *            �y�{���q
	 * @return HashMap<String, ArrayList<String>> <br>
	 *         Key = �֭�,�h�^,����<br>
	 *         Value = ArrayList of UserID
	 * 
	 * @throws Exception
	 */
	public HashMap<String, ArrayList<String>> getUserMap(String systemID, String flowID, int flowPhase) throws Exception {
		HashMap<String, ArrayList<String>> userMap = new HashMap<String, ArrayList<String>>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select ug.GroupID, ug.UserID, " + "case when dtl.FlowPhase = ? then '" + Action_Transfer + "' " + "when dtl.FlowPhase = ? then '" + Action_Reject + "' "
				+ "when dtl.FlowPhase = ? then '" + Action_Approve + "' else '' end 'Action' " + "from EsunBPM.dbo.tbFlowDtl dtl,  EsunBPM.dbo.tbUserGroup ug "
				+ "where dtl.SystemID = ug.SystemID and dtl.GroupID = ug.GroupID and dtl.SystemID = ? and dtl.FlowID = ? " + "and dtl.FlowPhase in (?, ?, ?) order by ug.GroupID ";

		int flowPhasePre = flowPhase - 1;
		int flowPhaseNext = flowPhase + 1;

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, flowPhase);
			ps.setInt(2, flowPhasePre);
			ps.setInt(3, flowPhaseNext);
			ps.setString(4, systemID);
			ps.setString(5, flowID);
			ps.setInt(6, flowPhase);
			ps.setInt(7, flowPhasePre);
			ps.setInt(8, flowPhaseNext);
			rs = ps.executeQuery();

			ArrayList<String> parUserIDList = new ArrayList<String>();
			ArrayList<String> preUserIDList = new ArrayList<String>();
			ArrayList<String> nextUserIDList = new ArrayList<String>();
			while (rs.next()) {
				if (rs.getString("Action").equals(Action_Transfer)) {					
					parUserIDList.add(rs.getString("UserID"));
				} else if (rs.getString("Action").equals(Action_Reject)) {					
					preUserIDList.add(rs.getString("UserID"));
				} else if (rs.getString("Action").equals(Action_Approve)) {
					nextUserIDList.add(rs.getString("UserID"));
				}
			}
			userMap.put(Action_Transfer, parUserIDList);
			userMap.put(Action_Reject, preUserIDList);
			userMap.put(Action_Approve, nextUserIDList);
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return userMap;
	}

	public Order getOrder(String systemID, String flowID, String orderID) throws Exception {
		Order order = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement("select * " + "from EsunBPM.dbo.tbOrder " + "where SystemID = ? and FlowID = ? and OrderID = ? ");
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			ps.setString(3, orderID);
			rs = ps.executeQuery();

			if (rs.next()) {
				order = new Order();
				order.setSystemID(rs.getString("SystemID"));
				order.setFlowID(rs.getString("FlowID"));
				order.setOrderID(rs.getString("OrderID"));
				order.setFlowPhase(rs.getInt("FlowPhase"));
				order.setApplyUser(rs.getString("ApplyUser"));
				order.setPreUser(rs.getString("PreUser"));
				order.setNextUser(rs.getString("NextUser"));
				order.setModifyUser(rs.getString("ModifyUser"));
				order.setModifyDatetime(rs.getTimestamp("ModifyDatetime"));
				order.setMemo(rs.getString("Memo"));
				order.setMaillink(rs.getString("Maillink"));
				order.setProcessUser(strToList(rs.getString("ProcessUser")));
				order.setMailRslt(rs.getString("MailRslt"));
			}
		} finally {
			try {
				ps.close();
			} catch (Exception ex) {
			}
			try {
				rs.close();
			} catch (Exception ex) {
			}
		}
		return order;
	}

	private ArrayList<String> strToList(String str) {
		if (str == null) {
			return null;
		}

		ArrayList<String> rslt = new ArrayList<String>();
		String[] data = str.split(",");
		for (int i = 0; i < data.length; i++) {
			rslt.add(data[i]);
		}
		return rslt;
	}

	/**
	 * @author ESB16510
	 * @param order
	 * @return ����O�_���ۦP�ϥΪ̱H�H���B�z��
	 * @throws Exception
	 */
	private boolean isMailToday(Order order) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		String today = DateUtil.getNowDate();
		String startTime = today.substring(0, 4) + "-" + today.substring(4, 6) + "-" + today.substring(6, 8) + " 00:00:00";
		String endTime = today.substring(0, 4) + "-" + today.substring(4, 6) + "-" + today.substring(6, 8) + " 23:59:59";
		String sql = "select count(*) as count FROM [EsunBPM].[dbo].[tbOrderHistory] " + "where SystemID = ? and FlowID = ? and PreUser = ? and NextUser = ? " + "and ModifyDatetime between ? and ?";
		ps = conn.prepareStatement(sql);
		ps.setString(1, order.getSystemID());
		ps.setString(2, order.getFlowID());
		ps.setString(3, order.getPreUser());
		ps.setString(4, order.getNextUser());
		ps.setString(5, startTime);
		ps.setString(6, endTime);
		rs = ps.executeQuery();
		while (rs.next()) {
			count = rs.getInt("count");
		}
		return count > 0;
	}

	private String info(Order order) {

		// ���P���q�椣�αH�H�q��
		if (order.getFlowPhase() == BPMUtil.cancleOrder) {
			return "���ݳq���G���P";
		}

		Order orgOrder = null;
		try {
			orgOrder = getOrder(order.getSystemID(), order.getFlowID(), order.getOrderID());
		} catch (Exception ex) {
			String exception = StringUtil.getStackTraceASString(ex);
			if (exception.getBytes().length > 480) {
				exception = new String(exception.getBytes(), 0, 480);
			}
			return "EXCEPTION-1�G" + exception;
		}

		// �ݳB�z�H���ܤ~�B�z
		if (orgOrder != null && order.getNextUser() != null && order.getNextUser().equals(orgOrder.getNextUser())) {
			return "���ݳq���G�ݳB�z�H������";
		}

		// ���׹w�]�n�q��
		boolean isNotice = false;
		String subject = "�i�y�{���ިt�γq���j";
		String systemName = null;
		String[] exNotice = null; // �ΨӦs����l�n�B�~�q�����Ҧ��H����mail

		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = "select tbFlowCtl.SystemName, tbFlowDtl.exNotice, " + "tbFlowDtl.isNotice " + "from EsunBPM.dbo.tbFlowCtl inner join EsunBPM.dbo.tbFlowDtl "
				+ "on tbFlowCtl.SystemID = tbFlowDtl.SystemID and " + "tbFlowCtl.FlowID = tbFlowDtl.FlowID " + "where tbFlowCtl.SystemID = ? and tbFlowCtl.FlowID = ? and "
				+ "tbFlowDtl.FlowPhase = (case when " + closeOrder + " = ?   then 0 else ? end)";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, order.getSystemID());
			ps.setString(2, order.getFlowID());
			ps.setInt(3, order.getFlowPhase());
			ps.setInt(4, order.getFlowPhase());
			rs = ps.executeQuery();

			if (rs.next()) {
				isNotice = (rs.getString("isNotice") != null && rs.getString("isNotice").equals("Y"));
				systemName = rs.getString("SystemName");
				exNotice = (rs.getString("exNotice") == null || rs.getString("exNotice").trim().equals("")) ? null : rs.getString("exNotice").split(",");
			}
		} catch (Exception ex) {
			String exception = StringUtil.getStackTraceASString(ex);
			if (exception.getBytes().length > 480) {
				exception = new String(exception.getBytes(), 0, 480);
			}
			return "EXCEPTION-2�G" + exception;
		} finally {
			try {
				ps.close();
			} catch (Exception ex) {
			}
			try {
				rs.close();
			} catch (Exception ex) {
			}
		}

		// �����q��
		if (!isNotice) {
			return "���ݳq���G�]�w���ݳq��";
		}
		try {
			MailUtil mailUtil = new MailUtil();
			mailUtil.setPrivate();// �]�w�����\��H
			String[] mailTo = null;
			String sendMail = null;
			String content = "�˷R���D�ަP���z�n�A<br><br>" + systemName + "��";
			CommonUtil cu = new CommonUtil();

			CommonUser user = null;
			if (order.getFlowPhase() == BPMUtil.closeOrder) {// ���ױH���ӽФH
				user = cu.getCommonUser(order.getApplyUser());
				content += "����";
				if (order.getMaillink() != null && !order.getMaillink().trim().equals("")) {
					content += "<a href = \"" + new SSOUtil().getVerifyMailLink(order.getMaillink()) + "\">[�q��]</a>";
				} else {
					content += "�q���C";
				}
			} else {
				user = cu.getCommonUser(order.getNextUser());
				content += "�ݳB�z";
				if (order.getMaillink() != null && !order.getMaillink().trim().equals("")) {
					content += "<a href = \"" + new SSOUtil().getVerifyMailLink(order.getMaillink()) + "\">[�q��]</a>";
				} else {
					content += "�q��";
				}
			}
			sendMail = ((user == null || user.getEMAIL() == null || user.getEMAIL().trim().equals("")) ? null : user.getEMAIL().trim());

			if (sendMail != null) {
				mailTo = new String[] { sendMail };
			}

			String[] exNoticeTo = null;
			if (exNotice != null) {
				exNoticeTo = new String[exNotice.length];
				for (int i = 0; i < exNotice.length; i++) {
					exNoticeTo[i] = cu.getCommonUser(exNotice[i]).getEMAIL();
				}
			}

			return "[" + sendMail + "]" + mailUtil.sendMail(mailTo, exNoticeTo, null, null, subject.concat(systemName), content, null);

		} catch (Exception ex) {
			String exception = StringUtil.getStackTraceASString(ex);
			if (exception.getBytes().length > 480) {
				exception = new String(exception.getBytes(), 0, 480);
			}
			return "EXCEPTION-3�G" + exception;
		}
	}

	/**
	 * �q�檬�A���ʡG���סB�P�סB�֭�B�h�^
	 * 
	 * @author ESB16510
	 * @param order
	 * @param isLessMail
	 *            (�P�@�ѡB�P�t�ΦP�U�@�ӨϥΪ̬O�_���Ƴq��)
	 * @return boolean
	 * @throws Exception
	 */
	private boolean updOrder(Order order, boolean isLessMail) throws Exception {
		// �P�_�O�_�q��
		if (!isLessMail || !isMailToday(order)) {
			order.setMailRslt(info(order));
		} else {
			order.setMailRslt("���ݳq��");
		}

		boolean rsStatus = false;
		PreparedStatement ps = null;

		// �Y�Ȭ�null�h�����ʭ������
		String sql = "update EsunBPM.dbo.tbOrder " + "set " + "FlowPhase = (CASE WHEN ? = -1 THEN FlowPhase ELSE ? END), " + "PreUser = (CASE WHEN ? is NULL THEN PreUser ELSE ? END), "
				+ "NextUser = (CASE WHEN ? is NULL THEN NextUser ELSE ? END), " + "ModifyUser = (CASE WHEN ? is NULL THEN ModifyUser ELSE ? END), "
				+ "ModifyDatetime = (CASE WHEN ? is NULL THEN ModifyDatetime ELSE ? END), " + "Memo = (CASE WHEN ? is NULL THEN Memo ELSE ? END), "
				+ "Maillink = (CASE WHEN ? is NULL THEN Maillink ELSE ? END), " + "ProcessUser = (CASE WHEN ProcessUser like ? THEN ProcessUser ELSE ProcessUser + ? END), " + "MailRslt = ? "
				+ "where SystemID = ? and FlowID = ? and OrderID = ? ";
		try {
			int idx = 1;
			ps = conn.prepareStatement(sql);
			ps.setInt(idx++, order.getFlowPhase());
			ps.setInt(idx++, order.getFlowPhase());
			ps.setString(idx++, order.getPreUser());
			ps.setString(idx++, order.getPreUser());
			ps.setString(idx++, order.getNextUser());
			ps.setString(idx++, order.getNextUser());
			ps.setString(idx++, order.getModifyUser());
			ps.setString(idx++, order.getModifyUser());
			ps.setTimestamp(idx++, order.getModifyDatetime());
			ps.setTimestamp(idx++, order.getModifyDatetime());
			ps.setString(idx++, order.getMemo());
			ps.setString(idx++, order.getMemo());
			ps.setString(idx++, order.getMaillink());
			ps.setString(idx++, order.getMaillink());
			ps.setString(idx++, '%' + order.getPreUser());
			ps.setString(idx++, "," + order.getPreUser());
			ps.setString(idx++, order.getMailRslt());
			ps.setString(idx++, order.getSystemID());
			ps.setString(idx++, order.getFlowID());
			ps.setString(idx++, order.getOrderID());

			rsStatus = ps.executeUpdate() == 1;
		} finally {
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return rsStatus;
	}

	/**
	 * �s�W�q����
	 * 
	 * @author ESB13264
	 * @param order
	 * @return boolean
	 * @throws Exception
	 */
	private boolean addOrder(Order order, boolean isHistory) throws Exception {
		// �P�_�O�_�q��
		if (!isHistory) {
			order.setMailRslt(info(order));
		}

		boolean rsStatus = false;
		PreparedStatement ps = null;

		String sql = "insert into EsunBPM.dbo." + (isHistory ? "tbOrderHistory" : "tbOrder") + "(SystemID, FlowID, OrderID, "
				+ "ApplyUser, FlowPhase, PreUser, NextUser, ModifyUser, ModifyDatetime, Memo, Maillink, ProcessUser, MailRslt) " + "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, order.getSystemID());
			ps.setString(2, order.getFlowID());
			ps.setString(3, order.getOrderID());
			ps.setString(4, order.getApplyUser());
			ps.setInt(5, order.getFlowPhase());
			ps.setString(6, order.getPreUser());
			ps.setString(7, order.getNextUser());
			ps.setString(8, order.getModifyUser());
			ps.setTimestamp(9, order.getModifyDatetime());
			ps.setString(10, order.getMemo());
			ps.setString(11, order.getMaillink());

			if (isHistory == false) {// NEW ADD
				ps.setString(12, order.getPreUser());
			} else {
				ps.setString(12, "");
			}

			ps.setString(13, order.getMailRslt());

			rsStatus = ps.executeUpdate() == 1;

		} finally {
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return rsStatus;
	}

	/**
	 * �s�W��ơG�q���ơB�q����v���
	 * 
	 * @author ESB13264
	 * @param order
	 * @return boolean
	 * @throws Exception
	 */
	public boolean addOrderData(Order order) throws Exception {
		boolean rslt = false;
		boolean orgCommit = conn.getAutoCommit();

		try {
			if (order.getApplyUser() == null || order.getApplyUser().equals("") || order.getNextUser() == null || order.getNextUser().equals("") || order.getModifyUser() == null
					|| order.getModifyUser().equals("")) {
				throw new Exception("�ӽФH �A�̫�ק�H�M�ǰe�H���o����");
			}
			if (orgCommit) {
				conn.setAutoCommit(false);
			}
			rslt = addOrder(order, false) && addOrder(order, true);
			if (orgCommit) {
				conn.commit();
			}
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(orgCommit);
		}
		return rslt;
	}

	/**
	 * �q�檬�A���ʡB�s�W�q����v���
	 * 
	 * @author ESB13264
	 * @param order
	 * @return boolean
	 * @throws Exception
	 */
	public boolean updOrderData(Order order) throws Exception {

		boolean rslt = false;
		boolean orgCommit = conn.getAutoCommit();
		try {
			if (order.getFlowPhase() != 0 && order.getFlowPhase() != 99 && order.getFlowPhase() != -99) {
				if (order.getApplyUser() == null || order.getApplyUser().equals("") || order.getNextUser() == null || order.getNextUser().equals("")) {
					throw new Exception("�̫�ק�H�M�ǰe�H���o����");
				}
			} else {
				if (order.getApplyUser() == null || order.getApplyUser().equals("")) {
					throw new Exception("�̫�ק�H�M�ǰe�H���o����");
				}
			}
			if (orgCommit) {
				conn.setAutoCommit(false);
			}
			rslt = updOrder(order, false) && addOrder(order, true);
			if (orgCommit) {
				conn.commit();
			}
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(orgCommit);
		}
		return rslt;
	}

	/**
	 * @author ESB16510�s�W �q��B�s�W�q����v���
	 * @return �s�W�q��
	 */
	public boolean addOrder(String systemID, String flowID, String orderID, int flowPhase, String applyUser, String preUser, String nextUser, String modifyUser, Timestamp modifyDatetime, String memo,
			String mailLink) throws Exception {
		Order order = new Order();
		order.setSystemID(systemID);
		order.setFlowID(flowID);
		order.setOrderID(orderID);
		order.setFlowPhase(flowPhase);
		order.setApplyUser(applyUser);
		order.setPreUser(preUser);
		order.setNextUser(nextUser);
		order.setModifyUser(modifyUser);
		order.setModifyDatetime(modifyDatetime);
		order.setMemo(memo);
		order.setMailLink(mailLink);
		return addOrderData(order);
	}

	/**
	 * @author ESB16510 �q�檬�A���ʡB�s�W�q����v���
	 * @param isLessNotice
	 *            �Өt�θӬy�{�ۦP��H�C�ѬO�_�u�H�@�ʫH
	 * @return ��s�q��(���U�@�h)
	 * 
	 *         19507 �W�[ �i�H�I���ۤv�� flag
	 */

	public boolean approveOrder(String systemID, String flowID, String orderID, String nextUser, String memo, String mailLink, boolean isLessNotice) throws Exception {
		return updOrderData(Action_Approve, systemID, flowID, orderID, nextUser, memo, mailLink, isLessNotice, false);
	}

	public boolean approveOrder(String systemID, String flowID, String orderID, String nextUser, String memo, String mailLink, boolean isLessNotice, boolean canClick) throws Exception {
		return updOrderData(Action_Approve, systemID, flowID, orderID, nextUser, memo, mailLink, isLessNotice, canClick);
	}

	/**
	 * @author ESB16510 �q�檬�A���ʡB�s�W�q����v���
	 * @param systemID,flowID,orderID
	 *            = �D��
	 * @param memo,mailLink
	 * @return ��s�q��(���e�@�h)
	 * 
	 *         19507 �W�[ �i�H�I���ۤv�� flag
	 */
	public boolean rejectOrder(String systemID, String flowID, String orderID, String memo, String mailLink) throws Exception {
		return rejectOrder(systemID, flowID, orderID, memo, mailLink, false);
	}

	public boolean rejectOrder(String systemID, String flowID, String orderID, String memo, String mailLink, boolean canClick) throws Exception {

		Order order = null;
		order = getOrder(systemID, flowID, orderID);
		int flowphase = order.getFlowPhase();
		if (order == null || flowphase == closeOrder // �P�_��order�ण��h
				|| flowphase == cancleOrder || flowphase == 0) {
			return false;
		}
		order.setPreUser(order.getNextUser()); // ������B�z��
		order.setModifyUser(order.getNextUser());
		order.setMemo(memo);
		order.setModifyDatetime(new Timestamp(System.currentTimeMillis()));
		order.setMailLink(mailLink == null ? "" : mailLink);
		FlowDtl flow = getFlowDtl(systemID, flowID, order.getFlowPhase());
		if (flow.getIsTop().equals("Y")) {
			order.setNextUser(order.getApplyUser()); // �s�����ӭn�B�z���H=ApplyUser
			order.setFlowPhase(0);
		} else {
			if (order.getFlowPhase() == 1) { // 1�i��borderhistory�䤣��0
				order.setNextUser(order.getApplyUser());
			} else {
				order.setNextUser(getPreUser(systemID, flowID, orderID));
			}
			order.setFlowPhase(flowphase - 1);
		}
		if (order.getNextUser() == null || order.getNextUser().equals("") || order.getModifyUser() == null || order.getModifyUser().equals("")) {
			throw new Exception("�̫�ק�H�M���B�z�H���o����");
		}
		return updOrderData(order, false, canClick);
	}

	/**
	 * @author ESB6510 �q�檬�A���ʡB�s�W�q����v���
	 * @param isLessNotice
	 *            �Өt�θӬy�{�ۦP��H�C�ѬO�_�u�H�@�ʫH
	 * @return ��s�q��(�P�@�h)
	 */
	public boolean transferOrder(String systemID, String flowID, String orderID, String nextUser, String memo, String mailLink) throws Exception {
		if (nextUser == null || nextUser.equals("")) {
			throw new Exception("���B�z�H���o����");
		}
		return updOrderData(Action_Transfer, systemID, flowID, orderID, nextUser, memo, mailLink, false);
	}

	/**
	 * @author ESB16510 �q�檬�A���ʡB�s�W�q����v���
	 * @param systemID,flowID,orderID
	 *            = �D��
	 * @param memo
	 *            = ���׻���
	 * @return �q�浲��
	 */
	public boolean closeOrder(String systemID, String flowID, String orderID, String memo) throws Exception {
		Order order = null;
		order = getOrder(systemID, flowID, orderID);
		if (order == null || order.getFlowPhase() != getFlowNo(systemID, flowID) - 1) { // �����٨S�쵲��
			return false;
		}
		order.setPreUser(order.getNextUser()); // ������B�z��
		order.setModifyUser(order.getNextUser());
		order.setMemo(memo);
		order.setModifyDatetime(new Timestamp(System.currentTimeMillis()));
		order.setMailLink("");
		return closeOrder(order);
	}

	/**
	 * @author ESB16510 �q�檬�A���ʡB�s�W�q����v���
	 * @param systemID,flowID,orderID
	 *            = �D��
	 * @param memo
	 *            = �P�׻���
	 * @return �q��P��
	 */
	public boolean cancelOrder(String systemID, String flowID, String orderID, String memo) throws Exception {
		Order order = null;
		order = getOrder(systemID, flowID, orderID);
		if (order == null) {
			return false;
		}
		order.setPreUser(order.getNextUser()); // ������B�z��
		order.setModifyUser(order.getNextUser());
		order.setMemo(memo);
		order.setModifyDatetime(new Timestamp(System.currentTimeMillis()));
		order.setMailLink("");
		return cancleOrder(order);
	}

	/*
	 * @author ESB19507 �s�W�B�z�H���ܬO�_�I���ۤv
	 * 
	 * @param canClick ��_�I���ۤv true:�i�H /false:����
	 */
	public boolean updOrderData(String action, String systemID, String flowID, String orderID, String nextUser, String memo, String mailLink, boolean isLessNotice) throws Exception {
		return updOrderData(action, systemID, flowID, orderID, nextUser, memo, mailLink, isLessNotice, false);
	}

	public boolean updOrderData(Order order, boolean isLessMail) throws Exception {
		return updOrderData(order, isLessMail, false);
	}

	/**
	 * @author ESB16510 �q�檬�A���ʡB�s�W�q����v���
	 * @param action
	 *            = Action_Approve, Action_Transfer
	 * @param isLessNotice
	 *            �Өt�θӬy�{�ۦP��H�C�ѬO�_�u�H�@�ʫH
	 * 
	 */
	public boolean updOrderData(String action, String systemID, String flowID, String orderID, String nextUser, String memo, String mailLink, boolean isLessNotice, boolean canClick) throws Exception {

		boolean rslt = false;
		Order order = getOrder(systemID, flowID, orderID);
		if (order == null) {
			return false;
		}
		// �����\�e���ۤv unless canClicke == true
		if (!canClick && order.getNextUser().toUpperCase().equals(nextUser.toUpperCase())) {
			return false;
		}
		// �ק�H�M�ǰe�H���o����
		if (order.getFlowPhase() != 0 && order.getFlowPhase() != 99 && order.getFlowPhase() != -99) {
			if (order.getApplyUser() == null || order.getApplyUser().equals("") || order.getNextUser() == null || order.getNextUser().equals("")) {
				throw new Exception("�̫�ק�H�M�ǰe�H���o����");
			}
		} else {
			if (order.getApplyUser() == null || order.getApplyUser().equals("")) {
				throw new Exception("�̫�ק�H�M�ǰe�H���o����");
			}
		}

		order.setPreUser(order.getNextUser()); // ������B�z��
		order.setModifyUser(order.getNextUser());
		order.setNextUser(nextUser); // �s�����ӭn�B�z���H
		order.setMemo(memo);
		order.setMailLink(mailLink == null ? "" : mailLink);
		order.setModifyDatetime(new Timestamp(System.currentTimeMillis()));

		if (action.equals(Action_Approve)) {
			order.setFlowPhase(order.getFlowPhase() + 1);
			rslt = updOrderData(order, isLessNotice, canClick);
		} else if (action.equals(Action_Transfer)) {
			rslt = updOrderData(order, isLessNotice, canClick);
		} else {
			return false;
		}
		return rslt;
	}

	/**
	 * �q�檬�A���ʡB�s�W�q����v���
	 * 
	 * @author ESB16510
	 * @param order
	 * @param isLessMail
	 *            (�P�t�ΦP�@��P�ӤU�@�ӨϥΪ̬O�_���Ʀ��H)
	 * @return boolean
	 * @throws Exception
	 */
	public boolean updOrderData(Order order, boolean isLessMail, boolean canClick) throws Exception {

		boolean rslt = false;
		// �����\�e���ۤv unless canClicke == true
		if (!canClick && order.getNextUser().equalsIgnoreCase(order.getPreUser())) {
			return false;
		}
		boolean orgCommit = conn.getAutoCommit();
		try {
			if (order.getFlowPhase() != 0 && order.getFlowPhase() != 99 && order.getFlowPhase() != -99) {
				if (order.getApplyUser() == null || order.getApplyUser().equals("") || order.getNextUser() == null || order.getNextUser().equals("")) {
					throw new Exception("�̫�ק�H�M�ǰe�H���o����");
				}
			}
			if (orgCommit) {
				conn.setAutoCommit(false);
			}
			rslt = updOrder(order, isLessMail) && addOrder(order, true);
			if (orgCommit) {
				conn.commit();
			}
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(orgCommit);
		}
		return rslt;
	}

	/**
	 * �P��
	 */
	public boolean cancleOrder(Order order) throws Exception {
		boolean rslt = false;
		try {
			conn.setAutoCommit(false);
			order.setFlowPhase(BPMUtil.cancleOrder);
			order.setNextUser("");
			rslt = updOrder(order, false) && addOrder(order, true);
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(true);
		}
		return rslt;
	}

	/**
	 * ����
	 */
	public boolean closeOrder(Order order) throws Exception {
		boolean rslt = false;
		try {
			conn.setAutoCommit(false);
			order.setFlowPhase(BPMUtil.closeOrder);
			order.setNextUser("");
			rslt = updOrder(order, false) && addOrder(order, true);
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(true);
		}
		return rslt;
	}

	/**
	 * ���o�ݳB�z�H�����
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param orderID
	 *            �q��s��
	 * @return NextUser �ݳB�z�H��
	 * @throws Exception
	 */
	public String getNextUser(String systemID, String flowID, String orderID) throws Exception {
		String preUser = "";
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select NextUser from EsunBPM.dbo.tbOrder " + "where SystemID = ? and FlowID = ? and OrderID = ? ";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			ps.setString(3, orderID);
			rs = ps.executeQuery();

			if (rs.next()) {
				preUser = rs.getString("NextUser");
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return preUser;
	}

	/**
	 * ���o�ӽФH�����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @param orderID
	 *            �q��s��
	 * @return applyUser �ӽФH��
	 * @throws Exception
	 */
	public String getApplyUser(String systemID, String flowID, String orderID) throws Exception {
		String applyUser = "";
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select ApplyUser from EsunBPM.dbo.tbOrder " + "where SystemID = ? and FlowID = ? and OrderID = ? ";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			ps.setString(3, orderID);
			rs = ps.executeQuery();

			if (rs.next()) {
				applyUser = rs.getString("ApplyUser");
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return applyUser;
	}

	/**
	 * @param systemID,flowID
	 * @return ��flow�`�@�h��
	 */
	public int getFlowNo(String systemID, String flowID) throws Exception {
		int rslt = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT [FlowNo] FROM [EsunBPM].[dbo].[tbFlowCtl] WHERE SystemID = ? and FlowID = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			;
			rs = ps.executeQuery();
			if (rs.next()) {
				rslt = Integer.parseInt(rs.getString("FlowNo"));
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return rslt;
	}

	/**
	 * �b�s��h�^order�ɷ|���䤣��e�e��ϥΪ̪����p�G�ݱqorderHistory��
	 * 
	 * @return �e�@��user
	 */
	public String getPreUser(String systemID, String flowID, String orderID) throws Exception {

		String historyPreUser = "";
		ArrayList<Order> rslt = getOrderHistory(systemID, flowID, orderID);
		if (rslt == null || rslt.size() < 1) { // �P�_history order�Ӽ�
			return null;
		} else if (rslt.size() == 1) {
			return rslt.get(0).getApplyUser();
		}
		Order orderLast = rslt.get(0); // �̫�@��Order
		Order orderPenultimate = rslt.get(1); // �˼ƲĤG��Order
		if (orderLast.getFlowPhase() > orderPenultimate.getFlowPhase()) { // �@���h�^
			historyPreUser = orderLast.getPreUser();
		} else { // ���ܳv�h�h�^
			for (int i = 2; i < rslt.size(); i++) {
				Order order = rslt.get(i);
				if (order.getFlowPhase() == orderLast.getFlowPhase() - 1) {
					historyPreUser = order.getNextUser();// ���e�@���P�hflow�����B�z�H
					break;
				}
			}
		}
		return historyPreUser;
	}

	/**
	 * ���o�y�{�Ӷ����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @return ArrayList<FlowDtl>
	 * @throws Exception
	 */
	public ArrayList<FlowDtl> getFlowDtl(String systemID, String flowID) throws Exception {
		ArrayList<FlowDtl> flowDtlList = new ArrayList<FlowDtl>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from EsunBPM.dbo.tbFlowDtl where SystemID = ? and FlowID = ? ";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			rs = ps.executeQuery();

			FlowDtl flowDtl = null;
			while (rs.next()) {
				flowDtl = new FlowDtl();
				flowDtl.setSystemID(rs.getString("SystemID"));
				flowDtl.setFlowID(rs.getString("FlowID"));
				flowDtl.setFlowPhase(rs.getInt("FlowPhase"));
				flowDtl.setGroupID(rs.getString("GroupID"));
				flowDtl.setIsNotice(rs.getString("isNotice"));
				flowDtl.setExNotice(rs.getString("exNotice"));
				flowDtl.setIsTop(rs.getString("isTop"));
				flowDtl.setMemo(rs.getString("Memo"));
				flowDtl.setOverTimeDay(rs.getInt("OverTimeDay"));
				flowDtlList.add(flowDtl);
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return flowDtlList;
	}

	/**
	 * ���o�y�{�Ӷ����
	 * 
	 * @author ESB13264
	 * 
	 * @param systemID
	 *            �t�ΥN��
	 * @param flowID
	 *            �y�{�N��
	 * @return ArrayList<FlowDtl>
	 * @throws Exception
	 */
	public FlowDtl getFlowDtl(String systemID, String flowID, int FlowPhase) throws Exception {
		FlowDtl flowDtl = null;

		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from EsunBPM.dbo.tbFlowDtl where SystemID = ? and FlowID = ? and FlowPhase = ?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, systemID);
			ps.setString(2, flowID);
			ps.setInt(3, FlowPhase);
			rs = ps.executeQuery();

			if (rs.next()) {
				flowDtl = new FlowDtl();
				flowDtl.setSystemID(rs.getString("SystemID"));
				flowDtl.setFlowID(rs.getString("FlowID"));
				flowDtl.setFlowPhase(rs.getInt("FlowPhase"));
				flowDtl.setGroupID(rs.getString("GroupID"));
				flowDtl.setIsNotice(rs.getString("isNotice"));
				flowDtl.setExNotice(rs.getString("exNotice"));
				flowDtl.setIsTop(rs.getString("isTop"));
				flowDtl.setMemo(rs.getString("Memo"));
				flowDtl.setOverTimeDay(rs.getInt("OverTimeDay"));
				flowDtl.setIsSECT(rs.getString("isSECT"));
			}
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return flowDtl;
	}

	/**
	 * �q�沾��
	 * 
	 * @author ESB13264
	 * @return boolean
	 * @throws Exception
	 */
	private boolean transOrder(String systemID, String flowID, String orderID, String nextUser, String modifyUser, Timestamp modifyDatetime) throws Exception {
		boolean status = false;
		PreparedStatement ps = null;
		String sql = "update EsunBPM.dbo.tbOrder " + "set NextUser = ?,  ModifyUser = ?, ModifyDatetime = ? " + "where SystemID = ? and FlowID = ? and OrderID = ? ";
		if (nextUser == null || nextUser.equals("") || modifyUser == null || modifyUser.equals("")) {
			throw new Exception("�̫�ק�H�M���B�z�H���o����");
		}
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, nextUser);
			ps.setString(2, modifyUser);
			ps.setTimestamp(3, modifyDatetime);
			ps.setString(4, systemID);
			ps.setString(5, flowID);
			ps.setString(6, orderID);
			status = ps.executeUpdate() == 1;

			if (!status) {
				throw new Exception("�q�沾�ॢ��");
			}
		} finally {
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return status;
	}

	/**
	 * �q�沾��B�s�W�q����v���
	 * 
	 * @author ESB13264
	 * @param order
	 * @return boolean
	 * @throws Exception
	 */
	public boolean transOrderData(String systemID, String flowID, String orderID, String nextUser, String modifyUser, Timestamp modifyDatetime) throws Exception {
		boolean rslt = false;
		try {
			if (nextUser == null || nextUser.equals("") || modifyUser == null || modifyUser.equals("")) {
				throw new Exception("�̫�ק�H�M���B�z�H���o����");
			}
			Order order = new Order();
			order.setSystemID(systemID); // �t�ΥN��
			order.setFlowID(flowID); // �y�{�N��
			order.setOrderID(orderID); // �q��s��
			order.setNextUser(nextUser); // ���B�z�H��
			order.setModifyUser(modifyUser); // ���ʤH��
			order.setModifyDatetime(modifyDatetime); // ���ʮɶ�

			conn.setAutoCommit(false);
			rslt = transOrder(systemID, flowID, orderID, nextUser, modifyUser, modifyDatetime) && addOrder(order, true);
			conn.commit();
		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (Exception ex1) {
			}
			throw ex;
		} finally {
			conn.setAutoCommit(true);
		}
		return rslt;

	}

	/**
	 * �d�߱����J
	 * 
	 * @author ESB13264
	 * @param dataType
	 *            ��Ʈ榡�Gjava.sql.Types.TIMESTAMP<BR>
	 *            java.sql.Types.VARCHAR<BR>
	 *            java.sql.Types.Integer
	 * @param colName
	 *            ���W��
	 * @param colValue
	 *            ����
	 * @param actionType
	 *            formatStr, formatInt, formatTime, actionEQ, actionGreaterEQ,
	 *            actionGreater, actionLessEQ, actionLess
	 */
	public void setQryCond(String colName, Object colValue, int actionType) {
		if (actionType == actionEQ) {
			if (colValue instanceof Integer) {
				equalMap.put(colName, (Integer) colValue);
			} else if (colValue instanceof Timestamp) {
				equalMap.put(colName, (Timestamp) colValue);
			} else {
				equalMap.put(colName, (String) colValue);
			}
		} else if (actionType == actionGreater) {
			if (colValue instanceof Integer) {
				greaterMap.put(colName, (Integer) colValue);
			} else if (colValue instanceof Timestamp) {
				greaterMap.put(colName, (Timestamp) colValue);
			} else {
				greaterMap.put(colName, (String) colValue);
			}
		} else if (actionType == actionGreaterEQ) {
			if (colValue instanceof Integer) {
				greaterEQMap.put(colName, (Integer) colValue);
			} else if (colValue instanceof Timestamp) {
				greaterEQMap.put(colName, (Timestamp) colValue);
			} else {
				greaterEQMap.put(colName, (String) colValue);
			}
		} else if (actionType == actionLessEQ) {
			if (colValue instanceof Integer) {
				lessEQMap.put(colName, (Integer) colValue);
			} else if (colValue instanceof Timestamp) {
				lessEQMap.put(colName, (Timestamp) colValue);
			} else {
				lessEQMap.put(colName, (String) colValue);
			}
		} else if (actionType == actionLess) {
			if (colValue instanceof Integer) {
				lessMap.put(colName, (Integer) colValue);
			} else if (colValue instanceof Timestamp) {
				lessMap.put(colName, (Timestamp) colValue);
			} else {
				lessMap.put(colName, (String) colValue);
			}
		} else if (actionType == actionLike) {
			if (colValue instanceof String) {
				likeMap.put(colName, (String) colValue);
			}
		}
	}

	/**
	 * ���󦡡G�۵�
	 * 
	 * @return
	 */
	public HashMap<String, Object> getEqualMap() {
		return equalMap;
	}

	/**
	 * ���󦡡G�j��
	 * 
	 * @return
	 */
	public HashMap<String, Object> getGreaterMap() {
		return greaterMap;
	}

	/**
	 * ���󦡡G�j��B����
	 * 
	 * @return
	 */
	public HashMap<String, Object> getGreaterEQMap() {
		return greaterEQMap;
	}

	/**
	 * ���󦡡G�p��
	 * 
	 * @return
	 */
	public HashMap<String, Object> getLessMap() {
		return lessMap;
	}

	/**
	 * �]�wtb.Order���d�߱���(=)
	 * 
	 * @return
	 */
	public void setTbOrderQryCondition(String colName, Object colValue) {
		orderCondMap.put(colName, colValue);
	}

	/**
	 * ���󦡡Glike
	 * 
	 * @return
	 */
	public HashMap<String, String> getLikeMap() {
		return likeMap;
	}

	/**
	 * ���󦡡G�p��B����
	 * 
	 * @return
	 */
	public HashMap<String, Object> getLessEQMap() {
		return lessEQMap;
	}

	/**
	 * �M���d�߱���
	 * 
	 */
	public void clearCondition() {
		equalMap.clear();
		greaterMap.clear();
		greaterEQMap.clear();
		lessMap.clear();
		lessEQMap.clear();
		orderCondMap.clear();
		likeMap.clear();
	}

	/**
	 * <pre>
	 * &#64;param submitFunction
	 *            = submit������javascript function
	 * &#64;param sessionUserAD
	 *            = �����W��sessionAD�ܼ�
	 * &#64;return �����^�Ǹ��systemID�BflowID�BflowPhase�BapplyUser�BpreUser�BnextUser�B
	 *         modifyUser�Bmemo 
	 *         ����addOrderData�A��J�^�Ǥ���ƨå[�JOrderID�BModifyDatetime�B
	 *         Maillink�A�H�s�WOrder
	 * &#64;throws Exception
	 * </pre>
	 *
	 * 19507 �s�W �O�_�i�H �I���ۤv �� flag
	 */
	public String getBPMAddOrderUtil(String systemID, String flowID, String submitFunction, String sessionUserAD) throws Exception {
		return getBPMAddOrderUtil(systemID, flowID, submitFunction, sessionUserAD, false);
	}

	public String getBPMAddOrderUtil(String systemID, String flowID, String submitFunction, String sessionUserAD, boolean canClick) throws Exception {

		String rslt = "";
		String nextUserMap = getSelectNextUser(systemID, flowID, 0, "onchange='getnextuser()'", sessionUserAD, canClick);
		if (!nextUserMap.equals("")) {
			rslt = "<script>" + "function getnextuser(){" + "if(document.getElementById('nextUser').value =='0'){" + "document.getElementById('setmemo').style.display = 'none';"
					+ "document.getElementById('memoarea').style.display = 'none'; " + "document.getElementById('submitbutton').style.display = 'none';" + "}else{"
					+ "document.getElementById('setmemo').style.display = 'inline';" + "document.getElementById('memoarea').style.display = 'inline'; "
					+ "document.getElementById('submitbutton').style.display = 'inline'; " + "}" + "}" + "</script>" + "<table width='400px' style='border:1px #663300 dashed;' bgcolor='B0DACC'>"
					+ "<tr><td colspan='2' align='right' style='color:#cc3300;font-family:Microsoft JhengHei;font-size:10px'>*�ǩ����ܸӥD��/�P���𰲤�</td></tr>" + "<tr>"
					+ "<td style='font-family:Microsoft JhengHei;'>�п�ܶǰe��H</td>" + "<td style='font-family:Microsoft JhengHei;'>" + nextUserMap + "</td>" + "</tr>" + "<tr>"
					+ "<td align='left' style='font-family:Microsoft JhengHei;'><div id='setmemo' style='display:none'>�п�J����</div></td>"
					+ "<td><div id='memoarea' style='display:none'><textarea id='memo' name='memo' rows='6' cols='30'>�Ш�U�B�z���ݨD�C</textarea></div>" + "</td></tr>" + "<tr>"
					+ "<td colspan='2' align='center'><div id='submitbutton' style='display:none'><input type='button' style='font-size:9pt;border:1px outset;padding-top:3px;padding-bottom:-2px;width:40px;' value='�e�X' onclick='"
					+ submitFunction + "'></div></td>" + "</tr>" + "</table>" + "<input type='hidden' id='systemID' name='systemID' value='" + systemID + "'>"
					+ "<input type='hidden' id='flowID' name='flowID' value='" + flowID + "'>" + "<input type='hidden' id='flowPhase' name='flowPhase' value='1'>"
					+ "<input type='hidden' id='applyUser' name='applyUser' value='" + sessionUserAD + "'>" + "<input type='hidden' id='preUser' name='preUser' value='" + sessionUserAD + "'>"
					+ "<input type='hidden' id='modifyUser' name='modifyUser' value='" + sessionUserAD + "'>";
		}
		return rslt;
	}

	/**
	 * <pre>
	 * &#64;param submitFunction
	 *            = submit������Javascript function
	 * &#64;return �^�Ǹ��actionType�BsystemID�BflowID�BorderID�BnextUser�Bmemo
	 * �P�_
	 * 1.actionType="A" �� approveOrder
	 * 2.actionType="R" �� rejectOrder
	 * 3.actionType="close" �� closeOrder
	 * 4.actionType="cancel" �� cancelOrder
	 * &#64;throws Exception
	 * </pre>
	 * 
	 * 19507 �s�W�O�_�i�H�I���ۤv�� flag
	 */
	public String getBPMUpdOrderUtil(String systemID, String flowID, String orderID, String submitFunction, String sessionUserAD) throws Exception {
		return getBPMUpdOrderUtil(systemID, flowID, orderID, submitFunction, sessionUserAD, false);
	}

	public String getBPMUpdOrderUtil(String systemID, String flowID, String orderID, String submitFunction, String sessionUserAD, boolean canClick) throws Exception {

		String rslt = null;
		String nextUserMap = null;
		Order order = getOrder(systemID, flowID, orderID);
		if (order != null) {
			nextUserMap = getSelectNextUser(systemID, flowID, order.getFlowPhase(), "onchange='choose()'", sessionUserAD, canClick);

			rslt = "<style>" + ".button" + "{" + "font-size: 9pt;border: 1px outset;padding-top: 3px;padding-bottom: -2px;width: 40px;" + "}" + "</style>" + "<script>" + "function cleanDisplay(){"
					+ "var divs = new Array('setmemo','memoarea','setuser','usermap','reject','memo','close','cancel','confirm') ;" + "for(i=0;i<divs.length;i++){"
					+ "document.getElementById(divs[i]).style.display = 'none';" + "}" + "}" + "function showMemo(){" + "document.getElementById('setmemo').style.display = 'inline';"
					+ "document.getElementById('memoarea').style.display = 'inline';" + "document.getElementById('memo').style.display = 'inline';" + "}" + "function getAction(){"
					+ "if(document.getElementById('actionType').value == '0'){" + "cleanDisplay();" + "}" + "if(document.getElementById('actionType').value == 'A'){" + "cleanDisplay();"
					+ "document.getElementById('nextUser').value = '0';" + "document.getElementById('setuser').style.display = 'inline';"
					+ "document.getElementById('usermap').style.display = 'inline';" + "}" + "else if(document.getElementById('actionType').value == 'R'){" + "cleanDisplay();"
					+ "document.getElementById('reject').style.display = 'inline';" + "document.getElementById('memo').value = '���H�h�^�A�Э��s�����C';" + "showMemo();" + "}"
					+ "else if(document.getElementById('actionType').value == 'close'){" + "cleanDisplay();" + "document.getElementById('close').style.display = 'inline';"
					+ "document.getElementById('memo').value = '���H�֭�A���סC';" + "showMemo();" + "}" + "else if(document.getElementById('actionType').value == 'cancel'){" + "cleanDisplay();"
					+ "document.getElementById('cancel').style.display = 'inline';" + "document.getElementById('memo').value = '���H�P�סC';" + "showMemo();" + "}" + "}" + "function choose(){"
					+ "if(document.getElementById('nextUser').value != '0'){" + "document.getElementById('confirm').style.display = 'inline';" + "document.getElementById('memo').value = '�Ш�U�B�z���ݨD�C';"
					+ "showMemo();" + "}else{" + "document.getElementById('setmemo').style.display = 'none';" + "document.getElementById('memoarea').style.display = 'none';"
					+ "document.getElementById('memo').style.display = 'none';" + "document.getElementById('confirm').style.display = 'none';" + "}" + "}" + "</script>";
			rslt += "<table width='400px' style='border:1px #663300 dashed;' bgcolor='B0DACC'>"
					+ "<tr><td colspan='2' align='right' style='color:#cc3300;font-family:Microsoft JhengHei;font-size:10px'>*�ǩ����ܸӥD��/�P���𰲤�</td></tr>" + "<tr>"
					+ "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'>�п�ܰʧ@</td>" + "<td><select id='actionType' name='actionType' onchange='getAction()'>"
					+ "<option value='0'>�п��</option>";
			if (nextUserMap == null) {
				rslt += "<option value='close'>����</option>";
			} else {
				rslt += "<option value='A'>�ǰe</option>";
			}
			if (order.getFlowPhase() != 0) {
				rslt += "<option value='R'>�h�^</option>";
			}
			if (order.getFlowPhase() == 0) {
				rslt += "<option value='cancel'>�P��</option>";
			}
			rslt += "</select></td>" + "</tr>" + "<tr>" + "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'><div id='setuser' style='display:none'>�п�ܶǰe��H</div></td>"
					+ "<td><div id='usermap' style='display:none'>";
			if (nextUserMap != null) {
				rslt += nextUserMap + "</div></td>";
			}
			rslt += "</tr>" + "<tr>" + "<td align='right' style='font-family:Microsoft JhengHei;'><div id='setmemo' style='display:none'>�п�J����</div></td>"
					+ "<td><div id='memoarea' style='display:none'><textarea id='memo' name='memo' rows='6' cols='30'></textarea></div></td>" + "</tr>" + "<tr>" + "<td></td>"
					+ "<td align='left'><div id='reject' style='display:none'><input type='button' class='button' value='�h�^' onclick='" + submitFunction + "'></div></td>" + "</tr>" + "<tr>"
					+ "<td></td>" + "<td align='left'><div id='cancel' style='display:none'><input type='button' class='button' value='�P��' onclick='" + submitFunction + "'></div></td>" + "</tr>"
					+ "<tr>" + "<td></td>" + "<td align='left'><div id='confirm' style='display:none'><input type='button' class='button' value='�e�X' onclick='" + submitFunction + "'></div></td>"
					+ "</tr>" + "<tr>" + "<td></td>" + "<td align='left'><div id='close' style='display:none'><input type='button' class='button' value='����' onclick='" + submitFunction
					+ "'></div></td>" + "</tr></table>" + "<input type='hidden' name='systemID' value='" + systemID + "'>" + "<input type='hidden' id='flowID' name='flowID' value='" + flowID + "'>"
					+ "<input type='hidden' id='orderID' name='orderID' value='" + orderID + "'>";
		}
		return rslt;
	}

	/**
	 * @param scriptName
	 *            = ���nextuser�W��ɭn�]��javasrcipt
	 * @param sessionUserAD
	 *            = �n�J��sessionAD (����nextUser�i�H�ۤv�ǵ��ۤv�f��)
	 * @return html��select���
	 */
	private String getSelectNextUser(String systemID, String flowID, int flowphase, String scriptName, String seeesionUserAD, boolean canClick) throws Exception {
		String rslt = null;
		CommonUser cu = null;
		ArrayList<String> nextUserMap;
		String bgStyle = "";
		String ftStyle = "";
		nextUserMap = getUserMap(systemID, flowID, flowphase).get("A");
		if (nextUserMap == null || nextUserMap.size() < 1) { // ���d����U�@�huser
			return null;
		}
		rslt = "<select id='nextUser' name='nextUser'";
		if (scriptName != null && !scriptName.equals("")) {
			rslt += scriptName; // getUserMap��H�i��ݭn�]javascript
		}
		rslt += "><option value='0'>�п��</option>";
		for (int i = 0; i < nextUserMap.size(); i++) {
			// �p�G����d�ۤv �~�|�z���ۤv �p�G�i�H�� �������L
			if (!canClick && seeesionUserAD.equalsIgnoreCase(nextUserMap.get(i))) {
				continue;
			}
			cu = new CommonUtil().getCommonUser(nextUserMap.get(i), conn);
			if (!CommonUtil.CDSTS_InPos.equals(cu.getCDSTS())) {
				continue;
			}
			String isSECT = getFlowDtl(systemID, flowID, flowphase).getIsSECT();
			CommonUser user = new CommonUtil().getCommonUser(seeesionUserAD, conn);
			if (isSECT != null && !isSECT.equals("")) {
				if (isSECT.equals("A") && (!user.getSECT().equals(cu.getSECT()) || !user.getDEPT().equals(cu.getDEPT()))) {
					continue;
				} else if (isSECT.equals("B") && !user.getDEPT().equals(cu.getDEPT())) {
					continue;
				}
			}

			bgStyle = (getUserAttenDanceScript(nextUserMap.get(i)) != null && !getUserAttenDanceScript(nextUserMap.get(i)).equals("")) ? "#e0e0e0" : "";
			ftStyle = (getUserAttenDanceScript(nextUserMap.get(i)) != null && !getUserAttenDanceScript(nextUserMap.get(i)).equals("")) ? "#6c6c6c" : "";
			rslt += "<option value='" + nextUserMap.get(i) + "' style='background-color:" + bgStyle + ";color:" + ftStyle + "' title='" + getUserAttenDanceScript(nextUserMap.get(i)) + "'>"
					+ cu.getEMCNM() + "(" + cu.getADACC() + ")" + "</option>";
		}
		rslt += "</select>";
		return rslt;
	}

	/**
	 * ���o�h�^UserAD
	 * @author ESB19332
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N��
	 * @param orderID
	 *            �y�{�渹
	 * @return String UserAD
	 * 
	 * @throws Exception
	 */
	public String getRejectUser(String systemID, String flowID, String orderID) throws Exception {
		String rejectUser = "";
		Order order = getOrder(systemID, flowID, orderID);
		FlowDtl flow = getFlowDtl(systemID, flowID, order.getFlowPhase());
		// �p�G�Ӭy�{�n�h�ܥӽмh�h�^�ǥӽФH�A�_�h�^�ǫe�B�z�H
		if (flow.getIsTop().equals("Y")) {
			rejectUser = order.getApplyUser();
		} else {
			rejectUser = getPreUser(systemID, flowID, orderID);
		}
		return rejectUser;
	}

	/**
	 * ���o�ϥΪ̦W��G�֭�W��B�h�^�W��B����W��<br>
	 * �p�G�]�w���h�^�ӽФH�A�h�վ�h�^�W�欰�ӽФH�W��
	 * 
	 * @author ESB19332
	 * 
	 * @param systemID
	 *            �t�ΥN�X
	 * @param flowID
	 *            �y�{�N��
	 * @param flowPhase
	 *            �y�{���q
	 * @return HashMap<String, ArrayList<String>> <br>
	 *         Key = �֭�,�h�^,����<br>
	 *         Value = ArrayList of UserID
	 * 
	 * @throws Exception
	 */
	public HashMap<String, ArrayList<String>> getTransUserMap(String systemID, String flowID, int flowPhase) throws Exception {
		HashMap<String, ArrayList<String>> userMap = new HashMap<String, ArrayList<String>>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select ug.GroupID, ug.UserID, " + "case when dtl.FlowPhase = ? then '" + Action_Transfer + "' " + "when dtl.FlowPhase = ? then '" + Action_Reject + "' "
				+ "when dtl.FlowPhase = ? then '" + Action_Approve + "' else '' end 'Action' " + "from EsunBPM.dbo.tbFlowDtl dtl,  EsunBPM.dbo.tbUserGroup ug "
				+ "where dtl.SystemID = ug.SystemID and dtl.GroupID = ug.GroupID and dtl.SystemID = ? and dtl.FlowID = ? " + "and dtl.FlowPhase in (?, ?, ?) order by ug.GroupID ";

		int flowPhasePre = flowPhase - 1;
		int flowPhaseNext = flowPhase + 1;

		if (getFlowDtl(systemID, flowID, flowPhase).getIsTop().equals("Y")) {
			flowPhasePre = 0;
		}

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, flowPhase);
			ps.setInt(2, flowPhasePre);
			ps.setInt(3, flowPhaseNext);
			ps.setString(4, systemID);
			ps.setString(5, flowID);
			ps.setInt(6, flowPhase);
			ps.setInt(7, flowPhasePre);
			ps.setInt(8, flowPhaseNext);
			rs = ps.executeQuery();

			ArrayList<String> parUserIDList = new ArrayList<String>();
			ArrayList<String> preUserIDList = new ArrayList<String>();
			ArrayList<String> nextUserIDList = new ArrayList<String>();

			while (rs.next()) {
				if (rs.getString("Action").equals(Action_Transfer)) {
					parUserIDList.add(rs.getString("UserID"));
				} else if (rs.getString("Action").equals(Action_Reject)) {
					preUserIDList.add(rs.getString("UserID"));
				} else if (rs.getString("Action").equals(Action_Approve)) {
					nextUserIDList.add(rs.getString("UserID"));
				}
			}
			userMap.put(Action_Transfer, parUserIDList);
			userMap.put(Action_Reject, preUserIDList);
			userMap.put(Action_Approve, nextUserIDList);
		} finally {
			try {
				rs.close();
			} catch (Exception ex) {
			}
			try {
				ps.close();
			} catch (Exception ex) {
			}
		}
		return userMap;
	}

	/**
	 * 
	 * @param submitFunction
	 *            = submit������Javascript function
	 * 
	 * @param canClick
	 *            �O�_��ǵ��ۤv
	 * 
	 * @return �^�Ǹ��actionType�BsystemID�BflowID�BorderID�BnextUser�Bmemo �P�_
	 *         1.actionType="A" �� approveOrder 2.actionType="R" �� rejectOrder
	 *         3.actionType="T" �� transferOrder 4.actionType="close" �� closeOrder
	 *         6.actionType="cancel" �� cancelOrder
	 * @throws Exception
	 * 
	 *             �s�W���\��
	 *
	 */
	public String getBPMUpdTransOrderUtil(String systemID, String flowID, String orderID, String submitFunction, String sessionUserAD) throws Exception {
		return getBPMUpdTransOrderUtil(systemID, flowID, orderID, submitFunction, sessionUserAD, false);
	}

	public String getBPMUpdTransOrderUtil(String systemID, String flowID, String orderID, String submitFunction, String sessionUserAD, boolean canClick) throws Exception {
		String rslt = null;
		String userMap = null;
		String nextUserMap = null;
		Order order = getOrder(systemID, flowID, orderID);
		if (order != null) {
			userMap = getSelectTransUser(systemID, flowID, order.getFlowPhase(), "onchange='choose()'", sessionUserAD);
			nextUserMap = getSelectNextUser(systemID, flowID, order.getFlowPhase(), "onchange='choose()'", sessionUserAD, canClick);
			rslt = "<style>" + ".button" + "{" + "font-size: 9pt;border: 1px outset;padding-top: 3px;padding-bottom: -2px;width: 40px;" + "}" + "</style>" + "<script>" + "function cleanDisplay(){"
					+ "var divs = new Array('setmemo','memoarea','setuser','settransuser','usermap','transusermap','reject','memo','close','cancel','confirm') ;" + "for(i=0;i<divs.length;i++){"
					+ "document.getElementById(divs[i]).style.display = 'none';" + "}" + "}" + "function showMemo(){" + "document.getElementById('setmemo').style.display = 'inline';"
					+ "document.getElementById('memoarea').style.display = 'inline';" + "document.getElementById('memo').style.display = 'inline';" + "}" + "function getAction(){"
					+ "if(document.getElementById('actionType').value == '0'){" + "cleanDisplay();" + "}" + "if(document.getElementById('actionType').value == 'A'){" + "cleanDisplay();"
					+ "document.getElementById('nextUser').value = '0';" + "document.getElementById('setuser').style.display = 'inline';"
					+ "document.getElementById('usermap').style.display = 'inline';" + "}" + "else if(document.getElementById('actionType').value == 'T'){" + "cleanDisplay();"
					+ "document.getElementById('transUser').value = '0';" + "document.getElementById('settransuser').style.display = 'inline';"
					+ "document.getElementById('transusermap').style.display = 'inline';" + "}" + "else if(document.getElementById('actionType').value == 'R'){" + "cleanDisplay();"
					+ "document.getElementById('reject').style.display = 'inline';" + "document.getElementById('memo').value = '���H�h�^�A�Э��s�����C';" + "showMemo();" + "}"
					+ "else if(document.getElementById('actionType').value == 'close'){" + "cleanDisplay();" + "document.getElementById('close').style.display = 'inline';"
					+ "document.getElementById('memo').value = '���H�֭�A���סC';" + "showMemo();" + "}" + "else if(document.getElementById('actionType').value == 'cancel'){" + "cleanDisplay();"
					+ "document.getElementById('cancel').style.display = 'inline';" + "document.getElementById('memo').value = '���H�P�סC';" + "showMemo();" + "}" + "}" + "function choose(){"
					+ "if(document.getElementById('nextUser').value != '0'){" + "document.getElementById('confirm').style.display = 'inline';" + "document.getElementById('memo').value = '�Ш�U�B�z���ݨD�C';"
					+ "showMemo();" + "}else if(document.getElementById('transUser').value != '0'){" + "document.getElementById('confirm').style.display = 'inline';"
					+ "document.getElementById('memo').value = '�Ш�U�B�z���ݨD�C';" + "showMemo();" + "}else{" + "document.getElementById('setmemo').style.display = 'none';"
					+ "document.getElementById('memoarea').style.display = 'none';" + "document.getElementById('memo').style.display = 'none';"
					+ "document.getElementById('confirm').style.display = 'none';" + "}" + "}" + "</script>";
			rslt += "<table width='400px' style='border:1px #663300 dashed;' bgcolor='B0DACC'>"
					+ "<tr><td colspan='2' align='right' style='color:#cc3300;font-family:Microsoft JhengHei;font-size:10px'>*�ǩ����ܸӥD��/�P���𰲤�</td></tr>" + "<tr>"
					+ "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'>�п�ܰʧ@</td>" + "<td><select id='actionType' name='actionType' onchange='getAction()'>"
					+ "<option value='0'>�п��</option>";
			rslt += "<option value='T'>���</option>";
			if (nextUserMap == null) {
				rslt += "<option value='close'>����</option>";
			} else {
				rslt += "<option value='A'>�ǰe</option>";
			}
			if (order.getFlowPhase() != 0) {
				rslt += "<option value='R'>�h�^</option>";
			}
			if (order.getFlowPhase() == 0) {
				rslt += "<option value='cancel'>�P��</option>";
			}
			rslt += "</select></td>" + "</tr>" + "<tr>" + "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'><div id='setuser' style='display:none'>�п�ܶǰe��H</div></td>"
					+ "<td><div id='usermap' style='display:none'>";
			if (nextUserMap != null) {
				rslt += nextUserMap + "</div></td>";
			}
			rslt += "</tr>" + "<tr>" + "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'><div id='settransuser' style='display:none'>�п�ܶǰe��H</div></td>"
					+ "<td><div id='transusermap' style='display:none'>";
			if (userMap != null) {
				rslt += userMap + "</div></td>";
			}
			rslt += "</tr>" + "<tr>" + "<td align='right' style='font-family:Microsoft JhengHei;'><div id='setmemo' style='display:none'>�п�J����</div></td>"
					+ "<td><div id='memoarea' style='display:none'><textarea id='memo' name='memo' rows='6' cols='30'></textarea></div></td>" + "</tr>" + "<tr>" + "<td></td>"
					+ "<td align='left'><div id='reject' style='display:none'><input type='button' class='button' value='�h�^' onclick='" + submitFunction + "'></div></td>" + "</tr>" + "<tr>"
					+ "<td></td>" + "<td align='left'><div id='cancel' style='display:none'><input type='button' class='button' value='�P��' onclick='" + submitFunction + "'></div></td>" + "</tr>"
					+ "<tr>" + "<td></td>" + "<td align='left'><div id='confirm' style='display:none'><input type='button' class='button' value='�e�X' onclick='" + submitFunction + "'></div></td>"
					+ "</tr>" + "<tr>" + "<td></td>" + "<td align='left'><div id='close' style='display:none'><input type='button' class='button' value='����' onclick='" + submitFunction
					+ "'></div></td>" + "</tr></table>" + "<input type='hidden' name='systemID' value='" + systemID + "'>" + "<input type='hidden' id='flowID' name='flowID' value='" + flowID + "'>"
					+ "<input type='hidden' id='orderID' name='orderID' value='" + orderID + "'>";
		}
		return rslt;
	}

	/**
	 * @param scriptName
	 *            = ���nextuser�W��ɭn�]��javasrcipt
	 * 
	 * @param sessionUserAD
	 *            = �n�J��sessionAD (����nextUser�i�H�ۤv�ǵ��ۤv�f��)
	 * 
	 * @return html��select���
	 */
	private String getSelectTransUser(String systemID, String flowID, int flowphase, String scriptName, String seeesionUserAD) throws Exception {
		String rslt = null;
		CommonUser cu = null;
		ArrayList<String> userMap;
		String bgStyle = "";
		String ftStyle = "";
		userMap = getUserMap(systemID, flowID, flowphase).get(Action_Transfer);
		if (userMap == null || userMap.size() < 1) { // ���d����P�@�huser
			return null;
		}
		rslt = "<select id='transUser' name='transUser'";
		if (scriptName != null && !scriptName.equals("")) {
			rslt += scriptName; // getUserMap��H�i��ݭn�]javascript
		}
		rslt += "><option value='0'>�п��</option>";
		for (int i = 0; i < userMap.size(); i++) {
			// �p�G����d�ۤv �~�|�z���ۤv �p�G�i�H�� �������L
			if (seeesionUserAD.equalsIgnoreCase(userMap.get(i))) {
				continue;
			}
			cu = new CommonUtil().getCommonUser(userMap.get(i), conn);
			if (!CommonUtil.CDSTS_InPos.equals(cu.getCDSTS())) {
				continue;
			}
			String isSECT = getFlowDtl(systemID, flowID, flowphase).getIsSECT();
			CommonUser user = new CommonUtil().getCommonUser(seeesionUserAD, conn);
			if (isSECT != null && !isSECT.equals("")) {
				if (isSECT.equals("A") && (!user.getSECT().equals(cu.getSECT()) || !user.getDEPT().equals(cu.getDEPT()))) {
					continue;
				} else if (isSECT.equals("B") && !user.getDEPT().equals(cu.getDEPT())) {
					continue;
				}
			}

			bgStyle = (getUserAttenDanceScript(userMap.get(i)) != null && !getUserAttenDanceScript(userMap.get(i)).equals("")) ? "#e0e0e0" : "";
			ftStyle = (getUserAttenDanceScript(userMap.get(i)) != null && !getUserAttenDanceScript(userMap.get(i)).equals("")) ? "#6c6c6c" : "";
			rslt += "<option value='" + userMap.get(i) + "' style='background-color:" + bgStyle + ";color:" + ftStyle + "' title='" + getUserAttenDanceScript(userMap.get(i)) + "'>" + cu.getEMCNM()
					+ "(" + cu.getADACC() + ")" + "</option>";
		}
		rslt += "</select>";
		return rslt;
	}

	/**
	 * BPM��椶��
	 *
	 * @param submitFunction
	 *            = submit������Javascript function
	 *
	 */
	public String getBPMTransOrderUtil(String systemID, String flowID, String orderID, String submitFunction, String sessionUserAD) throws Exception {
		String rslt = null;
		String userMap = null;
		Order order = getOrder(systemID, flowID, orderID);
		if (order != null) {
			userMap = getSelectTransUser(systemID, flowID, order.getFlowPhase(), "onchange='choose()'", sessionUserAD);
			rslt = "<style>" + ".button" + "{" + "font-size: 9pt;border: 1px outset;padding-top: 3px;padding-bottom: -2px;width: 40px;" + "}" + "</style>" + "<script>" + "function showMemo(){"
					+ "document.getElementById('settransmemo').style.display = 'inline';" + "document.getElementById('transmemoarea').style.display = 'inline';"
					+ "document.getElementById('transmemo').style.display = 'inline';" + "}" + "function choose(){" + "if(document.getElementById('transUser').value != '0'){"
					+ "document.getElementById('transfer').style.display = 'inline';" + "document.getElementById('transmemo').value = '�Ш�U�B�z���ݨD�C';" + "showMemo();" + "}else{"
					+ "document.getElementById('settransmemo').style.display = 'none';" + "document.getElementById('transmemoarea').style.display = 'none';"
					+ "document.getElementById('transmemo').style.display = 'none';" + "document.getElementById('transfer').style.display = 'none';" + "}" + "}" + "</script>";
			rslt += "<table width='400px' style='border:1px #663300 dashed;' bgcolor='B0DACC'>"
					+ "<tr><td colspan='2' align='right' style='color:#cc3300;font-family:Microsoft JhengHei;font-size:10px'>*�ǩ����ܸӥD��/�P���𰲤�</td></tr>" + "<tr>"
					+ "<td width='40%' align='right' style='font-family:Microsoft JhengHei;'><div id='settransuser' style='display:inline'>�п������H</div></td>"
					+ "<td><div id='transusermap' style='display:inline'>";
			if (userMap != null) {
				rslt += userMap + "</div></td>";
			}
			rslt += "</tr>" + "<tr>" + "<td align='right' style='font-family:Microsoft JhengHei;'><div id='settransmemo' style='display:none'>�п�J����</div></td>"
					+ "<td><div id='transmemoarea' style='display:none'><textarea id='transmemo' name='transmemo' rows='6' cols='30'></textarea></div></td>" + "</tr>" + "<tr>" + "<td></td>"
					+ "<td align='left'><div id='transfer' style='display:none'><input type='button' class='button' value='�e�X' onclick='" + submitFunction + "'></div></td>" + "</tr></table>"
					+ "<input type='hidden' name='systemID' value='" + systemID + "'>" + "<input type='hidden' id='flowID' name='flowID' value='" + flowID + "'>"
					+ "<input type='hidden' id='orderID' name='orderID' value='" + orderID + "'>";
		}
		return rslt;
	}
}