package esunbank.esunutil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import esunbank.esunutil.db.DBUtil;

public class CommonUtil {

	/**
	 * �w�]���w��Ʈw DBHost_In
	 */
	public CommonUtil() {

	}

	public static final int DBHost_Out = 0;
	public static final int DBHost_In = 1;
	public static final int DBHost_ACQ = 2;
	public static final int DBHost_DB = 3;

	/**
	 * ��¾���p�G����
	 */
	public static final String CDSTS_InPos = "1"; // 1:����

	/**
	 * ��¾���p�G�d¾
	 */
	public static final String CDSTS_KeepPos = "2"; // 2:�d¾

	/**
	 * ��¾���p�G��¾
	 */
	public static final String CDSTS_OutofPos = "3"; // 3:��¾

	private String dbHost = "";

	/**
	 * ���w��Ʈw�D��<br>
	 * CommonUtil.DBHost_Out/CommonUtil.DBHost_In/CommonUtil.DBHost_ACQ/
	 * CommonUtil.DBHost_DB
	 */
	public CommonUtil(int dbAssign) {
		if (dbAssign == DBHost_Out) {
			dbHost = commonDBAdress_Out;
		} else if (dbAssign == DBHost_In) {
			dbHost = commonDBAdress;
		} else if (dbAssign == DBHost_ACQ) {
			dbHost = commonDBAdress_ACQ;
		} else if (dbAssign == DBHost_DB) {
			dbHost = commonDBAdress_DB;
		}
	}

	private static HashMap<String, Object> seqLocker = new HashMap<String, Object>();

	// �B�z�Ǹ�lock����
	private void seqTypeMapper(String seqType) {
		if (seqLocker.get(seqType) == null) {
			seqLocker.put(seqType, new Object());
		}
	}

	/**
	 * ���o�����O���ѧǸ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param conn
	 *            ��Ʈw�s�u
	 * @return �ثe�Ǹ�
	 */
	public String getSeqNo(String seqType, int seqLength, Connection conn) {
		return getSeqNo(seqType, DateUtil.getNowDate(), seqLength, conn);
	}

	/**
	 * ���o�����O���ѧǸ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param conn
	 *            ��Ʈw�s�u
	 * @param isReset
	 *            �O�_�R����Ʈw��data
	 * @return �ثe�Ǹ�
	 */
	public String getSeqNo(String seqType, int seqLength, Connection conn, boolean isReset) {
		return getSeqNo(seqType, DateUtil.getNowDate(), seqLength, conn, isReset);
	}

	/**
	 * ���o�����O�Ǹ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqDate
	 *            �Ǹ����
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param conn
	 *            ��Ʈw�s�u
	 * @return �ثe�Ǹ�
	 */
	public String getSeqNo(String seqType, String seqDate, int seqLength, Connection conn) {
		return getSeqNo(seqType, seqDate, seqLength, conn, false);
	}

	/**
	 * ���o�����O�Ǹ�
	 * 
	 * @param seqType
	 *            �Ǹ����O
	 * @param seqDate
	 *            �Ǹ����
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @param conn
	 *            ��Ʈw�s�u
	 * @param isReset
	 *            �O�_�R����Ʈw��data
	 * @return �ثe�Ǹ�
	 */
	public String getSeqNo(String seqType, String seqDate, int seqLength, Connection conn, boolean isReset) {
		seqTypeMapper(seqType);
		synchronized (seqLocker.get(seqType)) {

			PreparedStatement ps = null;
			ResultSet rs = null;

			try {

				if (seqLength < 1 || seqLength > 9) {
					throw new Exception("�W�L���׭���");
				}

				if (isReset) {
					String sql = "IF NOT EXISTS (SELECT * FROM [Common].[dbo].[tbSeq] WHERE SeqType=? and SeqDate=?) " + "DELETE FROM [Common].[dbo].[tbSeq] WHERE SeqType=?;";

					ps = conn.prepareStatement(sql);
					ps.setString(1, seqType);
					ps.setString(2, seqDate);
					ps.setString(3, seqType);
					ps.execute();
				}

				String sql = "IF EXISTS (SELECT * FROM [Common].[dbo].[tbSeq] WHERE SeqType=? and SeqDate=?) " + "update [Common].[dbo].[tbSeq] set SeqNum=SeqNum+1 WHERE SeqType=? and SeqDate=? "
						+ "ELSE insert into [Common].[dbo].[tbSeq] (SeqType,SeqDate,SeqNum) values (?,?,1);";

				ps = conn.prepareStatement(sql);
				ps.setString(1, seqType);
				ps.setString(2, seqDate);
				ps.setString(3, seqType);
				ps.setString(4, seqDate);
				ps.setString(5, seqType);
				ps.setString(6, seqDate);
				if (ps.executeUpdate() != 1) {
					throw new Exception("��s�Ǹ�����");
				}

				sql = "select * from [Common].[dbo].[tbSeq] where SeqType=? and SeqDate=?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, seqType);
				ps.setString(2, seqDate);

				rs = ps.executeQuery();
				rs.next();

				int SeqNum = rs.getInt("SeqNum");

				int MaxSeq = getMaxSeq(seqLength);
				if (SeqNum < MaxSeq) {
					return StringUtil.apdSplt(seqLength, SeqNum + "", "0", false);
				} else {
					throw new Exception("�W�L�̤j�Ǹ�");
				}

			} catch (Exception e) {
				return null;
			} finally {
				try {
					rs.close();
				} catch (Exception e) {
				}
				try {
					ps.close();
				} catch (Exception e) {
				}
			}
		}
	}

	/**
	 * ���o�Ӫ��קǸ��̤j��
	 * 
	 * @param seqLength
	 *            �Ǹ�����(�����N�|����'0'�ܫ��w����)�A���׭���1-9
	 * @return �Ӫ��קǸ��̤j��
	 */
	public int getMaxSeq(int seqLength) {
		return seqLength <= 0 ? 0 : (int) Math.pow(10, seqLength) - 1;
	}

	static TreeMap<String, CommonUser> CommonUserList_byAD = null;

	static TreeMap<String, CommonUser> CommonUserList_by400ID = null;

	static TreeMap<String, CommonUser> CommonUserList_byEMNO = null;

	static TreeMap<String, ArrayList<CommonUser>> CommonUserList_byDeptSect = null;

	static TreeMap<String, CardImageObj> CardImage = new TreeMap<String, CardImageObj>();

	static Object userlock = new Object();

	static boolean isUserUpdater = false;

	static int keyType_AD = 1;

	static int keyType_400ID = 2;

	static int keyType_EMNO = 3;

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param userAD
	 *            �ϥΪ�AD�b��
	 * @param conn
	 *            ��Ʈw�s�u
	 * @return CommonUser
	 */
	public CommonUser getCommonUser(String userAD, Connection conn) {
		return getCommonUser(userAD);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param userAD
	 *            �ϥΪ�AD�b��
	 * @return CommonUser
	 */
	public CommonUser getCommonUser(String userAD) {
		return getUser(keyType_AD, userAD);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param user400ID
	 *            �ϥΪ�400�b��
	 * @param conn
	 *            ��Ʈw�s�u
	 * @return CommonUser
	 */
	public CommonUser getCommonUserBy400ID(String user400ID, Connection conn) {
		return getCommonUserBy400ID(user400ID);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param user400ID
	 *            �ϥΪ�400�b��
	 * @return CommonUser
	 */
	public CommonUser getCommonUserBy400ID(String user400ID) {
		return getUser(keyType_400ID, user400ID);
	}

	/**
	 * ���oCommon��ƪ���user�U����T
	 * 
	 * @param userEMNO
	 *            �ϥΪ̭��u�s��
	 * @return CommonUser
	 */
	public CommonUser getCommonUserByEMNO(String userEMNO) {
		return getUser(keyType_EMNO, userEMNO);
	}

	private CommonUser getUser(int keyType, String key) {
		updCommonUser(false);
		CommonUser commonUser = null;
		if (keyType == keyType_AD) {
			commonUser = CommonUserList_byAD.get(key.toUpperCase());
		} else if (keyType == keyType_400ID) {
			commonUser = CommonUserList_by400ID.get(key.toUpperCase());
		} else if (keyType == keyType_EMNO) {
			commonUser = CommonUserList_byEMNO.get(key.toUpperCase());
		}
		if (commonUser == null) {
			commonUser = new CommonUser();
			if (keyType == keyType_AD) {
				commonUser.setUSRID("");
				commonUser.setADACC(key);
				commonUser.setEMNO("");
			} else if (keyType == keyType_400ID) {
				commonUser.setUSRID(key);
				commonUser.setADACC("");
				commonUser.setEMNO("");
			} else if (keyType == keyType_EMNO) {
				commonUser.setUSRID("");
				commonUser.setADACC("");
				commonUser.setEMNO(key);
			}
			commonUser.setEMCNM(key);
			commonUser.setSECT("");
			commonUser.setSECT_INFO("");
			commonUser.setDEPT("");
			commonUser.setDEPT_INFO("");
			commonUser.setEXPNO("");
			commonUser.setTWSID("");
			commonUser.setCELL("");
			commonUser.setEMAIL("");
			commonUser.setPSRK1("");
			commonUser.setPSNM("");
			commonUser.setCDSTS(CDSTS_OutofPos);
		}
		return commonUser;
	}

	/**
	 * �̳����էO���o�ϥΪ�
	 * 
	 * @param dept
	 *            �����N�X
	 * @param sect
	 *            �էO�N�X
	 * @return �ϥΪ̦C��
	 */
	public ArrayList<CommonUser> getCommonUserByDeptSect(String dept, String sect) {
		updCommonUser(false);
		return CommonUserList_byDeptSect.get(dept.toUpperCase() + "#|" + sect.toUpperCase());
	}

	/**
	 * �̳������o�ϥΪ�
	 * 
	 * @param dept
	 *            �����N�X
	 * @return �ϥΪ̦C��
	 */
	public ArrayList<CommonUser> getCommonUserByDept(String dept) {
		updCommonUser(false);
		ArrayList<CommonUser> rslt = new ArrayList<CommonUser>();
		for (Map.Entry<String, ArrayList<CommonUser>> list : CommonUserList_byDeptSect.entrySet()) {
			if (list.getKey().split("[#][|]")[0].equals(dept.toUpperCase())) {
				rslt.addAll(list.getValue());
			}
		}
		return rslt;
	}

	protected void updCommonUser(boolean isForceUpdate) {
		if (isForceUpdate || CommonUserList_byAD == null || CommonUserList_by400ID == null || CommonUserList_byEMNO == null || CommonUserList_byDeptSect == null) {
			synchronized (userlock) {
				if (isForceUpdate || CommonUserList_byAD == null || CommonUserList_by400ID == null || CommonUserList_byEMNO == null || CommonUserList_byDeptSect == null) {
					updUser();
				}
				if (!isUserUpdater) {
					new userInfoUpdater().start();
					isUserUpdater = true;
				}
			}
		}
	}

	private void updUser() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = "SELECT * FROM [Common].[dbo].[tbUserInfo] where ADACC is not null and USRID is not null and EMNO is not null ";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			TreeMap<String, CommonUser> tmp_CommonUserList_byAD = new TreeMap<String, CommonUser>();
			TreeMap<String, CommonUser> tmp_CommonUserList_by400ID = new TreeMap<String, CommonUser>();
			TreeMap<String, CommonUser> tmp_CommonUserList_byEMNO = new TreeMap<String, CommonUser>();
			TreeMap<String, ArrayList<CommonUser>> tmp_CommonUserList_byDeptSect = new TreeMap<String, ArrayList<CommonUser>>();
			CommonUser user = null;
			String key = null;
			while (rs.next()) {
				user = new CommonUser();
				user.setEMNO(rs.getString("EMNO"));
				user.setUSRID(rs.getString("USRID"));
				user.setADACC(rs.getString("ADACC"));
				user.setEMCNM(rs.getString("EMCNM"));
				user.setSECT(rs.getString("SECT"));
				user.setSECT_INFO(rs.getString("SECT_INFO"));
				user.setDEPT(rs.getString("DEPT"));
				user.setDEPT_INFO(rs.getString("DEPT_INFO"));
				user.setEXPNO(rs.getString("EXPNO"));
				user.setTWSID(rs.getString("TWSID"));
				user.setCELL(rs.getString("CELL"));
				user.setEMAIL(rs.getString("EMAIL"));
				user.setPSRK1(rs.getString("PSRK1"));
				user.setPSNM(rs.getString("PSNM"));
				user.setCDSTS(rs.getString("CDSTS"));
				user.setDTREL(rs.getInt("DTREL"));
				tmp_CommonUserList_byAD.put(user.getADACC().toUpperCase(), user);
				tmp_CommonUserList_by400ID.put(user.getUSRID().toUpperCase(), user);
				tmp_CommonUserList_byEMNO.put(user.getEMNO().toUpperCase(), user);
				key = rs.getString("DEPT").toUpperCase() + "#|" + rs.getString("SECT").toUpperCase();
				if (tmp_CommonUserList_byDeptSect.get(key) == null) {
					tmp_CommonUserList_byDeptSect.put(key, new ArrayList<CommonUser>());
				}
				tmp_CommonUserList_byDeptSect.get(key).add(user);
			}
			CommonUserList_byAD = tmp_CommonUserList_byAD;
			CommonUserList_by400ID = tmp_CommonUserList_by400ID;
			CommonUserList_byEMNO = tmp_CommonUserList_byEMNO;
			CommonUserList_byDeptSect = tmp_CommonUserList_byDeptSect;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	static ArrayList<UserDept> userDeptList = null;

	static ArrayList<UserSect> userSectList = null;

	static Object deptsectlock = new Object();

	static boolean isDeptSectUpdater = false;

	/**
	 * �̳������o������T
	 * 
	 * @param dept
	 *            �����N�X
	 * @return ������T
	 */
	public UserDept getDept(String dept) {
		updUserDeptSect(false);
		for (int i = 0; i < userDeptList.size(); i++) {
			if (userDeptList.get(i).getDEPT().equals(dept.toUpperCase())) {
				return userDeptList.get(i);
			}
		}
		return null;
	}

	/**
	 * ���o�Ҧ�������T
	 * 
	 * @return ������T
	 */
	public ArrayList<UserDept> getDept() {
		updUserDeptSect(false);
		return userDeptList;
	}

	/**
	 * �̳����βէO���o�էO��T
	 * 
	 * @param dept
	 *            �����N�X
	 * @param sect
	 *            �էO�N�X
	 * @return �էO��T
	 */
	public UserSect getSect(String dept, String sect) {
		updUserDeptSect(false);
		for (int i = 0; i < userSectList.size(); i++) {
			if (userSectList.get(i).getDEPT().equals(dept.toUpperCase()) && userSectList.get(i).getSECT().equals(sect.toUpperCase())) {
				return userSectList.get(i);
			}
		}
		return null;
	}

	/**
	 * �̳������o�ӳ����Ҧ����էO��T
	 * 
	 * @param dept
	 *            �����N�X
	 * @return �էO��T
	 */
	public ArrayList<UserSect> getSect(String dept) {
		updUserDeptSect(false);
		ArrayList<UserSect> list = new ArrayList<UserSect>();
		for (int i = 0; i < userSectList.size(); i++) {
			if (userSectList.get(i).getDEPT().equals(dept.toUpperCase())) {
				list.add(userSectList.get(i));
			}
		}
		return list;
	}

	/**
	 * ���o�Ҧ��էO��T
	 * 
	 * @return �էO��T
	 */
	public ArrayList<UserSect> getSect() {
		return userSectList;
	}

	public void updUserDeptSect(boolean isForceUpdate) {
		if (isForceUpdate || userDeptList == null || userSectList == null) {
			synchronized (deptsectlock) {
				if (isForceUpdate || userDeptList == null || userSectList == null) {
					updUserDeptSect();
				}
				if (!isDeptSectUpdater) {
					// ��XThread�C���s
					new deptsectInfoUpdater().start();
					isDeptSectUpdater = true;
				}
			}
		}
	}

	// ��s�����B�էO��T
	private void updUserDeptSect() {
		ArrayList<UserDept> tmp_userDeptList = new ArrayList<UserDept>();
		ArrayList<UserSect> tmp_userSectList = new ArrayList<UserSect>();
		TreeMap<String, UserDept> tmp_userDeptList_proc = new TreeMap<String, UserDept>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = "SELECT [DEPT],[DEPT_INFO],[SECT],[SECT_INFO],COUNT(*) AS CNT FROM [Common].[dbo].[tbUserInfo] GROUP BY [DEPT],[DEPT_INFO],[SECT],[SECT_INFO]";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			UserDept userDept = null;
			UserSect userSect = null;
			while (rs.next()) {
				userSect = new UserSect();
				userSect.setDEPT(rs.getString("DEPT").toUpperCase());
				userSect.setDEPT_INFO(rs.getString("DEPT_INFO"));
				userSect.setSECT(rs.getString("SECT").toUpperCase());
				userSect.setSECT_INFO(rs.getString("SECT_INFO"));
				userSect.setSECT_CNT(rs.getInt("CNT"));
				tmp_userSectList.add(userSect);
				if (tmp_userDeptList_proc.get(userSect.getDEPT()) == null) {
					userDept = new UserDept();
					userDept.setDEPT(userSect.getDEPT().toUpperCase());
					userDept.setDEPT_INFO(userSect.getDEPT_INFO());
					userDept.setDEPT_CNT(0);
					tmp_userDeptList_proc.put(userDept.getDEPT(), userDept);
				}
				tmp_userDeptList_proc.get(userDept.getDEPT()).setDEPT_CNT(tmp_userDeptList_proc.get(userDept.getDEPT()).getDEPT_CNT() + userSect.getSECT_CNT());
			}
			for (Map.Entry<String, UserDept> entry : tmp_userDeptList_proc.entrySet()) {
				tmp_userDeptList.add(entry.getValue());
			}
			userDeptList = tmp_userDeptList;
			userSectList = tmp_userSectList;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	static TreeMap<String, CurrencyInfo> currencyInfoList = null;

	static Object currencylock = new Object();

	static boolean isCurrencyInfoUpdater = false;

	public void updCurrencyInfo(boolean isForceUpdate) {
		if (isForceUpdate || currencyInfoList == null) {
			synchronized (currencylock) {
				if (isForceUpdate || currencyInfoList == null) {
					updCurrencyInfo();
				}
				if (!isCurrencyInfoUpdater) {
					// ��XThread�C���s
					new currencyInfoUpdater().start();
					isCurrencyInfoUpdater = true;
				}
			}
		}
	}

	// ��s���O��T
	private void updCurrencyInfo() {
		TreeMap<String, CurrencyInfo> tmp_currencyInfoList = new TreeMap<String, CurrencyInfo>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = "SELECT * FROM [Common].[dbo].[CurrencyInfo]";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_Out : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			CurrencyInfo currencyInfo = null;
			while (rs.next()) {
				currencyInfo = new CurrencyInfo();
				currencyInfo.setPOSID(rs.getString("POSID"));
				currencyInfo.setCurrency(rs.getString("Currency"));
				currencyInfo.setCurrencyDesc(rs.getString("CurrencyDesc"));
				currencyInfo.setCode(rs.getString("Code"));
				currencyInfo.setInfo(rs.getString("Info"));
				tmp_currencyInfoList.put(currencyInfo.getPOSID(), currencyInfo);
			}
			currencyInfoList = tmp_currencyInfoList;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * ��POSID���o���O��T
	 * 
	 * @param posid
	 *            POSID
	 * 
	 * @return ���O��T
	 */
	public CurrencyInfo getCurrencyInfo(String posid) {
		updCurrencyInfo(false);
		if (posid.startsWith("50")) {
			return currencyInfoList.get("50[0-9]{6}");
		} else if (posid.startsWith("51")) {
			return currencyInfoList.get("51[0-9]{6}");
		} else if (posid.startsWith("52")) {
			return currencyInfoList.get("52[0-9]{6}");
		} else if (posid.startsWith("53")) {
			return currencyInfoList.get("53[0-9]{6}");
		} else if (posid.startsWith("54")) {
			return currencyInfoList.get("54[0-9]{6}");
		} else if (posid.startsWith("E") && posid.endsWith("1")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}1");
		} else if (posid.startsWith("E") && posid.endsWith("2")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}2");
		} else if (posid.startsWith("E") && posid.endsWith("3")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}3");
		} else if (posid.startsWith("E") && posid.endsWith("4")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}4");
		} else if (posid.startsWith("E") && posid.endsWith("5")) {
			return currencyInfoList.get("E[A-Z0-9]{1}[0-9]{5}5");
		}
		for (Map.Entry<String, CurrencyInfo> currencyInfoItem : currencyInfoList.entrySet()) {
			if (posid.matches(currencyInfoItem.getKey())) {
				CurrencyInfo currencyInfo = currencyInfoItem.getValue();
				currencyInfo.setPOSID(posid);
				return currencyInfo;
			}
		}
		return null;
	}

	// ���o�d������(�qDB)
	private byte[] getCardImageFromDB(String AGNO, String CATP) {
		byte[] image = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = "SELECT top 1 * FROM [EsunCreditweb].[dbo].[tbCardImgCtl] WHERE Status = 'Y' AND AGNO = ? AND NOCD = ? order by VersionID desc";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_ACQ : dbHost, commonDBPort, esuncreditwebDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, AGNO);
			ps.setString(2, CATP);
			rs = ps.executeQuery();
			if (rs.next()) {
				image = rs.getBytes("CardFile");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return image;
	}

	// ���o�d������
	public byte[] getCardImage(String AGNO, String CATP) {
		long time = System.currentTimeMillis();
		CardImageObj cardimage = null;

		// 1.���P�_MAP�̭����S���A�S���ζW�L�@�Ѽ�DB
		cardimage = CardImage.get(AGNO + "#|" + CATP);
		if (cardimage == null || (time - CardImage.get(AGNO + "#|" + CATP).lastUpdateTime > 86400)) {
			cardimage = getCardImageForcedFromDBAndUpdate(AGNO, CATP, time);
		}

		// 2.�٬O�S�����ɡA�^��BANK+CATP
		if (cardimage == null) {
			if ((cardimage = CardImage.get("BANK" + "#|" + CATP)) == null) {
				cardimage = getCardImageForcedFromDBAndUpdate("BANK", CATP, time);
			}
		}

		// 3.�٬O�S�����ɡA�^��BANK+CATP�Ĥ@�X
		if (cardimage == null) {
			if ((cardimage = CardImage.get("BANK" + "#|" + CATP.substring(0, 1))) == null) {
				cardimage = getCardImageForcedFromDBAndUpdate("BANK", CATP.substring(0, 1), time);
			}
		}

		return cardimage == null ? null : cardimage.image;
	}

	// ���o�d������
	private CardImageObj getCardImageForcedFromDBAndUpdate(String AGNO, String CATP, long time) {
		CardImageObj cardImageObj = null;
		byte[] image = getCardImageFromDB(AGNO, CATP);
		if (image != null) {
			cardImageObj = new CardImageObj();
			cardImageObj.image = image;
			cardImageObj.lastUpdateTime = time;
			CardImage.put(AGNO + "#|" + CATP, cardImageObj);
		}

		return cardImageObj;
	}

	public static final String non_holiday_Code = "1";

	public static final String half_holiday_Code = "2";

	public static final String holiday_Code = "3";

	public static final int Month_Period_Next = 1;

	public static final int Month_Period_Previous = -1;

	private ResourceBundle dmres = ResourceBundle.getBundle("esunbank.esunutil.config");

	private String commonDBAdress_Out = dmres.getString("commonDBAdress_Out");

	private String commonDBAdress_ACQ = dmres.getString("commonDBAdress_ACQ");

	private String commonDBAdress_DB = dmres.getString("commonDBAdress_DB");

	private String commonDBAdress = dmres.getString("commonDBAdress");

	private String commonDBPort = dmres.getString("commonDBPort");

	private String commonDBName = dmres.getString("commonDBName");

	private String commonDBID = dmres.getString("commonDBID");

	private String commonDBPassword = dmres.getString("commonDBPassword");

	private String esuncreditwebDBName = dmres.getString("esuncreditwebDBName");

	private static TreeMap<String, HolidayInfo> actcdList = new TreeMap<String, HolidayInfo>();

	/*
	 * �^�ǥN�����Ӥ몺�W�Z�񰲦r��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return antcd
	 * 
	 * @throws Exception
	 */

	public String getMonthsANTCD(GregorianCalendar gc) throws Exception {

		HolidayInfo info = null;
		String antcd = "";
		Connection conn = null;
		info = actcdList.get(gc.get(GregorianCalendar.YEAR) + "" + (gc.get(GregorianCalendar.MONTH) + 1));
		try {
			if (info != null && info.getSysDate().equals(DateUtil.getNowDate())) {
				antcd = info.getAntcdStr();
			} else {
				conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
				antcd = getANTCD(conn, gc.get(GregorianCalendar.YEAR), gc.get(GregorianCalendar.MONTH) + 1);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return antcd;
	}

	/**
	 * �^�ǩ��e�d�ߥX�Ӫ����@��
	 * 
	 * @param gc
	 *            ���GregorianCalendar
	 * @param compare_date
	 *            �n�d�ߤu�@�άO�񰲪��N��String
	 * @return gc
	 * @throws Exception
	 */

	public GregorianCalendar getBeforeDay(GregorianCalendar gc, String compare_date) throws Exception {
		String antcd = "";
		try {
			int idx = 0;
			boolean isfinded = false;
			gc.add(GregorianCalendar.DATE, -2); // �@�}�l����@�� �]���q0�}�l�ҥH�A��@��
			while (!isfinded) {
				antcd = getMonthsANTCD(gc); // �@����@�Ӥ몺�r��
				idx = antcd.lastIndexOf(compare_date, gc.get(GregorianCalendar.DATE)); // �q�ۤv�o�@�Ѷ}�l��
				if (idx != -1) { // �N�������
					isfinded = true;
					gc.set(GregorianCalendar.DATE, idx + 1);
				} else { // �N���S���
					gc = getAddMonOrSubMon(gc, Month_Period_Previous);
					gc.set(GregorianCalendar.DATE, getDaysInMonth((gc.get(GregorianCalendar.MONTH) + 1), gc.get(GregorianCalendar.YEAR)));
				}
			}
			return gc;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * �^�ǩ���d�ߥX�Ӫ����@��
	 * 
	 * @param gc
	 *            ���GregorianCalendar
	 * @param compare_date
	 *            �n�d�ߤu�@�άO�񰲪��N��String
	 * @return gc
	 * @throws Exception
	 */

	public GregorianCalendar getAfterDay(GregorianCalendar gc, String compare_date) throws Exception {
		String antcd = "";
		try {
			int idx = 0;
			boolean isfinded = false;
			gc.add(GregorianCalendar.DATE, 1); // �@�}�l���[�@��
			while (!isfinded) {
				antcd = getMonthsANTCD(gc);
				idx = antcd.indexOf(compare_date, gc.get(GregorianCalendar.DATE) - 1); // �q�ۤv�o�@�Ѷ}�l��
				if (idx != -1) { // �N�������
					isfinded = true;
					gc.set(GregorianCalendar.DATE, idx + 1);
				} else {
					gc = getAddMonOrSubMon(gc, Month_Period_Next);
					gc.set(GregorianCalendar.DATE, 1);
				}
			}
			return gc;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * �P�_���Ѫ�����O�_������
	 * 
	 * @param gc
	 *            ���GregorianCalendar
	 * @return �O�_������(true/false)
	 * @throws Exception
	 */
	public boolean isHoliday(GregorianCalendar gc) throws Exception {
		try {
			return getMonthsANTCD(gc).substring(gc.get(GregorianCalendar.DATE) - 1, gc.get(GregorianCalendar.DATE)).equals(holiday_Code);
		} catch (Exception e) {
			throw e;
		}
	}

	/*
	 * ����[�@�Ӥ�δ�@�Ӥ�
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @param control ����[�άO��
	 * 
	 * @return antcd
	 * 
	 * @throws Exception
	 */
	public GregorianCalendar getAddMonOrSubMon(GregorianCalendar gc, int control) throws Exception {
		gc.add(GregorianCalendar.MONTH, control);
		return gc;
	}

	/*
	 * ���w����d�ߤU�@�Ӱ���
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar
	 * 
	 * @throws Exception
	 */

	public GregorianCalendar getNextHoliday(GregorianCalendar gc) throws Exception {
		return getAfterDay(gc, holiday_Code);

	}

	/**
	 * �P�_���ѬO�_������
	 * 
	 * @return �O�_������(true/false)
	 * @throws Exception
	 */
	public boolean isHoliday() throws Exception {
		return isHoliday(new GregorianCalendar());
	}

	/**
	 * �d�ߤU�@�Ӱ���
	 * 
	 * @return GregorianCalendar
	 * @throws Exception
	 */
	public GregorianCalendar getNextHoliday() throws Exception {
		return getNextHoliday(new GregorianCalendar());
	}

	/*
	 * ���w����d�ߤU�@�Ӥu�@��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar
	 * 
	 * @throws Exception
	 */

	public GregorianCalendar getNextWorkday(GregorianCalendar gc) throws Exception {
		return getAfterDay(gc, non_holiday_Code);
	}

	/*
	 * �d�ߤ��Ѥ���U�@�Ӥu�@��
	 * 
	 * @return GregorianCalendar
	 * 
	 * @throws Exception
	 */

	public GregorianCalendar getNextWorkday() throws Exception {
		return getNextWorkday(new GregorianCalendar());
	}

	/*
	 * ���w����d�߫e�@�Ӥu�@��
	 * 
	 * @param gc ���GregorianCalendar
	 * 
	 * @return GregorianCalendar
	 * 
	 * @throws Exception
	 */

	public GregorianCalendar getPreviousWorkday(GregorianCalendar gc) throws Exception {
		return getBeforeDay(gc, non_holiday_Code);
	}

	/**
	 * �d�߸�Ʈw���@�Ӥ����������
	 * 
	 * @param conn
	 *            ��Ʈw�s�u
	 * @param year
	 *            �d�ߦ~
	 * @param month
	 *            �d�ߤ�
	 * @return String
	 * @throws Exception
	 */
	private String getANTCD(Connection conn, int year, int month) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		HolidayInfo info = null;
		String sql;
		String antcdStr = "";
		try {
			/*
			 * int next_year = month == 12 ? (year + 1) : year; int next_month = month == 12
			 * ? 1 : (month + 1);
			 */
			sql = "select * from [Common].[dbo].[CPMCAC] where (year = ? and month = ?) order by year,month";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, year);
			ps.setInt(2, month);
			// ps.setInt(3, next_year);
			// ps.setInt(4, next_month);
			rs = ps.executeQuery();
			while (rs.next()) {
				info = new HolidayInfo();
				info.setAntcdStr(rs.getString("antcd"));
				info.setSysDate(DateUtil.getNowDate());
				actcdList.put(rs.getInt("year") + "" + rs.getInt("month"), info);
				antcdStr = antcdStr + rs.getString("antcd");
			}
			return antcdStr;
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
	}

	/**
	 * �d�ߤ릳�X��
	 * 
	 * @param year
	 *            �d�ߦ~
	 * @param month
	 *            �d�ߤ�
	 * @return Int day in month
	 */
	private int getDaysInMonth(int month, int year) {
		if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {
			return 31;
		} else if (month == 4 || month == 6 || month == 9 || month == 11) {
			return 30;
		} else if (month == 2) { // �P�_�O���O�|�~
			if (new GregorianCalendar().isLeapYear(year)) {
				return 29;
			} else {
				return 28;
			}
		}
		return 0;
	}

	class HolidayInfo {
		String antcdStr;
		String sysDate;

		public String getAntcdStr() {
			return antcdStr;
		}

		public void setAntcdStr(String antcdStr) {
			this.antcdStr = antcdStr;
		}

		public String getSysDate() {
			return sysDate;
		}

		public void setSysDate(String sysDate) {
			this.sysDate = sysDate;
		}
	}

	class CardImageObj {
		byte[] image;
		long lastUpdateTime;
	}

	class userInfoUpdater extends Thread {

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					updCommonUser(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	class deptsectInfoUpdater extends Thread {

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					updUserDeptSect(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	class currencyInfoUpdater extends Thread {

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					updCurrencyInfo(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	// �x�s����W�٤ΥN�X
	private static LinkedHashMap<String, String> esunBranch = null;

	// �x�s�U�ȥi�H�˻⪺����ξ��c�W�٤ΥN�X
	private static LinkedHashMap<String, String> esunBranchByInPerson = null;

	/**
	 * �d�ߩҦ����s/�˻���
	 * 
	 * @return ���s/�˻���N�X�ΦW��
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getEsunBranch() throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = null;
		try {

			if (esunBranch == null || esunBranch.size() <= 0) {

				esunBranch = new LinkedHashMap<String, String>();

				conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_Out : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);

				sql = "select * from [Common].[dbo].[EsunBranch] where IsValid = 'Y' and brnchType = 'C' order by [brnchType], [sort], [BranchNo] ";

				ps = conn.prepareStatement(sql);

				rs = ps.executeQuery();
				while (rs.next()) {

					esunBranch.put(rs.getString("BranchNo"), StringUtil.getChineseTrim(rs.getString("BankName")));
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (rs != null && !rs.isClosed()) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null && !ps.isClosed()) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
		return esunBranch;
	}

	/**
	 * �d�߿˻���N�X�ΦW��
	 * 
	 * @return �˻���N�X�ΦW��
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getEsunBranchByInPerson() throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = null;
		try {

			if (esunBranchByInPerson == null || esunBranchByInPerson.size() <= 0) {

				esunBranchByInPerson = new LinkedHashMap<String, String>();

				conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_Out : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);

				sql = "select * from [Common].[dbo].[EsunBranch] where IsValid = 'Y' and brnchType = 'C' and InPerson = 'Y' order by [brnchType], [sort], [BranchNo] ";

				ps = conn.prepareStatement(sql);

				rs = ps.executeQuery();
				while (rs.next()) {

					esunBranchByInPerson.put(rs.getString("BranchNo"), StringUtil.getChineseTrim(rs.getString("BankName")));
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (rs != null && !rs.isClosed()) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null && !ps.isClosed()) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
		return esunBranchByInPerson;
	}

	/**
	 * �d�߳��W��
	 * 
	 * @param branchNo
	 *            ���w���s/�˻���N�X
	 * 
	 * @return ���s/�˻���W��
	 * @throws Exception
	 */
	public String getEsunBranch(String branchNo) throws Exception {

		String branchName = "";
		try {

			// �P�_esunBranch�O�_�����
			if (esunBranch == null || esunBranch.size() <= 0) {
				esunBranch = getEsunBranch();
			}
			branchName = esunBranch.get(branchNo);

		} catch (Exception e) {
			throw e;
		}
		return branchName;
	}

	private static TreeMap<String, CommonAGNO> CommonAGNOList = null;

	public CommonAGNO getAGNO(String AGNO) {

		if (CommonAGNOList == null) {
			updAGNOBatch();
		}

		CommonAGNO commonAGNO = CommonAGNOList.get(AGNO);
		if (commonAGNO == null) {
			commonAGNO = new CommonAGNO();
			commonAGNO.setAGNO(AGNO);
			commonAGNO.setCMCNM("�ɤs�Ȧ�");
			commonAGNO.setCMSNM("�ɤs�Ȧ�");
			commonAGNO.setCMENM("E.SUN BANK");
			commonAGNO.setAFCNM("�ɤs�H�Υd");
		}
		return commonAGNO;
	}

	class AgnoUpdater extends Thread {

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					updAGNOBatch();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static boolean isAGNOUpdater = false;
	private static final Object agnolock = new Object();

	protected void updAGNOBatch() {
		synchronized (agnolock) {
			updAGNO();
			if (!isAGNOUpdater) {
				isAGNOUpdater = true;
				new AgnoUpdater().start();
			}
		}
	}

	private void updAGNO() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String sql = "SELECT * FROM [Common].[dbo].[tbAGNO]";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			TreeMap<String, CommonAGNO> tmp_CommonAGNOList = new TreeMap<String, CommonAGNO>();
			CommonAGNO agno = null;
			while (rs.next()) {
				agno = new CommonAGNO();
				agno.setAGNO(rs.getString("AGNO"));
				agno.setCMCNM(rs.getString("CMCNM"));
				agno.setCMSNM(rs.getString("CMSNM"));
				agno.setCMENM(rs.getString("CMENM"));
				agno.setAFCNM(rs.getString("AFCNM"));
				tmp_CommonAGNOList.put(agno.getAGNO(), agno);
			}
			CommonAGNOList = tmp_CommonAGNOList;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	private static HashMap<String, SSBANKDATA> bankData = null;
	private static boolean isBankData = false;
	private static final Object bankDatalock = new Object();

	// ���o�Ȧ��ƦW��
	public HashMap<String, SSBANKDATA> getBankData() throws Exception {
		if (bankData == null) {
			synchronized (bankDatalock) {
				if (!isBankData) {
					setBankNO();
					isBankData = true;
				}
			}
		}
		return bankData;
	}

	/**
	 * ��J�Ȧ�N�X���o�ҹ������Ȧ�W��
	 * 
	 * @param bankNO
	 *            �Ȧ�N�X
	 * @return �Ȧ�W��
	 */

	private void setBankNO() throws Exception {
		ResultSet rs = null;
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = null;
		SSBANKDATA data = null;
		try {
			bankData = new HashMap<String, SSBANKDATA>();
			if (conn == null) {
				conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_Out : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			}
			sql = "select * from [Common].[dbo].[SSBANKDATA]";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				data = new SSBANKDATA();
				data.setBANKNO(rs.getString("BANKNO"));
				data.setBANKNAME(rs.getString("BANKNAME"));
				data.setBANKTEL1(rs.getString("BANKTEL1"));
				data.setBANKTEL2(rs.getString("BANKTEL2"));
				data.setBANKTEL3(rs.getString("BANKTEL3"));
				data.setBANKTEL4(rs.getString("BANKTEL4"));
				data.setBANKFAX(rs.getString("BANKFAX"));
				data.setBATCHNO(rs.getInt("BATCHNO"));
				data.setNOWDATE(rs.getString("NOWDATE"));
				bankData.put(data.getBANKNO(), data);
			}
		} finally {
			try {
				rs.close();
			} catch (Exception e) {
			}

			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * ��J�d�����o�ҹ������d�����Ӹ��
	 * 
	 * @param CardNO
	 *            �H�Υd�d��
	 * @return �d�����Ӹ��
	 */
	public SSBankBin getCardData(String CardNO, Connection conn) throws Exception {
		SSBankBin cardData = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = null;
		try {
			if (CardNO == null || CardNO.length() < 6) {
				return null;
			}
			sql = "select * from [Common].[dbo].[SSBANKBIN] where BINNO in ( ";

			if (CardNO.length() >= 6) {
				sql += "?,";
			}
			if (CardNO.length() >= 8) {
				sql += "?,";
			}
			if (CardNO.length() >= 9) {
				sql += "?,";
			}

			sql = sql.substring(0, sql.length() - 1) + ")";

			ps = conn.prepareStatement(sql);
			if (CardNO.length() >= 6) {
				ps.setString(1, CardNO.substring(0, 6));
			}
			if (CardNO.length() >= 8) {
				ps.setString(2, CardNO.substring(0, 8));
			}
			if (CardNO.length() >= 9) {
				ps.setString(3, CardNO.substring(0, 9));
			}

			rs = ps.executeQuery();
			if (rs.next()) {
				cardData = new SSBankBin();
				cardData.setBinNo(rs.getString("BINNO"));
				cardData.setBankNo(rs.getString("BANKNO"));
				cardData.setBankType(rs.getString("BANKTYPE"));
				cardData.setBrand(rs.getString("BRAND"));
				cardData.setCardType(rs.getString("CARDTYPE"));
			}
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
			}
		}
		return cardData;
	}

	/**
	 * �O�_�O�ɤsBIN
	 */
	private static HashMap<String, SSBankBin> ESunCardBinNo = null;
	private static boolean isInit = false; // �O�_��esun��BinNo
	private static final Object ESunBankBinNo = new Object();

	/**
	 * �O�_�O�ɤs�d
	 * 
	 * @param ����d��
	 */
	public boolean isEsunCard(String cano) throws Exception {
		if (ESunCardBinNo == null) {
			synchronized (ESunBankBinNo) {
				if (!isInit) {
					updEsunCard();
					isInit = true;
				}
			}
		}
		return ESunCardBinNo.containsKey(cano.substring(0, 6));
	}

	/**
	 * ���o�ɤsBIN���
	 * 
	 * @param ����d��
	 */
	public SSBankBin getEsunCardBinData(String cano) throws Exception {
		if (ESunCardBinNo == null) {
			synchronized (ESunBankBinNo) {
				if (!isInit) {
					updEsunCard();
					isInit = true;
				}
			}
		}
		return ESunCardBinNo.get(cano.substring(0, 6));
	}

	// thread ��s EsunCardData()
	private static boolean isEsunUpdater = false;
	private static final Object esunlock = new Object();

	protected void updEsunCard() throws Exception {
		synchronized (esunlock) {
			setEsunCardData();
			if (!isEsunUpdater) {
				isEsunUpdater = true;
				new EsunCardDataUpdater().start();
			}
		}
	}

	class EsunCardDataUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					setEsunCardData();
				} catch (Exception e) {

				}
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
			}
		}
	}

	// ���o�ɤsBIN���Dao
	private void setEsunCardData() throws Exception {
		ESunCardBinNo = new HashMap<String, SSBankBin>();
		SSBankBin cardData = null;
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = null;
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_Out : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			sql = "select * from [Common].[dbo].[SSBANKBIN] where BANKNO = '808' ";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				cardData = new SSBankBin();
				cardData.setBinNo(rs.getString("BINNO"));
				cardData.setBankNo(rs.getString("BANKNO"));
				cardData.setBankType(rs.getString("BANKTYPE"));
				cardData.setBrand(rs.getString("BRAND"));
				cardData.setCardType(rs.getString("CARDTYPE"));
				ESunCardBinNo.put(rs.getString("BINNO"), cardData);
			}
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
		// return ESunCardBinNo;
	}

	/**
	 * ���o�Ҧ�FXML��w
	 */
	public ArrayList<BankDataCtl> getFXMLBankCtl(Connection conn) throws Exception {
		ArrayList<BankDataCtl> rslt = null;
		BankDataCtl tmp = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = null;
		try {
			sql = "SELECT * FROM Common.dbo.BankDataCtl where isFXML= '1'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs != null) {
				rslt = new ArrayList<BankDataCtl>();
			}
			while (rs.next()) {
				tmp = new BankDataCtl();
				tmp.setBANKID(rs.getString("BANKID"));
				tmp.setBANKCNAME(rs.getString("BANKCNAME"));
				tmp.setBANKENAME(rs.getString("BANKENAME"));
				tmp.setSTATUS(rs.getString("STATUS"));
				tmp.setCHANNEL(rs.getString("CHANNEL"));
				tmp.setSALBANK(rs.getString("SALBANK"));
				tmp.setATM(rs.getString("isATM").equals("1") ? true : false);
				tmp.setRMT(rs.getString("isRMT").equals("1") ? true : false);
				tmp.setFEDI(rs.getString("isFEDI").equals("1") ? true : false);
				tmp.setFXML(rs.getString("isFXML").equals("1") ? true : false);
				rslt.add(tmp);
			}
		} finally { // conn do not close
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
		return rslt;
	}

	/**
	 * ���o��w�������
	 */
	public ArrayList<BankDataDtl> getBankDtl(String BANKID, Connection conn) throws Exception {
		ArrayList<BankDataDtl> rslt = null;
		BankDataDtl tmp = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = null;
		try {
			sql = "SELECT * FROM Common.dbo.BankDataDtl where BANKID= ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, BANKID);
			rs = ps.executeQuery();
			if (rs != null) {
				rslt = new ArrayList<BankDataDtl>();
			}
			while (rs.next()) {
				tmp = new BankDataDtl();
				tmp.setXTYPE(rs.getString("XTYPE"));
				tmp.setBANKID(rs.getString("BANKID"));
				tmp.setBRANCHID(rs.getString("BRANCHID"));
				tmp.setBANKNAME(rs.getString("BANKNAME"));
				tmp.setBRANCHNAME(rs.getString("BRANCHNAME"));
				tmp.setBRANCHADDR(rs.getString("BRANCHADDR"));
				tmp.setBRANCHPHONE(rs.getString("BRANCHPHONE"));
				tmp.setBRANCHDATE(rs.getString("BRANCHDATE"));
				tmp.setRY(rs.getString("RY"));
				tmp.setRM(rs.getString("RM"));
				rslt.add(tmp);
			}
		} finally { // conn do not close
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
		return rslt;
	}

	private static ArrayList<NCCCCardVerify> cardVerifyBank = null;
	private static final Object CardVerifyBankDatalock = new Object();
	private static boolean isCardVerifyBankUpdater = false;
	private static String cardVerifyBankName = null;

	/**
	 * ���oNCCC �H�Υd���һȦ�W��
	 */
	public String getCardVerifyBankName() throws Exception {
		if (cardVerifyBank == null) {
			updCardVerifyBank();
		}
		return cardVerifyBankName;
	}

	/**
	 * ���oNCCC �H�Υd���һȦ�
	 */
	public ArrayList<NCCCCardVerify> getCardVerifyBank() throws Exception {
		if (cardVerifyBank == null) {
			updCardVerifyBank();
		}
		return cardVerifyBank;
	}

	private void updCardVerifyBank() throws Exception {
		try {
			synchronized (CardVerifyBankDatalock) {
				if (cardVerifyBank == null) {
					getCardVerifyBankData();
				}
				if (!isCardVerifyBankUpdater) {
					isCardVerifyBankUpdater = true;
					new CardVerifyBankUpdater().start();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	class CardVerifyBankUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getCardVerifyBankData();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void getCardVerifyBankData() throws Exception {
		NCCCCardVerify tmp = null;
		Connection conn = null;
		ArrayList<NCCCCardVerify> rslt = new ArrayList<NCCCCardVerify>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = null;
		try {
			if (conn == null) {
				conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress_DB : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			}
			sql = "SELECT * FROM Common.dbo.NCCCCardVerify ";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				tmp = new NCCCCardVerify();
				tmp.setBANKID(rs.getString("bANKID"));
				tmp.setBANKCNAME(StringUtil.getChineseTrim(rs.getString("bANKCNAME")));
				rslt.add(tmp);
			}
			if (rslt != null && rslt.size() > 0) {
				cardVerifyBank = rslt;
				String tmpBankName = "";
				for (int i = 0; i < cardVerifyBank.size(); i++) {
					tmpBankName += "�B" + cardVerifyBank.get(i).getBANKCNAME();
				}
				cardVerifyBankName = tmpBankName.substring(1);
			}
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
	}

	private static LinkedHashMap<String, HostConfig> nationalityData = null;
	private static final Object NationalityDataLock = new Object();
	private static boolean isNationalityDataUpdater = false;

	/**
	 * ���o���y���
	 * 
	 * @return LinkedHashMap<String, HostConfig>
	 */
	public LinkedHashMap<String, HostConfig> getNationalitySelectData() throws Exception {
		if (nationalityData == null) {
			updNationalityData();
		}
		return nationalityData;
	}

	/**
	 * ��s���y��ƨåB�Ұ�thread�w�ɧ�s���
	 */
	private void updNationalityData() throws Exception {
		try {
			synchronized (NationalityDataLock) {
				if (nationalityData == null) {
					getNationalityData();
				}
				if (!isNationalityDataUpdater) {
					isNationalityDataUpdater = true;
					new NationalityDataUpdater().start();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	class NationalityDataUpdater extends Thread {
		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getNationalityData();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * ���o���y��ơA�j����01�B������121(�ѷӥD��B3000�]�w)
	 * 
	 * @throws Exception
	 **/
	private void getNationalityData() throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		HostConfig hostConfig = null;
		LinkedHashMap<String, HostConfig> nationalityData_temp = new LinkedHashMap<String, HostConfig>();
		String sql = "select * from [Common].[dbo].[HostConfig] where TTPCD ='01' and STPCD = '121'";

		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);

			rs = ps.executeQuery();
			while (rs.next()) {
				hostConfig = new HostConfig();
				hostConfig.setTTPCD(rs.getString("TTPCD"));
				hostConfig.setSTPCD(rs.getString("STPCD"));
				hostConfig.setNOCD(StringUtil.getChineseTrimR(rs.getString("NOCD")));
				hostConfig.setNMCDD(StringUtil.getChineseTrimR(rs.getString("NMCDD")));
				hostConfig.setDMARK(rs.getString("DMARK"));
				nationalityData_temp.put(hostConfig.getNOCD(), hostConfig);
			}

			if (!nationalityData_temp.isEmpty()) {
				nationalityData = nationalityData_temp;
			}
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
	}

	/***********************************
	 * Nationality Parameter
	 *******************************/
	private static LinkedHashMap<String, HostConfig> hostData = null;
	private static final Object HostDataLock = new Object();
	private static boolean isHostDataUpdater = false;

	/**
	 * ��TTPCD,STPCD���o�S�w�N�X��
	 * 
	 * @param TTPCD,STPCD
	 * @return LinkedHashMap<String, HostConfig>
	 * @author ESB20138
	 */
	public LinkedHashMap<String, HostConfig> getHostConfigSelectData(String TTPCD, String STPCD) throws Exception {
		LinkedHashMap<String, HostConfig> hostDataNotNull = null;
		String key = TTPCD + STPCD;

		if (hostData == null) {
			updHostData();
		}

		hostDataNotNull = new LinkedHashMap<String, HostConfig>(hostData);

		Iterator<String> it = hostDataNotNull.keySet().iterator();
		while (it.hasNext()) {
			String obj = it.next();
			if (!obj.startsWith(key)) {
				it.remove();
			}
		}

		return hostDataNotNull;

	}

	/**
	 * ��s�N�X����ƨåB�Ұ�thread�w�ɧ�s���
	 * 
	 * @author ESB20138
	 */
	private void updHostData() throws Exception {
		try {
			synchronized (HostDataLock) {
				if (hostData == null) {
					getHostData();
				}
				if (!isHostDataUpdater) {
					isHostDataUpdater = true;
					new HostDataUpdater().start();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * ��s�N�X����ƨåB�Ұ�thread�w�ɧ�s���
	 * 
	 * @author ESB20138
	 */
	class HostDataUpdater extends Thread {

		public void run() {
			while (true) {
				try {
					Thread.sleep(24 * 60 * 60 * 1000);
				} catch (Exception e) {
				}
				try {
					getHostData();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * ���o�N�X�����(�ѷӥD��B3000�]�w)
	 * 
	 * @throws Exception
	 * @author ESB20138
	 **/
	private void getHostData() throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		HostConfig hostConfig = null;
		LinkedHashMap<String, HostConfig> nationalityData_temp = new LinkedHashMap<String, HostConfig>();

		String sql = "select * from [Common].[dbo].[HostConfig]";
		try {
			conn = new DBUtil().getSQLConn(dbHost.equals("") ? commonDBAdress : dbHost, commonDBPort, commonDBName, commonDBID, commonDBPassword, false);
			ps = conn.prepareStatement(sql);

			rs = ps.executeQuery();

			while (rs.next()) {
				hostConfig = new HostConfig();
				hostConfig.setTTPCD(rs.getString("TTPCD"));
				hostConfig.setSTPCD(rs.getString("STPCD"));
				hostConfig.setNOCD(StringUtil.getChineseTrimR(rs.getString("NOCD")));
				hostConfig.setNMCDD(StringUtil.getChineseTrimR(rs.getString("NMCDD")));
				hostConfig.setDMARK(rs.getString("DMARK"));
				nationalityData_temp.put(rs.getString("TTPCD") + rs.getString("STPCD") + StringUtil.getChineseTrimR(rs.getString("NOCD")), hostConfig);
			}

			if (!nationalityData_temp.isEmpty()) {
				hostData = nationalityData_temp;
			}

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
			}
		}
	}

}
