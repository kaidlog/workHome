package esunbank.esunutil;

public class BankDataDtl {

	private String XTYPE;// �ݩʥN��
	private String BANKID;// �q�צ����ݻȦ�N�X
	private String BRANCHID;// �q�צ�N�X
	private String BANKNAME;// �q�צ�W��
	private String BRANCHNAME;// �q�צ����ݻȦ�W��
	private String BRANCHADDR;// �q�צ�a�}
	private String BRANCHPHONE;// �q�צ�q��
	private String BRANCHDATE;// �ͮĤ��
	private String RY;// �e���ܧ󫬺A
	private String RM;// �q�׷~�ȵ��O�A�L�q�׷~�Ȫ̬��ť�

	public String getXTYPE() {
		return XTYPE;
	}

	public void setXTYPE(String xTYPE) {
		XTYPE = xTYPE;
	}

	public String getBANKID() {
		return BANKID;
	}

	public void setBANKID(String bANKID) {
		BANKID = bANKID;
	}

	public String getBRANCHID() {
		return BRANCHID;
	}

	public void setBRANCHID(String bRANCHID) {
		BRANCHID = bRANCHID;
	}

	public String getBANKNAME() {
		return BANKNAME;
	}

	public void setBANKNAME(String bANKNAME) {
		BANKNAME = bANKNAME;
	}

	public String getBRANCHNAME() {
		return BRANCHNAME;
	}

	public void setBRANCHNAME(String bRANCHNAME) {
		BRANCHNAME = bRANCHNAME;
	}

	public String getBRANCHADDR() {
		return BRANCHADDR;
	}

	public void setBRANCHADDR(String bRANCHADDR) {
		BRANCHADDR = bRANCHADDR;
	}

	public String getBRANCHPHONE() {
		return BRANCHPHONE;
	}

	public void setBRANCHPHONE(String bRANCHPHONE) {
		BRANCHPHONE = bRANCHPHONE;
	}

	public String getBRANCHDATE() {
		return BRANCHDATE;
	}

	public void setBRANCHDATE(String bRANCHDATE) {
		BRANCHDATE = bRANCHDATE;
	}

	public String getRY() {
		return RY;
	}

	public void setRY(String rY) {
		RY = rY;
	}

	public String getRM() {
		return RM;
	}

	public void setRM(String rM) {
		RM = rM;
	}

}
