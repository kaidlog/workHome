package esunbank.esunutil;

import java.sql.Timestamp;
import java.util.*;
import java.text.*;

public class DateUtil {

	/** �Ǧ^�t�ήɶ� �榡:YYYYMMDD */
	public static String getNowDate() {
		return getDateTime(new GregorianCalendar(), DateUtil.DateFmt_Mode_Date);
	}

	/** �Ǧ^�t�ήɶ� �榡:YYYYMMDDHHMMSS */
	public static String getNowDateTime() {
		return getDateTime(new GregorianCalendar(), DateUtil.DateFmt_Mode_Datetime);
	}

	/** �Ǧ^�t�ήɶ� �榡:yyyyMMddHHmmssSSS */
	public static String getNowDateTimeMillisecond() {
		return getDateTime(new GregorianCalendar(), DateUtil.DateFmt_Mode_Datetime_Millisecond);
	}

	/**
	 * �ഫTimestamp���r��<br>
	 * 
	 * @param splt1
	 *            :�~�����j�Ÿ�<br>
	 *            splt2:�ɤ������j�Ÿ�<br>
	 *            splt3:��ɤ��j�Ÿ� <br>
	 * @param mode
	 *            =DateUtil.DateFmt_Mode_Date:�~���<br>
	 *            mode=DateUtil.DateFmt_Mode_Time:�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime:�~���+�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime_Millisecond:�~���+�ɤ���+�@��
	 */
	public static String getNowDateTime(String splt1, String splt2, String splt3, int mode) {
		return fmtCalendar(new GregorianCalendar(), getDateFormat(splt1, splt2, splt3, mode));
	}

	/**
	 * �ഫTimestamp���r��<br>
	 * 
	 * @param splt1
	 *            :�~�����j�Ÿ�<br>
	 *            splt2:�ɤ������j�Ÿ�<br>
	 *            splt3:��ɤ��j�Ÿ� <br>
	 *            splt4:���@�����j�Ÿ� <br>
	 * @param mode
	 *            =DateUtil.DateFmt_Mode_Date:�~���<br>
	 *            mode=DateUtil.DateFmt_Mode_Time:�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime:�~���+�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime_Millisecond:�~���+�ɤ���+�@��
	 */

	public static String getNowDateTime(String splt1, String splt2, String splt3, String splt4, int mode) {
		return fmtCalendar(new GregorianCalendar(), getDateFormat(splt1, splt2, splt3, splt4, mode));
	}

	/**
	 * @param dateTimeType
	 *            DateFmt_Mode_Datetime_Millisecond->yyyyMMddHHmmssSSS
	 *            DateUtil.DateFmt_Mode_Datetime->yyyyMMddHHmmss
	 *            DateUtil.DateFmt_Mode_Date->yyyyMMdd
	 *            DateUtil.DateFmt_Mode_Time->HHmmss
	 */
	public static String getDateTime(GregorianCalendar gc, int dateTimeType) {
		if (dateTimeType == DateFmt_Mode_Datetime_Millisecond) {
			return fmtCalendar(gc, "yyyyMMddHHmmssSSS");
		} else if (dateTimeType == DateFmt_Mode_Datetime) {
			return fmtCalendar(gc, "yyyyMMddHHmmss");
		} else if (dateTimeType == DateFmt_Mode_Date) {
			return fmtCalendar(gc, "yyyyMMdd");
		} else if (dateTimeType == DateFmt_Mode_Time) {
			return fmtCalendar(gc, "HHmmss");
		} else {
			return null;
		}
	}

	// yyyy-MM-dd HH:mm:ss
	public static String fmtNowCalendar(String format) {
		return fmtCalendar(Calendar.getInstance(), format);
	}

	// yyyy-MM-dd HH:mm:ss
	public static String fmtCalendar(Calendar cal, String format) {
		return new SimpleDateFormat(format).format(cal.getTime());
	}

	public static final int DateFmt_Mode_Date = 1;
	public static final int DateFmt_Mode_Time = 2;
	public static final int DateFmt_Mode_Datetime = 3;
	public static final int DateFmt_Mode_Datetime_Millisecond = 4;

	/**
	 * �ഫCalendar���r��<br>
	 * 
	 * @param splt1
	 *            :�~�����j�Ÿ�<br>
	 *            splt2:�ɤ������j�Ÿ�<br>
	 *            splt3:��ɤ��j�Ÿ� <br>
	 * @param mode
	 *            =DateUtil.DateFmt_Mode_Date:�~���<br>
	 *            mode=DateUtil.DateFmt_Mode_Time:�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime:�~���+�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime_Millisecond:�~���+�ɤ���+�@��
	 */
	public static String fmtCalendar(Calendar calendar, String splt1, String splt2, String splt3, int mode) {
		return fmtCalendar(calendar, getDateFormat(splt1, splt2, splt3, mode));
	}

	public static String fmtTimestamp(Timestamp Timestamp, String splt1, String splt2, String splt3, int mode) {
		return fmtCalendar(timestamp2gc(Timestamp), getDateFormat(splt1, splt2, splt3, mode));
	}

	/**
	 * �ഫCalendar���r��<br>
	 * 
	 * @param splt1
	 *            :�~�����j�Ÿ�<br>
	 *            splt2:�ɤ������j�Ÿ�<br>
	 *            splt3:��ɤ��j�Ÿ� <br>
	 *            splt4:���@�����j�Ÿ� <br>
	 * @param mode
	 *            =DateUtil.DateFmt_Mode_Date:�~���<br>
	 *            mode=DateUtil.DateFmt_Mode_Time:�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime:�~���+�ɤ���<br>
	 *            mode=DateUtil.DateFmt_Mode_Datetime_Millisecond:�~���+�ɤ���+�@��
	 */

	public static String fmtCalendar(Calendar calendar, String splt1, String splt2, String splt3, String splt4, int mode) {
		return fmtCalendar(calendar, getDateFormat(splt1, splt2, splt3, splt4, mode));
	}

	public static String fmtTimestamp(Timestamp Timestamp, String splt1, String splt2, String splt3, String splt4, int mode) {
		return fmtCalendar(timestamp2gc(Timestamp), getDateFormat(splt1, splt2, splt3, splt4, mode));
	}

	/** GregorianCalendar->Timestamp */
	public static Timestamp gc2timestamp(GregorianCalendar gc) {
		return new Timestamp(gc.getTimeInMillis());
	}

	/** Timestamp->GregorianCalendar */
	public static GregorianCalendar timestamp2gc(Timestamp timestamp) {
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(timestamp);
		return gc;
	}

	/**
	 * @param yyyymmddhhmmss
	 * @throws ParseException
	 */
	public static GregorianCalendar fmtDateTimeStr(String yyyymmddhhmmss) throws ParseException {

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(yyyymmddhhmmss));
		return gc;
	}

	/**
	 * @param yyyymmddhhmmssSSS
	 * @throws ParseException
	 */
	public static GregorianCalendar fmtDateTimeMilliSecondStr(String yyyymmddhhmmssSSS) throws ParseException {

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(yyyymmddhhmmssSSS));
		return gc;
	}

	private static String getDateFormat(String splt1, String splt2, String splt3, int mode) {
		return getDateFormat(splt1, splt2, splt3, ".", mode);
	}

	private static String getDateFormat(String splt1, String splt2, String splt3, String splt4, int mode) {
		StringBuffer result = new StringBuffer();
		if (mode == DateFmt_Mode_Date || mode == DateFmt_Mode_Datetime || mode == DateFmt_Mode_Datetime_Millisecond) {
			result.append("yyyy").append(splt1).append("MM").append(splt1).append("dd");
		}
		if (mode == DateFmt_Mode_Time || mode == DateFmt_Mode_Datetime || mode == DateFmt_Mode_Datetime_Millisecond) {
			if (mode == DateFmt_Mode_Datetime || mode == DateFmt_Mode_Datetime_Millisecond) {
				result.append(splt3);
			}
			result.append("HH").append(splt2).append("mm").append(splt2).append("ss");
		}
		if (mode == DateFmt_Mode_Datetime_Millisecond) {
			result.append(splt4).append("SSS");
		}
		return result.toString();
	}

	/**
	 * �P�_����r��O�_�ŦX�W�h(default yyyyMMdd)
	 * 
	 * @return boolean �O�_�ŦX
	 */
	public static boolean checkDateFormat(String sdate) {
		return checkDateFormat(sdate, "yyyyMMdd");
	}

	/**
	 * �P�_����r��O�_�ŦX�W�h(parse by pattern)
	 * 
	 * @param pattern
	 *            �P�_�W��pattern
	 * @return boolean �O�_�ŦX
	 */
	public static boolean checkDateFormat(String sdate, String pattern) {
		try {
			SimpleDateFormat dFormat = new SimpleDateFormat(pattern);
			dFormat.setLenient(false);
			dFormat.parse(sdate);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	/**
	 * ���o������~�g��
	 * 
	 * @param tms
	 * @return week of year (01, 02, ...,53)
	 */

	public static String getWeekOfYear(Timestamp tms) {
		Calendar cal = DateUtil.timestamp2gc(tms);
		int ordinalDay = cal.get(Calendar.DAY_OF_YEAR);
		int weekDay = cal.get(Calendar.DAY_OF_WEEK) - 1; // Sunday = 0
		int numberOfWeeks = (ordinalDay - weekDay + 10) / 7;
		return StringUtil.apdSpltL(2, String.valueOf(numberOfWeeks), "0");
	}

	/**
	 * @param yyyymmddhhmmssSSS
	 * @return Timestamp
	 */

	public static Timestamp fmDateTimeMSToTimestamp(String yyyymmddhhmmssSSS) throws Exception {
		return gc2timestamp(fmtDateTimeMilliSecondStr(yyyymmddhhmmssSSS));
	}

	/**
	 * @param yyyymmddhhmmss
	 * @return Timestamp
	 */

	public static Timestamp fmDateTimeToTimestamp(String yyyymmddhhmmss) throws Exception {
		return gc2timestamp(fmtDateTimeStr(yyyymmddhhmmss));
	}

}
