package esunbank.esunutil;

public class CurrencyInfo {

	private String POSID;
	
	private String Currency;
	
	private String Code;
	
	private String CurrencyDesc;
	
	private String Info;

	public String getPOSID() {
		return POSID;
	}

	public void setPOSID(String pOSID) {
		POSID = pOSID;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getCurrencyDesc() {
		return CurrencyDesc;
	}

	public void setCurrencyDesc(String currencyDesc) {
		CurrencyDesc = currencyDesc;
	}

	public String getInfo() {
		return Info;
	}

	public void setInfo(String info) {
		Info = info;
	}
	
}
