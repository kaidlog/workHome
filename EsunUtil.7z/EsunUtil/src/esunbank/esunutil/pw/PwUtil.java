package esunbank.esunutil.pw;

import java.util.ResourceBundle;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.JSONObject;

public class PwUtil {
	protected static ResourceBundle config = ResourceBundle.getBundle("esunbank.esunutil.pw.config");

	private static final String checkPwHost = config.getString("pwServiceHost") + ":"
			+ config.getString("pwServicePort") + config.getString("pwService") + "/checkSavePwd";
	private static final String genPwHost = config.getString("pwServiceHost") + ":" + config.getString("pwServicePort")
			+ config.getString("pwService") + "/genPwd";

	/**
	 * �K�X�ˮ�-���x�s
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param String
	 *            UserPwd �K�X
	 * 
	 * @return CSPwResponse
	 *         ���\:CSPwResponse.Rslt=="OK"�B����:CSPwResponse.Rslt=="FALSE"
	 */
	public CSPwResponse checkPwNotSave(String SystemID, String UserID, String UserPwd) {
		return checkPw(SystemID, UserID, UserPwd, Boolean.FALSE);
	}

	/**
	 * �K�X�ˮ�-�Y�q�L�ˮ֫K�x�s�ӱK�X
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param String
	 *            UserPwd �K�X
	 * 
	 * @return CSPwResponse
	 *         ���\:CSPwResponse.Rslt=="OK"�B����:CSPwResponse.Rslt=="FALSE"
	 */
	public CSPwResponse checkPwSave(String SystemID, String UserID, String UserPwd) {
		return checkPw(SystemID, UserID, UserPwd, Boolean.TRUE);
	}

	/**
	 * �K�X�ˮ�-�Ѽ�(isSave)�M�w�x�s�P�_
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param String
	 *            UserPwd �K�X
	 * @param boolean
	 *            isSave true:�q�L�ˮ֫��x�s�Bfalse:���x�s
	 * 
	 * @return CSPwResponse
	 *         ���\:CSPwResponse.Rslt=="OK"�B����:CSPwResponse.Rslt=="FALSE"
	 */
	public CSPwResponse checkPw(String SystemID, String UserID, String UserPwd, boolean isSave) {
		CSPwResponse response = new CSPwResponse();

		PostMethod post = null;
		HttpClient httpclient;
		
		response.setSuccess(false);
		response.setRsCode("99");
		response.setRsMsg("�t�Φ��L���A�еy�ԦA��");
		try {
			if (null == SystemID || "".equals(SystemID)) {
				response.setRsCode("E1");
			} else if (null == UserID || "".equals(UserID)) {
				response.setRsCode("E2");
			} else if (null == UserPwd || "".equals(UserPwd)) {
				response.setRsCode("E3");
			} else {
				// �s��
				httpclient = new HttpClient();
				post = new PostMethod(checkPwHost);
				post.addParameter("SystemID", SystemID);
				post.addParameter("UserID", UserID);
				post.addParameter("UserPwd", UserPwd);
				post.addParameter("ActType", isSave ? "S" : "C");

				httpclient.executeMethod(post);
				// ���o�^�ǵ��G
				JSONObject obj = new JSONObject(post.getResponseBodyAsString());

				if ("OK".equals(obj.getString("Rslt"))) {
					response.setSuccess(true);
				} else {
					response.setSuccess(false);
					response.setRsCode(obj.getString("RsCode"));
					response.setRsMsg(obj.getString("RsMsg"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setRsCode("99");
			response.setRsMsg("�t�Φ��L���A�еy�ԦA��");
		} finally {
			if (post != null) {
				post.releaseConnection();
			}
		}

		return response;
	}

	/**
	 * �����H���K�X-���x�s
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param int
	 *            PwdLength �K�X���
	 * 
	 * @return GPwResponse
	 *         ���\:GPwResponse.Rslt=="OK"�B����:GPwResponse.Rslt=="FALSE"
	 */
	public GPwResponse genPwNotSave(String SystemID, String UserID, int PwdLength) {
		return genPw(SystemID, UserID, PwdLength, Boolean.FALSE);
	}

	/**
	 * �����H���K�X-�����x�s�ӱK�X
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param int
	 *            PwdLength �K�X���
	 * 
	 * @return GPwResponse
	 *         ���\:GPwResponse.Rslt=="OK"�B����:GPwResponse.Rslt=="FALSE"
	 */
	public GPwResponse genPwSave(String SystemID, String UserID, int PwdLength) {
		return genPw(SystemID, UserID, PwdLength, Boolean.TRUE);
	}

	/**
	 * �����H���K�X-�Ѽ�(isSave)�M�w�x�s�P�_
	 * 
	 * @param String
	 *            SystemID �t�ΥN�X
	 * @param String
	 *            UserID �b��
	 * @param int
	 *            PwdLength �K�X���
	 * @param boolean
	 *            isSave true:���ͨ��x�s�Bfalse:�Ȧ^���H���K�X�A���x�s
	 * 
	 * @return GPwResponse
	 *         ���\:GPwResponse.Rslt=="OK"�B����:GPwResponse.Rslt=="FALSE"
	 */
	public GPwResponse genPw(String SystemID, String UserID, int PwdLength, boolean isSave) {
		GPwResponse response = new GPwResponse();

		PostMethod post = null;
		HttpClient httpclient;
		
		response.setSuccess(false);
		response.setRsCode("99");
		try {
			if (null == SystemID || "".equals(SystemID)) {
				response.setRsCode("E1");
			} else if (null == UserID || "".equals(UserID)) {
				response.setRsCode("E2");
			} else if (PwdLength <= 0) {
				response.setRsCode("E5");
			} else {
				// �s��
				httpclient = new HttpClient();
				post = new PostMethod(genPwHost);
				post.addParameter("SystemID", SystemID);
				post.addParameter("UserID", UserID);
				post.addParameter("PwdLength", String.valueOf(PwdLength));
				post.addParameter("IsAutoCommit", isSave ? "Y" : "N");

				httpclient.executeMethod(post);
				// ���o�^�ǵ��G
				JSONObject obj = new JSONObject(post.getResponseBodyAsString());

				if ("OK".equals(obj.getString("Rslt"))) {
					response.setSuccess(true);
					response.setPwd(obj.getString("Pwd"));
					response.setRsCode(obj.getString("RsCode"));
				} else {
					response.setSuccess(false);
					response.setRsCode(obj.getString("RsCode"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setRsCode("99");
		} finally {
			if (post != null) {
				post.releaseConnection();
			}
		}

		return response;
	}
}
