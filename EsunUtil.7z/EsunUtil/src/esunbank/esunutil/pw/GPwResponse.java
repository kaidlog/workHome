package esunbank.esunutil.pw;

public class GPwResponse {
	/**
	 * ���G
	 * */
	private boolean isSuccess;
	/**
	 * �K�X(���\�~����)
	 * */
	private String Pwd;
	
	private String RsCode;
	
	public String getRsCode() {
		return RsCode;
	}
	public void setRsCode(String rsCode) {
		RsCode = rsCode;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getPwd() {
		return Pwd;
	}
	public void setPwd(String pwd) {
		Pwd = pwd;
	}
	
}
