package esunbank.esunutil.pw;

public class CSPwResponse {
	/**
	 * �O�_���\
	 * */
	private boolean isSuccess;
	/**
	 * ���~�N�X(���Ѥ~����)
	 * */
	private String RsCode;
	/**
	 * ���~�T��(���Ѥ~����)
	 * */
	private String RsMsg;
	
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getRsCode() {
		return RsCode;
	}
	public void setRsCode(String rsCode) {
		RsCode = rsCode;
	}
	public String getRsMsg() {
		return RsMsg;
	}
	public void setRsMsg(String rsMsg) {
		RsMsg = rsMsg;
	}

}
