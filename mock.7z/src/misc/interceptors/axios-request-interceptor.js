import Vue from "vue";
import store from "@store";
import messageBridgeApi from "@api/core/message-bridge-api";

/**
 * 攔截每個AJAX HTTP Request進行處理
 * @param {*} config
 */
const handleRequest = config => {
  // Request發送出去後500ms，才將次數加1，避免回應很快的Request一樣會轉圈圈 -------------------------------------------
  setTimeout(function() {
    store.dispatch("doIncrementAjaxReq");
  }, 500);

  if (Vue.prototype.$keycloak.token) {
    config.headers.Authorization = "Bearer " + Vue.prototype.$keycloak.token;
  }

  messageBridgeApi.notifyCountdownReset();
  store.dispatch("doResetSessionExpiredTime");

  return config;
};

/**
 * 攔截每個AJAX HTTP Request Error進行處理
 * @param {*} error
 */
const handleRequestError = error => {
  return Promise.reject(error);
};

export { handleRequest, handleRequestError };
