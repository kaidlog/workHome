import Vue from "vue";
import store from "@store";
import router from "@router";

/**
 * 顯示伺服器端告知使用者的訊息
 * @param {*} msgs
 */
const showMessage = msgs => {
  if (!msgs || Vue._.size(msgs) < 1) {
    return;
  }

  let style = "'margin-left: 25px; text-align: left'";

  let html = "<div style=" + style + "><ol><li>";
  html += Vue._.join(msgs, "</li><li>");
  html += "</li></ol></div>";

  Vue.swal({
    icon: "warning",
    html: html,
    showCancelButton: false,
    allowOutsideClick: false,
    buttonsStyling: true,
    allowEscapeKey: true
  });
};

/**
 * 攔截每個AJAX HTTP Response進行處理
 * @param {*} response
 */
const handleResponse = response => {
  store.dispatch("doDecrementAjaxReq");
  showMessage(response.data.msg);
  return response;
};

/**
 * 攔截每個AJAX HTTP Response Error進行處理
 * @param {*} error
 */
const handleResponseError = error => {
  store.dispatch("doDecrementAjaxReq");
  Vue.$log.error("handleResponseError", error);

  /**
   * 401: (Unauthorized)代表客戶端錯誤，指的是由於缺乏目標資源要求的身份驗證憑證，發送的請求未得到滿足
   */
  if (error.response && error.response.status === 401) {
    router.push("/unauthorized");
    return Promise.reject(error);
  }

  /**
   * 403: (Forbidden)代表客戶端錯誤，指的是服務器端有能力處理該請求，但是拒絕授權訪問
   */
  if (error.response && error.response.status === 403) {
    router.push("/forbidden");
    return Promise.reject(error);
  }

  /**
   * 412: (Precondition Failed)傳入參數不符Server端預期
   */
  if (error.response && error.response.status === 412) {
    showMessage(error.response.data.msg);
    return Promise.reject(error);
  }

  /**
   * 401(Unauthorized)、403(Forbidden)及412: (Precondition Failed)以外，其他類型錯誤
   */
  store.dispatch("doUpdateAjaxSpanId", { spanId: error.response.data.spanId });
  router.push("/error");
  return Promise.reject(error);
};

export { handleResponse, handleResponseError };
