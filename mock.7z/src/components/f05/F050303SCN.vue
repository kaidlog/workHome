<template>
  <div>
    <Modal
      width="80"
      v-model="isCompositeModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 設定複合 | {{ role.roleNm }}</span>
      </p>
      <Form :model="formValidate" ref="formValidate" :label-width="120">
        <Row>
          <Col span="8">
            <FormItem label="角色類別" prop="roleType">
              <sys-cd-select
                :ctId="42"
                :value.sync="formValidate.roleType"
                clearable
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="角色名稱" prop="roleNm">
              <Input
                v-model="formValidate.roleNm"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button
            @click="searchRoles"
            :disabled="viewComponentCtrl.isQryBtnDisabled"
          >
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row
        v-show="viewComponentCtrl.isQryBtnDisabled"
        type="flex"
        justify="center"
      >
        <span style="color: grey">
          <Icon type="ios-information-circle-outline" />
          提醒：如需以上方條件查詢角色，請先完成或取消目前設定
        </span>
      </Row>
      <br />

      <Transfer
        :data="transferData"
        :target-keys="targetKeys"
        @on-change="handleChange"
        :list-style="{ width: '45%', height: '300px' }"
        :operations="['移除', '新增']"
        :titles="['可選角色', '複合角色']"
        filterable
      />
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdCompositeRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdCompositeRole">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f050303Api from "@api/f05/f050303-api";
import exclusiveApi from "@api/common/exclusive-api";

export default {
  components: {},
  props: {
    // 是否顯示對話框
    isCompositeModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來角色資訊
    roleInfo: {
      type: Object,
      default: function() {
        return {
          // 角色狀態
          roleSts: "",
          // 角色代碼
          roleId: "",
          // 角色類別
          roleType: "",
          // 角色說明
          roleMemo: "",
          // 角色名稱
          roleNm: ""
        };
      }
    }
  },
  data() {
    return {
      // 穿梭框角色物件清單
      transferData: [],
      // 已選擇複合角色
      targetKeys: [],
      // 角色資訊
      role: {},
      // 新增複合角色
      addComposites: [],
      // 移除複合角色
      removeComposites: [],
      // 查詢條件表單
      formValidate: {
        // 角色類別
        roleType: "",
        // 角色名稱
        roleNm: ""
      },
      // 畫面元件控制
      viewComponentCtrl: {
        isQryBtnDisabled: false
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 取消
     */
    cancelUpdCompositeRole: function() {
      this.resetModal();
      this.$emit("close");
      this.$Message.info("操作取消");
    },
    /**
     * 顯示互斥衝突錯誤訊息
     */
    showConflictMsg: function(roleList) {
      roleList = this._.map(roleList, function(role) {
        return role.roleNm;
      });

      let roleStr = this._.join(this._.slice(roleList, 0, 3), "、");
      this.$Message.error({
        content: roleStr.concat(" 等角色發生互斥衝突，請重新操作"),
        duration: 5
      });
    },
    /**
     * 處理穿梭框左至右
     */
    handleMoveRight: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(key => {
        if (!this.removeComposites.includes(key)) {
          this.addComposites.push(key);
        }
        vm._.remove(this.removeComposites, function(ele) {
          return ele === key;
        });
      });
    },
    /**
     * 處理穿梭框右至左
     */
    handleMoveLeft: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(key => {
        if (!this.addComposites.includes(key)) {
          this.removeComposites.push(key);
        }
        vm._.remove(this.addComposites, function(ele) {
          return ele === key;
        });
      });
    },
    /**
     * 處理穿梭框異動
     * on-change
     * event handler return newKeys(顯示在右邊窗格中的所有的key), direction(此次異動的方向), moveKeys(實際被移動的keys)
     */
    handleChange: async function(newKeys, direction, moveKeys) {
      if (direction === "right") {
        // 檢查moveKeys中與newKeys互斥衝突的角色清單
        let result = await exclusiveApi.doQryExclusiveConflict({
          sourceRoleList: moveKeys,
          targetRoleList: newKeys
        });

        // 存在互斥衝突角色
        if (!this._.isEmpty(result)) {
          this.showConflictMsg(result);
          return;
        }
        this.handleMoveRight(moveKeys);
      }

      if (direction === "left") {
        this.handleMoveLeft(moveKeys);
      }

      this.targetKeys = newKeys;
      this.disableQryBtn();
    },
    /**
     * 停用/啟用查詢按鈕
     */
    disableQryBtn: function() {
      // 若尚未操作異動，才可查詢角色
      if (
        this._.isEmpty(this.addComposites) &&
        this._.isEmpty(this.removeComposites)
      ) {
        this.viewComponentCtrl.isQryBtnDisabled = false;
        return;
      }

      this.viewComponentCtrl.isQryBtnDisabled = true;
    },
    /**
     * 取得角色清單
     */
    searchRoles: async function() {
      // 取得已復合角色清單
      let compositedRoles = await f050303Api.doGetCompositeRoles({
        roleId: this.role.roleId
      });

      // 取得可複合角色清單
      let selectableRoles = await f050303Api.doGetSelectableRoles({
        roleId: this.role.roleId,
        roleNm: this.formValidate.roleNm,
        roleType: this.formValidate.roleType
      });

      this.targetKeys = compositedRoles.map(role => role.key);
      this.transferData = selectableRoles.concat(compositedRoles);
    },
    /**
     * 新增/移除複合角色
     */
    doUpdCompositeRole: async function() {
      if (isBlank(this.addComposites) && isBlank(this.removeComposites)) {
        this.$Message.error("異動資料不得為空");
        return;
      }

      f050303Api
        .doUpdCompositeRoles({
          roleId: this.role.roleId,
          addComposites: this.addComposites,
          removeComposites: this.removeComposites
        })
        .then(() => {
          this.resetModal();
          this.$emit("close", true);
          this.$Message.info("新增成功");
        });
    },
    /**
     * 重置Modal
     */
    resetModal: function() {
      this.transferData = [];
      this.targetKeys = [];
      this.removeComposites = [];
      this.addComposites = [];
      this.viewComponentCtrl.isQryBtnDisabled = false;
      this.$refs["formValidate"].resetFields();
    }
  },
  watch: {
    /**
     * 監聽 props 改變時，深拷貝角色資訊(避免物件傳址而修改到父組件值)，以及查詢複合角色和清空設定資料
     */
    roleInfo(newValue) {
      if (!newValue.roleId) {
        return;
      }

      this.role = this._.cloneDeep(this.roleInfo);
      this.searchRoles();
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
