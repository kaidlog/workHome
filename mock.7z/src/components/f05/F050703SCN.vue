<template>
  <div>
    <Modal
      width="80"
      v-model="isRsrcModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'archive'" />
        <span> 選擇資源</span>
      </p>
      <Form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="系統" prop="sysId">
              <SysSelect :value.sync="formData.sysId" />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源狀態" prop="rsrcSts">
              <sys-cd-select :ctId="30" :value.sync="formData.rsrcSts" />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源類別" prop="rsrcType">
              <sys-cd-select :ctId="36" :value.sync="formData.rsrcType" />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="8">
            <FormItem label="資源等級" prop="confLv">
              <sys-cd-select :ctId="37" :value.sync="formData.confLv" />
            </FormItem>
          </Col>
        </Row>
      </Form>

      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="getRsrcList">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row type="flex" justify="center" align="middle">
        <Col span="8">
          <Input v-model="rsrcSelected.rsrcNm" readonly>
            <span slot="prepend" style="color:#808695"
              ><Icon
                type="ios-checkmark-circle-outline"
                color="#808695"
                size="24"
              />
              選擇資源</span
            >
          </Input>
        </Col>
      </Row>
      <br />

      <Table
        :columns="rsrcColumn"
        :data="rsrcData"
        @on-sort-change="handleRsrcSort"
        border
      >
        <template slot-scope="{ row }" slot="action">
          <Button @click="selectRsrc(row)">選擇</Button>
        </template>
      </Table>
      <br />

      <Row type="flex" justify="center">
        <Page
          show-total
          show-elevator
          show-sizer
          :total="rsrcPage.total"
          :current.sync="rsrcPage.index"
          @on-change="getRsrcList"
          @on-page-size-change="handleRsrcPageSizeChange"
        ></Page>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelSelectRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col soan="2">
          <Button type="primary" @click="confirmSelectRsrc">
            <font-awesome-icon :icon="'check-circle'" /><span> 確認</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050703Api from "@api/f05/f050703-api";
import namingConverter from "@misc/naming-converter";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    SysSelect
  },
  props: {
    // 是否顯示modal
    isRsrcModalVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 選定資源
      rsrcSelected: {
        rsrcSeqNo: "",
        rsrcNm: ""
      },
      // 表單資料
      formData: {
        // 系統代碼
        sysId: "",
        // 資源狀態
        rsrcSts: "",
        // 資源類別
        rsrcType: "",
        //資源等級
        confLv: ""
      },
      //欄位非空驗證規則
      formRules: {
        sysId: [
          {
            required: true,
            message: "請選擇系統",
            trigger: "change"
          }
        ]
      },
      // 資源資料清單
      rsrcData: [],
      // 資源欄位
      rsrcColumn: [
        {
          title: "資源類別",
          key: "rsrcTypeNm"
        },
        {
          title: "資源等級",
          key: "confLvNm",
          sortable: "custom"
        },
        {
          title: "資源名稱",
          key: "rsrcNm"
        },
        {
          title: "所屬系統",
          key: "upMenuNm",
          sortable: "custom"
        },
        {
          title: "資源狀態",
          key: "rsrcStsNm",
          sortable: "custom"
        },
        {
          title: "資源說明",
          key: "rsrcMemo"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ],
      // page
      rsrcPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢系統資源
     */
    getRsrcList: function() {
      this.$refs["formRef"].validate(async valid => {
        if (valid) {
          let result = await f050703Api.getResourceList({
            sysId: this.formData.sysId,
            rsrcSts: this.formData.rsrcSts,
            rsrcType: this.formData.rsrcType,
            confLv: this.formData.confLv,
            pageNo: this.rsrcPage.index,
            pageSize: this.rsrcPage.size,
            sortColumn: this.rsrcPage.sortColumn,
            sortType: this.rsrcPage.sortType
          });

          this.rsrcPage.index = result.pageNo;
          this.rsrcPage.total = result.totalCount;
          this.rsrcData = result.resourceList;
        }
      });
    },
    /**
     * 選擇資源
     */
    selectRsrc: function(row) {
      this.rsrcSelected.rsrcSeqNo = row.resourceSeqNo;
      this.rsrcSelected.rsrcNm = row.rsrcNm;
    },
    /**
     * 確認選擇資源
     */
    confirmSelectRsrc: function() {
      if (this.rsrcSelected.rsrcSeqNo && this.rsrcSelected.rsrcNm) {
        this.$Message.info("已選擇資源");
        this.$emit("update", this.rsrcSelected);
      } else {
        this.$Message.error("請選擇資源");
      }
    },
    /**
     * 處理資源清單排序
     */
    handleRsrcSort: function(col) {
      if (!this.rsrcPage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.rsrcPage.sortColumn = null;
        this.rsrcPage.sortType = null;
      }
      // 進行排序
      if (col.order !== "normal") {
        this.rsrcPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rsrcPage.sortType = col.order.toUpperCase();
      }

      this.getRsrcList();
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleRsrcPageSizeChange: function(newPageSize) {
      this.rsrcPage.size = newPageSize;
      this.getRsrcList();
    },
    /**
     * 取消資源選擇，關閉Modal
     */
    cancelSelectRole: function() {
      //讓父元件關閉modal
      this.$emit("cancel");
      // 顯示操作取消訊息
      this.$Message.info("操作取消");
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
