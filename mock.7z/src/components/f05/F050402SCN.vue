<template>
  <div>
    <Modal
      v-model="viewComponentCtrl.isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 角色資源設定</span>
      </p>
      <Row>
        <Col span="8">
          <p>
            異動角色:<span> {{ roleInfo.roleNm }}</span>
          </p>
        </Col>
      </Row>
      <Form
        ref="resourceForm"
        :model="resourceForm"
        :rules="resourceFormRule"
        :label-width="120"
        style="margin-top:15px;"
      >
        <Row>
          <Col span="8">
            <FormItem prop="sysId" label="系統名稱">
              <SysSelect
                :value.sync="resourceForm.sysId"
                :sysProp.sync="resourceForm.sysId"
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源類別">
              <sys-cd-select :ctId="36" :value.sync="resourceForm.rsrcType" />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源等級">
              <sys-cd-select :ctId="37" :value.sync="resourceForm.confLv" />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="doQryRsrcLists">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row>
        <Transfer
          filterable
          :list-style="{ width: '45%', height: '400px' }"
          :data="transferData.rsrcList"
          :target-keys="transferData.targetRsrcSeqNo"
          :operations="['移除', '新增']"
          :titles="['可關聯資源', '已關聯資源']"
          :key="componentKeys.transferKey"
          @on-change="handleChange"
        ></Transfer>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdateRsrc">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdateRsrc">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050402Api from "@api/f05/f050402-api";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    SysSelect
  },
  props: {
    showUpdResourceModal: {
      type: Boolean,
      required: false,
      default: false
    },
    roleInfo: {
      type: Object,
      default: function() {
        return {
          // 角色代碼
          roleId: "",
          // 角色名稱
          roleNm: "",
          // 角色狀態
          roleSts: ""
        };
      }
    }
  },
  data() {
    return {
      // 表單驗證項目
      resourceForm: {
        roleId: "",
        sysId: "",
        rsrcType: "",
        confLv: ""
      },
      // 表單驗證規則
      resourceFormRule: {
        sysId: [
          {
            required: true,
            message: "請選擇系統",
            trigger: "change"
          }
        ]
      },
      // 穿梭框資料
      transferData: {
        //資源清單
        rsrcList: [],
        //顯示於右側穿梭框的資源清單
        targetRsrcSeqNo: [],
        //已關聯資源清單
        selectedRsrcSeqNo: []
      },
      // 異動資料
      updRoleRsrcLists: {
        roleId: "",
        sysId: "",
        rsrc2Add: [],
        rsrc2Remove: []
      },
      // 畫面元件控制
      viewComponentCtrl: {
        isModalVisible: false
      },
      // 元件鍵值
      componentKeys: {
        transferKey: 1
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢資源清單
     */
    doQryRsrcLists: function() {
      this.$refs["resourceForm"].validate(async valid => {
        if (valid) {
          let result = await f050402Api.doQryResourceLists(this.resourceForm);

          this.transferData.selectedRsrcSeqNo = result.selectedRsrcSeqNo;
          this.transferData.targetRsrcSeqNo = result.selectedRsrcSeqNo;
          this.transferData.rsrcList = result.rsrcList;
        }
      });
    },
    /**
     * 處理穿梭框左至右
     */
    handleMoveRight: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(rsrcSeqNo => {
        if (!this.transferData.selectedRsrcSeqNo.includes(rsrcSeqNo)) {
          this.updRoleRsrcLists.rsrc2Add.push(rsrcSeqNo);
        }
        vm._.remove(this.updRoleRsrcLists.rsrc2Remove, function(ele) {
          return ele === rsrcSeqNo;
        });
      });
    },
    /**
     * 處理穿梭框右至左
     */
    handleMoveLeft: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(rsrcSeqNo => {
        if (this.transferData.selectedRsrcSeqNo.includes(rsrcSeqNo)) {
          this.updRoleRsrcLists.rsrc2Remove.push(rsrcSeqNo);
        }
        vm._.remove(this.updRoleRsrcLists.rsrc2Add, function(ele) {
          return ele === rsrcSeqNo;
        });
      });
    },
    /**
     * 處理穿梭框異動
     * on-change
     * event handler return newKeys(顯示在右邊窗格中的所有的key), direction(此次異動的方向), moveKeys(實際被移動的keys)
     */
    handleChange: function(newKeys, direction, moveKeys) {
      this.transferData.targetRsrcSeqNo = newKeys;

      if (direction === "right") {
        this.handleMoveRight(moveKeys);
        return;
      }
      this.handleMoveLeft(moveKeys);
    },
    /**
     * 重置Modal
     */
    resetModal: function() {
      this.transferData = {
        rsrcList: [],
        targetRsrcSeqNo: [],
        selectedRsrcSeqNo: []
      };
      this.updRoleRsrcLists = {
        roleId: "",
        rsrc2Add: [],
        rsrc2Remove: []
      };
      this.componentKeys.transferKey += 1;
      this.$refs["resourceForm"].resetFields();
    },
    /**
     * 取消異動
     */
    cancelUpdateRsrc: function() {
      this.resetModal();
      this.$emit("close");
      this.$Message.info("操作取消");
    },
    /**
     * 送出異動資料
     */
    doUpdateRsrc: function() {
      if (
        !this.updRoleRsrcLists.rsrc2Add.length &&
        !this.updRoleRsrcLists.rsrc2Remove.length
      ) {
        this.$Message.error("請設定要異動的資源");
        return;
      }

      f050402Api.doUpdRoleResource(this.updRoleRsrcLists).then(() => {
        this.resetModal();
        this.$emit("close", true);
        this.$Message.info("設定完成");
      });
    }
  },
  watch: {
    showUpdResourceModal(newValue) {
      this.viewComponentCtrl.isModalVisible = newValue;
    },
    roleInfo(newValue) {
      this.resourceForm.roleId = newValue.roleId;
      this.updRoleRsrcLists.roleId = newValue.roleId;
    },
    "resourceForm.sysId": function(newValue) {
      this.updRoleRsrcLists.sysId = newValue;
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
