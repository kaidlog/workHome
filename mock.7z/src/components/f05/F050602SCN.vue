<template>
  <div>
    <Modal
      width="80"
      v-model="isAttrModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 資源屬性設定</span>
      </p>
      <Form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="屬性鍵" prop="attrKey">
              <Input
                v-model="formData.attrKey"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="屬性值" prop="attrVal">
              <Input
                v-model="formData.attrVal"
                maxlength="100"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
        <FormItem label="說明" prop="attrMemo">
          <Input
            v-model="formData.attrMemo"
            type="textarea"
            maxlength="300"
            show-word-limit
          />
        </FormItem>
      </Form>

      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button type="primary" @click="addResourceAttr">
            <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Table :columns="attrColumn" :data="attrData" border>
        <template slot-scope="{ row }" slot="action">
          <Row type="flex" justify="center">
            <Button type="error" @click="showRemoveModal(row)">移除</Button>
          </Row>
        </template>
      </Table>
      <br />

      <Row type="flex" justify="center">
        <Col span="1.5">
          <Button @click="$emit('close')">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>
    <Modal
      v-model="isRemoveModalVisible"
      :closable="false"
      :mask-closable="false"
      @on-ok="deleteAttr"
      @on-cancel="hideModal"
    >
      <p slot="header">
        <font-awesome-icon :icon="'exclamation-circle'" />
        <span> 請確認是否移除資源屬性</span>
      </p>
      <Row>
        <Col span="12">目標資源:</Col>
        <Col span="12">{{ rsrc.rsrcNm }}</Col>
      </Row>
      <Row>
        <Col span="12">屬性鍵:</Col>
        <Col span="12">{{ attrToRmv.attrKey }}</Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050602Api from "@api/f05/f050602-api";

export default {
  components: {},
  props: {
    // 使否顯示modal
    isAttrModalVisible: {
      type: Boolean,
      default: false
    },
    // 操作目標資源
    rsrc: {
      type: Object,
      default: function() {
        return {
          // 資源主鍵
          resourceSeqNo: "",
          // 資源名稱
          rsrcNm: ""
        };
      }
    }
  },
  data() {
    return {
      // 是否顯示對話框(確認移除資源屬性)
      isRemoveModalVisible: false,
      // 欲移除的資源屬性
      attrToRmv: {
        attrSeqNo: "",
        attrKey: ""
      },
      // 驗證欄位非空提醒
      formRules: {
        attrKey: [
          {
            required: true,
            message: "請輸入屬性鍵",
            trigger: "blur"
          },
          {
            pattern: "^[A-z0-9]+$",
            message: "僅能填入英文、數字或底線",
            trigger: "blur"
          }
        ],
        attrVal: [
          {
            required: true,
            message: "請輸入屬性值",
            trigger: "blur"
          }
        ]
      },
      // 表單資料
      formData: {
        attrKey: "",
        attrVal: "",
        attrMemo: ""
      },
      // 屬性資料
      attrData: [],
      // 屬性欄位
      attrColumn: [
        {
          title: "屬性鍵",
          key: "attrKey"
        },
        {
          title: "屬性值",
          key: "attrVal"
        },
        {
          title: "說明",
          key: "attrMemo"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ]
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢資源屬性資料
     */
    getResourceAttrList: async function() {
      this.attrData = await f050602Api.getResourceAttrList({
        resourceSeqNo: this.rsrc.resourceSeqNo,
        // 屬性類別: RS
        attrType: "RS"
      });
    },
    /**
     * 檢核欄位非空才做新增資源屬性
     */
    addResourceAttr: function() {
      this.$refs["formRef"].validate(valid => {
        if (valid) {
          f050602Api
            .addResourceAttr({
              resourceSeqNo: this.rsrc.resourceSeqNo,
              attrKey: this.formData.attrKey,
              attrVal: this.formData.attrVal,
              attrMemo: this.formData.attrMemo,
              // 屬性類別: RS
              attrType: "RS"
            })
            .then(() => {
              // 清空表單
              this.$refs["formRef"].resetFields();
              // 重新獲取資源屬性清單
              this.getResourceAttrList();
              // 顯示成功訊息
              this.$Message.info("新增成功");
            });
        }
      });
    },
    /**
     * 顯示'確認移除資源屬性'對話框
     */
    showRemoveModal: function(row) {
      this.isRemoveModalVisible = true;
      this.attrToRmv.attrSeqNo = row.attrSeqNo;
      this.attrToRmv.attrKey = row.attrKey;
    },
    /**
     * 刪除資源屬性
     */
    deleteAttr: function() {
      f050602Api
        .delResourceAttr({
          resourceSeqNo: this.rsrc.resourceSeqNo,
          attrSeqNo: this.attrToRmv.attrSeqNo
        })
        .then(() => {
          // 重新獲取資源屬性清單
          this.getResourceAttrList();
          // 顯示成功訊息
          this.$Message.info("移除成功");
        });
    },
    /**
     * 關閉'確認移除角色屬性'對話框
     */
    hideModal: function() {
      this.isRemoveModalVisible = false;
    }
  },
  watch: {
    /**
     * 資源主鍵變動時則重查屬性清單
     */
    "rsrc.resourceSeqNo": function(newValue) {
      if (!newValue) {
        return;
      }
      this.getResourceAttrList();
    },
    /**
     * 關閉則清空
     */
    isAttrModalVisible(newValue) {
      if (!newValue) {
        // 清空表單
        this.$refs["formRef"].resetFields();
        // 清空屬性清單
        this.attrData = [];
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
