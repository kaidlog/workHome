<template>
  <div>
    <Modal
      width="80"
      v-model="isAttrModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 新增角色資源屬性</span>
      </p>
      <Form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="屬性鍵" prop="attrKey">
              <Input
                v-model="formData.attrKey"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="屬性值" prop="attrVal">
              <Input
                v-model="formData.attrVal"
                maxlength="100"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="屬性說明" prop="attrMemo">
              <Input
                v-model="formData.attrMemo"
                maxlength="200"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelAddAttr">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="addAttr">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050704Api from "@api/f05/f050704-api";

export default {
  components: {},
  props: {
    // 是否顯示modal
    isAttrModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來的角色代碼
    roleId: {
      type: String,
      default: ""
    },
    // 父組件傳來的資源編碼
    rsrcSeqNo: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      // 表單資料
      formData: {
        // 屬性值
        attrKey: "",
        // 屬性鍵
        attrVal: "",
        // 屬性說明
        attrMemo: ""
      },
      //欄位非空驗證規則
      formRules: {
        attrKey: [
          {
            required: true,
            message: "請輸入屬性鍵",
            trigger: "blur"
          },
          {
            pattern: "^[A-z0-9]+$",
            message: "僅能填入英文、數字或底線",
            trigger: "blur"
          }
        ],
        attrVal: [
          {
            required: true,
            message: "請輸入屬性值",
            trigger: "blur"
          }
        ]
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 檢核欄位非空才做新增屬性
     */
    addAttr: function() {
      this.$refs["formRef"].validate(valid => {
        if (valid) {
          f050704Api
            .addAttr({
              roleId: this.roleId,
              resourceSeqNo: this.rsrcSeqNo,
              attrKey: this.formData.attrKey,
              attrVal: this.formData.attrVal,
              attrMemo: this.formData.attrMemo,
              // 屬性類別: RR
              attrType: "RR"
            })
            .then(() => {
              // 關閉Modal，並讓父組件重新獲取新資料
              this.$emit("update");
              // 顯示成功訊息
              this.$Message.info("新增成功");
              //清空表單
              this.$refs["formRef"].resetFields();
            });
        }
      });
    },
    cancelAddAttr: function() {
      //關閉Modal，不重新獲取新資料
      this.$emit("cancel");
      //顯示取消訊息
      this.$Message.info("操作取消");
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
