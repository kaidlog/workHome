<template>
  <div>
    <Modal
      width="80"
      v-model="isEditModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> {{ isModification ? "修改系統" : "新增系統" }}</span>
      </p>
      <Form ref="sys" :model="sys" :rules="ruleValidate" :label-width="120">
        <OrgSelect
          :divisionProp.sync="sys.selectedDivision"
          :headquarterProp.sync="sys.selectedHeadquarter"
          :departmentProp.sync="sys.selectedDepartment"
          :sectionProp.sync="sys.selectedSection"
          disableGroup
          disableUser
          ref="org"
        />
        <Row>
          <Col span="8">
            <FormItem label="系統狀態" prop="sysSts">
              <sys-cd-select suspend="N" :ctId="30" :value.sync="sys.sysSts" />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="系統代碼" prop="sysId">
              <Input
                v-model="sys.sysId"
                :disabled="sysIdDisabled"
                maxlength="10"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="系統名稱" prop="sysNm">
              <Input v-model="sys.sysNm" maxlength="150" show-word-limit />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="8">
            <FormItem label="URL" prop="url">
              <Input v-model="sys.url" maxlength="50" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="排序編號" prop="sortNum">
              <Input
                v-model="sys.sortNum"
                type="number"
                maxlength="16"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col>
            <FormItem label="系統說明" prop="sysMemo">
              <Input
                v-model="sys.sysMemo"
                type="textarea"
                maxlength="300"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdSystem">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdateSystem">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050102Api from "@api/f05/f050102-api";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  computed: {
    // 群組編號
    grpId: function() {
      return (
        this.sys.selectedSection ||
        this.sys.selectedDepartment ||
        this.sys.selectedHeadquarter ||
        this.sys.selectedDivision
      );
    }
  },
  props: {
    // 是否顯示對話框
    isEditModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來系統資訊
    sysInfo: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    const validateSysId = async (rule, value, callback) => {
      if (this.isModification) {
        return callback();
      }

      if (!value.match("^[A-Za-z0-9_]+$")) {
        return callback(new Error("僅能填入英文、數字或底線"));
      }

      let systemCount = await f050102Api.doQrySystemCount({
        sysId: value
      });
      if (systemCount > 0) {
        return callback(new Error("代碼已存在，請更換代碼"));
      }

      callback();
    };
    const validateSortNum = async (rule, value, callback) => {
      // 若為系統修改且排序編號的值未修改
      if (this.isModification && value === this.originalSortNum) {
        return callback();
      }

      let systemCount = await f050102Api.doQrySystemCount({
        sortNum: value
      });
      if (systemCount > 0) {
        return callback(new Error("排序編號已存在，請更換編號"));
      }

      callback();
    };
    return {
      // 驗證規則
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ],
        sysSts: [
          {
            required: true,
            message: "請選擇系統狀態",
            trigger: "change"
          }
        ],
        sysId: [
          {
            required: true,
            message: "請輸入系統代碼",
            trigger: "blur"
          },
          {
            validator: validateSysId,
            trigger: "blur"
          }
        ],
        sysNm: [
          {
            required: true,
            message: "請輸入系統名稱",
            trigger: "blur"
          }
        ],
        url: [
          {
            required: true,
            message: "請輸入URL",
            trigger: "blur"
          },
          { type: "url", message: "請輸入正確的URL格式", trigger: "blur" }
        ],
        sortNum: [
          {
            required: true,
            message: "請輸入排序編號",
            trigger: "blur"
          },
          {
            validator: validateSortNum,
            trigger: "blur"
          }
        ]
      },
      sysIdDisabled: false,
      sys: {
        // 事業處
        selectedDivision: "",
        // 本部
        selectedHeadquarter: "",
        // 部門
        selectedDepartment: "",
        // 科別
        selectedSection: "",
        // 組織編號
        grpId: "",
        // 系統狀態
        sysSts: "",
        // 系統代碼
        sysId: "",
        // 系統名稱
        sysNm: "",
        // URL
        url: "",
        // 排序編號
        sortNum: null,
        // 系統說明
        sysMemo: ""
      },
      // 系統原本的排序編號
      originalSortNum: null,
      // 動作是否為編輯
      isModification: false
    };
  },
  methods: {
    /**
     * 取消
     */
    cancelUpdSystem: function() {
      this.$emit("close");
      this.$Message.info("操作取消");
      // 清除表單欄位並重新深拷貝系統資訊
      this.$refs["sys"].resetFields();
      this.sys = this._.cloneDeep(this.sysInfo);
      this.$refs.org.selectedDivision = this.sys.selectedDivision;
      this.$refs.org.selectedHeadquarter = this.sys.selectedHeadquarter;
      this.$refs.org.selectedDepartment = this.sys.selectedDepartment;
      this.$refs.org.selectedSection = this.sys.selectedSection;
    },
    /**
     * 新增/修改人員
     */
    doUpdateSystem: function() {
      this.$refs["sys"].validate(async valid => {
        if (valid) {
          this.sys.grpId = this.grpId;
          let result = await f050102Api.doUpdSystem(this.sys);
          if (result) {
            // 關閉 Modal，並傳回訊息讓父組件重新獲取新資料
            this.$emit("close", true);
            this.$Message.info("操作成功");
          }
        }
      });
    }
  },
  watch: {
    /**
     * 深拷貝系統資訊，避免物件傳址而修改到父組件值，若為編輯則停用系統編碼輸入框
     */
    sysInfo: {
      handler: function() {
        this.sys = this._.cloneDeep(this.sysInfo);
        this.$refs.org.selectedDivision = this.sys.selectedDivision;
        this.$refs.org.selectedHeadquarter = this.sys.selectedHeadquarter;
        this.$refs.org.selectedDepartment = this.sys.selectedDepartment;
        this.$refs.org.selectedSection = this.sys.selectedSection;

        if (this.sys.sysId) {
          this.sysIdDisabled = true;
          this.isModification = true;
          this.originalSortNum = this.sys.sortNum;
        } else {
          this.sysIdDisabled = false;
          this.isModification = false;
          this.originalSortNum = null;
          this.$refs["sys"].resetFields();
        }
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
