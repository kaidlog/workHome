<template>
  <div>
    <Modal
      width="80"
      v-model="isRoleModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 角色選擇</span>
      </p>
      <Form :label-width="120">
        <Row>
          <Col span="8">
            <FormItem label="一般/複合">
              <Select v-model="roleCat" filterable clearable>
                <Option
                  v-for="item in catList"
                  :value="item.value"
                  :key="item.value"
                  >{{ item.label }}</Option
                >
              </Select>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="角色代碼">
              <Input v-model="roleId" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="角色名稱">
              <Input v-model="roleNm" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="getRoleList">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row type="flex" justify="center" align="middle">
        <Col span="8">
          <Input v-model="roleSelected.roleNm" readonly>
            <span slot="prepend" style="color:#808695"
              ><Icon
                type="ios-checkmark-circle-outline"
                color="#808695"
                size="24"
              />
              選擇角色</span
            >
          </Input>
        </Col>
      </Row>
      <br />

      <Table
        :columns="roleColumn"
        :data="roleData"
        @on-sort-change="handleRoleSort"
        border
      >
        <template slot-scope="{ row }" slot="action">
          <Button @click="selectRole(row)">選擇</Button>
        </template>
      </Table>
      <br />

      <Row type="flex" justify="center">
        <Page
          show-total
          show-elevator
          show-sizer
          :total="rolePage.total"
          :current.sync="rolePage.index"
          :page-size="rolePage.size"
          @on-change="getRoleList"
          @on-page-size-change="handleRolePageSizeChange"
        ></Page>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelSelectRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="confirmSelectRole">
            <font-awesome-icon :icon="'check-circle'" /><span> 確認</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050702Api from "@api/f05/f050702-api";
import namingConverter from "@misc/naming-converter";

export default {
  components: {},
  props: {
    // 是否顯示modal
    isRoleModalVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 一般/複合(用以查詢角色清單)
      roleCat: "",
      // 角色代碼(用以查詢角色清單)
      roleId: "",
      // 角色名稱(用以查詢角色清單)
      roleNm: "",
      // 選定角色
      roleSelected: {
        roleId: "",
        roleNm: ""
      },
      // 一般/複合選單
      catList: [
        {
          value: "N",
          label: "一般角色"
        },
        {
          value: "C",
          label: "複合角色"
        }
      ],
      // 角色資料清單
      roleData: [],
      // 角色欄位
      roleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色代碼",
          key: "roleId"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ],
      // page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        //排序欄位
        sortColumn: null,
        //排序方向
        sortType: null
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢角色
     */
    getRoleList: async function() {
      let result = await f050702Api.getRoleList({
        roleCat: this.roleCat,
        roleId: this.roleId,
        roleNm: this.roleNm,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleData = result.roleInfoList;
    },
    /**
     * 選擇角色
     */
    selectRole: function(row) {
      this.roleSelected.roleId = row.roleId;
      this.roleSelected.roleNm = row.roleNm;
    },
    /**
     * 確認選擇角色
     */
    confirmSelectRole: function() {
      if (this.roleSelected.roleId && this.roleSelected.roleNm) {
        this.$Message.info("已選擇角色");
        this.$emit("update", this.roleSelected);
      } else {
        this.$Message.error("請選擇角色");
      }
    },
    /**
     * 排序角色清單
     */
    handleRoleSort: function(col) {
      if (!this.rolePage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // 進行排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.getRoleList();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.getRoleList();
    },
    /**
     * 取消角色選擇，關閉Modal
     */
    cancelSelectRole: function() {
      //讓父元件關閉modal
      this.$emit("cancel");
      // 顯示操作取消訊息
      this.$Message.info("操作取消");
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
