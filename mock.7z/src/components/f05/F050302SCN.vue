<template>
  <div>
    <Modal
      width="80"
      v-model="isEditModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span>{{ isModification ? " 修改角色" : " 新增角色" }}</span>
      </p>
      <Form
        ref="formValidate"
        :model="role"
        :rules="ruleValidate"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="角色類別" prop="roleType">
              <sys-cd-select
                suspend="N"
                :ctId="42"
                :value.sync="role.roleType"
                clearable
              />
            </FormItem>
          </Col>
          <Col span="6">
            <FormItem label="角色代碼" prop="roleId">
              <Input
                v-model="role.roleId"
                :disabled="roleIdDisabled"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="10">
            <FormItem label="角色名稱" prop="roleNm">
              <Input v-model="role.roleNm" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
        </Row>
        <FormItem label="角色說明" prop="roleMemo">
          <Input
            v-model="role.roleMemo"
            type="textarea"
            maxlength="300"
            show-word-limit
          />
        </FormItem>
        <Row>
          <Col span="8">
            <FormItem label="角色狀態" prop="roleSts">
              <sys-cd-select
                suspend="N"
                :ctId="30"
                :value.sync="role.roleSts"
                clearable
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdateRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdateRole">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050302Api from "@api/f05/f050302-api";

export default {
  components: {},
  computed: {},
  props: {
    // 是否顯示對話框
    isEditModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來角色資訊
    roleInfo: {
      type: Object,
      default: function() {
        return {
          // 角色狀態
          roleSts: "",
          // 角色類別
          roleType: "",
          // 角色說明
          roleMemo: "",
          // 角色名稱
          roleNm: "",
          // 角色代碼
          roleId: ""
        };
      }
    }
  },
  data() {
    const validateRoleId = async (rule, value, callback) => {
      if (this.isModification) {
        return callback();
      }

      if (!value.match("^[A-Za-z0-9_]+$")) {
        return callback(new Error("僅能填入英文、數字或底線"));
      }

      let roleCount = await f050302Api.doQryRoleCount({
        roleId: value
      });
      if (roleCount > 0) {
        return callback(new Error("代碼已存在，請更換代碼"));
      }

      callback();
    };
    return {
      ruleValidate: {
        roleType: [
          {
            required: true,
            message: "請選擇角色類別",
            trigger: "change"
          }
        ],
        roleId: [
          {
            required: true,
            message: "請輸入角色代碼",
            trigger: "blur"
          },
          {
            validator: validateRoleId,
            trigger: "blur"
          }
        ],
        roleNm: [
          {
            required: true,
            message: "請輸入角色名字",
            trigger: "blur"
          }
        ],
        roleSts: [
          {
            required: true,
            message: "請選擇角色狀態",
            trigger: "change"
          }
        ]
      },
      role: {},
      roleIdDisabled: false,
      // 動作是否為編輯
      isModification: false
    };
  },
  methods: {
    /**
     * 取消
     */
    cancelUpdateRole: function() {
      // 關閉 Modal
      this.$emit("close");
      this.$Message.info("操作取消");
    },
    /**
     * 送出
     */
    doUpdateRole: function() {
      this.$refs["formValidate"].validate(async valid => {
        if (valid) {
          let result = await f050302Api.doUpdRole(this.role);
          if (result) {
            // 關閉 Modal 並傳回訊息讓父組件重新獲取新資料
            this.$emit("close", true);
            // 重新獲取角色資料
            this.$Message.info("操作成功");
          }
        }
      });
    }
  },
  watch: {
    /**
     * 深拷貝角色資訊，避免物件傳址而修改到父組件值
     */
    roleInfo: {
      handler: function() {
        this.role = this._.cloneDeep(this.roleInfo);
        if (this.role.roleId) {
          this.roleIdDisabled = true;
          this.isModification = true;
        } else {
          this.roleIdDisabled = false;
          this.isModification = false;
        }
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
