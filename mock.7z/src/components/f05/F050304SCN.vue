<template>
  <div>
    <Modal
      width="80"
      v-model="isExclusiveModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 設定互斥 | {{ role.roleNm }}</span>
      </p>
      <Form
        :model="formValidate"
        ref="formValidate"
        :rules="ruleValidate"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="一般/複合" prop="roleCat">
              <Select v-model="formValidate.roleCat" filterable clearable>
                <Option
                  v-for="item in catList"
                  :value="item.value"
                  :key="item.value"
                  >{{ item.label }}</Option
                >
              </Select>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="角色類別" prop="roleType">
              <sys-cd-select
                :ctId="42"
                :value.sync="formValidate.roleType"
                clearable
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="角色名稱" prop="roleNm">
              <Input
                v-model="formValidate.roleNm"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="searchRoles">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Transfer
        :data="selectableRoles"
        :target-keys="exclusiveRoles"
        @on-change="handleChange"
        :list-style="{ width: '45%', height: '300px' }"
        :operations="['移除', '新增']"
        :titles="['可選角色', '互斥角色']"
        filterable
      />
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdExclusiveRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdExclusiveRole">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f050304Api from "@api/f05/f050304-api";

export default {
  components: {},
  props: {
    // 是否顯示對話框
    isExclusiveModalVisible: {
      type: Boolean,
      default: false
    },
    //父組件傳來角色資訊
    roleInfo: {
      type: Object,
      default: function() {
        return {
          // 角色狀態
          roleSts: "",
          // 角色代碼
          roleId: "",
          // 角色類別
          roleType: "",
          // 角色說明
          roleMemo: "",
          // 角色名稱
          roleNm: ""
        };
      }
    }
  },
  data() {
    return {
      ruleValidate: {
        roleType: [
          {
            required: true,
            message: "請選擇角色類別",
            trigger: "change"
          }
        ]
      },
      // 可選擇角色
      selectableRoles: [],
      // 已選擇互斥角色
      exclusiveRoles: [],
      // 角色資訊
      role: {},
      // 新增互斥角色
      addExclusives: [],
      // 移除互斥角色
      removeExclusives: [],
      // 初始互斥角色
      initRoles: [],
      // 一般/複合選單
      catList: [
        {
          value: "N",
          label: "一般角色"
        },
        {
          value: "C",
          label: "複合角色"
        }
      ],
      //表單資訊(用以查詢可選角色)
      formValidate: {
        // 角色類別
        roleType: "",
        // 角色名稱
        roleNm: "",
        // 一般/複合
        roleCat: ""
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 搜尋可選取角色
     */
    searchRoles: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetSelectableRoles();
        }
      });
    },
    /**
     * 取消
     */
    cancelUpdExclusiveRole: function() {
      this.$refs["formValidate"].resetFields();
      this.$emit("close");
      this.$Message.info("操作取消");
    },
    /**
     * 處理穿梭框異動
     * on-change
     * event handler return newKeys(顯示在右邊窗格中的所有的key), direction(此次異動的方向), moveKeys(實際被移動的keys)
     */
    handleChange: function(newKeys, direction, moveKeys) {
      this.exclusiveRoles = newKeys;
      // direction === "right" ，為自穿梭框左側選至右側 (新增)
      if (direction === "right") {
        moveKeys.forEach(key => {
          if (this.removeExclusives.indexOf(key) > -1) {
            this.removeExclusives.splice(this.removeExclusives.indexOf(key), 1);
          } else this.addExclusives.push(key);
        });
        return;
      }
      // direction === "right" ，為自穿梭框左側選至右側 (新增)
      if (direction !== "right") {
        moveKeys.forEach(key => {
          if (this.addExclusives.indexOf(key) > -1) {
            this.addExclusives.splice(this.addExclusives.indexOf(key), 1);
          } else this.removeExclusives.push(key);
        });
      }
    },
    /**
     * 查詢該角色已互斥的角色清單
     */
    doGetExclusiveRoles: async function() {
      if (this.role.roleId) {
        let result = await f050304Api.doGetExclusiveRoles({
          roleId: this.role.roleId
        });
        this.selectableRoles = result;
        this.initRoles = result;
        this.exclusiveRoles = result.map(item => item.key);
      }
    },
    /**
     * 查詢角色清單排除該角色樹系的複合角色
     */
    doGetSelectableRoles: async function() {
      let result = await f050304Api.doGetSelectableRoles({
        roleId: this.role.roleId,
        roleNm: this.formValidate.roleNm,
        roleType: this.formValidate.roleType,
        roleCategory: this.formValidate.roleCat
      });
      this.selectableRoles = this.initRoles.concat(result);
    },
    /**
     * 新增/移除互斥角色
     */
    doUpdExclusiveRole: async function() {
      if (isBlank(this.addExclusives) && isBlank(this.removeExclusives)) {
        this.$Message.info("異動資料不得為空");
        return;
      }
      let result = await f050304Api.doUpdExclusiveRoles({
        roleId: this.role.roleId,
        addExclusives: this.addExclusives,
        removeExclusives: this.removeExclusives
      });
      if (result) {
        // 關閉 Modal 並傳回訊息讓父組件重新獲取新資料
        this.$emit("close", true);
        this.$Message.info("操作成功");
      }
    }
  },
  watch: {
    /**
     * 監聽 props 改變時，深拷貝角色資訊(避免物件傳址而修改到父組件值)，以及查詢互斥角色和清空設定資料
     */
    roleInfo: {
      handler: function() {
        this.role = this._.cloneDeep(this.roleInfo);
        if (this.role) {
          this.doGetExclusiveRoles();
        }
        this.addExclusives = [];
        this.removeExclusives = [];
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
