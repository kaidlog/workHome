<template>
  <div>
    <Modal
      v-model="isEditModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
      width="80"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span>{{ isModification ? " 修改資源" : " 新增資源" }}</span>
      </p>
      <Form ref="rsrc" :model="rsrc" :rules="ruleValidate" :label-width="120">
        <FormItem label="資源類別" prop="rsrcType">
          <sys-cd-radio suspend="N" :ctId="36" :value.sync="rsrc.rsrcType" />
        </FormItem>
        <Row>
          <Col span="8">
            <FormItem label="系統" prop="sysId">
              <SysSelect :value.sync="rsrc.sysId" :sysProp="rsrc.sysId" />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源狀態" prop="rsrcSts">
              <sys-cd-select
                suspend="N"
                :ctId="30"
                :value.sync="rsrc.rsrcSts"
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="資源等級" prop="confLv">
              <sys-cd-select suspend="N" :ctId="37" :value.sync="rsrc.confLv" />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="8">
            <FormItem label="資源名稱" prop="rsrcNm">
              <Input v-model="rsrc.rsrcNm" maxlength="10" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="URI" prop="rsrcUri">
              <Input v-model="rsrc.rsrcUri" maxlength="50" show-word-limit />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col>
            <FormItem label="資源說明" prop="rsrcMemo">
              <Input
                v-model="rsrc.rsrcMemo"
                type="textarea"
                maxlength="300"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>

        <div v-if="isMenu">
          <Row>
            <Col span="8">
              <FormItem label="上層選單" prop="upMenuSeqNo">
                <Select v-model="rsrc.upMenuSeqNo" clearable filterable>
                  <Option
                    v-for="menu in menuList"
                    :value="menu.menuSeqNo"
                    :key="menu.menuSeqNo"
                    >{{ menu.rsrcNm }}</Option
                  >
                </Select>
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="選單位置" prop="position">
                <sys-cd-select
                  suspend="N"
                  :ctId="39"
                  :value.sync="rsrc.position"
                />
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="轉導類型" prop="redirectType">
                <sys-cd-select
                  suspend="N"
                  :ctId="38"
                  :value.sync="rsrc.redirectType"
                />
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="8">
              <FormItem label="排序編號" prop="sortNum">
                <Input
                  v-model="rsrc.sortNum"
                  type="number"
                  maxlength="16"
                  show-word-limit
                />
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="文字圖示" prop="iconText">
                <Input
                  v-model="rsrc.iconText"
                  maxlength="100"
                  show-word-limit
                />
              </FormItem>
            </Col>
          </Row>
        </div>
      </Form>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdResource">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdResource">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f050202Api from "@api/f05/f050202-api";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    SysSelect
  },
  computed: {
    /**
     * 資源類別是否為選單(用以決定是否開啟決定選單選項)
     */
    isMenu: function() {
      return this.rsrc.rsrcType === "M"; // M: Menu
    }
  },
  props: {
    // 是否顯示對話框
    isEditModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來系統資訊
    rsrcInfo: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      // 驗證規則
      ruleValidate: {
        rsrcType: [
          {
            required: true,
            message: "請選擇資源類別",
            trigger: "change"
          }
        ],
        sysId: [
          {
            required: true,
            message: "請選擇所屬系統",
            trigger: "change"
          }
        ],
        rsrcSts: [
          {
            required: true,
            message: "請選擇資源狀態",
            trigger: "change"
          }
        ],
        confLv: [
          {
            required: true,
            message: "請選擇資源等級",
            trigger: "change"
          }
        ],
        rsrcNm: [
          {
            required: true,
            message: "請輸入資源名稱",
            trigger: "blur"
          }
        ],
        rsrcUri: [
          {
            pattern: "^[/A-z0-9]+$",
            message: "請輸入正確的URI格式",
            trigger: "blur"
          }
        ],
        position: [
          {
            required: true,
            message: "請選擇選單位置",
            trigger: "change"
          }
        ],
        redirectType: [
          {
            required: true,
            message: "請選擇轉導類型",
            trigger: "change"
          }
        ],
        sortNum: [
          {
            required: true,
            message: "請輸入排序編號(僅能輸入數字)",
            trigger: "blur"
          }
        ],
        iconText: [
          {
            pattern: "^[A-Za-z0-9-]+$",
            message: "僅能填入英文、數字或連字符",
            trigger: "blur"
          }
        ]
      },
      // 資源資訊
      rsrc: {
        sysId: ""
      },
      // 選單選項
      menuList: [],
      // 動作是否為編輯
      isModification: false
    };
  },
  methods: {
    /**
     * 取消
     */
    cancelUpdResource: function() {
      this.$emit("close");
      this.$Message.info("操作取消");
      // 清除表單欄位並重新深拷貝系統資訊
      this.$refs["rsrc"].resetFields();
      this.rsrc = this._.cloneDeep(this.rsrcInfo);
    },
    /**
     * 送出
     */
    doUpdResource: function() {
      this.$refs["rsrc"].validate(async valid => {
        if (valid) {
          if (this.isMenu) {
            await f050202Api.doUpdMenu(this.rsrc);
          }

          if (!this.isMenu) {
            await f050202Api.doUpdResource(this.rsrc);
          }

          // 關閉 Modal 並傳回訊息讓父組件重新獲取新資料
          this.$emit("close", true);
          this.$Message.info("操作成功");
        }
      });
    }
  },
  watch: {
    /**
     * 深拷貝資源資訊，避免物件傳址而修改到父組件值
     */
    rsrcInfo: {
      handler: function() {
        this.rsrc = this._.cloneDeep(this.rsrcInfo);

        if (this.rsrc.sysId) {
          this.isModification = true;
        } else {
          this.isModification = false;
        }
      }
    },
    /**
     * 監聽系統選項，用以查詢選單選項
     */
    "rsrc.sysId": async function(newValue) {
      if (isBlank(newValue)) {
        return;
      }

      this.menuList = await f050202Api.doGetMenuList({
        sysId: newValue
      });
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
