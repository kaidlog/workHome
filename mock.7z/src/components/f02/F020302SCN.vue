<template>
  <div>
    <Modal
      v-model="viewComponentCtrl.isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span>
          {{ viewComponentCtrl.isModification ? "異動群組" : "新增群組" }}
        </span>
      </p>
      <Row v-if="viewComponentCtrl.isModification">
        <p><span style="margin-right:10px;">隸屬單位:</span>{{ upGrpNm }}</p>
        <Divider />
      </Row>
      <Form
        v-if="!viewComponentCtrl.isModification"
        ref="orgSelectForm"
        :model="orgSelectForm"
        :rules="orgSelectRule"
        :label-width="120"
      >
        <OrgSelect
          :divisionProp.sync="orgSelectForm.selectedDivision"
          :headquarterProp.sync="orgSelectForm.selectedHeadquarter"
          :departmentProp.sync="orgSelectForm.selectedDepartment"
          :sectionProp.sync="orgSelectForm.selectedSection"
          :groupProp.sync="orgSelectForm.selectedGroup"
          :userProp.sync="orgSelectForm.selectedUser"
          :disableGroup="orgSelectCtrl.groupDisable"
          :disableUser="orgSelectCtrl.userDisable"
          :key="componentKeys.orgSelectKey"
        ></OrgSelect>
      </Form>
      <Form
        ref="groupForm"
        :model="groupForm"
        :rules="groupRule"
        :label-width="120"
      >
        <Row>
          <Col>
            <FormItem prop="grpNm" label="群組名稱">
              <Input
                v-model="groupForm.grpNm"
                style="width: 100%"
                maxlength="200"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="8">
            <FormItem prop="grpType" label="群組類型">
              <sys-cd-select
                :ctId="31"
                :value.sync="groupForm.grpType"
              ></sys-cd-select>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem prop="grpSts" label="群組狀態">
              <sys-cd-select
                :ctId="30"
                :value.sync="groupForm.grpSts"
              ></sys-cd-select>
            </FormItem>
          </Col>
        </Row>
        <Row type="flex" justify="center">
          <Col span="8">
            <FormItem prop="permanent" label="永久有效">
              <sys-cd-select
                :ctId="2"
                :value.sync="groupForm.permanent"
              ></sys-cd-select>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem prop="startDate" label="有效起日">
              <DatePicker
                style="width:100%;"
                @on-change="handleStartDateChange"
                :value="groupForm.startDate"
                type="date"
                format="yyyy/MM/dd"
                :key="componentKeys.startDatePicker"
                :editable="false"
                :options="options"
                :disabled="viewComponentCtrl.isPermanent"
              ></DatePicker>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem prop="endDate" label="有效迄日">
              <DatePicker
                style="width:100%;"
                @on-change="handleEndDateChange"
                :value="groupForm.endDate"
                type="date"
                format="yyyy/MM/dd"
                :key="componentKeys.endDatePicker"
                :editable="false"
                :options="options"
                :disabled="viewComponentCtrl.isPermanent"
              ></DatePicker>
            </FormItem>
          </Col>
        </Row>
      </Form>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdateGroup">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="submitValidGrpInfo">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
import f020302Api from "@api/f02/f020302-api";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  props: {
    /**
     * 是否顯示Modal
     */
    showUpdGrpModal: {
      type: Boolean,
      required: false,
      default: false
    },
    /**
     * 欲修改群組的群組編號
     */
    updGroupId: {
      type: String,
      required: false
    }
  },
  data() {
    // Custom Validator
    const validateStartDate = (rule, value, callback) => {
      // validate fields
      if (
        this.groupForm.permanent === "N" &&
        isBlank(this.groupForm.startDate)
      ) {
        return callback(new Error("非永久有效請提供有效起日"));
      }

      callback();
    };
    const validateEndDate = (rule, value, callback) => {
      // validate fields
      if (this.groupForm.permanent === "N" && isBlank(this.groupForm.endDate)) {
        return callback(new Error("非永久有效請提供有效迄日"));
      }

      callback();
    };
    return {
      // 表單驗證項目
      orgSelectForm: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: "",
        selectedUser: ""
      },
      groupForm: {
        // Group資料
        grpId: "",
        grpNm: "",
        upGrpId: "",
        grpType: "",
        grpSts: "",
        startDate: "",
        endDate: "",
        permanent: ""
      },
      // 表單驗證規則
      orgSelectRule: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ]
      },
      groupRule: {
        grpNm: [
          {
            required: true,
            message: "請輸入群組名稱",
            trigger: "blur"
          }
        ],
        grpType: [
          {
            required: true,
            message: "請選擇群組類型",
            trigger: "change"
          }
        ],
        grpSts: [
          {
            required: true,
            message: "請選擇群組狀態",
            trigger: "change"
          }
        ],
        permanent: [
          {
            required: true,
            message: "請選擇是否永久有效",
            trigger: "change"
          }
        ],
        startDate: [{ validator: validateStartDate, trigger: "blur" }],
        endDate: [{ validator: validateEndDate, trigger: "blur" }]
      },
      // Datepicker禁選今天以前的日期
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      // OrgSelect 控制項
      orgSelectCtrl: {
        groupDisable: true,
        userDisable: true
      },
      // 畫面元件控制
      viewComponentCtrl: {
        isModalVisible: false,
        isModification: false,
        isPermanent: false
      },
      // 上層群組名稱(異動群組資料時顯示)
      upGrpNm: "",
      // 元件鍵值
      componentKeys: {
        orgSelectKey: 1,
        startDatePicker: 1,
        endDatePicker: 1
      }
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.orgSelectForm.selectedGroup ||
        this.orgSelectForm.selectedSection ||
        this.orgSelectForm.selectedDepartment ||
        this.orgSelectForm.selectedHeadquarter ||
        this.orgSelectForm.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 重置Modal
     */
    resetModal: function() {
      if (!this.viewComponentCtrl.isModification) {
        this.componentKeys.orgSelectKey += 1;
        this.$refs["orgSelectForm"].resetFields();
      }
      this.viewComponentCtrl.isModification = false;

      this.upGrpNm = "";
      this.componentKeys.startDatePicker += 1;
      this.componentKeys.endDatePicker += 1;
      this.$refs["groupForm"].resetFields();
      this.groupForm.grpId = "";
      this.groupForm.upGrpId = "";
    },
    /**
     * 處理有效起日異動
     */
    handleStartDateChange: function(date) {
      this.groupForm.startDate = date;
    },
    /**
     * 處理有效迄日異動
     */
    handleEndDateChange: function(date) {
      this.groupForm.endDate = date;
    },
    /**
     * 取消新增/異動
     */
    cancelUpdateGroup: function() {
      this.$emit("close");
      this.resetModal();
      this.$Message.info("操作取消");
    },
    /**
     * 送出驗證無誤的群組資料
     */
    submitValidGrpInfo: function() {
      let validOrgSelect = false;
      let validGroup = false;

      if (!this.viewComponentCtrl.isModification) {
        this.$refs["orgSelectForm"].validate(async valid => {
          if (!valid) {
            return;
          }
          validOrgSelect = true;
        });
      }

      this.$refs["groupForm"].validate(async valid => {
        if (!valid) {
          return;
        }
        validGroup = true;
      });

      if (this.viewComponentCtrl.isModification && validGroup) {
        this.doUpdGroup().then(() => {
          this.$emit("close", true);
          this.resetModal();
          this.$Message.info("操作完成");
        });
        return;
      }

      if (
        !this.viewComponentCtrl.isModification &&
        validOrgSelect &&
        validGroup
      ) {
        this.doUpdGroup().then(() => {
          this.$emit("close", true);
          this.resetModal();
          this.$Message.info("操作完成");
        });
      }
    },
    /**
     * 送出異動資料
     */
    doUpdGroup: async function() {
      return await f020302Api.doUpdGroup(this.groupForm);
    }
  },
  watch: {
    /**
     * 監聽OrgSelectGrp
     */
    orgSelectGrp: function(newValue) {
      if (newValue) {
        this.groupForm.upGrpId = newValue;
      }
    },
    /**
     * 監聽外部傳入是否顯示Modal
     */
    showUpdGrpModal(newValue) {
      this.viewComponentCtrl.isModalVisible = newValue;
    },
    /**
     * 監聽外部傳入欲異動的群組編號
     */
    updGroupId: async function(newValue) {
      if (!newValue) {
        return;
      }

      this.viewComponentCtrl.isModification = true;

      let result = await f020302Api.doGetGroup4Upd({
        grpId: newValue
      });

      this.groupForm.grpId = result.grpId;
      this.groupForm.grpNm = result.grpNm;
      this.groupForm.upGrpId = result.upGrpId;
      this.groupForm.grpType = result.grpType;
      this.groupForm.grpSts = result.grpSts;
      this.groupForm.startDate = result.startDate;
      this.groupForm.endDate = result.endDate;
      this.groupForm.permanent = result.permanent;
      this.upGrpNm = result.upGrpNm;
    },
    /**
     * 監聽是否永久有效選項
     */
    "groupForm.permanent": function(newValue) {
      if (!newValue) {
        return;
      }

      if (newValue === "N") {
        this.viewComponentCtrl.isPermanent = false;
      }

      if (newValue === "Y") {
        this.viewComponentCtrl.isPermanent = true;
        this.groupForm.startDate = "";
        this.groupForm.endDate = "";
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
