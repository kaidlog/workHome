<template>
  <div>
    <Modal
      v-model="viewComponentCtrl.isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 群組角色設定</span>
      </p>
      <Form ref="roleForm" :model="roleForm" :label-width="120">
        <Row>
          <Col span="8">
            <FormItem prop="roleType" label="角色類別">
              <sys-cd-select
                :ctId="42"
                :value.sync="roleForm.roleType"
              ></sys-cd-select>
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem prop="roleId" label="角色代碼">
              <Input v-model="roleForm.roleId" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem prop="roleNm" label="角色名稱">
              <Input v-model="roleForm.roleNm" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button
            @click="doQryRoleLists"
            :disabled="viewComponentCtrl.isQryBtnDisabled"
          >
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row
        v-show="viewComponentCtrl.isQryBtnDisabled"
        type="flex"
        justify="center"
      >
        <span style="color: grey">
          <Icon type="ios-information-circle-outline" />
          提醒：如需以上方條件查詢角色，請先完成或取消目前設定
        </span>
      </Row>
      <br />

      <Transfer
        filterable
        :list-style="{ width: '45%', height: '400px' }"
        :data="transferData.unselectedRoles"
        :target-keys="transferData.selectedRoleIds"
        :operations="['移除', '新增']"
        :titles="['可關聯角色', '已關聯角色']"
        @on-change="handleChange"
      />
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdGroupRole">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdGrpRole">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f020303Api from "@api/f02/f020303-api";
import exclusiveApi from "@api/common/exclusive-api";

export default {
  components: {},
  props: {
    showUpdRoleModal: {
      type: Boolean,
      required: false,
      default: false
    },
    updGroupId: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      // 角色查詢表單
      roleForm: {
        grpId: "",
        roleType: "",
        roleNm: "",
        roleId: ""
      },
      // 角色清單
      roleLists: {
        grpRoleList: [],
        grpExRoleList: [],
        roleList: []
      },
      // 畫面元件控制
      viewComponentCtrl: {
        isModalVisible: false,
        isQryBtnDisabled: false
      },
      // 異動角色清單
      updRoleLists: {
        grpId: "",
        roles2Add: [],
        roles2Remove: []
      },
      // 穿梭框資料Cache
      transferData: {
        // 可關聯角色清單
        unselectedRoles: [],
        // 群組角色代碼
        grpRoleIds: [],
        exRoleIds: [],
        selectedRoleIds: []
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 轉換穿梭框角色物件
     */
    convertRole: function(roleList, isEx) {
      return this._.map(roleList, function(role) {
        return {
          key: role.roleId,
          label: role.roleNm,
          disabled: isEx
        };
      });
    },
    /**
     * 取得角色清單
     */
    doQryRoleLists: async function() {
      this.updRoleLists.roles2Add = [];
      this.updRoleLists.roles2Remove = [];
      // 查詢角色清單
      this.roleLists = await f020303Api.doGetRoleLists(this.roleForm);
      // 轉換可選角色
      this.transferData.unselectedRoles = this.convertRole(
        this.roleLists.roleList,
        false
      );
      // 放入禁選的互斥角色
      this.transferData.unselectedRoles.push(
        ...this.convertRole(this.roleLists.grpExRoleList, true)
      );
      // 轉換已選角色並放入左側清單
      let selecedRoles = this.convertRole(this.roleLists.grpRoleList, false);
      this.transferData.unselectedRoles.push(...selecedRoles);
      // 設定已選角色代碼移至右側
      this.transferData.selectedRoleIds = this._.map(selecedRoles, role => {
        return role.key;
      });
      // 轉換角色代碼清單
      this.transferData.grpRoleIds = this._.map(
        this.roleLists.grpRoleList,
        role => {
          return role.roleId;
        }
      );
      this.transferData.exRoleIds = this._.map(
        this.roleLists.grpExRoleList,
        role => {
          return role.roleId;
        }
      );
    },
    /**
     * 顯示互斥衝突錯誤訊息
     */
    showConflictMsg: function(roleList) {
      roleList = this._.map(roleList, function(role) {
        return role.roleNm;
      });

      let roleStr = this._.join(this._.slice(roleList, 0, 3), "、");
      this.$Message.error({
        content: roleStr.concat(" 等角色發生互斥衝突，請重新操作"),
        duration: 5
      });
    },
    /**
     * 處理穿梭框左至右
     */
    handleMoveRight: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(key => {
        if (!this.updRoleLists.roles2Remove.includes(key)) {
          this.updRoleLists.roles2Add.push(key);
        }
        vm._.remove(this.updRoleLists.roles2Remove, function(ele) {
          return ele === key;
        });
      });
    },
    /**
     * 處理穿梭框右至左
     */
    handleMoveLeft: function(moveKeys) {
      let vm = this;

      moveKeys.forEach(key => {
        if (!this.updRoleLists.roles2Add.includes(key)) {
          this.updRoleLists.roles2Remove.push(key);
        }
        vm._.remove(this.updRoleLists.roles2Add, function(ele) {
          return ele === key;
        });
      });
    },
    /**
     * 處理穿梭框異動
     * on-change
     * event handler return newKeys(顯示在右邊窗格中的所有的key), direction(此次異動的方向), moveKeys(實際被移動的keys)
     */
    handleChange: async function(newKeys, direction, moveKeys) {
      if (moveKeys.length < 1) {
        return;
      }

      if (direction === "right") {
        // 檢查moveKeys中與newKey互斥衝突的角色清單
        let result = await exclusiveApi.doQryExclusiveConflict({
          sourceRoleList: moveKeys,
          targetRoleList: newKeys
        });

        // 存在互斥衝突角色
        if (!this._.isEmpty(result)) {
          this.showConflictMsg(result);
          return;
        }
        this.handleMoveRight(moveKeys);
      }

      if (direction === "left") {
        this.handleMoveLeft(moveKeys);
      }

      this.transferData.selectedRoleIds = newKeys;
      this.disableQryBtn();
    },
    /**
     * 停用/啟用查詢按鈕
     */
    disableQryBtn: function() {
      // 若尚未操作異動，才可查詢角色
      if (
        this._.isEmpty(this.updRoleLists.roles2Add) &&
        this._.isEmpty(this.updRoleLists.roles2Remove)
      ) {
        this.viewComponentCtrl.isQryBtnDisabled = false;
        return;
      }

      this.viewComponentCtrl.isQryBtnDisabled = true;
    },
    /**
     * 重置Modal
     */
    resetModal: function() {
      this.roleLists = {
        grpRoleList: [],
        grpExRoleList: [],
        roleList: []
      };
      this.updRoleLists = {
        grpId: "",
        roles2Add: [],
        roles2Remove: []
      };
      this.transferData = {
        unselectedRoles: [],
        grpRoleIds: [],
        exRoleIds: [],
        selectedRoleIds: []
      };
      this.$refs["roleForm"].resetFields();
    },
    /**
     * 取消群組角色異動
     */
    cancelUpdGroupRole: function() {
      this.resetModal();
      this.$emit("close");
      this.$Message.info("操作取消");
    },
    /**
     * 送出群組角色異動
     */
    doUpdGrpRole: function() {
      if (
        !this.updRoleLists.roles2Add.length &&
        !this.updRoleLists.roles2Remove.length
      ) {
        this.$Message.error("請設定要異動的角色");
        return;
      }

      f020303Api.doUpdGrpRoles(this.updRoleLists).then(() => {
        this.resetModal();
        this.$emit("close");
        this.$Message.info("設定完成");
      });
    }
  },
  watch: {
    showUpdRoleModal(newValue) {
      this.viewComponentCtrl.isModalVisible = newValue;
      this.viewComponentCtrl.isQryBtnDisabled = false;
    },
    updGroupId(newValue) {
      if (!newValue) {
        return;
      }

      this.roleForm.grpId = newValue;
      this.updRoleLists.grpId = newValue;
      this.doQryRoleLists();
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
