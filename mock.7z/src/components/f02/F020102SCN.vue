<template>
  <div>
    <Modal
      v-model="viewComponentCtrl.isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span>
          新增 {{ targetUpdGrp ? targetUpdGrp.grpId : "" }} |
          {{ targetUpdGrp ? targetUpdGrp.grpNm : "" }} 群組人員
        </span>
      </p>
      <Form
        ref="formValidate"
        :model="formValidate"
        :rules="ruleValidate"
        :label-width="120"
      >
        <OrgSelect
          :divisionProp.sync="formValidate.selectedDivision"
          :headquarterProp.sync="formValidate.selectedHeadquarter"
          :departmentProp.sync="formValidate.selectedDepartment"
          :sectionProp.sync="formValidate.selectedSection"
          :groupProp.sync="formValidate.selectedGroup"
          :divisionReadonly="orgSelectCtrl.divisionDisable"
          :headquarterReadonly="orgSelectCtrl.headquarterDisable"
          :departmentReadonly="orgSelectCtrl.departmentDisable"
          :sectionReadonly="orgSelectCtrl.sectionDisable"
          :disableGroup="orgSelectCtrl.groupDisable"
          :disableUser="orgSelectCtrl.userDisable"
          :key="orgSelectKey"
        >
        </OrgSelect>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="doQryUserList">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Row :gutter="8">
        <Col span="12">
          <Table
            height="400"
            border
            :columns="selectableColumns"
            :data="selectableList"
          >
            <template slot-scope="{ row }" slot="select">
              <Button type="primary" size="small" @click="selectUser(row)">
                <Icon type="md-arrow-forward" />
              </Button>
            </template>
          </Table>
        </Col>
        <Col span="12">
          <Table
            height="400"
            border
            :columns="selectedColumns"
            :data="selectedList"
          >
            <template slot-scope="{ row }" slot="deSelect">
              <Button type="error" size="small" @click="deSelectUser(row)">
                <Icon type="md-close" />
              </Button>
            </template>
          </Table>
        </Col>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdGroupUser">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdGroupUser">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
import f020101Api from "@api/f02/f020101-api";
import f020102Api from "@api/f02/f020102-api";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  props: {
    /**
     * 是否顯示Modal
     */
    showUpdModal: {
      type: Boolean,
      required: false,
      default: false
    },
    /**
     * 異動使用者對象
     */
    updateGroup: {
      type: Object,
      required: false,
      default: function() {
        return {
          // 群組代碼
          grpId: "",
          // 群組名稱
          grpNm: "",
          // 資料來源
          dataSrc: ""
        };
      }
    }
  },
  data() {
    // 事業處或業務群組不得皆為空驗證
    const validateDivOrGrp = (rule, value, callback) => {
      if (this.orgSelectCtrl.groupDisable) {
        if (isBlank(this.formValidate.selectedDivision)) {
          return callback(new Error("請選擇事業處"));
        }

        return callback();
      }

      if (
        isBlank(this.formValidate.selectedDivision) &&
        isBlank(this.formValidate.selectedGroup)
      ) {
        return callback(new Error("請選擇事業處或業務群組"));
      }

      if (isBlank(this.formValidate.selectedDivision)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedDivision"
        }).resetField();
      }

      if (isBlank(this.formValidate.selectedGroup)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedGroup"
        }).resetField();
      }

      callback();
    };
    return {
      // Table Columns
      selectableColumns: [
        {
          title: "員工編號",
          key: "empNo"
        },
        {
          title: "姓名",
          key: "empNm"
        },
        {
          title: "加入名單",
          slot: "select",
          align: "center"
        }
      ],
      selectedColumns: [
        {
          title: "員工編號",
          key: "empNo",
          align: "right"
        },
        {
          title: "姓名",
          key: "empNm"
        },
        {
          title: "移出名單",
          slot: "deSelect",
          align: "center"
        }
      ],
      // 表單驗證項目
      formValidate: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: ""
      },
      // 表單驗證規則
      ruleValidate: {
        selectedDivision: [{ validator: validateDivOrGrp, trigger: "change" }],
        selectedGroup: [{ validator: validateDivOrGrp, trigger: "change" }]
      },
      // OrgSelect 控制項
      orgSelectCtrl: {
        divisionDisable: null,
        headquarterDisable: null,
        departmentDisable: null,
        sectionDisable: null,
        groupDisable: null,
        userDisable: null
      },
      // 畫面元件控制
      viewComponentCtrl: {
        isModalVisible: false
      },
      // 查詢條件
      qryConditionObj: {
        targetGrp: null,
        grpUnitcode: "L40", // L40: 總經理室
        pageNo: 1,
        pageSize: 100,
        sortColumn: null,
        sortType: null
      },
      // 可選使用者清單
      selectableList: [],
      // 已選使用者清單
      selectedList: [],
      // 異動對象群組
      targetUpdGrp: {},
      // 已選AD帳號清單
      userList: [],
      // OrgSelect Component Key
      orgSelectKey: 1
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 查詢群組使用者
     */
    doQryUserList: async function() {
      this.$refs["formValidate"].validate(async valid => {
        if (valid) {
          let result = await f020101Api.doGetGroupUserList(
            this.qryConditionObj
          );

          this.selectableList = result.userList.filter(
            user => this.optUserProfile.adAccount !== user.adAccount
          );
        }
      });
    },
    /**
     * 選取使用者放入已選清單
     */
    selectUser: function(row) {
      if (this.userList.indexOf(row.adAccount) > -1) {
        this.$Message.error("使用者已在名單內");
        return;
      }

      this.selectedList.push(row);
      this.userList.push(row.adAccount);
    },
    /**
     * 從已選清單移除使用者
     */
    deSelectUser: function(row) {
      this.selectedList = this._.filter(this.selectedList, function(user) {
        return user.adAccount !== row.adAccount;
      });

      this._.pull(this.userList, row.adAccount);
    },
    /**
     * 關閉Modal
     */
    cancelUpdGroupUser: function() {
      this.$emit("close");
      this.resetSelection();
      this.$Message.info("操作取消");
    },
    /**
     * 送出異動資料
     */
    doUpdGroupUser: function() {
      if (!this.userList.length || !this.targetUpdGrp) {
        this.$Message.error("請設定加入名單");
        return;
      }

      f020102Api
        .doUpdGroupUser({
          targetGrp: this.targetUpdGrp.grpId,
          userList: this.userList
        })
        .then(() => {
          this.$emit("close", true);
          this.resetSelection();
          this.$Message.info("新增成功");
        });
    },
    /**
     * 重設選項
     */
    resetSelection: function() {
      this.formValidate.selectedDivision = "";
      this.formValidate.selectedDepartment = "";
      this.formValidate.selectedSection = "";
      this.formValidate.selectedGroup = "";
      this.orgSelectKey += 1;
      this.selectableList = [];
      this.selectedList = [];
      this.userList = [];
    },
    /**
     * 系統管理員配置
     */
    sysAdminConfig: function() {
      this.orgSelectCtrl.userDisable = true;
    },
    /**
     * 經理人配置
     */
    managerConfig: function() {
      this.orgSelectCtrl.divisionDisable = true;
      this.orgSelectCtrl.headquarterDisable = true;
      this.orgSelectCtrl.departmentDisable = true;
      this.orgSelectCtrl.userDisable = true;
      this.orgSelectCtrl.groupDisable = true;
    },
    /**
     * 科主管配置
     */
    secSupConfig: function() {
      this.orgSelectCtrl.divisionDisable = true;
      this.orgSelectCtrl.headquarterDisable = true;
      this.orgSelectCtrl.departmentDisable = true;
      this.orgSelectCtrl.sectionDisable = true;
      this.orgSelectCtrl.userDisable = true;
      this.orgSelectCtrl.groupDisable = true;
    }
  },
  watch: {
    /**
     * 監聽OrgSelectGrp
     */
    orgSelectGrp: function(newValue) {
      if (newValue) {
        this.qryConditionObj.targetGrp = newValue;
      }
    },
    /**
     * 監聽外部傳入是否顯示Modal
     */
    showUpdModal(newValue) {
      this.viewComponentCtrl.isModalVisible = newValue;
    },
    /**
     * 監聽外部傳入的異動群組
     */
    updateGroup(newValue) {
      if (!newValue) {
        return;
      }
      this.targetUpdGrp = newValue;
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {
    // 是否具有系統管理員/風險管理部經辦角色,
    // ROLE_00000 系統管理員, ROLE_00032 風險管理部經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00000") ||
      this.optUserProfile.roles.includes("ROLE_00032")
    ) {
      this.sysAdminConfig();
      return;
    }

    // 是否具有部經理/客服中心維運經辦角色,
    // ROLE_00001 部經理, ROLE_00030 客服中心維運經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00001") ||
      this.optUserProfile.roles.includes("ROLE_00030")
    ) {
      this.managerConfig();
      return;
    }

    // 是否具有科主管角色, ROLE_00002 科主管
    if (this.optUserProfile.roles.includes("ROLE_00002")) {
      this.secSupConfig();
      return;
    }
  },
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
