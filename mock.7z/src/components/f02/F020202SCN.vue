<template>
  <div>
    <Modal
      v-model="isModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
      width="90"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user-plus'" />
        <span>
          新增 {{ targetGroup ? targetGroup.grpId : "" }} |
          {{ targetGroup ? targetGroup.grpNm : "" }} 群組管理者</span
        >
      </p>

      <Form
        ref="formValidate"
        :model="formValidate"
        :rules="ruleValidate"
        :label-width="100"
      >
        <OrgSelect
          :divisionProp.sync="formValidate.selectedDivision"
          :headquarterProp.sync="formValidate.selectedHeadquarter"
          :departmentProp.sync="formValidate.selectedDepartment"
          :sectionProp.sync="formValidate.selectedSection"
          disableGroup
          disableUser
        ></OrgSelect>
      </Form>
      <Row type="flex" justify="end">
        <Col span="1.5">
          <Button @click="queryUser">
            <font-awesome-icon :icon="'search'" /><span> 查詢</span>
          </Button>
        </Col>
      </Row>
      <Divider />

      <Table
        :columns="userColumn"
        :data="userList"
        @on-sort-change="handleSort"
      >
        <template slot-scope="{ row }" slot="action">
          <div v-if="isGrpMgr(row)" class="table-alert-cell-row">
            <b>已是{{ targetGroup ? targetGroup.grpNm : "" }}管理者</b>
          </div>
          <Button v-else @click="doAddGroupLeader(row)">加入</Button>
        </template>
      </Table>
      <br />
      <Row type="flex" justify="center">
        <Page
          show-total
          show-elevator
          show-sizer
          :total="page.total"
          :page-size="page.size"
          :current.sync="page.index"
          @on-change="doGetUserList"
          @on-page-size-change="handlePageSizeChange"
          transfer
        ></Page>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="1.5">
          <Button @click="cancelAddGrpMnger">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f020202Api from "@api/f02/f020202-api";
import namingConverter from "@misc/naming-converter";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  props: {
    // 是否顯示對話框
    isModalVisible: {
      type: Boolean,
      default: false
    },
    // 操作的群組資料
    targetGroup: {
      type: Object,
      required: false,
      default: function() {
        return {
          // 群組代碼
          grpId: "",
          // 群組名稱
          grpNm: "",
          // 資料來源
          dataSrc: ""
        };
      }
    },
    // 群組管理者清單
    grpMgrList: {
      type: Array,
      default: function() {
        return [];
      }
    }
  },
  data() {
    return {
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ]
      },
      formValidate: {
        // 事業處
        selectedDivision: "",
        // 本部
        selectedHeadquarter: "",
        // 部門
        selectedDepartment: "",
        // 科別
        selectedSection: ""
      },
      // page
      page: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      userList: [],
      userColumn: [
        {
          title: "單位",
          key: "grpNm"
        },
        {
          title: "職稱",
          key: "titleNm"
        },
        {
          title: "AD帳號",
          key: "adAccount",
          sortable: "custom"
        },
        {
          title: "員工編號",
          key: "empNo",
          sortable: "custom",
          align: "right"
        },
        {
          title: "員工姓名",
          key: "empNm"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ]
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    queryUser: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetUserList();
        }
      });
    },
    /**
     * 查詢使用者清單
     */
    doGetUserList: async function() {
      let result = await f020202Api.doGetUserList({
        grpId: this.grpId,
        pageNo: this.page.index,
        pageSize: this.page.size,
        sortColumn: this.page.sortColumn,
        sortType: this.page.sortType
      });

      this.page.total = result.totalCount;
      this.userList = result.userInfoList;
    },
    /**
     * 處理排序
     */
    handleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.page.sortColumn = null;
        this.page.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.page.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.page.sortType = col.order.toUpperCase();
      }

      this.queryUser();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.page.size = newPageSize;
      this.queryUser();
    },
    /**
     * 新增群組管理者
     */
    doAddGroupLeader: async function(row) {
      let result = await f020202Api.doAddGroupLeader({
        grpId: this.targetGroup.grpId,
        adAccount: row.adAccount
      });

      if (result) {
        // 傳回訊息讓父組件重新獲取新資料
        this.$emit("close", true);
        this.$Message.info("加入成功");
      }
    },
    // 是否為群組管理者
    isGrpMgr: function(row) {
      return this.grpMgrList.filter(user => user.adAccount === row.adAccount)
        .length;
    },
    // 關閉Modal
    cancelAddGrpMnger: function() {
      this.$emit("close");
      this.$Message.info("操作取消");
    }
  },
  computed: {
    // 群組編號
    grpId: function() {
      return (
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
