<template>
  <div>
    <Table :columns="roleColumn" :data="roleList"></Table>
  </div>
</template>

<script>
import exclusiveApi from "@api/common/exclusive-api";

export default {
  props: {
    // 所屬事業處
    roleId: {
      type: String,
      required: true,
      default: ""
    }
  },
  data() {
    return {
      // table
      roleList: [],
      roleColumn: [
        {
          title: "互斥角色",
          key: "roleNm",
          sortable: "true"
        }
      ]
    };
  },
  methods: {
    /**
     * 查詢互斥角色清單
     */
    doQryExclusives: async function() {
      this.roleList = await exclusiveApi.doQryExclusives({
        roleId: this.roleId
      });
    }
  },
  watch: {
    /**
     * 監聽父組件props 角色代碼改變做查詢
     */
    roleId(newValue) {
      if (!newValue) {
        return;
      }

      this.doQryExclusives();
    }
  }
};
</script>
