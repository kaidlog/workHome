<template>
  <div>
    <Select
      v-model="selectedItem"
      @on-change="$emit('update:value', $event)"
      clearable
      filterable
    >
      <Option v-for="item in sysList" :value="item.value" :key="item.value">{{
        item.label
      }}</Option>
    </Select>
  </div>
</template>

<script>
import systemListApi from "@api/common/system-list-api";

export default {
  methods: {
    /**
     * 查詢系統清單
     */
    doQrySystemList: async function() {
      let result = await systemListApi.doQrySystemList();
      this.sysList = result;
    }
  },
  data() {
    return {
      sysList: [],
      selectedItem: ""
    };
  },
  created() {
    this.doQrySystemList();
  },
  props: {
    // 所選系統
    sysProp: {
      type: String,
      required: false
    }
  },
  watch: {
    /**
     * 監聽所選系統
     */
    sysProp: async function(newValue) {
      this.selectedItem = newValue;
    }
  }
};
</script>
