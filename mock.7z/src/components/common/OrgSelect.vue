<template>
  <div>
    <Row>
      <Col span="8">
        <FormItem prop="selectedDivision" label="事業處">
          <Select
            v-model="selectedDivision"
            :disabled="divisionReadonly"
            clearable
            filterable
            @on-change="$emit('update:divisionProp', $event)"
          >
            <Option
              v-for="division in divisionList"
              :value="division.grpId"
              :key="division.grpId"
              >{{ division.grpNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <Col span="8">
        <FormItem prop="selectedHeadquarter" label="本部">
          <Select
            v-model="selectedHeadquarter"
            :disabled="headquarterReadonly"
            clearable
            filterable
            @on-change="$emit('update:headquarterProp', $event)"
          >
            <Option
              v-for="headquarter in headquarterList"
              :value="headquarter.grpId"
              :key="headquarter.grpId"
              >{{ headquarter.grpNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <Col span="8">
        <FormItem prop="selectedDepartment" label="部門/中心">
          <Select
            v-model="selectedDepartment"
            :disabled="departmentReadonly"
            clearable
            filterable
            @on-change="$emit('update:departmentProp', $event)"
          >
            <Option
              v-for="department in departmentList"
              :value="department.grpId"
              :key="department.grpId"
              >{{ department.grpNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <Col span="8">
        <FormItem prop="selectedSection" label="科別">
          <Select
            v-model="selectedSection"
            :disabled="sectionReadonly"
            clearable
            filterable
            @on-change="$emit('update:sectionProp', $event)"
          >
            <Option
              v-for="section in sectionList"
              :value="section.grpId"
              :key="section.grpId"
              >{{ section.grpNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <Col span="8" v-if="!disableGroup">
        <FormItem prop="selectedGroup" label="業務群組">
          <Select
            v-model="selectedGroup"
            clearable
            filterable
            @on-change="$emit('update:groupProp', $event)"
          >
            <Option
              v-for="group in groupList"
              :value="group.grpId"
              :key="group.grpId"
              >{{ group.grpNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <Col span="8" v-if="!disableUser">
        <FormItem prop="selectedUser" label="人員">
          <Select
            v-model="selectedUser"
            clearable
            filterable
            @on-change="$emit('update:userProp', $event)"
          >
            <Option
              v-for="user in userList"
              :value="user.adAccount"
              :key="user.empNo"
              >{{ user.empNm }}</Option
            >
          </Select>
        </FormItem>
      </Col>

      <slot></slot>
    </Row>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import subordinateApi from "@api/common/subordinate-api.js";

export default {
  components: {},
  props: {
    // 所屬事業處
    divisionProp: {
      type: String,
      required: false
    },
    // 所屬本部
    headquarterProp: {
      type: String,
      required: false
    },
    // 所屬部門
    departmentProp: {
      type: String,
      required: false
    },
    // 所屬科別
    sectionProp: {
      type: String,
      required: false
    },
    // 所屬群組
    groupProp: {
      type: String,
      required: false
    },
    // 所屬使用者
    userProp: {
      type: String,
      required: false
    },
    // 事業處選單是否唯讀
    divisionReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 本部選單是否唯讀
    headquarterReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 部門選單是否唯讀
    departmentReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 科別選單是否唯讀
    sectionReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 啟用GroupSelect
    disableGroup: {
      type: Boolean,
      required: false,
      default: false
    },
    // 啟用UserSelect
    disableUser: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data() {
    return {
      divisionList: [],
      headquarterList: [],
      departmentList: [],
      sectionList: [],
      groupList: [],
      userList: [],
      upperUnitList: [],
      selectedDivision: "",
      selectedHeadquarter: "",
      selectedDepartment: "",
      selectedSection: "",
      selectedGroup: "",
      selectedUser: "",
      initial: true
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"])
  },
  methods: {
    /**
     * 更新事業處下拉選單資料
     */
    doUpdDivisions: async function(grpId) {
      let result = await subordinateApi.doQrySubordinateUnit({
        upGrpId: grpId,
        grpUnitcodeList: ["L50"]
      });
      this.divisionList = result.hrGrpList;
      this.groupList = result.custGrpList;

      this.selectedDivision = this.divisionProp;
    },
    /**
     * 更新本部下拉選單資料
     */
    doUpdHeadquarters: async function(grpId) {
      let result = await subordinateApi.doQrySubordinateUnit({
        upGrpId: grpId,
        grpUnitcodeList: ["L55"]
      });
      this.headquarterList = result.hrGrpList;
      this.groupList = result.custGrpList;

      this.selectedHeadquarter = this.headquarterProp;
    },
    /**
     * 更新部門下拉選單資料
     */
    doUpdDepartments: async function(grpId) {
      if (!grpId) {
        return;
      }

      let result = await subordinateApi.doQrySubordinateUnit({
        upGrpId: grpId,
        grpUnitcodeList: ["L60", "L80"]
      });
      this.departmentList = result.hrGrpList;
      this.groupList = result.custGrpList;

      this.selectedDepartment = this.departmentProp;
    },
    /**
     * 更新科別下拉選單資料
     */
    doUpdSections: async function(grpId) {
      if (!grpId) {
        return;
      }

      let result = await subordinateApi.doQrySubordinateUnit({
        upGrpId: grpId,
        grpUnitcodeList: ["L90"]
      });
      this.sectionList = result.hrGrpList;
      this.groupList = result.custGrpList;

      this.selectedSection = this.sectionProp;
    },
    /**
     * 更新業務群組下拉選單資料
     */
    doUpdGroups: async function(grpId) {
      if (!grpId) {
        return;
      }

      let result = await subordinateApi.doQrySubordinateUnit({
        upGrpId: grpId,
        grpUnitcodeList: []
      });
      this.groupList = result.custGrpList;

      this.selectedGroup = this.groupProp;
    },
    /**
     * 更新使用者下拉選單資料
     */
    doUpdUsers: async function(newGrpId, oldGrpId) {
      if (!oldGrpId && !newGrpId) {
        this.userList = [];
        return;
      }

      if (!newGrpId) {
        this.userList = await subordinateApi.doQrySubordinateUser({
          grpId: oldGrpId
        });
        return;
      }

      this.userList = await subordinateApi.doQrySubordinateUser({
        grpIdList: newGrpId
      });

      this.selectedUser = this.userProp;
    }
  },
  watch: {
    /**
     * 監聽事業處選項
     */
    selectedDivision: async function(newValue) {
      if (this.initial) {
        return;
      }

      this.headquarterList = [];
      this.departmentList = [];
      this.sectionList = [];
      this.groupList = [];
      this.userList = [];
      this.selectedHeadquarter = "";
      this.selectedDepartment = "";
      this.selectedSection = "";
      this.selectedGroup = "";
      this.selectedUser = "";

      if (!newValue) {
        await this.doUpdDivisions();
        return;
      }

      await this.doUpdHeadquarters(newValue);
      await this.doUpdDepartments(newValue);
      await this.doUpdSections(newValue);
      await this.doUpdUsers(newValue, newValue);
    },
    /**
     * 監聽本部選項
     */
    selectedHeadquarter: async function(newValue) {
      if (this.initial) {
        return;
      }

      this.departmentList = [];
      this.sectionList = [];
      this.groupList = [];
      this.userList = [];
      this.selectedDepartment = "";
      this.selectedSection = "";
      this.selectedGroup = "";
      this.selectedUser = "";

      if (!newValue) {
        await this.doUpdHeadquarters(this.selectedDivision);
        await this.doUpdUsers(newValue, this.selectedDivision);
        return;
      }

      await this.doUpdDepartments(newValue);
      await this.doUpdUsers(newValue, this.selectedDivision);
    },
    /**
     * 監聽部門選項
     */
    selectedDepartment: async function(newValue) {
      if (this.initial) {
        return;
      }

      this.sectionList = [];
      this.groupList = [];
      this.userList = [];
      this.selectedSection = "";
      this.selectedGroup = "";
      this.selectedUser = "";

      let prevGrp = this.selectedHeadquarter || this.selectedDivision;

      if (!newValue) {
        await this.doUpdDepartments(prevGrp);
        await this.doUpdUsers(newValue, prevGrp);
        return;
      }

      await this.doUpdSections(newValue);
      await this.doUpdUsers(newValue, prevGrp);
    },
    /**
     * 監聽科別選項
     */
    selectedSection: async function(newValue) {
      if (this.initial) {
        return;
      }

      this.groupList = [];
      this.userList = [];
      this.selectedGroup = "";
      this.selectedUser = "";

      let prevGrp = this.selectedDepartment || this.selectedHeadquarter;

      if (!newValue) {
        await this.doUpdSections(this.selectedDepartment);
        await this.doUpdUsers(newValue, prevGrp);
        return;
      }

      await this.doUpdGroups(newValue);
      await this.doUpdUsers(newValue, prevGrp);
    },
    /**
     * 監聽群組選項
     */
    selectedGroup: async function(newValue) {
      this.selectedUser = "";

      let prevGrp =
        this.selectedSection ||
        this.selectedDepartment ||
        this.selectedHeadquarter ||
        this.selectedDivision;

      await this.doUpdUsers(newValue, prevGrp);
    }
  },
  beforeCreate() {},
  created() {
    (async () => {
      /** 建立時取得事業處選單 */
      await this.doUpdDivisions("");

      /** 建立時取得操作人員組織樹清單, 依停用選單自動帶入單位 */
      this.upperUnitList = await subordinateApi.doQryUpperUnit({
        grpId: this.optUserProfile.grpId
      });

      // L50: 處級單位
      if (this.divisionReadonly) {
        this.selectedDivision = this._.find(this.upperUnitList, u => {
          return u.grpUnitcode === "L50";
        }).grpId;

        this.$emit("update:divisionProp", this.selectedDivision);

        await this.doUpdHeadquarters(this.selectedDivision);
        await this.doUpdDepartments(this.selectedDivision);
        await this.doUpdUsers(this.selectedDivision);
      }

      // L55: 本部級單位
      if (this.headquarterReadonly) {
        let targetGrpId;
        let headquarter = this._.find(this.upperUnitList, u => {
          return u.grpUnitcode === "L55";
        });

        if (headquarter) {
          targetGrpId = headquarter.grpId;
          this.selectedHeadquarter = headquarter.grpId;
        } else {
          targetGrpId = this.selectedDivision;
        }

        this.$emit("update:headquarterProp", this.selectedHeadquarter);

        await this.doUpdDepartments(targetGrpId);
        await this.doUpdUsers(targetGrpId);
      }

      // L60 部級單位, L80 部級單位
      if (this.departmentReadonly) {
        let targetGrpId;
        let department = this._.find(this.upperUnitList, u => {
          return u.grpUnitcode === "L60" || u.grpUnitcode === "L80";
        });

        if (department) {
          targetGrpId = department.grpId;
          this.selectedDepartment = department.grpId;
        } else {
          targetGrpId = this.selectedDivision;
        }

        this.$emit("update:departmentProp", this.selectedDepartment);

        await this.doUpdSections(targetGrpId);
        await this.doUpdUsers(targetGrpId);
      }

      // L90 科級單位
      if (this.sectionReadonly) {
        this.selectedSection = this._.find(this.upperUnitList, u => {
          return u.grpUnitcode === "L90";
        }).grpId;

        this.$emit("update:sectionProp", this.selectedSection);

        await this.doUpdGroups(this.selectedSection);
        await this.doUpdUsers(this.selectedSection, this.selectedSection);
      }

      /** 完成初始化後設為false */
      this.initial = false;
    })();
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
