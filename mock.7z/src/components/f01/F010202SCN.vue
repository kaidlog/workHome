<template>
  <div>
    <Modal
      width="80"
      v-model="isModalVisible"
      :closable="false"
      :mask-closable="false"
      footer-hide
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span>
          {{ isModification ? "修改人員" : "新增人員" }}
        </span>
      </p>
      <Form
        ref="formValidate"
        :model="user"
        :rules="ruleValidate"
        :label-width="120"
      >
        <Row>
          <Col span="8">
            <FormItem label="AD帳號" prop="adAccount">
              <Input
                v-model="user.adAccount"
                :disabled="adAccountDisabled"
                maxlength="20"
                show-word-limit
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="員工姓名" prop="empNm">
              <Input v-model="user.empNm" maxlength="20" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="EMAIL" prop="email">
              <Input
                v-model="user.email"
                type="email"
                maxlength="70"
                show-word-limit
              />
            </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="8">
            <FormItem label="分機號碼" prop="phoneExt">
              <Input v-model="user.phoneExt" maxlength="12" show-word-limit />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="職稱" prop="titleCd">
              <sys-cd-select
                suspend="N"
                :ctId="33"
                :value.sync="user.titleCd"
                readonly
              />
            </FormItem>
          </Col>
          <Col span="8">
            <FormItem label="帳號狀態" prop="accSts">
              <sys-cd-select
                suspend="N"
                flag01="B"
                :ctId="35"
                :value.sync="user.accSts"
                clearable
              />
            </FormItem>
          </Col>
        </Row>
      </Form>
      <br />
      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelUpdateUser">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="doUpdateUser">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f010202Api from "@api/f01/f010202-api";

export default {
  components: {},
  computed: {},
  props: {
    // 是否顯示對話框
    isModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來角色資訊
    userInfo: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    const validateAdAcc = async (rule, value, callback) => {
      if (this.isModification) {
        return callback();
      }

      if (!value.match("^[A-Za-z0-9-]+$")) {
        return callback(new Error("僅能填入英文、數字或連字符"));
      }

      let userCount = await f010202Api.doQryUserCount({
        adAccount: value
      });
      if (userCount > 0) {
        return callback(new Error("AD帳號已存在，請更換AD帳號"));
      }

      callback();
    };
    return {
      // 動作是否為修改
      isModification: false,
      // 驗證規則
      ruleValidate: {
        adAccount: [
          {
            required: true,
            message: "請輸入AD帳號",
            trigger: "blur"
          },
          {
            validator: validateAdAcc,
            trigger: "blur"
          }
        ],
        empNm: [
          {
            required: true,
            message: "請輸入員工姓名",
            trigger: "blur"
          }
        ],
        email: [
          {
            required: true,
            message: "請輸入公司Email",
            trigger: "blur"
          },
          {
            type: "email",
            message: "請輸入正確的email格式",
            trigger: "blur"
          }
        ],
        phoneExt: [
          {
            required: true,
            message: "請輸入分機號碼",
            trigger: "blur"
          },
          {
            pattern: "^[0-9]+$",
            message: "僅能填入數字",
            trigger: "blur"
          }
        ],
        titleCd: [
          {
            required: true,
            message: "請選擇職稱",
            trigger: "change"
          }
        ],
        accSts: [
          {
            required: true,
            message: "請選擇帳號狀態",
            trigger: "change"
          }
        ]
      },
      adAccountDisabled: false,
      user: {}
    };
  },
  methods: {
    /**
     * 取消
     */
    cancelUpdateUser: function() {
      this.$emit("close");
      // 顯示取消訊息
      this.$Message.info("操作取消");
      // 清除表單欄位並重新深拷貝人員資訊
      this.$refs["formValidate"].resetFields();
      this.user = {};
    },
    /**
     * 新增/修改人員
     */
    doUpdateUser: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          f010202Api.doUpdateUser(this.user).then(() => {
            // 關閉 Modal 並傳回訊息讓父組件重新獲取新資料
            this.$emit("close", true);
            // 顯示成功訊息
            this.$Message.info("操作成功");
          });
        }
      });
    }
  },
  watch: {
    /**
     * 深拷貝使用者資訊，避免物件傳址而修改到父組件值，若為編輯使用者資訊則停用使用者AD帳號輸入框
     */
    userInfo: {
      handler: function() {
        this.user = this._.cloneDeep(this.userInfo);
        if (this.user.adAccount) {
          this.isModification = true;
          this.adAccountDisabled = true;
        } else {
          this.adAccountDisabled = false;
          this.isModification = false;
          this.user = {
            // AD帳號
            adAccount: "",
            // 員工姓名
            empNm: "",
            // EMAIL
            email: "",
            // 分機號碼
            phoneExt: "",
            // 職稱代碼，控制畫面呈現 (B_1: 委外人員)
            titleCd: "B_1",
            // 帳號狀態 (3: 任用)
            accSts: "3"
          };
        }
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
