<template>
  <div>
    <Modal
      v-model="isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'cog'" />
        <span> 新增代理設定</span>
      </p>

      <Row v-if="!isAdmin && !isCopyAgent">
        <Col span="8">
          <sys-cd-radio
            :ctId="197"
            :value.sync="agentTarget"
            :type="'button'"
            v-if="!isManager"
          ></sys-cd-radio>
        </Col>
      </Row>

      <Form
        ref="formValidate"
        :model="formValidate"
        :rules="userFormRules"
        :label-width="120"
      >
        <Row
          v-if="!isAdmin && !isCopyAgent"
          style="margin-top:15px;margin-bottom:15px;"
          type="flex"
          justify="center"
        >
          <Col span="12">
            <FormItem prop="selectedUser" label="人員">
              <Select v-model="formValidate.selectedUser" filterable>
                <Option
                  v-for="user in userList"
                  :value="user.adAccount"
                  :key="user.empNo"
                >
                  {{ user.empNm }}
                </Option>
              </Select>
            </FormItem>
          </Col>
        </Row>
        <Row v-if="isAdmin && !isCopyAgent" type="flex" justify="center">
          <Col span="24">
            <OrgSelect
              :divisionProp.sync="formValidate.selectedDivision"
              :headquarterProp.sync="formValidate.selectedHeadquarter"
              :departmentProp.sync="formValidate.selectedDepartment"
              :sectionProp.sync="formValidate.selectedSection"
              :groupProp.sync="formValidate.selectedGroup"
              :userProp.sync="formValidate.selectedUser"
              :disableGroup="true"
              :key="orgSelectComponentKey"
            ></OrgSelect>
          </Col>
        </Row>
      </Form>

      <Row v-if="!isCopyAgent">
        <Col span="4" offset="4">
          <Button :disabled="disableAgentUserBtn" @click="setAgentUser">
            <font-awesome-icon :icon="'arrow-alt-circle-down'" />
            <span> 設為被代理人</span>
          </Button>
        </Col>
        <Col span="4" offset="8">
          <Button @click="setAgent">
            <span>設為代理人 </span>
            <font-awesome-icon :icon="'arrow-alt-circle-down'" />
          </Button>
        </Col>
      </Row>
      <Row :gutter="16" type="flex" justify="center" style="margin-top:15px;">
        <Col span="10">
          <DatePicker
            style="width:100%;"
            @on-change="startTime = $event"
            type="datetime"
            placeholder="選擇代理區間(起)"
            format="yyyy/MM/dd HH:mm:ss"
            :key="startTimePickerComponentKey"
            :editable="false"
            :options="options"
            :time-picker-options="{ steps: [1, 10, 10] }"
          ></DatePicker>
        </Col>
        <Col span="10">
          <DatePicker
            style="width:100%;"
            @on-change="endTime = $event"
            type="datetime"
            placeholder="選擇代理區間(迄)"
            format="yyyy/MM/dd HH:mm:ss"
            :key="endTimePickerComponentKey"
            :editable="false"
            :options="options"
            :time-picker-options="{ steps: [1, 10, 10] }"
          ></DatePicker>
        </Col>
      </Row>
      <Row type="flex" justify="center" style="margin-top:15px;">
        <Col span="20">
          <Input
            v-model="formValidate.reason"
            type="textarea"
            placeholder="緣由"
            style="width: 100%"
            maxlength="300"
            show-word-limit
          />
        </Col>
      </Row>
      <br />

      <Row>
        <Transfer
          filterable
          :list-style="{ width: '45%', height: '250px' }"
          :data="agentUserRoles"
          :target-keys="agentRoles"
          :operations="['移除', '代理']"
          :titles="transferTitle"
          :not-found-text="noDataText"
          @on-change="handleChange"
        ></Transfer>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="cancelAddAgentInfo">
            <font-awesome-icon :icon="'undo-alt'" /><span> 取消</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="postAgentInfo">
            <font-awesome-icon :icon="'paper-plane'" /><span> 送出</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import f010102Api from "@api/f01/f010102-api";
import f010103Api from "@api/f01/f010103-api";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  props: {
    showAddModal: {
      type: Boolean,
      required: false,
      default: false
    },
    copyAgentSeqNo: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      formValidate: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: "",
        selectedUser: "",
        reason: ""
      },
      userFormRules: {
        selectedUser: [
          {
            required: true,
            message: "請選擇使用者",
            trigger: "change"
          }
        ]
      },
      // Datepicker禁選今天以前的日期
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      transferTitle: ["", ""],
      // 穿梭框預設文字
      noDataText: "無資料",
      // 設定對象 S: Self(操作人), O: Others(同仁), 科主管時使用
      agentTarget: "",
      // 使用者清單
      userList: [],
      // 被代理人
      agentUser: "",
      // 被代理人姓名
      agentUserName: "",
      // 被代理人群組有效角色
      agentUserRoles: [],
      // 被代理人與代理人互斥角色清單
      exRoles: [],
      // 代理人
      agent: "",
      // 代理人姓名
      agentName: "",
      // 代理人已代理角色, Array<roleId>
      agentRoles: [],
      // 代理區間(起)
      startTime: "",
      // 代理區間(迄)
      endTime: "",
      // 要被代理的角色, Array<roleId>
      payloadRoleIds: [],
      // 畫面控制項
      disableAgentUserBtn: false,
      isModalVisible: false,
      isCopyAgent: false,
      isAdmin: false,
      isManager: false,
      // Component Key for rerender
      orgSelectComponentKey: 1,
      startTimePickerComponentKey: 1,
      endTimePickerComponentKey: 1
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"])
  },
  methods: {
    /**
     * 轉換穿梭框角色物件
     */
    convertRole: function(roleList, isEx) {
      return this._.map(roleList, function(role) {
        return {
          key: role.roleId,
          label: role.roleNm,
          disabled: isEx
        };
      });
    },
    /**
     * 設定被代理人
     */
    setAgentUser: function() {
      this.$refs["formValidate"].validate(valid => {
        if (!valid) {
          return;
        }

        if (this.agent === this.formValidate.selectedUser) {
          this.$Message.error("代理人、被代理人不可相同");
          return;
        }

        this.agentUser = this.formValidate.selectedUser;
        this.transferTitle[0] = this.agentUser;

        this.agentUserName = "";
        this.agent = "";
        this.agentName = "";
        this.agentUserRoles = [];
        this.exRoles = [];
        this.agentRoles = [];
        this.payloadRoleIds = [];
      });
    },
    /**
     * 設定代理人, 並取得被代理人角色(排除代理人互斥的角色)
     */
    setAgent: function() {
      if (!this.agentUser) {
        this.$Message.error("請先設定被代理人員");
        return;
      }

      this.$refs["formValidate"].validate(valid => {
        if (!valid) {
          return;
        }

        if (this.agentUser === this.formValidate.selectedUser) {
          this.$Message.error("代理人、被代理人不可相同");
          return;
        }

        this.agent = this.formValidate.selectedUser;
        this.setTransfer();
      });
    },
    /**
     * 設定穿梭框角色資料
     */
    setTransfer: async function() {
      // 被代理人群組有效角色清單 & 被代理人與代理人互斥角色清單
      let roles = await f010103Api.doGetAgentUserRoles({
        agentUser: this.agentUser,
        agent: this.agent
      });

      // 被代理人 & 代理人姓名
      this.agentUserName = roles.agentUserProfile.empName;
      this.agentName = roles.agentProfile.empName;
      this.transferTitle[0] = this.agentUser + " " + this.agentUserName;
      this.transferTitle[1] = this.agent + " " + this.agentName;

      // 被代理人群組有效角色清單
      this.agentUserRoles = this.convertRole(roles.agentUserRoles, false);

      // 被代理人與代理人互斥角色清單
      this.exRoles = this.convertRole(roles.exclusiveRoles, true);
      this.agentUserRoles.push(...this.exRoles);
    },
    /**
     * 處理穿梭框異動
     * on-change
     * event handler return newKeys(顯示在右邊窗格中的所有的key), direction(此次異動的方向), moveKeys(實際被移動的keys)
     */
    handleChange: function(newKeys, direction, moveKeys) {
      this.agentRoles = newKeys;
      // direction === "right" 為自穿梭框左側選至右側
      if (direction === "right") {
        this.payloadRoleIds.push(...moveKeys);
        return;
      }
      moveKeys.forEach(key => {
        if (this.payloadRoleIds.indexOf(key) > -1) {
          this.payloadRoleIds.splice(this.payloadRoleIds.indexOf(key), 1);
        }
      });
    },
    /**
     * 送出新增
     */
    postAgentInfo: function() {
      // 確認 [被代理人、代理人、代理區間起迄、代理角色] 皆設定完成
      if (
        !this.agentUser ||
        !this.agent ||
        !this.startTime ||
        !this.endTime ||
        !this.payloadRoleIds.length
      ) {
        this.$Message.error(
          "請確認 [被代理人、代理人、代理區間起迄、代理角色] 皆設定完成"
        );
        return;
      }
      // 確認代理時間起迄設定無誤
      if (!this.checkStartIsBeforeEnd()) {
        this.$Message.error("結束時間不得小於開始時間");
        return;
      }
      // 確認代理區間不超過60天
      if (!this.checkPeriod()) {
        this.$Message.error("代理區間不得超過60天");
        return;
      }

      f010103Api
        .doAddAgent({
          agent: this.agent,
          agentUser: this.agentUser,
          reason: this.formValidate.reason,
          startTime: this.startTime,
          endTime: this.endTime,
          agentRoleList: this.payloadRoleIds
        })
        .then(() => {
          this.$emit("close", true);
          this.resetSelection();
          this.$Message.info("新增成功");
        });
    },
    /**
     * 取消新增
     */
    cancelAddAgentInfo: function() {
      this.$emit("close");
      this.resetSelection();
      this.$Message.info("取消新增");
    },
    /**
     * 檢查起迄時間
     */
    checkStartIsBeforeEnd: function() {
      let start = this.$moment(this.startTime, "YYYY/MM/DD HH:mm:ss");
      let end = this.$moment(this.endTime, "YYYY/MM/DD HH:mm:ss");
      return start.isBefore(end);
    },
    /**
     * 檢查起迄區間
     */
    checkPeriod: function() {
      let start = this.$moment(this.startTime, "YYYY/MM/DD HH:mm:ss");
      let end = this.$moment(this.endTime, "YYYY/MM/DD HH:mm:ss");
      return this.$moment.duration(end.diff(start)).asDays() <= 60;
    },
    /**
     * 重設選項
     */
    resetSelection: function() {
      this.formValidate.selectedDivision = "";
      this.formValidate.selectedDepartment = "";
      this.formValidate.selectedSection = "";
      this.formValidate.selectedGroup = "";
      this.formValidate.selectedUser = "";
      this.formValidate.reason = "";
      this.startTime = "";
      this.endTime = "";
      this.agentUserName = "";
      this.agent = "";
      this.agentName = "";
      this.exRoles = [];
      this.agentRoles = [];
      this.agentUserRoles = [];
      this.payloadRoleIds = [];
      this.isCopyAgent = false;
      this.isModalVisible = false;
      this.orgSelectComponentKey += 1;
      this.startTimePickerComponentKey += 1;
      this.endTimePickerComponentKey += 1;
      if (!this.isManager) {
        this.agentUser = "";
        this.agentTarget = "";
        this.userList = [];
        this.transferTitle = ["", ""];
      }
    }
  },
  watch: {
    /**
     * 監聽外部傳入是否顯示Modal
     */
    showAddModal(newValue) {
      this.isModalVisible = newValue;
    },
    /**
     * 監聽是否複製代理
     */
    copyAgentSeqNo: async function(newValue) {
      if (!newValue) {
        return;
      }
      this.isCopyAgent = true;

      // 複製代理資訊 ----------------------------------------------------------------------------------------------------
      let copyOfAgent = await f010103Api.doGetAgent({
        agentSeqNo: newValue
      });

      this.agentUser = copyOfAgent.agentUser;
      this.agent = copyOfAgent.agent;

      // 要複製的代理角色清單 --------------------------------------------------------------------------------------------
      let lastAgentRoles = await f010102Api.doGetAgentRoleList({
        agentSeqNo: newValue
      });

      // 配置穿梭框 -----------------------------------------------------------------------------------------------------
      await this.setTransfer();

      // 被代理人角色代碼清單 --------------------------------------------------------------------------------------------
      let agentUserRoleIds = this._.map(this.agentUserRoles, function(role) {
        return role.key;
      });

      // 互斥角色代碼清單 ------------------------------------------------------------------------------------------------
      let exRoleIds = this._.map(this.exRoles, function(role) {
        return role.key;
      });

      // 要複製的代理角色代碼清單 -----------------------------------------------------------------------------------------
      let lastRoleIds = this._.map(lastAgentRoles, function(role) {
        return role.roleId;
      });

      // 排除要複製的代理角色中的互斥角色 ---------------------------------------------------------------------------------
      lastRoleIds = this._.filter(lastRoleIds, function(roleId) {
        return !exRoleIds.includes(roleId);
      });

      // 將複製的代理角色移動至穿梭框右側 ---------------------------------------------------------------------------------
      this.agentRoles = this._.filter(agentUserRoleIds, function(roleId) {
        return lastRoleIds.includes(roleId);
      });

      // 放入要送出的角色代碼清單 -----------------------------------------------------------------------------------------
      this.payloadRoleIds.push(...this.agentRoles);
    },
    /**
     * 監聽代理對象設定
     */
    agentTarget(newValue) {
      // 取消新增時避免發送Request
      if (!newValue) {
        return;
      }
      // S: Self
      if (newValue === "S") {
        this.disableAgentUserBtn = true;
        this.agentUser = this.optUserProfile.adAccount;
        this.transferTitle[0] = this.agentUser;
      }
      // O: Other
      if (newValue === "O") {
        this.disableAgentUserBtn = false;
        this.agentUser = "";
        this.transferTitle = ["", ""];
      }
      this.agentUserName = "";
      this.agent = "";
      this.agentName = "";
      this.agentUserRoles = [];
      this.exRoles = [];
      this.agentRoles = [];
      this.startTime = "";
      this.endTime = "";
      this.formValidate.reason = "";
      this.startTimePickerComponentKey += 1;
      this.endTimePickerComponentKey += 1;

      let optUser = this.optUserProfile.adAccount;
      f010103Api
        .doGetUserList({
          target: newValue
        })
        .then(val => {
          this.userList = this._.filter(val, function(user) {
            return user.adAccount !== optUser;
          });
        });
    }
  },
  beforeCreate() {},
  created() {
    // ROLE_00000 系統管理員, ROLE_00035 權限平台_代理人設定_風管部
    this.isAdmin =
      this.optUserProfile.roles.includes("ROLE_00000") ||
      this.optUserProfile.roles.includes("ROLE_00035");
    // ROLE_00034 權限平台_代理人設定_部經理
    if (this.optUserProfile.roles.includes("ROLE_00034")) {
      this.isManager = true;
      this.agentTarget = "S"; // S: Self
    }
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
