<template>
  <div>
    <Modal
      v-model="isModalVisible"
      :closable="false"
      :mask-closable="false"
      :footer-hide="true"
      width="80%"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 代理角色</span>
      </p>
      <Table border :height="300" :columns="roleColumns" :data="agentRoles">
      </Table>
      <br />
      <Row type="flex" justify="center">
        <Col span="2">
          <Button @click="closeRoleModal">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
        <Col span="2">
          <Button type="primary" @click="resetAgent">
            <font-awesome-icon :icon="'copy'" /><span> 重新代理</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f010102Api from "@api/f01/f010102-api";

export default {
  components: {},
  props: {
    /**
     * 是否顯示Modal
     */
    showRoleModal: {
      type: Boolean,
      required: false,
      default: false
    },
    /**
     * 代理SeqNo
     */
    agentSeqNo: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      // 代理角色清單
      agentRoles: [],
      // 畫面控制項
      isModalVisible: false,
      // Role Table Columns
      roleColumns: [
        {
          title: "角色代碼",
          key: "roleId"
        },
        {
          title: "角色類別",
          key: "roleTypeNm"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        }
      ]
    };
  },
  computed: {},
  methods: {
    /**
     * 取得代理角色清單
     */
    doQryRoleList: async function() {
      this.agentRoles = await f010102Api.doGetAgentRoleList({
        agentSeqNo: this.agentSeqNo
      });
    },
    /**
     * 關閉檢視代理角色Modal
     */
    closeRoleModal: function() {
      this.$emit("unload");
    },
    /**
     * 再次設定代理
     */
    resetAgent: function() {
      this.$emit("load");
    }
  },
  watch: {
    /**
     * 監聽外部傳入是否顯示Modal
     */
    showRoleModal(newValue) {
      this.isModalVisible = newValue;
    },
    /**
     * 監聽外部傳入代理SeqNo
     */
    agentSeqNo() {
      this.doQryRoleList();
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
