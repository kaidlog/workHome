<template>
  <div>
    <Modal
      v-model="isModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
      width="90"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 檢視角色</span>
      </p>
      <Table
        :columns="roleColumn"
        :data="roleList"
        @on-sort-change="handleRoleSort"
        border
      ></Table>
      <br />
      <Row type="flex" justify="center">
        <Page
          show-total
          show-elevator
          show-sizer
          :total="rolePage.total"
          :current.sync="rolePage.index"
          @on-change="doGetResourceRoleList"
          @on-page-size-change="handleRolePageSizeChange"
        ></Page>
      </Row>
      <br />

      <Row type="flex" justify="center">
        <Col>
          <Button @click="$emit('close')">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f030402Api from "@api/f03/f030402-api";
import namingConverter from "@misc/naming-converter";

export default {
  components: {},
  props: {
    // 是否顯示對話框
    isModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來資源主鍵(用以查詢資源關聯角色)
    resourceSeqNo: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      // page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      roleList: [],
      roleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom"
        }
      ]
    };
  },
  methods: {
    /**
     * 查詢資源關聯角色
     */
    doGetResourceRoleList: async function() {
      let result = await f030402Api.doGetResourceRoleList({
        resourceSeqNo: this.resourceSeqNo,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleList = result.roleInfoList;
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      if (!this.rolePage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.doGetRoleList();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
    }
  },
  watch: {
    /**
     * 監聽父組件props值改變做查詢
     */
    resourceSeqNo: {
      handler: function() {
        this.doGetResourceRoleList();
      }
    }
  },
  computed: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
