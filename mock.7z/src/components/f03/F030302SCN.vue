<template>
  <div>
    <Modal
      v-model="isModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
      width="90"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 檢視角色</span>
      </p>
      <Tabs value="grp" type="card">
        <TabPane label="關聯群組" name="grp">
          <Table
            :columns="grpColumn"
            :data="grpList"
            @on-sort-change="handleGrpSort"
            border
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="grpPage.total"
              :current.sync="grpPage.index"
              @on-change="doGetGroupList"
              @on-page-size-change="handleGrpPageSizeChange"
            ></Page>
          </Row>
        </TabPane>
        <TabPane label="關聯資源" name="resource">
          <Table
            :columns="resourceColumn"
            :data="resourceList"
            @on-sort-change="handleResourceSort"
            border
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="resourcePage.total"
              :current.sync="resourcePage.index"
              @on-change="doGetResourceList"
              @on-page-size-change="handleResourcePageSizeChange"
            ></Page>
          </Row>
        </TabPane>
        <TabPane label="複合角色" name="composite">
          <Table
            :columns="compositeColumn"
            :data="compositeList"
            border
          ></Table>
          <br />
        </TabPane>
      </Tabs>
      <br />

      <Row type="flex" justify="center">
        <Col span="1.5">
          <Button @click="$emit('close')">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f030302Api from "@api/f03/f030302-api";
import f050303Api from "@api/f05/f050303-api";
import namingConverter from "@misc/naming-converter";

export default {
  props: {
    // 是否顯示對話框
    isModalVisible: {
      type: Boolean,
      default: false
    },
    // 父組件傳來角色代碼 (用以查詢角色資源及群組資訊。)
    roleId: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      // page
      grpPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      resourcePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table data
      grpList: [],
      resourceList: [],
      compositeList: [],
      grpColumn: [
        {
          title: "群組類型",
          key: "grpTypeNm"
        },
        {
          title: "事業處",
          key: "devisionNm"
        },
        {
          title: "部門",
          key: "departmentNm"
        },
        {
          title: "科別",
          key: "sectionNm"
        },
        {
          title: "業務群組",
          key: "groupNm"
        },
        {
          title: "群組狀態",
          key: "grpStsNm",
          sortable: "custom"
        },
        {
          title: "群組起日",
          key: "startDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "群組迄日",
          key: "endDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "是否永久有效",
          key: "permanentNm",
          sortable: "custom"
        }
      ],
      resourceColumn: [
        {
          title: "資源類別",
          key: "rsrcTypeNm"
        },
        {
          title: "資源名稱",
          key: "rsrcNm"
        },
        {
          title: "資源說明",
          key: "rsrcMemo"
        },
        {
          title: "資源等級",
          key: "confLvNm",
          sortable: "custom"
        },
        {
          title: "URI",
          key: "rsrcUri"
        },
        {
          title: "上層選單",
          key: "upMenuNm",
          sortable: "custom"
        },
        {
          title: "轉導類型",
          key: "redirectTypeNm"
        },
        {
          title: "選單位置",
          key: "positionNm"
        },
        {
          title: "排序號碼",
          key: "sortNum",
          align: "right"
        },
        {
          title: "資源狀態",
          key: "rsrcStsNm",
          sortable: "custom"
        }
      ],
      compositeColumn: [
        {
          title: "複合角色",
          key: "label",
          sortable: "true"
        }
      ]
    };
  },
  methods: {
    /**
     * 查詢角色對應群組清單
     */
    doGetGroupList: async function() {
      let result = await f030302Api.doGetGroupList({
        roleId: this.roleId,
        pageNo: this.grpPage.index,
        pageSize: this.grpPage.size,
        sortColumn: this.grpPage.sortColumn,
        sortType: this.grpPage.sortType
      });

      this.grpPage.index = result.pageNo;
      this.grpPage.total = result.totalCount;
      this.grpList = result.groupInfoList;
    },
    /**
     * 查詢角色對應資源清單
     */
    doGetResourceList: async function() {
      let result = await f030302Api.doGetResourceList({
        roleId: this.roleId,
        pageNo: this.resourcePage.index,
        pageSize: this.resourcePage.size,
        sortColumn: this.resourcePage.sortColumn,
        sortType: this.resourcePage.sortType
      });

      this.resourcePage.index = result.pageNo;
      this.resourcePage.total = result.totalCount;
      this.resourceList = result.resourceList;
    },
    /**
     * 查詢該角色復合的角色
     */
    doGetCompositeList: async function() {
      this.compositeList = await f050303Api.doGetCompositeRoles({
        roleId: this.roleId
      });
    },
    /**
     * 處理群組清單排序
     */
    handleGrpSort: function(col) {
      if (!this.grpPage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.grpPage.sortColumn = null;
        this.grpPage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.grpPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.grpPage.sortType = col.order.toUpperCase();
      }

      this.doGetGroupList();
    },
    /**
     * 處理資源清單排序
     */
    handleResourceSort: function(col) {
      if (!this.resourcePage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.resourcePage.sortColumn = null;
        this.resourcePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.resourcePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.resourcePage.sortType = col.order.toUpperCase();
      }

      this.doGetResourceList();
    },
    /**
     * 處理群組每頁筆數改變
     */
    handleGrpPageSizeChange: function(newPageSize) {
      this.grpPage.size = newPageSize;
      this.doGetGrpList();
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleResourcePageSizeChange: function(newPageSize) {
      this.resourcePage.size = newPageSize;
      this.doGetResourceList();
    }
  },
  watch: {
    /**
     * 監聽父組件props值改變做查詢
     */
    roleId: {
      handler: function() {
        this.doGetGroupList();
        this.doGetResourceList();
        this.doGetCompositeList();
      }
    }
  },
  computed: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
