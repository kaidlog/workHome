<template>
  <div id="app" class="layout">
    <Layout :style="{ minHeight: '100vh' }">
      <Header><banner></banner></Header>
      <Layout>
        <Sider width="270">
          <left-navigator></left-navigator>
        </Sider>
        <Layout>
          <Content :style="{ padding: '40px 30px' }">
            <function-title></function-title>
            <keep-alive>
              <router-view />
            </keep-alive>
          </Content>
          <Footer :style="{ textAlign: 'center' }">© E.SUN BANK</Footer>
        </Layout>
      </Layout>
    </Layout>
    <BackTop></BackTop>
    <spinner></spinner>
    <logout-spinner></logout-spinner>
  </div>
</template>

<script>
import Banner from "@components/layout/Banner.vue";
import Spinner from "@components/misc/Spinner.vue";
import LeftNavigator from "@components/layout/LeftNavigator.vue";
import FunctionTitle from "@components/layout/FunctionTitle.vue";
import LogoutSpinner from "@components/misc/LogoutSpinner.vue";

export default {
  components: {
    Banner,
    Spinner,
    LeftNavigator,
    FunctionTitle,
    LogoutSpinner
  },
  props: {},
  data() {
    return {};
  },
  computed: {},
  methods: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
