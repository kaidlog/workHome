<template>
  <BlockUI :message="logoutMsg" v-show="isShowSpinner">
    <font-awesome-icon icon="cog" size="3x" spin fixed-width>
    </font-awesome-icon>
  </BlockUI>
</template>

<script>
import { mapActions } from "vuex";
import sessionKeeperApi from "@api/core/session-keeper-api";

export default {
  components: {},
  props: {},
  data() {
    return {
      /** 系統登出中訊息 */
      logoutMsg: "系統登出中，請稍候!!",
      /** 是否顯示登出中視窗 */
      isShowSpinner: true
    };
  },
  computed: {},
  methods: {
    ...mapActions(["doCleanUserProfile"])
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {
    this.doCleanUserProfile();
    sessionKeeperApi.doLogOut().then(() => {
      this.$keycloak.logoutFn();
    });
  },
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
