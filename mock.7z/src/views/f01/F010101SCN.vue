<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        :userProp.sync="formValidate.selectedUser"
        :divisionReadonly="orgSelectCtrl.divisionDisable"
        :headquarterReadonly="orgSelectCtrl.headquarterDisable"
        :departmentReadonly="orgSelectCtrl.departmentDisable"
        :sectionReadonly="orgSelectCtrl.sectionDisable"
        :disableGroup="orgSelectCtrl.groupDisable"
        :disableUser="orgSelectCtrl.userDisable"
      >
        <Col span="8">
          <FormItem label="代理狀態" prop="cdId">
            <sys-cd-select
              :ctId="30"
              :value.sync="formValidate.cdId"
            ></sys-cd-select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem prop="startTime" label="有效起日">
            <DatePicker
              style="width:100%;"
              @on-change="formValidate.startTime = $event"
              type="datetime"
              format="yyyy/MM/dd HH:mm:ss"
              :editable="false"
              :time-picker-options="{ steps: [1, 10, 10] }"
            ></DatePicker>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem prop="endTime" label="有效迄日">
            <DatePicker
              style="width:100%;"
              @on-change="formValidate.endTime = $event"
              type="datetime"
              format="yyyy/MM/dd HH:mm:ss"
              :editable="false"
              :time-picker-options="{ steps: [1, 10, 10] }"
            ></DatePicker>
          </FormItem>
        </Col>
      </OrgSelect>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="qryAgentListRerenderTable">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="addAgent">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <Table
      border
      :columns="agentColumns"
      :data="agentList"
      @on-sort-change="handleSortChange"
      :key="agentTableKey"
      style="margin-top:15px;"
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        :total="total"
        :current.sync="pageNo"
        :page-size="pageSize"
        :page-size-opts="[10, 20, 50]"
        show-total
        show-sizer
        show-elevator
        @on-page-size-change="handlePageSizeChange"
        @on-change="doQryAgentList"
      ></Page>
    </Row>
    <Modal
      v-model="inactivateModal"
      :closable="false"
      :mask-closable="false"
      @on-ok="confirmInactivate"
      @on-cancel="cancelInactivate"
    >
      <p slot="header">
        <font-awesome-icon :icon="'exclamation-circle'" />
        <span> 請確認是否停用</span>
      </p>
      <Row>
        <Col span="12">被代理人:</Col>
        <Col span="12">{{ inactivateTarget.agentUserNm }}</Col>
      </Row>
      <Row>
        <Col span="12">代理人:</Col>
        <Col span="12">{{ inactivateTarget.agentNm }}</Col>
      </Row>
      <Row>
        <Col span="12">緣由:</Col>
        <Col span="12">{{ inactivateTarget.reason }}</Col>
      </Row>
      <Row>
        <Col span="12">開始時間:</Col>
        <Col span="12">{{ inactivateTarget.startTime }}</Col>
      </Row>
      <Row>
        <Col span="12">結束時間:</Col>
        <Col span="12">{{ inactivateTarget.endTime }}</Col>
      </Row>
    </Modal>
    <F010102SCN
      :showRoleModal="viewRoleModal"
      :agentSeqNo="viewAgentSeqNo"
      @unload="hideRoleModal"
      @load="copyAgent"
    ></F010102SCN>
    <F010103SCN
      :showAddModal="newAgentModal"
      :copyAgentSeqNo="copyAgentSeqNo"
      @close="hideAddModal"
    ></F010103SCN>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
// import f010101Api from "@api/f01/f010101-api";
import namingConverter from "@misc/naming-converter";
import OrgSelect from "@components/common/OrgSelect.vue";
import F010102SCN from "@components/f01/F010102SCN.vue";
import F010103SCN from "@components/f01/F010103SCN.vue";

export default {
  components: {
    OrgSelect,
    F010102SCN,
    F010103SCN
  },
  props: {},
  data() {
    return {
      // 表單驗證項目
      formValidate: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: "",
        selectedUser: "",
        // 30: 生效狀態
        cdId: "",
        // 起訖日期
        startTime: "",
        endTime: ""
      },
      // 表單驗證規則
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ],
        cdId: [
          {
            required: true,
            message: "請選擇生效狀態",
            trigger: "change"
          }
        ]
      },
      // 是否為啟用代理人員的資料
      isInactive: false,
      // 資料筆數
      total: 0,
      // table目前頁面
      pageNo: 1,
      // table顯示筆數
      pageSize: 10,
      // 排序欄位
      sortColumn: null,
      // 排序方向
      sortType: null,
      // agentList
      agentList: [],
      // Agent Info Table Columns
      agentColumns: [
        {
          title: "被代理人",
          key: "agentUserNm"
        },
        {
          title: "代理人",
          key: "agentNm"
        },
        {
          title: "代理狀態",
          key: "agentStsNm"
        },
        {
          title: "有效時間(起)",
          key: "startTime",
          sortable: "custom",
          width: 250
        },
        {
          title: "有效時間(迄)",
          key: "endTime",
          sortable: "custom",
          width: 250
        },
        {
          title: "緣由",
          key: "reason"
        },
        {
          title: "代理角色",
          slot: "agent",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.viewRoles(params.row);
                  }
                }
              },
              "檢視"
            );
          }
        },
        {
          title: "動作",
          slot: "action",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                props: {
                  type: "error",
                  disabled: this.isInactive
                },
                on: {
                  click: () => {
                    this.inactivateAgent(params.row);
                  }
                }
              },
              "停用"
            );
          }
        }
      ],
      // OrgSelect 控制項
      orgSelectCtrl: {
        divisionDisable: null,
        headquarterDisable: null,
        departmentDisable: null,
        sectionDisable: null,
        groupDisable: null,
        userDisable: null
      },
      // 要查詢的群組
      targetGrp: null,
      // 要檢視的代理
      viewAgentSeqNo: null,
      // 要複製的代理
      copyAgentSeqNo: null,
      // 停用確認Modal
      inactivateModal: false,
      // 停用代理標的
      inactivateTarget: {},
      // 檢視代理角色Modal
      viewRoleModal: false,
      // 新增代理Modal
      newAgentModal: false,
      // table key
      agentTableKey: 1
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 查詢代理資料並重新渲染table
     */
    qryAgentListRerenderTable: async function() {
      this.pageNo = 1;
      this.sortColumn = null;
      this.sortType = null;
      await this.doQryAgentList();
      this.agentTableKey += 1;
      return;
    },
    /**
     * 停用代理
     */
    inactivateAgent: function(row) {
      this.inactivateTarget = row;
      this.inactivateModal = true;
    },
    /**
     * 確定停用
     */
    // confirmInactivate: function() {
    //   f010101Api
    //     .doInactivateAgent({
    //       agentSeqNo: this.inactivateTarget.agentSeqNo
    //     })
    //     .then(() => {
    //       this.doQryAgentList();
    //       this.inactivateTarget = {};
    //       this.inactivationModal = false;
    //       this.$Message.info("停用成功");
    //     });
    // },
    /**
     * 取消停用
     */
    cancelInactivate: function() {
      this.inactivateTarget = {};
      this.inactivationModal = false;
      this.$Message.info("操作取消");
    },
    /**
     * 檢視代理角色
     */
    viewRoles: function(row) {
      this.viewAgentSeqNo = row.agentSeqNo;
      this.viewRoleModal = true;
    },
    /**
     * 複製代理設定
     */
    copyAgent: function() {
      this.copyAgentSeqNo = this.viewAgentSeqNo;
      this.viewRoleModal = false;
      this.newAgentModal = true;
    },
    /**
     * 新增代理
     */
    addAgent: function() {
      this.newAgentModal = true;
    },
    /**
     * 隱藏檢視代理角色Modal
     */
    hideRoleModal: function() {
      this.viewRoleModal = false;
    },
    /**
     * 隱藏新增代理Modal
     */
    hideAddModal: function(isRefresh) {
      this.newAgentModal = false;
      this.copyAgentSeqNo = "";
      // 避免使用者在沒查詢的狀況下新增後出現表單檢驗文字
      if (
        isRefresh &&
        !isBlank(this.targetGrp) &&
        !isBlank(this.formValidate.cdId)
      ) {
        this.qryAgentListRerenderTable();
      }
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.pageSize = newPageSize;
      this.qryAgentListRerenderTable();
    },
    /**
     * 處理代理清單排序
     */
    handleSortChange: async function(col) {
      if (!this.total) {
        return;
      }
      // normal: 取消排序
      if (col.order === "normal") {
        this.pageNo = 1;
        this.sortColumn = null;
        this.sortType = null;
      }
      // normal: 取消排序
      if (col.order !== "normal") {
        this.pageNo = 1;
        this.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.sortType = col.order.toUpperCase();
      }
      // 依據條件代理資訊
      await this.doQryAgentList();
    },
    /**
     * 查詢代理資料清單
     */
    doQryAgentList: async function() {
      this.$refs["formValidate"].validate(async valid => {
        if (
          !valid ||
          isBlank(this.formValidate.selectedDivision) ||
          isBlank(this.formValidate.cdId)
        ) {
          return;
        }

        // 確認代理時間起迄設定無誤
        if (!this.checkStartIsBeforeEnd()) {
          this.$Message.error("結束時間不得小於開始時間!!");
          return;
        }

        // 是否顯示停用按鈕
        if (this.formValidate.cdId === "I") {
          this.isInactive = true;
        } else if (this.formValidate.cdId === "A") {
          this.isInactive = false;
        }

        // let result = await f010101Api.doGetAgentList({
        //   grpId: this.targetGrp,
        //   adAccount: this.formValidate.selectedUser,
        //   agentSts: this.formValidate.cdId,
        //   startTime: this.formValidate.startTime,
        //   endTime: this.formValidate.endTime,
        //   pageNo: this.pageNo,
        //   pageSize: this.pageSize,
        //   sortColumn: this.sortColumn,
        //   sortType: this.sortType
        // });

        // this.agentList = result.agentList;
        // this.total = result.totalCount;
        // this.pageNo = result.pageNo;
      });
    },
    /**
     * 系統管理員配置
     */
    sysAdminConfig: function() {
      this.orgSelectCtrl.groupDisable = true;
    },
    /**
     * 經理人配置
     */
    managerConfig: function() {
      this.orgSelectCtrl.divisionDisable = true;
      this.orgSelectCtrl.headquarterDisable = true;
      this.orgSelectCtrl.departmentDisable = true;
      this.orgSelectCtrl.groupDisable = true;
    },
    /**
     * 科主管配置
     */
    secSupConfig: function() {
      this.orgSelectCtrl.divisionDisable = true;
      this.orgSelectCtrl.headquarterDisable = true;
      this.orgSelectCtrl.departmentDisable = true;
      this.orgSelectCtrl.sectionDisable = true;
      this.orgSelectCtrl.groupDisable = true;
    },
    /**
     * 檢查起迄時間
     */
    checkStartIsBeforeEnd: function() {
      if (!this.formValidate.startTime || !this.formValidate.endTime) {
        return true;
      }
      let start = this.$moment(
        this.formValidate.startTime,
        "YYYY/MM/DD HH:mm:ss"
      );
      let end = this.$moment(this.formValidate.endTime, "YYYY/MM/DD HH:mm:ss");
      return start.isBefore(end);
    }
  },
  watch: {
    /**
     * 監聽OrgSelectGrp
     */
    orgSelectGrp: function(newValue) {
      if (newValue) {
        this.targetGrp = newValue;
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {
    // // ROLE_00000 系統管理員, ROLE_00035 權限平台_代理人設定_風管部
    // if (
    //   this.optUserProfile.roles.includes("ROLE_00000") ||
    //   this.optUserProfile.roles.includes("ROLE_00035")
    // ) {
    //   this.sysAdminConfig();
    //   return;
    // }

    // // ROLE_00034 權限平台_代理人設定_部經理
    // if (this.optUserProfile.roles.includes("ROLE_00034")) {
    //   this.managerConfig();
    //   return;
    // }

    // // ROLE_00033 權限平台_代理人設定_科主管
    // if (this.optUserProfile.roles.includes("ROLE_00033")) {
    //   this.secSupConfig();
    //   return;
    // }
  },
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把Modal關閉
     */
    this.hideAddModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
