﻿<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        disableUser
      >
        <Col span="8">
          <FormItem label="帳號狀態" prop="accSts">
            <sys-cd-select :ctId="35" :value.sync="formValidate.accSts" />
          </FormItem>
        </Col>
      </OrgSelect>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="queryUser">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="editUser({})">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table :columns="userColumn" :data="userList" @on-sort-change="handleSort">
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="page.total"
        :page-size="page.size"
        :current.sync="page.index"
        @on-change="doGetUserList"
        @on-page-size-change="handlePageSizeChange"
        transfer
      ></Page>
    </Row>

    <F010202SCN
      :isModalVisible="isModalVisible"
      :userInfo="userInfo"
      @close="hideModal"
    />
  </div>
</template>

<script>
import isBlank from "is-blank";
import f010201Api from "@api/f01/f010201-api";
import namingConverter from "@misc/naming-converter";
import F010202SCN from "@components/f01/F010202SCN.vue";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect,
    F010202SCN
  },
  data() {
    // Custom Validator
    const validateDivOrGrp = (rule, value, callback) => {
      // validate fields
      if (
        isBlank(this.formValidate.selectedDivision) &&
        isBlank(this.formValidate.selectedGroup)
      ) {
        return callback(new Error("請選擇事業處或業務群組"));
      }

      if (isBlank(this.formValidate.selectedDivision)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedDivision"
        }).resetField();
      }

      if (isBlank(this.formValidate.selectedGroup)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedGroup"
        }).resetField();
      }

      callback();
    };
    return {
      // 是否顯示對話框(F010202SCN)
      isModalVisible: false,
      // 表單驗證規則
      ruleValidate: {
        selectedDivision: [{ validator: validateDivOrGrp, trigger: "change" }],
        selectedGroup: [{ validator: validateDivOrGrp, trigger: "change" }],
        accSts: [
          {
            required: true,
            message: "請選擇帳號狀態",
            trigger: "change"
          }
        ]
      },
      // 表單驗證項目
      formValidate: {
        // 事業處
        selectedDivision: "",
        // 本部
        selectedHeadquarter: "",
        // 部門
        selectedDepartment: "",
        // 科別
        selectedSection: "",
        // 業務群組
        selectedGroup: "",
        // 帳號狀態
        accSts: ""
      },
      // 人員資訊物件，用以props給子組件
      userInfo: {},
      // page
      page: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      userList: [],
      // 人員表格欄位
      userColumn: [
        {
          title: "單位",
          key: "grpNm"
        },
        {
          title: "職稱",
          key: "titleNm"
        },
        {
          title: "AD帳號",
          key: "adAccount",
          sortable: "custom"
        },
        {
          title: "員工編號",
          key: "empNo",
          sortable: "custom",
          align: "right"
        },
        {
          title: "員工姓名",
          key: "empNm"
        },
        {
          title: "分機號碼",
          key: "phoneExt",
          align: "right"
        },
        {
          title: "EMAIL",
          key: "email"
        },
        {
          title: "帳號狀態",
          key: "accStsNm"
        },
        {
          title: "動作",
          slot: "action",
          align: "center",
          render: (h, params) => {
            return this.getBtn(h, params.row);
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 取得表格內按鈕
     */
    getBtn: function(h, row) {
      let btn;
      if (row.titleCd === "B_1") {
        // B_1: 處級-其他
        btn = h(
          "Button",
          {
            on: {
              click: () => {
                this.editUser(row);
              }
            }
          },
          "修改"
        );
      } else {
        let btnStr;
        let typeStr;

        if (row.accSts === "99") {
          // 99:停權
          btnStr = "復權";
          typeStr = "default";
        } else {
          btnStr = "停權";
          typeStr = "error";
        }

        btn = h(
          "Button",
          {
            props: {
              type: typeStr
            },
            on: {
              click: () => {
                this.doToggleUserSts(row);
              }
            }
          },
          btnStr
        );
      }
      return btn;
    },
    /**
     * 停權/復權使用者
     */
    doToggleUserSts: function(row) {
      f010201Api
        .doToggleUserSts({
          adAccount: row.adAccount,
          empNm: row.empNm,
          email: row.email,
          phoneExt: row.phoneExt,
          titleCd: row.titleCd,
          accSts: row.accSts
        })
        .then(() => {
          // 重新獲取使用者清單
          this.queryUser();
          // 顯示成功訊息
          this.$Message.info("操作成功");
        });
    },
    /**
     * 檢核欄位非空才做查詢
     */
    queryUser: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetUserList();
        }
      });
    },
    /**
     * 查詢人員資訊清單
     */
    doGetUserList: async function() {
      let result = await f010201Api.doGetUserList({
        grpId: this.grpId,
        accSts: this.formValidate.accSts,
        pageNo: this.page.index,
        pageSize: this.page.size,
        sortColumn: this.page.sortColumn,
        sortType: this.page.sortType
      });

      this.page.total = result.totalCount;
      this.userList = result.userInfoList;
    },
    /**
     * 處理排序
     */
    handleSort: function(col) {
      if (!this.page.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.page.sortColumn = null;
        this.page.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.page.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.page.sortType = col.order.toUpperCase();
      }

      this.queryUser();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.page.size = newPageSize;
      this.queryUser();
    },
    /**
     * 修改人員
     */
    editUser: function(user) {
      this.userInfo = user;
      this.isModalVisible = true;
    },
    /**
     * 關閉Modal，並重新查詢人員
     */
    hideModal: function(isRefresh) {
      this.isModalVisible = false;
      this.userInfo = {};
      if (
        isRefresh &&
        !isBlank(this.formValidate.accSts) &&
        !isBlank(this.grpId)
      ) {
        this.queryUser();
      }
    }
  },
  computed: {
    // 群組編號 (用以查詢人員資料)
    grpId: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  props: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
