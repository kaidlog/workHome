<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        :disableGroup="orgSelectCtrl.groupDisable"
        :disableUser="orgSelectCtrl.userDisable"
      >
        <Col span="8">
          <FormItem label="群組類型">
            <sys-cd-select
              :ctId="31"
              :value.sync="qryConditionObj.grpType"
            ></sys-cd-select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="群組狀態">
            <sys-cd-select
              :ctId="30"
              :value.sync="qryConditionObj.grpSts"
            ></sys-cd-select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資料來源">
            <sys-cd-select
              :ctId="29"
              :value.sync="qryConditionObj.dataSrc"
            ></sys-cd-select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem prop="permanent" label="永久有效">
            <sys-cd-select
              :ctId="2"
              :value.sync="formValidate.permanent"
            ></sys-cd-select>
          </FormItem>
        </Col>
      </OrgSelect>
      <Row>
        <Col span="8">
          <FormItem prop="startDate" label="有效起日">
            <DatePicker
              style="width:100%;"
              @on-change="qryConditionObj.startDate = $event"
              type="date"
              format="yyyy/MM/dd"
              :key="componentKeys.startDatePicker"
              :editable="false"
              :disabled="viewComponentCtrl.isPermanent"
            ></DatePicker>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem prop="endDate" label="有效迄日">
            <DatePicker
              style="width:100%;"
              @on-change="qryConditionObj.endDate = $event"
              type="date"
              format="yyyy/MM/dd"
              :key="componentKeys.endDatePicker"
              :editable="false"
              :disabled="viewComponentCtrl.isPermanent"
            ></DatePicker>
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="doQryGrpDtlListRerenderTable">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="addGroup">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Table
      border
      :columns="grpTableColumns"
      :data="qryResultObj.groupList"
      @on-sort-change="handleSortChange"
      :key="componentKeys.userTableKey"
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        :total="qryResultObj.totalCount"
        :current.sync="qryConditionObj.pageNo"
        :page-size="qryConditionObj.pageSize"
        :page-size-opts="[10, 20, 50]"
        show-total
        show-sizer
        show-elevator
        @on-page-size-change="handlePageSizeChange"
        @on-change="doQryGrpDtls"
      ></Page>
    </Row>

    <F020302SCN
      :showUpdGrpModal="viewComponentCtrl.viewUpdGrpModal"
      :updGroupId="grpId4UpdGrp"
      @close="hideModal"
    ></F020302SCN>

    <F020303SCN
      :showUpdRoleModal="viewComponentCtrl.viewUpdRoleModal"
      :updGroupId="grpId4UpdGrpRole"
      @close="hideModal"
    >
    </F020303SCN>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
import f020301Api from "@api/f02/f020301-api";
import namingConverter from "@misc/naming-converter";
import OrgSelect from "@components/common/OrgSelect.vue";
import F020302SCN from "@components/f02/F020302SCN.vue";
import F020303SCN from "@components/f02/F020303SCN.vue";

export default {
  components: {
    OrgSelect,
    F020302SCN,
    F020303SCN
  },
  props: {},
  data() {
    return {
      // Table Columns
      grpTableColumns: [
        {
          title: "群組名稱",
          key: "grpNm"
        },
        {
          title: "群組層級",
          key: "grpUnitcodeNm"
        },
        {
          title: "群組類型",
          key: "grpTypeNm"
        },
        {
          title: "所屬單位",
          key: "upGrpNm"
        },
        {
          title: "資料來源",
          key: "dataSrcNm"
        },
        {
          title: "永久有效",
          key: "permanentNm"
        },
        {
          title: "有效起日",
          key: "startDate",
          sortable: "custom"
        },
        {
          title: "有效迄日",
          key: "endDate",
          sortable: "custom"
        },
        {
          title: "群組狀態",
          key: "grpStsNm"
        },
        {
          title: "動作",
          slot: "action",
          align: "center",
          width: "280",
          render: (h, params) => {
            return [
              h(
                "Button",
                {
                  props: {
                    disabled: this.disableUpdGrpBtn(params.row)
                  },
                  on: {
                    click: () => {
                      this.showUpdGrpModal(params.row);
                    }
                  }
                },
                "修改群組"
              ),
              h(
                "Button",
                {
                  on: {
                    click: () => {
                      this.showUpdRoleModal(params.row);
                    }
                  },
                  style: {
                    marginLeft: "8px"
                  }
                },
                "設定角色"
              )
            ];
          }
        }
      ],
      // 表單驗證項目
      formValidate: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: "",
        permanent: ""
      },
      // 表單驗證規則
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請選擇至少選擇事業處",
            trigger: "change"
          }
        ],
        permanent: [
          {
            required: true,
            message: "請選擇是否永久有效",
            trigger: "change"
          }
        ]
      },
      // OrgSelect 控制項
      orgSelectCtrl: {
        groupDisable: true,
        userDisable: true
      },
      // 元件鍵值
      componentKeys: {
        grpDtlTableKey: 1,
        startDatePicker: 1,
        endDatePicker: 1
      },
      // 畫面元件控制
      viewComponentCtrl: {
        viewUpdGrpModal: false,
        viewUpdRoleModal: false,
        viewAddGrpModal: false,
        isPermanent: false
      },
      // 查詢條件
      qryConditionObj: {
        targetGrp: null,
        startDate: null,
        endDate: null,
        permanent: null,
        grpType: null,
        grpSts: null,
        dataSrc: null,
        pageNo: 1,
        pageSize: 10,
        sortColumn: null,
        sortType: null
      },
      // 回傳資料
      qryResultObj: {
        totalCount: null,
        pageNo: null,
        groupList: [],
        targetGroup: null
      },
      // 異動的群組編號
      grpId4UpdGrp: "",
      // 異動群組角色的群組編號
      grpId4UpdGrpRole: ""
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 取得群組資料清單
     */
    doQryGrpDtls: async function() {
      this.$refs["formValidate"].validate(async valid => {
        if (!valid) {
          return;
        }

        // 確認群組有效時間起迄設定無誤
        if (!this.checkStartIsBeforeEnd()) {
          this.$Message.error("結束時間不得小於開始時間");
          return;
        }

        this.qryResultObj = await f020301Api.doGetGroupList(
          this.qryConditionObj
        );
        this.qryConditionObj.pageNo = this.qryResultObj.pageNo;
      });
    },
    /**
     * 取得群組資料清單並重新渲染Table
     */
    doQryGrpDtlListRerenderTable: async function() {
      this.qryConditionObj.pageNo = 1;
      this.qryConditionObj.sortColumn = null;
      this.qryConditionObj.sortType = null;

      await this.doQryGrpDtls();
      this.componentKeys.grpDtlTableKey += 1;
    },
    /**
     * 群組異動按鈕控制
     */
    disableUpdGrpBtn: function(row) {
      return row.dataSrc === "H";
    },
    /**
     * 顯示群組Modal
     */
    showUpdGrpModal: function(row) {
      this.grpId4UpdGrp = row.grpId;
      this.viewComponentCtrl.viewUpdGrpModal = true;
    },
    /**
     * 顯示異動角色Modal
     */
    showUpdRoleModal: function(row) {
      this.grpId4UpdGrpRole = row.grpId;
      this.viewComponentCtrl.viewUpdRoleModal = true;
    },
    /**
     * 關閉 Modal，並重查群組資料
     */
    hideModal: function(isRefresh) {
      this.grpId4UpdGrp = "";
      this.grpId4UpdGrpRole = "";
      this.viewComponentCtrl.viewUpdGrpModal = false;
      this.viewComponentCtrl.viewUpdRoleModal = false;
      // 避免使用者在沒查詢的狀況下新增後出現表單檢驗文字
      if (
        isRefresh &&
        !isBlank(this.qryConditionObj.targetGrp) &&
        !isBlank(this.qryConditionObj.permanent)
      ) {
        this.doQryGrpDtlListRerenderTable();
      }
    },
    /**
     * 新增群組
     */
    addGroup: function() {
      this.viewComponentCtrl.viewUpdGrpModal = true;
    },
    /**
     * 處理代理清單排序
     */
    handleSortChange: async function(col) {
      if (!this.qryResultObj.totalCount) {
        return;
      }
      // normal: 取消排序
      if (col.order === "normal") {
        this.qryConditionObj.pageNo = 1;
        this.qryConditionObj.sortColumn = null;
        this.qryConditionObj.sortType = null;
      }
      // normal: 取消排序
      if (col.order !== "normal") {
        this.qryConditionObj.pageNo = 1;
        this.qryConditionObj.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.qryConditionObj.sortType = col.order.toUpperCase();
      }
      // 依據條件查詢群組資訊
      await this.doQryGrpDtls();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.qryConditionObj.pageSize = newPageSize;
      this.doQryGrpDtlListRerenderTable();
    },
    /**
     * 檢查起迄時間
     */
    checkStartIsBeforeEnd: function() {
      if (!this.qryConditionObj.startTime || !this.qryConditionObj.endTime) {
        return true;
      }
      let start = this.$moment(this.qryConditionObj.startTime, "YYYY/MM/DD");
      let end = this.$moment(this.qryConditionObj.endTime, "YYYY/MM/DD");
      return start.isBefore(end);
    }
  },
  watch: {
    /**
     * 監聽OrgSelectGrp
     */
    orgSelectGrp: function(newValue) {
      if (newValue) {
        this.qryConditionObj.targetGrp = newValue;
      }
    },
    "formValidate.permanent": function(newValue) {
      if (!newValue) {
        return;
      }

      this.qryConditionObj.permanent = newValue;

      if (newValue === "N") {
        this.viewComponentCtrl.isPermanent = false;
      }

      if (newValue === "Y") {
        this.viewComponentCtrl.isPermanent = true;
        this.qryConditionObj.startDate = null;
        this.qryConditionObj.endDate = null;
        this.componentKeys.startDatePicker += 1;
        this.componentKeys.endDatePicker += 1;
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
