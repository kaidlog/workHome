<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        disableUser
        ref="org"
      ></OrgSelect>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="queryMgr">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="addMgr">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table
      :columns="userColumn"
      :data="qryResultObj.grpMgrList"
      @on-sort-change="handleSort"
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="page.total"
        :page-size="page.size"
        :current.sync="page.index"
        @on-change="doGetGroupLeaderList"
        @on-page-size-change="handlePageSizeChange"
        transfer
      ></Page>
    </Row>

    <F020202SCN
      :isModalVisible="isModalVisible"
      :targetGroup="qryResultObj.targetGroup"
      :grpMgrList="qryResultObj.grpMgrList"
      @close="hideModal"
    />
    <Modal
      v-model="isRemoveModalVisible"
      :closable="false"
      :mask-closable="false"
      @on-ok="doRemoveGroupLeader"
      @on-cancel="hideModal"
    >
      <p slot="header">
        <font-awesome-icon :icon="'exclamation-circle'" />
        <span> 請確認是否移除群組管理者</span>
      </p>
      <Row>
        <Col span="12">業務群組:</Col>
        <Col span="12">{{
          qryResultObj.targetGroup ? qryResultObj.targetGroup.grpNm : ""
        }}</Col>
      </Row>
      <Row>
        <Col span="12">使用者員編:</Col>
        <Col span="12">{{ grpLeaderToRmv ? grpLeaderToRmv.empNo : "" }}</Col>
      </Row>
      <Row>
        <Col span="12">使用者姓名:</Col>
        <Col span="12">{{ grpLeaderToRmv ? grpLeaderToRmv.empNm : "" }}</Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f020201Api from "@api/f02/f020201-api";
import namingConverter from "@misc/naming-converter";
import F020202SCN from "@components/f02/F020202SCN.vue";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect,
    F020202SCN
  },
  data() {
    return {
      // 是否顯示對話框(F020202SCN)
      isModalVisible: false,
      // 是否顯示對話框(移除確認)
      isRemoveModalVisible: false,
      // 欲移除的群組管理者
      grpLeaderToRmv: {
        // ad帳號
        adAccount: "",
        // 員工編號
        empNo: "",
        // 員工姓名
        empNm: ""
      },
      // 表單驗證規則
      ruleValidate: {
        selectedGroup: [
          {
            required: true,
            message: "請選擇業務群組",
            trigger: "change"
          }
        ]
      },
      // 表單驗證項目
      formValidate: {
        // 事業處
        selectedDivision: "",
        // 本部
        selectedHeadquarter: "",
        // 部門
        selectedDepartment: "",
        // 科別
        selectedSection: "",
        // 業務群組
        selectedGroup: ""
      },
      // 分頁
      page: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // 查詢結果
      qryResultObj: {
        // 群組管理人員清單
        grpMgrList: [],
        // 查詢群組資訊
        targetGroup: {
          // 群組代碼
          grpId: "",
          // 群組名稱
          grpNm: "",
          // 資料來源
          dataSrc: ""
        }
      },
      // 人員表格欄位
      userColumn: [
        {
          title: "單位",
          key: "grpNm"
        },
        {
          title: "職稱",
          key: "titleNm"
        },
        {
          title: "AD帳號",
          key: "adAccount",
          sortable: "custom"
        },
        {
          title: "員工編號",
          key: "empNo",
          sortable: "custom",
          align: "right"
        },
        {
          title: "員工姓名",
          key: "empNm"
        },
        {
          title: "帳號狀態",
          key: "accSts"
        },
        {
          title: "動作",
          slot: "action",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                props: {
                  type: "error"
                },
                on: {
                  click: () => {
                    this.showRemoveModal(params.row);
                  }
                }
              },
              "移除"
            );
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    queryMgr: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetGroupLeaderList();
        }
      });
    },
    /**
     * 查詢群組管理者清單
     */
    doGetGroupLeaderList: async function() {
      let result = await f020201Api.doGetGroupLeaderList({
        grpId: this.grpId,
        pageNo: this.page.index,
        pageSize: this.page.size,
        sortColumn: this.page.sortColumn,
        sortType: this.page.sortType
      });

      this.qryResultObj.targetGroup = result.targetGroup;
      this.qryResultObj.grpMgrList = result.userList;
      this.page.index = result.pageNo;
      this.page.total = result.totalCount;
    },
    /**
     * 處理排序
     */
    handleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.page.sortColumn = null;
        this.page.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.page.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.page.sortType = col.order.toUpperCase();
      }

      this.queryMgr();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.page.size = newPageSize;
      this.queryMgr();
    },
    /**
     * 顯示確認移除群組管理者對話框
     */
    showRemoveModal: function(row) {
      this.isRemoveModalVisible = true;
      this.grpLeaderToRmv = row;
    },
    /**
     * 移除群組管理者
     */
    doRemoveGroupLeader: async function() {
      let result = await f020201Api.doRemoveGroupLeader({
        grpId: this.qryResultObj.targetGroup.grpId,
        adAccount: this.grpLeaderToRmv.adAccount
      });

      if (result) {
        this.$Message.info("移除成功");
        this.queryMgr();
      }
    },
    /**
     * 新增人員
     */
    addMgr: function() {
      this.$refs["formValidate"].validate(async valid => {
        if (valid) {
          await this.queryMgr();
          this.isModalVisible = true;
        }
      });
    },
    /**
     * 關閉modal，並重新查詢群組管理者清單
     */
    hideModal: function(isRefresh) {
      this.isModalVisible = false;
      this.isRemoveModalVisible = false;
      if (isRefresh && !isBlank(this.grpId)) {
        this.queryMgr();
      }
    }
  },
  computed: {
    // 群組編號 (用以查詢群組管理者資料)
    grpId: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  props: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
