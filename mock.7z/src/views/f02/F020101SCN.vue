<template>
  <div>
    <Form
      v-if="viewComponentCtrl.isSysAdmin"
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        :disableUser="orgSelectCtrl.userDisable"
      ></OrgSelect>
    </Form>
    <Row type="flex" justify="center" v-if="!viewComponentCtrl.isSysAdmin">
      <Col span="8">
        <Form
          ref="subFormValidate"
          :model="subFormValidate"
          :rules="subRuleValidate"
          :label-width="120"
        >
          <FormItem label="業務群組" prop="customGrpId">
            <Select v-model="subFormValidate.customGrpId" clearable filterable>
              <Option
                v-for="group in custGroupList"
                :value="group.grpId"
                :key="group.grpId"
                >{{ group.grpNm }}
              </Option>
            </Select>
          </FormItem>
        </Form>
      </Col>
    </Row>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="doQryUserListRerenderTable">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button
          type="primary"
          @click="addUser2Group"
          :disabled="viewComponentCtrl.disableAddBtn"
        >
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <Table
      border
      :columns="userTableColumns"
      :data="qryResultObj.userList"
      @on-sort-change="handleSortChange"
      :key="componentKeys.userTableKey"
      style="margin-top:15px;"
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        :total="qryResultObj.totalCount"
        :current.sync="qryConditionObj.pageNo"
        :page-size="qryConditionObj.pageSize"
        :page-size-opts="[10, 20, 50]"
        show-total
        show-sizer
        show-elevator
        @on-page-size-change="handlePageSizeChange"
        @on-change="doQryUserList"
      ></Page>
    </Row>
    <Modal
      v-model="viewComponentCtrl.viewRemoveModal"
      :closable="false"
      :mask-closable="false"
      @on-ok="doRemoveGroupUser"
      @on-cancel="hideRemoveModel"
    >
      <p slot="header">
        <font-awesome-icon :icon="'exclamation-circle'" />
        <span> 請確認是否移除使用者</span>
      </p>
      <Row>
        <Col span="12">業務群組:</Col>
        <Col span="12">{{
          qryResultObj.targetGroup ? qryResultObj.targetGroup.grpNm : ""
        }}</Col>
      </Row>
      <Row>
        <Col span="12">使用者員編:</Col>
        <Col span="12">{{
          removeTarget.empNo ? removeTarget.empNo : "委外帳號不具員編"
        }}</Col>
      </Row>
      <Row>
        <Col span="12">使用者姓名:</Col>
        <Col span="12">{{ removeTarget.empNm }}</Col>
      </Row>
    </Modal>
    <F020102SCN
      :showUpdModal="viewComponentCtrl.viewUpdModal"
      :updateGroup="qryResultObj.targetGroup"
      @close="hideUpdModal"
    ></F020102SCN>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
import namingConverter from "@misc/naming-converter";
import f020101Api from "@api/f02/f020101-api";
import subordinateApi from "@api/common/subordinate-api";
import OrgSelect from "@components/common/OrgSelect.vue";
import F020102SCN from "@components/f02/F020102SCN.vue";

export default {
  components: {
    OrgSelect,
    F020102SCN
  },
  props: {},
  data() {
    // Custom Validator
    const validateDivOrGrp = (rule, value, callback) => {
      // validate fields
      if (
        isBlank(this.formValidate.selectedDivision) &&
        isBlank(this.formValidate.selectedGroup)
      ) {
        return callback(new Error("請選擇事業處或業務群組"));
      }

      if (isBlank(this.formValidate.selectedDivision)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedDivision"
        }).resetField();
      }

      if (isBlank(this.formValidate.selectedGroup)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedGroup"
        }).resetField();
      }

      callback();
    };
    return {
      // Table Columns
      userTableColumns: [
        {
          title: "單位",
          key: "grpNm",
          sortable: "custom"
        },
        {
          title: "職稱",
          key: "titleNm"
        },
        {
          title: "AD帳號",
          key: "adAccount"
        },
        {
          title: "員工編號",
          key: "empNo",
          sortable: "custom"
        },
        {
          title: "姓名",
          key: "empNm"
        },
        {
          title: "帳號狀態",
          key: "accSts"
        },
        {
          title: "動作",
          slot: "remove",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                props: {
                  type: "error",
                  disabled: this.disableRemoveBtn(params.row)
                },
                on: {
                  click: () => {
                    this.showRemoveModal(params.row);
                  }
                }
              },
              "移除"
            );
          }
        }
      ],
      // OrgSelect元件表單驗證項目
      formValidate: {
        // OrgSelect 綁定資料
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: ""
      },
      // 表單驗證項目
      subFormValidate: {
        // 自建群組下拉選單
        customGrpId: ""
      },
      // OrgSelect元件表單驗證規則
      ruleValidate: {
        selectedDivision: [{ validator: validateDivOrGrp, trigger: "change" }],
        selectedGroup: [{ validator: validateDivOrGrp, trigger: "change" }]
      },
      // 表單驗證規則
      subRuleValidate: {
        customGrpId: [
          {
            required: true,
            message: "請選擇群組",
            trigger: "change"
          }
        ]
      },
      // OrgSelect 控制項
      orgSelectCtrl: {
        userDisable: true
      },
      // 元件鍵值
      componentKeys: {
        userTableKey: 1
      },
      // 畫面元件控制
      viewComponentCtrl: {
        disableAddBtn: true,
        viewRemoveModal: false,
        viewUpdModal: false,
        isSysAdmin: false,
        isGroupManager: false
      },
      // 查詢條件
      qryConditionObj: {
        targetGrp: null,
        grpUnitcode: null,
        pageNo: 1,
        pageSize: 10,
        sortColumn: null,
        sortType: null
      },
      // 回傳資料
      qryResultObj: {
        totalCount: null,
        pageNo: null,
        userList: [],
        targetGroup: null
      },
      // 移除對象
      removeTarget: {},
      // 使用者擔任管理者的自建群組清單
      custGroupList: [],
      // 異動標的群組
      updTargetGroup: {}
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 是否停用移除按鈕
     */
    disableRemoveBtn: function(row) {
      // N: 非可維護群組成員, H: 資料來源為人事單位, B_1: 查詢'其他'群組
      return (
        row.isMaintainable === "N" ||
        this.qryResultObj.targetGroup.dataSrc === "H" ||
        this.qryResultObj.targetGroup.grpId === "B_1"
      );
    },
    /**
     * 查詢群組使用者
     */
    doQryUserList: async function() {
      if (this.viewComponentCtrl.isSysAdmin) {
        this.$refs["formValidate"].validate(async valid => {
          if (!valid) {
            return;
          }

          this.qryResultObj = await f020101Api.doGetGroupUserList(
            this.qryConditionObj
          );
          this.qryConditionObj.pageNo = this.qryResultObj.pageNo;
          this.viewComponentCtrl.disableAddBtn =
            this.qryResultObj.targetGroup.dataSrc === "H" || // H: 資料來源為人事單位
            this.qryResultObj.targetGroup.grpId === "B_1"; // B_1: 其他
        });
      }

      if (this.viewComponentCtrl.isGroupManager) {
        this.$refs["subFormValidate"].validate(async valid => {
          if (!valid || isBlank(this.subFormValidate.customGrpId)) {
            return;
          }

          this.qryResultObj = await f020101Api.doGetGroupUserList(
            this.qryConditionObj
          );
          this.qryConditionObj.pageNo = this.qryResultObj.pageNo;
          this.viewComponentCtrl.disableAddBtn =
            this.qryResultObj.targetGroup.dataSrc === "H" || // H: 資料來源為人事單位
            this.qryResultObj.targetGroup.grpId === "B_1"; // B_1: 其他
        });
      }
    },
    /**
     * 查詢群組使用者並重新渲染UserTable
     */
    doQryUserListRerenderTable: async function() {
      this.qryConditionObj.pageNo = 1;
      this.qryConditionObj.sortColumn = null;
      this.qryConditionObj.sortType = null;

      await this.doQryUserList();
      this.componentKeys.userTableKey += 1;
    },
    /**
     * 移除群組使用者
     */
    doRemoveGroupUser: function() {
      f020101Api
        .doRemoveGroupUser({
          grpId: this.removeTarget.custGrpId,
          adAccount: this.removeTarget.adAccount
        })
        .then(() => {
          this.doQryUserListRerenderTable();
          this.hideRemoveModel();
          this.$Message.info("移除成功");
        });
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.qryConditionObj.pageSize = newPageSize;
      this.doQryUserListRerenderTable();
    },
    /**
     * 處理排序
     */
    handleSortChange: async function(col) {
      if (!this.qryResultObj.totalCount) {
        return;
      }
      // normal: 取消排序
      if (col.order === "normal") {
        this.pageNo = 1;
        this.qryConditionObj.sortColumn = null;
        this.qryConditionObj.sortType = null;
      }
      // normal: 取消排序
      if (col.order !== "normal") {
        this.pageNo = 1;
        this.qryConditionObj.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.qryConditionObj.sortType = col.order.toUpperCase();
      }
      // 依據條件重新查詢
      await this.doQryUserList();
    },
    /**
     * 顯示移除Modal
     */
    showRemoveModal: function(row) {
      this.removeTarget = row;
      this.viewComponentCtrl.viewRemoveModal = true;
    },
    /**
     * 隱藏移除Modal
     */
    hideRemoveModel: function() {
      this.removeTarget = {};
      this.viewComponentCtrl.viewRemoveModal = false;
    },
    /**
     * 新增群組使用者
     */
    addUser2Group: function() {
      this.viewComponentCtrl.viewUpdModal = true;
    },
    /**
     * 更新群組清單
     */
    doUpdGroupList: function() {
      f020101Api.doGetGroupList().then(val => {
        this.custGroupList = val;
      });
    },
    /**
     * 隱藏新增Modal
     */
    hideUpdModal: async function(isRefresh) {
      this.viewComponentCtrl.viewUpdModal = false;
      if (isRefresh && !isBlank(this.qryConditionObj.targetGrp)) {
        await this.doQryUserList();
      }
    },
    /**
     * 經理人配置
     */
    managerConfig: async function() {
      let upperUnitList = await subordinateApi.doQryUpperUnit({
        grpId: this.optUserProfile.grpId
      });

      let targetUnit = this._.find(upperUnitList, u => {
        // L60|L80: 部級單位
        return u.grpUnitcode === "L60" || u.grpUnitcode === "L80";
      });

      this.qryConditionObj.grpUnitcode = targetUnit.grpUnitcode;
    }
  },
  watch: {
    /**
     * 監聽OrgSelectGrp
     */
    orgSelectGrp: function(newValue) {
      if (newValue) {
        this.qryConditionObj.targetGrp = newValue;
      }
    },
    /**
     * 監聽已選自建群組
     */
    "subFormValidate.customGrpId": function(newValue) {
      if (!newValue) {
        this.qryConditionObj.targetGrp = "";
        return;
      }
      this.qryConditionObj.targetGrp = newValue;
    }
  },
  beforeCreate() {},
  created() {
    this.optUserGrpId = this.optUserProfile.grpId;
  },
  beforeMount() {},
  mounted() {
    // 初始化先設定為不具任何群組人員維護角色
    this.viewComponentCtrl.isSysAdmin = false;
    this.viewComponentCtrl.isGroupManager = false;

    // ROLE_00000 權限平台_系統管理員, ROLE_00032 風險管理部經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00000") ||
      this.optUserProfile.roles.includes("ROLE_00032")
    ) {
      this.qryConditionObj.grpUnitcode = "L40"; // L40: 總經理室
      this.viewComponentCtrl.isSysAdmin = true;
      return;
    }

    // ROLE_00001 權限平台_部經理, ROLE_00030 權限平台_客服中心維運經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00001") ||
      this.optUserProfile.roles.includes("ROLE_00030")
    ) {
      this.managerConfig();
      this.viewComponentCtrl.isGroupManager = true;

      this.doUpdGroupList();
      return;
    }

    // ROLE_00032 風險管理部經辦
    if (this.optUserProfile.roles.includes("ROLE_00002")) {
      this.qryConditionObj.grpUnitcode = "L90"; // L90: 科
      this.viewComponentCtrl.isGroupManager = true;

      this.doUpdGroupList();
      return;
    }
  },
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把Modal關閉
     */
    this.hideUpdModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
