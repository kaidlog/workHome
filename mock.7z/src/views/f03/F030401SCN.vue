<template>
  <div>
    <Row>
      <Col span="8">
        <Form
          ref="formValidate"
          :model="formValidate"
          :rules="ruleValidate"
          :label-width="120"
        >
          <FormItem label="系統" prop="sysId">
            <SysSelect :value.sync="formValidate.sysId" />
          </FormItem>
        </Form>
      </Col>
    </Row>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="queryAllSystemInfo">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Tabs value="role" type="card">
      <TabPane label="關聯角色" name="role">
        <Table
          :columns="roleColumn"
          :data="roleList"
          @on-sort-change="handleRoleSort"
        ></Table>
        <br />
        <Row type="flex" justify="center">
          <Page
            show-total
            show-elevator
            show-sizer
            :total="rolePage.total"
            :current.sync="rolePage.index"
            @on-change="doGetRoleList"
            @on-page-size-change="handleRolePageSizeChange"
          ></Page>
        </Row>
      </TabPane>
      <TabPane label="系統資源" name="resource">
        <Table
          :columns="resourceColumn"
          :data="resourceList"
          @on-sort-change="handleResourceSort"
        >
        </Table>
        <br />
        <Row type="flex" justify="center">
          <Page
            show-total
            show-elevator
            show-sizer
            :total="resourcePage.total"
            :current.sync="resourcePage.index"
            @on-change="doGetResourceList"
            @on-page-size-change="handleResourcePageSizeChange"
          ></Page>
        </Row>
      </TabPane>
    </Tabs>

    <F030402SCN
      :isModalVisible="isModalVisible"
      :resourceSeqNo="resourceSeqNo"
      @close="hideModal"
    />
  </div>
</template>

<script>
import f030401Api from "@api/f03/f030401-api";
import namingConverter from "@misc/naming-converter";
import F030402SCN from "@components/f03/F030402SCN.vue";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    F030402SCN,
    SysSelect
  },
  data() {
    return {
      // 驗證欄位非空提醒
      ruleValidate: {
        sysId: [
          {
            required: true,
            message: "請選擇系統",
            trigger: "change"
          }
        ]
      },
      // 是否顯示對話框(f030402SCN)
      isModalVisible: false,
      // 表單驗證項目
      formValidate: {
        // 系統代碼(用以查詢系統資源/關聯角色)
        sysId: ""
      },
      // 資源主鍵(用以props給子組件，查詢資源關聯角色)
      resourceSeqNo: "",
      //page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      resourcePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      roleList: [],
      resourceList: [],
      roleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom"
        }
      ],
      // 資源表格欄位
      resourceColumn: [
        {
          title: "資源類別",
          key: "rsrcTypeNm",
          width: "150",
          fixed: "left"
        },
        {
          title: "資源名稱",
          key: "rsrcNm",
          width: "200",
          fixed: "left"
        },
        {
          title: "資源說明",
          key: "rsrcMemo",
          width: "350",
          fixed: "left"
        },
        {
          title: "資源等級",
          key: "confLvNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "URI",
          key: "rsrcUri",
          width: "300"
        },
        {
          title: "上層選單",
          key: "upMenuNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "轉導類型",
          key: "redirectTypeNm",
          width: "150"
        },
        {
          title: "選單位置",
          key: "positionNm",
          width: "150"
        },
        {
          title: "排序號碼",
          key: "sortNum",
          width: "150",
          align: "right"
        },
        {
          title: "資源狀態",
          key: "rsrcStsNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "動作",
          slot: "action",
          width: "150",
          fixed: "right",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.props(params.row);
                  }
                }
              },
              "檢視角色"
            );
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    queryAllSystemInfo: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetResourceList();
          this.doGetRoleList();
        }
      });
    },
    /**
     * 查詢系統資源
     */
    doGetResourceList: async function() {
      let result = await f030401Api.doGetResourceList({
        sysId: this.formValidate.sysId,
        pageNo: this.resourcePage.index,
        pageSize: this.resourcePage.size,
        sortColumn: this.resourcePage.sortColumn,
        sortType: this.resourcePage.sortType
      });

      this.resourcePage.index = result.pageNo;
      this.resourcePage.total = result.totalCount;
      this.resourceList = result.resourceList;
    },
    /**
     * 查詢系統關聯角色
     */
    doGetRoleList: async function() {
      let result = await f030401Api.doGetRoleList({
        sysId: this.formValidate.sysId,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleList = result.roleInfoList;
    },
    /**
     * props resourceSeqNo給子組件(用以查詢資源角色清單)
     */
    props: function(row) {
      this.resourceSeqNo = row.resourceSeqNo;
      this.isModalVisible = true;
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.queryAllSystemInfo();
    },
    /**
     * 處理資源清單排序
     */
    handleResourceSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.resourcePage.sortColumn = null;
        this.resourcePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.resourcePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.resourcePage.sortType = col.order.toUpperCase();
      }

      this.queryAllSystemInfo();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.queryAllSystemInfo();
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleResourcePageSizeChange: function(newPageSize) {
      this.resourcePage.size = newPageSize;
      this.queryAllSystemInfo();
    },
    /**
     * 關閉modal
     */
    hideModal: function() {
      this.isModalVisible = false;
    }
  },
  props: {},
  computed: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
