<template>
  <div>
    <Form :label-width="120">
      <Row>
        <Col span="8">
          <FormItem label="系統">
            <SysSelect :value.sync="sysId" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色類別">
            <sys-cd-select :ctId="42" :value.sync="roleType" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色名稱">
            <Input v-model="roleNm" maxlength="20" show-word-limit />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="doGetRoleList">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Table
      :columns="roleColumn"
      :data="roleList"
      @on-sort-change="handleRoleSort"
    >
      <template slot-scope="{ row }" slot="action">
        <Button @click="showRoleModal(row)">檢視</Button>
      </template>
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="rolePage.total"
        :current.sync="rolePage.index"
        :page-size="rolePage.size"
        @on-change="doGetRoleList"
        @on-page-size-change="handleRolePageSizeChange"
      ></Page>
    </Row>

    <F030302SCN
      :isModalVisible="isModalVisible"
      :roleId="roleId"
      @close="hideModal"
    />
  </div>
</template>

<script>
import f030301Api from "@api/f03/f030301-api";
import namingConverter from "@misc/naming-converter";
import F030302SCN from "@components/f03/F030302SCN.vue";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    F030302SCN,
    SysSelect
  },
  props: {},
  data() {
    return {
      // 是否顯示對話框(F030302SCN)
      isModalVisible: false,
      // 系統代碼(用以查詢角色清單)
      sysId: "",
      // 角色類別(用以查詢角色清單)
      roleType: "",
      // 角色名稱(用以查詢角色清單)
      roleNm: "",
      // 角色代碼(用以props給子組件，查詢角色對應群組/資源)
      roleId: "",
      // 角色類別選單，決定roleType(角色類別)
      roleTypeList: [],
      // page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      roleList: [],
      roleColumn: [
        {
          title: "一般/複合",
          key: "roleCatNm"
        },
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色代碼",
          key: "roleId",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ]
    };
  },
  methods: {
    /**
     * 查詢角色清單
     */
    doGetRoleList: async function() {
      let result = await f030301Api.doGetRoleList({
        sysId: this.sysId,
        roleType: this.roleType,
        roleNm: this.roleNm,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleList = result.roleInfoList;
    },
    /**
     * props roleId給子組件(用以查詢角色對應群組/資源)
     */
    showRoleModal: function(row) {
      this.roleId = row.roleId;
      this.isModalVisible = true;
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.doGetRoleList();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.doGetRoleList();
    },
    hideModal: function() {
      this.isModalVisible = false;
    }
  },
  computed: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
