<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleInline"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        disableUser
      ></OrgSelect>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="queryAllGroupInfo">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Tabs value="grpUser" type="card">
      <TabPane label="使用者" name="grpUser">
        <div>
          <Table
            :columns="grpUserColumn"
            :data="grpUserList"
            @on-sort-change="handleUserSort"
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="grpUserPage.total"
              :current.sync="grpUserPage.index"
              @on-change="doGetGroupUserList"
              @on-page-size-change="handleUserPageSizeChange"
              transfer
            ></Page>
          </Row>
        </div>
      </TabPane>
      <TabPane label="角色" name="grpRole">
        <div>
          <Table
            :columns="grpRoleColumn"
            :data="grpRoleList"
            @on-sort-change="handleRoleSort"
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="grpRolePage.total"
              :current.sync="grpRolePage.index"
              @on-change="doGetGroupRoleList"
              @on-page-size-change="handleRolePageSizeChange"
              transfer
            ></Page>
          </Row>
        </div>
      </TabPane>
      <TabPane label="群組" name="subGrp">
        <div>
          <Table
            :columns="subGrpColumn"
            :data="subGrpList"
            @on-sort-change="handleGrpSort"
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="subGrpPage.total"
              :current.sync="subGrpPage.index"
              @on-change="doGetSubordinateList"
              @on-page-size-change="handleGrpPageSizeChange"
              transfer
            ></Page>
          </Row>
        </div>
      </TabPane>
    </Tabs>

    <Modal
      v-model="isCompositeModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 查詢複合角色</span>
      </p>
      <Table
        :columns="compositeRoleColumn"
        :data="compositeRoleList"
        border
      ></Table>
      <br />
      <Row type="flex" justify="center">
        <Col>
          <Button @click="hideModal">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f030201Api from "@api/f03/f030201-api";
import f050303Api from "@api/f05/f050303-api";
import namingConverter from "@misc/naming-converter";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  computed: {
    // 群組編號 (用以查詢群組使用者/角色/業務群組)
    grpId: function() {
      return (
        this.formValidate.selectedGroup ||
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  data() {
    // Custom Validator
    const validateDivOrGrp = (rule, value, callback) => {
      this.$refs.formValidate.validateField("selectedGroup");
      if (
        isBlank(this.formValidate.selectedDivision) &&
        isBlank(this.formValidate.selectedGroup)
      ) {
        return callback(new Error("請選擇事業處或業務群組"));
      }

      if (isBlank(this.formValidate.selectedDivision)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedDivision"
        }).resetField();
      }

      if (isBlank(this.formValidate.selectedGroup)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedGroup"
        }).resetField();
      }

      callback();
    };
    return {
      // 表單驗證提醒
      ruleInline: {
        selectedDivision: [{ validator: validateDivOrGrp, trigger: "change" }],
        selectedGroup: [{ validator: validateDivOrGrp, trigger: "change" }]
      },
      // 表單資料(OrgSelect component，為查詢條件)
      formValidate: {
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: ""
      },
      // page
      grpUserPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      grpRolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      subGrpPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      grpUserList: [],
      grpRoleList: [],
      subGrpList: [],
      compositeRoleList: [],
      grpUserColumn: [
        {
          title: "事業處",
          key: "devisionNm"
        },
        {
          title: "部門",
          key: "departmentNm"
        },
        {
          title: "科別",
          key: "sectionNm"
        },
        {
          title: "姓名",
          key: "empNm"
        },
        {
          title: "AD帳號",
          key: "adAccount"
        },
        {
          title: "員工編號",
          key: "empNo",
          sortable: "custom",
          align: "right"
        },
        {
          title: "職稱",
          key: "titleNm"
        }
      ],
      grpRoleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom"
        },
        {
          title: "複合角色",
          slot: "action",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.viewCompositeRoles(params.row);
                  }
                }
              },
              "檢視"
            );
          }
        }
      ],
      subGrpColumn: [
        {
          title: "群組類型",
          key: "grpTypeNm"
        },
        {
          title: "群組名稱",
          key: "grpNm"
        },
        {
          title: "資料來源",
          key: "dataSrcNm"
        },
        {
          title: "有效起日",
          key: "startDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "有效迄日",
          key: "endDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "是否永久有效",
          key: "permanentNm",
          sortable: "custom"
        }
      ],
      compositeRoleColumn: [
        {
          title: "複合角色",
          key: "label",
          sortable: "true"
        }
      ],
      // 是否顯示複合角色對話框
      isCompositeModalVisible: false
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    queryAllGroupInfo: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetGroupUserList();
          this.doGetGroupRoleList();
          this.doGetSubordinateList();
        }
      });
    },
    /**
     * 查詢群組使用者清單
     */
    doGetGroupUserList: async function() {
      let result = await f030201Api.doGetGroupUserList({
        grpId: this.grpId,
        pageNo: this.grpUserPage.index,
        pageSize: this.grpUserPage.size,
        sortColumn: this.grpUserPage.sortColumn,
        sortType: this.grpUserPage.sortType
      });

      this.grpUserPage.index = result.pageNo;
      this.grpUserPage.total = result.totalCount;
      this.grpUserList = result.grpUserList;
    },
    /**
     * 查詢群組角色清單
     */
    doGetGroupRoleList: async function() {
      let result = await f030201Api.doGetGroupRoleList({
        grpId: this.grpId,
        pageNo: this.grpRolePage.index,
        pageSize: this.grpRolePage.size,
        sortColumn: this.grpRolePage.sortColumn,
        sortType: this.grpRolePage.sortType
      });

      this.grpRolePage.index = result.pageNo;
      this.grpRolePage.total = result.totalCount;
      this.grpRoleList = result.roleInfoList;
    },
    /**
     * 檢視角色已複合的角色
     */
    viewCompositeRoles: async function(row) {
      this.isCompositeModalVisible = true;

      this.compositeRoleList = await f050303Api.doGetCompositeRoles({
        roleId: row.roleId
      });
    },
    /**
     * 查詢子群組清單
     */
    doGetSubordinateList: async function() {
      let result = await f030201Api.doGetSubordinateList({
        grpId: this.grpId,
        pageNo: this.subGrpPage.index,
        pageSize: this.subGrpPage.size,
        sortColumn: this.subGrpPage.sortColumn,
        sortType: this.subGrpPage.sortType
      });

      this.subGrpPage.index = result.pageNo;
      this.subGrpPage.total = result.totalCount;
      this.subGrpList = result.groupInfoList;
    },
    /**
     * 處理使用者清單排序
     */
    handleUserSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.grpUserPage.sortColumn = null;
        this.grpUserPage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.grpUserPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.grpUserPage.sortType = col.order.toUpperCase();
      }

      this.queryAllGroupInfo();
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.grpRolePage.sortColumn = null;
        this.grpRolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.grpRolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.grpRolePage.sortType = col.order.toUpperCase();
      }

      this.queryAllGroupInfo();
    },
    /**
     * 處理群組清單排序
     */
    handleGrpSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.subGrpPage.sortColumn = null;
        this.subGrpPage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.subGrpPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.subGrpPage.sortType = col.order.toUpperCase();
      }

      this.queryAllGroupInfo();
    },
    /**
     * 處理使用者每頁筆數改變
     */
    handleUserPageSizeChange: function(newPageSize) {
      this.grpUserPage.size = newPageSize;
      this.queryAllGroupInfo();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.grpRolePage.size = newPageSize;
      this.queryAllGroupInfo();
    },
    /**
     * 處理群組每頁筆數改變
     */
    handleGrpPageSizeChange: function(newPageSize) {
      this.subGrpPage.size = newPageSize;
      this.queryAllGroupInfo();
    },
    /**
     * 關閉 Modal
     */
    hideModal: function() {
      this.isCompositeModalVisible = false;
    }
  },
  props: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
