﻿<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect :userProp.sync="formValidate.selectedUser">
        <Col span="8">
          <FormItem label="AD帳號" prop="adAccount">
            <Input
              v-model="formValidate.adAccount"
              maxlength="20"
              show-word-limit
            />
          </FormItem>
        </Col>
      </OrgSelect>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="queryAllUserInfo">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Tabs value="group" type="card">
      <TabPane label="業務群組" name="group">
        <div>
          <Table
            :columns="groupColumn"
            :data="groupList"
            @on-sort-change="handleGrpSort"
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="grpPage.total"
              :current.sync="grpPage.index"
              @on-change="doGetGroupList"
              @on-page-size-change="handleGrpPageSizeChange"
              transfer
            ></Page>
          </Row>
        </div>
      </TabPane>
      <TabPane label="角色" name="role">
        <div>
          <Table
            :columns="roleColumn"
            :data="roleList"
            @on-sort-change="handleRoleSort"
          ></Table>
          <br />
          <Row type="flex" justify="center">
            <Page
              show-total
              show-elevator
              show-sizer
              :total="rolePage.total"
              :page-size="rolePage.size"
              :current.sync="rolePage.index"
              @on-change="doGetRoleList"
              @on-page-size-change="handleRolePageSizeChange"
              transfer
            ></Page>
          </Row>
        </div>
      </TabPane>
    </Tabs>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f030101Api from "@api/f03/f030101-api";
import namingConverter from "@misc/naming-converter";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  data() {
    // Custom Validator
    const validateAdAccount = (rule, value, callback) => {
      // validate fields
      if (isBlank(this.adAccount)) {
        return callback(new Error("請選擇人員或輸入AD帳號"));
      }

      // 選擇人員及輸入框AD帳號都有值但不一致
      if (
        !isBlank(this.formValidate.selectedUser) &&
        !isBlank(this.formValidate.adAccount) &&
        this.formValidate.selectedUser !== this.formValidate.adAccount
      ) {
        return callback(new Error("AD帳號與選擇人員請保持一致(或擇一查詢)"));
      }

      if (isBlank(this.formValidate.selectedUser)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "selectedUser"
        }).resetField();
      }

      if (isBlank(this.formValidate.adAccount)) {
        this._.find(this.$refs["formValidate"].fields, {
          prop: "adAccount"
        }).resetField();
      }

      callback();
    };
    return {
      formValidate: {
        // 使用者AD帳號 (用以查詢使用者所屬群組/擁有角色)
        adAccount: "",
        selectedUser: ""
      },
      // 驗證欄位非空提醒
      ruleValidate: {
        adAccount: [{ validator: validateAdAccount, trigger: "blur" }],
        selectedUser: [{ validator: validateAdAccount, trigger: "change" }]
      },
      // page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      grpPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      roleList: [],
      groupList: [],
      roleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom"
        }
      ],
      groupColumn: [
        {
          title: "群組類別",
          key: "grpTypeNm",
          width: 280
        },
        {
          title: "群組名稱",
          key: "grpNm"
        },
        {
          title: "群組狀態",
          key: "grpStsNm",
          sortable: "custom"
        },
        {
          title: "資料來源",
          key: "dataSrcNm",
          sortable: "custom"
        },
        {
          title: "有效起日",
          key: "startDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "有效迄日",
          key: "endDate",
          sortable: "custom",
          align: "center"
        },
        {
          title: "是否永久有效",
          key: "permanentNm",
          sortable: "custom"
        }
      ]
    };
  },
  methods: {
    /**
     * 點按查詢按鈕，檢核欄位非空才做查詢
     */
    queryAllUserInfo: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetRoleList();
          this.doGetGroupList();
        }
      });
    },
    /**
     * 查詢使用者群組清單
     */
    doGetGroupList: async function() {
      let result = await f030101Api.doGetGroupList({
        adAccount: this.adAccount.toUpperCase(),
        pageNo: this.grpPage.index,
        pageSize: this.grpPage.size,
        sortColumn: this.grpPage.sortColumn,
        sortType: this.grpPage.sortType
      });

      this.grpPage.total = result.totalCount;
      this.groupList = result.groupInfoList;
    },
    /**
     * 查詢使用者角色清單
     */
    doGetRoleList: async function() {
      let result = await f030101Api.doGetRoleList({
        adAccount: this.adAccount.toUpperCase(),
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.total = result.totalCount;
      this.roleList = result.roleInfoList;
    },
    /**
     * 處理群組清單排序
     */
    handleGrpSort: function(col) {
      if (!this.grpPage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.grpPage.sortColumn = null;
        this.grpPage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.grpPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.grpPage.sortType = col.order.toUpperCase();
      }

      this.queryAllUserInfo();
    },
    /**
     * 處理角色清單
     */
    handleRoleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.queryAllUserInfo();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.queryAllUserInfo();
    },
    /**
     * 處理群組每頁筆數改變
     */
    handleGrpPageSizeChange: function(newPageSize) {
      this.grpPage.size = newPageSize;
      this.queryAllUserInfo();
    }
  },
  props: {},
  computed: {
    // AD帳號 (用以判斷拿選擇人員或輸入框AD帳號做查詢)
    adAccount: function() {
      return this.formValidate.adAccount || this.formValidate.selectedUser;
    }
  },
  watch: {
    // 當 formValidate.selectedUser (選擇人員)改變時同步修改 formValidate.adAccount (輸入框AD帳號)
    "formValidate.selectedUser": {
      handler: function() {
        this.formValidate.adAccount = this.formValidate.selectedUser;
      }
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
