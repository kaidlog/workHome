<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        :groupProp.sync="formValidate.selectedGroup"
        :divisionReadonly="orgSelectCtrl.divisionDisable"
        :headquarterReadonly="orgSelectCtrl.headquarterDisable"
        :departmentReadonly="orgSelectCtrl.departmentDisable"
        :sectionReadonly="orgSelectCtrl.sectionDisable"
        disableGroup
        disableUser
        ref="org"
      >
      </OrgSelect>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col v-if="isAdmin" span="1.5">
        <Button @click="downloadOthersReport">
          <Icon type="md-download" /> 委外人員權限報表
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="downloadReport">
          <Icon type="md-download" /> 下載
        </Button>
      </Col>
    </Row>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import f040101Api from "@api/f04/f040101-api";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    OrgSelect
  },
  props: {},
  data() {
    return {
      // OrgSelect元件表單驗證項目
      formValidate: {
        selectedDivision: "",
        selectedHeadquarter: "",
        selectedDepartment: "",
        selectedSection: "",
        selectedGroup: ""
      },
      // OrgSelect 控制項
      orgSelectCtrl: {
        divisionDisable: null,
        headquarterDisable: null,
        departmentDisable: null,
        sectionDisable: null
      },
      // 表單驗證規則
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ]
      },
      // 是否為系統管理員/風管部角色
      isAdmin: false
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    orgSelectGrp: function() {
      return (
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  methods: {
    /**
     * 取得群組名稱
     */
    getGrpNm: function(orgSelectGrp) {
      if (this.formValidate.selectedSection) {
        return this._.find(this.$refs.org.sectionList, { grpId: orgSelectGrp })
          .grpNm;
      }

      if (this.formValidate.selectedDepartment) {
        return this._.find(this.$refs.org.departmentList, {
          grpId: orgSelectGrp
        }).grpNm;
      }

      if (this.formValidate.selectedHeadquarter) {
        return this._.find(this.$refs.org.headquarterList, {
          grpId: orgSelectGrp
        }).grpNm;
      }

      if (this.formValidate.selectedDivision) {
        return this._.find(this.$refs.org.divisionList, { grpId: orgSelectGrp })
          .grpNm;
      }
    },
    /**
     * 下載權限報表
     */
    downloadReport: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          let fileName =
            this.getGrpNm(this.orgSelectGrp) +
            "_權限報表_" +
            new Date().toISOString().slice(0, 10) +
            ".xlsx";

          f040101Api.downloadReport(
            {
              grpId: this.orgSelectGrp
            },
            fileName
          );
        }
      });
    },
    /**
     * 下載委外人員權限報表
     */
    downloadOthersReport: function() {
      let fileName =
        "委外人員_權限報表_" + new Date().toISOString().slice(0, 10) + ".xlsx";

      f040101Api.downloadReport(
        {
          grpId: "B_1"
        },
        fileName
      );
    },
    /**
     * 經理人配置
     */
    managerConfig: function() {
      this.orgSelectCtrl.divisionDisable = true;
      this.orgSelectCtrl.headquarterDisable = true;
      this.orgSelectCtrl.departmentDisable = true;
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {
    // 是否具有系統管理員/風險管理部經辦角色
    // ROLE_00000 系統管理員, ROLE_00032 風險管理部經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00000") ||
      this.optUserProfile.roles.includes("ROLE_00032")
    ) {
      this.isAdmin = true;
      return;
    }

    // 是否具有部經理/科主管/資訊聯絡員/客服中心維運經辦角色
    // ROLE_00001 部經理, ROLE_00002 科主管
    // ROLE_00003 資訊聯絡員, ROLE_00030 客服中心維運經辦
    if (
      this.optUserProfile.roles.includes("ROLE_00001") ||
      this.optUserProfile.roles.includes("ROLE_00002") ||
      this.optUserProfile.roles.includes("ROLE_00003") ||
      this.optUserProfile.roles.includes("ROLE_00030")
    ) {
      this.managerConfig();
      return;
    }
  },
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
