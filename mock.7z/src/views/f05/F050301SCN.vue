﻿<template>
  <div>
    <Form :label-width="120">
      <Row>
        <Col span="8">
          <FormItem label="一般/複合">
            <Select v-model="roleCat" filterable clearable>
              <Option
                v-for="item in catList"
                :value="item.value"
                :key="item.value"
                >{{ item.label }}</Option
              >
            </Select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色類別">
            <sys-cd-select :ctId="42" :value.sync="roleType" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色名稱">
            <Input v-model="roleNm" maxlength="20" show-word-limit />
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="8">
          <FormItem label="角色狀態">
            <sys-cd-select :ctId="30" :value.sync="roleSts" />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <br />
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="doGetRoleList">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="showEditModal({})">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>

    <Table
      :columns="roleColumn"
      :data="roleList"
      @on-sort-change="handleRoleSort"
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="rolePage.total"
        :current.sync="rolePage.index"
        :page-size="rolePage.size"
        @on-change="doGetRoleList"
        @on-page-size-change="handleRolePageSizeChange"
      ></Page>
    </Row>

    <Modal
      v-model="isLookupExModalVisible"
      footer-hide
      :closable="false"
      :mask-closable="false"
    >
      <p slot="header">
        <font-awesome-icon :icon="'user'" />
        <span> 查詢互斥角色</span>
      </p>
      <ExclusiveLookup :roleId="roleInfo.roleId" />
      <br />
      <Row type="flex" justify="center">
        <Col>
          <Button @click="hideModal">
            <font-awesome-icon :icon="'times'" /><span> 關閉</span>
          </Button>
        </Col>
      </Row>
    </Modal>

    <F050302SCN
      :isEditModalVisible="isEditModalVisible"
      :roleInfo="roleInfo"
      @close="hideModal"
    />

    <F050303SCN
      :isCompositeModalVisible="isCompositeModalVisible"
      :roleInfo="roleInfo"
      @close="hideModal"
    />

    <F050304SCN
      :isExclusiveModalVisible="isExclusiveModalVisible"
      :roleInfo="roleInfo"
      @close="hideModal"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import f050301Api from "@api/f05/f050301-api";
import namingConverter from "@misc/naming-converter";
import F050302SCN from "@components/f05/F050302SCN.vue";
import F050303SCN from "@components/f05/F050303SCN.vue";
import F050304SCN from "@components/f05/F050304SCN.vue";
import ExclusiveLookup from "@components/common/ExclusiveLookup.vue";

export default {
  components: {
    F050302SCN,
    F050303SCN,
    F050304SCN,
    ExclusiveLookup
  },
  data() {
    return {
      // 是否顯示對話框(ExclusiveLookup)
      isLookupExModalVisible: false,
      // 是否顯示對話框(f050302SCN)
      isEditModalVisible: false,
      // 是否顯示對話框(f050303SCN)
      isCompositeModalVisible: false,
      // 是否顯示對話框(f050304SCN)
      isExclusiveModalVisible: false,
      // 角色狀態(用以查詢角色清單)
      roleSts: "",
      // 角色類別(用以查詢角色清單)
      roleType: "",
      // 一般/複合(用以查詢角色清單)
      roleCat: "",
      // 角色名稱(用以查詢角色清單)
      roleNm: "",
      // 角色資訊物件，用以props給子組件
      roleInfo: {},
      // 一般/複合選單
      catList: [
        {
          value: "N",
          label: "一般角色"
        },
        {
          value: "C",
          label: "複合角色"
        }
      ],
      // page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      roleList: [],
      // 角色欄位項目
      roleColumn: [
        {
          title: "一般/複合",
          key: "roleCatNm",
          fixed: "left",
          width: "135"
        },
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom",
          fixed: "left",
          width: "135"
        },
        {
          title: "角色代碼",
          key: "roleId",
          sortable: "custom",
          width: "200"
        },
        {
          title: "角色名稱",
          key: "roleNm",
          width: "300",
          fixed: "left"
        },
        {
          title: "角色說明",
          key: "roleMemo",
          width: "350"
        },
        {
          title: "角色狀態",
          key: "roleStsNm",
          sortable: "custom",
          width: "135"
        },
        {
          title: "互斥角色",
          slot: "exclusiveRole",
          width: "113",
          fixed: "right",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.exclusiveLookup(params.row);
                  }
                }
              },
              "檢視"
            );
          }
        },
        {
          title: "動作",
          slot: "action",
          width: "350",
          fixed: "right",
          align: "center",
          render: (h, params) => {
            return [
              h(
                "Button",
                {
                  on: {
                    click: () => {
                      this.showEditModal(params.row);
                    }
                  }
                },
                "修改"
              ),
              h(
                "Button",
                {
                  props: {
                    disabled: this.disableComposite(params.row)
                  },
                  on: {
                    click: () => {
                      this.composite(params.row);
                    }
                  },
                  style: {
                    marginLeft: "8px"
                  }
                },
                "設定複合"
              ),
              h(
                "Button",
                {
                  props: {
                    disabled: this.disableExclusive()
                  },
                  on: {
                    click: () => {
                      this.exclusive(params.row);
                    }
                  },
                  style: {
                    marginLeft: "8px"
                  }
                },
                "設定互斥"
              )
            ];
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 查詢角色清單
     */
    doGetRoleList: async function() {
      let result = await f050301Api.doGetRoleList({
        roleCat: this.roleCat,
        roleType: this.roleType,
        roleNm: this.roleNm,
        roleSts: this.roleSts,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleList = result.roleInfoList;
    },
    /**
     * 查詢互斥角色
     */
    exclusiveLookup: function(row) {
      this.roleInfo = row;
      this.isLookupExModalVisible = true;
    },
    /**
     * 新增/修改角色
     */
    showEditModal: function(row) {
      this.roleInfo = row;
      this.isEditModalVisible = true;
    },
    /**
     * 設定複合
     */
    composite: function(row) {
      this.roleInfo = row;
      this.isCompositeModalVisible = true;
    },
    /**
     * 設定互斥
     */
    exclusive: function(row) {
      this.roleInfo = row;
      this.isExclusiveModalVisible = true;
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.doGetRoleList();
    },
    /**
     * 處理角色每頁筆數改變
     */
    handleRolePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.doGetRoleList();
    },
    /**
     * 關閉 Modal，並查看是否需重新查詢
     */
    hideModal: function(isRefresh) {
      this.isLookupExModalVisible = false;
      this.isEditModalVisible = false;
      this.isCompositeModalVisible = false;
      this.isExclusiveModalVisible = false;
      this.roleInfo = {};

      if (isRefresh) {
        this.doGetRoleList();
      }
    },
    // 是否停用複合按鈕
    disableComposite: function(row) {
      // 系統發展部經辦不可設定複合, ROLE_00031 系統發展部經辦
      if (this.optUserProfile.roles.includes("ROLE_00031")) {
        return true;
      }
      return row.isChildRole === "Y"; // Y: 屬於被複合角色
    },
    // 是否停用互斥按鈕
    disableExclusive: function() {
      // 系統發展部經辦不可設定互斥, ROLE_00031 系統發展部經辦
      if (this.optUserProfile.roles.includes("ROLE_00031")) {
        return true;
      }
      return false;
    }
  },
  props: {},
  computed: {
    ...mapGetters(["optUserProfile"])
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
<style lang="scss" scoped></style>
