<template>
  <div>
    <Form :label-width="120">
      <Row>
        <Col span="8">
          <FormItem label="一般/複合">
            <Select v-model="formData.roleCat" filterable clearable>
              <Option
                v-for="item in catList"
                :value="item.value"
                :key="item.value"
                >{{ item.label }}</Option
              >
            </Select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色代碼">
            <Input v-model="formData.roleId" maxlength="20" show-word-limit />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色名稱">
            <Input v-model="formData.roleNm" maxlength="20" show-word-limit />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="getRoleList">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table
      :columns="roleColumn"
      :data="roleData"
      @on-sort-change="handleRoleSort"
      border
    >
    </Table>
    <br />

    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="rolePage.total"
        :current.sync="rolePage.index"
        @on-change="getRoleList"
        @on-page-size-change="handleResourcePageSizeChange"
      ></Page>
    </Row>

    <F050502SCN
      :isAttrModalVisible="isAttrModalVisible"
      :role="roleSelected"
      @close="hideModal"
    />
  </div>
</template>

<script>
import f050501Api from "@api/f05/f050501-api";
import namingConverter from "@misc/naming-converter";
import F050502SCN from "@components/f05/F050502SCN.vue";

export default {
  components: {
    F050502SCN
  },
  props: {},
  data() {
    return {
      formData: {
        // 一般/複合(用以查詢角色清單)
        roleCat: "",
        // 角色代碼(用以查詢角色清單)
        roleId: "",
        // 角色名稱(用以查詢角色清單)
        roleNm: ""
      },
      // 操作目標角色
      roleSelected: {
        //角色代碼
        roleId: "",
        //角色名稱
        roleNm: ""
      },
      // 一般/複合選單
      catList: [
        {
          value: "N",
          label: "一般角色"
        },
        {
          value: "C",
          label: "複合角色"
        }
      ],
      // 是否顯示對話框
      isAttrModalVisible: false,
      // 角色資料清單
      roleData: [],
      // 角色欄位項目
      roleColumn: [
        {
          title: "角色類別",
          key: "roleTypeNm",
          sortable: "custom"
        },
        {
          title: "角色代碼",
          key: "roleId"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "動作",
          slot: "action",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.editRole(params.row);
                  }
                }
              },
              "設定屬性"
            );
          }
        }
      ],
      //page
      rolePage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢角色
     */
    getRoleList: async function() {
      let result = await f050501Api.getRoleList({
        roleCat: this.formData.roleCat,
        roleId: this.formData.roleId,
        roleNm: this.formData.roleNm,
        pageNo: this.rolePage.index,
        pageSize: this.rolePage.size,
        sortColumn: this.rolePage.sortColumn,
        sortType: this.rolePage.sortType
      });

      this.rolePage.index = result.pageNo;
      this.rolePage.total = result.totalCount;
      this.roleData = result.roleInfoList;
    },
    /**
     * editRole role給子組件(用以查詢角色清單)
     */
    editRole: function(row) {
      this.roleSelected = row;
      this.isAttrModalVisible = true;
    },
    /**
     * 關閉對話框
     */
    hideModal: function() {
      this.isAttrModalVisible = false;
      this.roleSelected = {};
    },
    /**
     * 處理角色清單排序
     */
    handleRoleSort: function(col) {
      if (!this.rolePage.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.rolePage.sortColumn = null;
        this.rolePage.sortType = null;
      }

      // 進行排序
      if (col.order !== "normal") {
        this.rolePage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rolePage.sortType = col.order.toUpperCase();
      }

      this.getRoleList();
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleResourcePageSizeChange: function(newPageSize) {
      this.rolePage.size = newPageSize;
      this.getRoleList();
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
