<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <Row>
        <Col span="8">
          <FormItem label="系統" prop="sysId">
            <SysSelect :value.sync="formValidate.sysId" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資源狀態" prop="rsrcSts">
            <sys-cd-select :ctId="30" :value.sync="formValidate.rsrcSts" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資源類別" prop="rsrcType">
            <sys-cd-select :ctId="36" :value.sync="formValidate.rsrcType" />
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="8">
          <FormItem label="資源等級" prop="confLv">
            <sys-cd-select :ctId="37" :value.sync="formValidate.confLv" />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="queryRsrc">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button @click="updRsrc({})" type="primary">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table
      :columns="rsrcColumn"
      :data="rsrcList"
      @on-sort-change="handleResourceSort"
    >
    </Table>
    <br />

    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="rsrcPage.total"
        :current.sync="rsrcPage.index"
        @on-change="queryRsrc"
        @on-page-size-change="handleRsrcPageSizeChange"
      ></Page>
    </Row>

    <F050202SCN
      :isEditModalVisible="isEditModalVisible"
      :rsrcInfo="rsrcInfo"
      @close="hideModal"
    />
  </div>
</template>

<script>
import isBlank from "is-blank";
import f050201Api from "@api/f05/f050201-api";
import namingConverter from "@misc/naming-converter";
import F050202SCN from "@components/f05/F050202SCN.vue";
import SysSelect from "@components/common/SysSelect.vue";

export default {
  components: {
    F050202SCN,
    SysSelect
  },
  data() {
    return {
      // 驗證欄位非空提醒
      ruleValidate: {
        sysId: [
          {
            required: true,
            message: "請選擇系統",
            trigger: "change"
          }
        ]
      },
      // 是否顯示對話框(f050202SCN)
      isEditModalVisible: false,
      formValidate: {
        // 系統代碼
        sysId: "",
        // 資源狀態
        rsrcSts: "",
        // 資源類別
        rsrcType: "",
        // 資源等級
        confLv: ""
      },
      // 資源資訊(用以props給子組件，修改資源資料)
      rsrcInfo: {},
      //page
      rsrcPage: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      rsrcList: [],
      // 資源欄位項目
      rsrcColumn: [
        {
          title: "資源類別",
          key: "rsrcTypeNm",
          width: "150",
          fixed: "left",
          sortable: "custom"
        },
        {
          title: "資源名稱",
          key: "rsrcNm",
          width: "200",
          fixed: "left"
        },
        {
          title: "資源說明",
          key: "rsrcMemo",
          width: "350",
          fixed: "left"
        },
        {
          title: "資源等級",
          key: "confLvNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "URI",
          key: "rsrcUri",
          width: "300"
        },
        {
          title: "所屬系統",
          key: "sysNm",
          width: "150"
        },
        {
          title: "資源狀態",
          key: "rsrcStsNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "上層選單",
          key: "upMenuNm",
          sortable: "custom",
          width: "150"
        },
        {
          title: "轉導類型",
          key: "redirectTypeNm",
          width: "150"
        },
        {
          title: "選單位置",
          key: "positionNm",
          width: "150"
        },
        {
          title: "排序號碼",
          key: "sortNum",
          width: "150",
          align: "right"
        },
        {
          title: "動作",
          slot: "action",
          width: "150",
          fixed: "right",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.updRsrc(params.row);
                  }
                }
              },
              "修改"
            );
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    queryRsrc: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetResourceList();
        }
      });
    },
    /**
     * 查詢系統資源
     */
    doGetResourceList: async function() {
      let result = await f050201Api.doGetResourceList({
        sysId: this.formValidate.sysId,
        rsrcSts: this.formValidate.rsrcSts,
        rsrcType: this.formValidate.rsrcType,
        confLv: this.formValidate.confLv,
        pageNo: this.rsrcPage.index,
        pageSize: this.rsrcPage.size,
        sortColumn: this.rsrcPage.sortColumn,
        sortType: this.rsrcPage.sortType
      });

      this.rsrcPage.index = result.pageNo;
      this.rsrcPage.total = result.totalCount;
      this.rsrcList = result.resourceList;
    },
    /**
     * 修改或新增資源
     */
    updRsrc: function(row) {
      this.rsrcInfo = row;
      this.isEditModalVisible = true;
    },
    /**
     * 處理資源清單排序
     */
    handleResourceSort: function(col) {
      // normal: 取消排序
      if (col.order === "normal") {
        this.rsrcPage.sortColumn = null;
        this.rsrcPage.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.rsrcPage.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.rsrcPage.sortType = col.order.toUpperCase();
      }

      this.queryRsrc();
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleRsrcPageSizeChange: function(newPageSize) {
      this.rsrcPage.size = newPageSize;
      this.queryRsrc();
    },
    /**
     * 關閉Modal，並重新查詢系統資源
     */
    hideModal: function(isRefresh) {
      // 避免使用者在沒查詢的狀況下新增後出現表單檢驗文字
      if (isRefresh && !isBlank(this.formValidate.sysId)) {
        this.queryRsrc();
      }
      this.isEditModalVisible = false;
    }
  },
  computed: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
