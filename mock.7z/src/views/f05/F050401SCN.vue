<template>
  <div>
    <Form
      ref="roleForm"
      :model="roleForm"
      :rules="roleFormRule"
      :label-width="120"
    >
      <Row>
        <Col span="8">
          <FormItem prop="roleCat" label="一般/複合">
            <Select v-model="roleForm.roleCat" filterable clearable>
              <Option
                v-for="item in roleCatList"
                :value="item.value"
                :key="item.value"
                >{{ item.label }}</Option
              >
            </Select>
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem prop="roleType" label="角色類別">
            <sys-cd-select :ctId="42" :value.sync="roleForm.roleType" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="角色名稱">
            <Input v-model="roleForm.roleNm" maxlength="20" show-word-limit />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="doQryRoleListRerenderTable">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>

    <Table
      border
      :columns="roleTableColumns"
      :data="qryResultObj.roleInfoList"
      :key="componentKeys.roleTableKey"
      @on-sort-change="handleSortChange"
      style="margin-top:15px;"
    ></Table>

    <div style="text-align:center;margin-top:15px;">
      <Page
        :total="qryResultObj.totalCount"
        :current.sync="roleForm.pageNo"
        :page-size="roleForm.pageSize"
        :page-size-opts="[10, 20, 50]"
        show-total
        show-sizer
        show-elevator
        @on-page-size-change="handlePageSizeChange"
        @on-change="doQryRoleList"
      ></Page>
    </div>

    <F050402SCN
      :showUpdResourceModal="viewComponentCtrl.viewUpdResourceModal"
      :roleInfo="targetRole"
      @close="hideModal"
    ></F050402SCN>
  </div>
</template>

<script>
import isBlank from "is-blank";
import f030301Api from "@api/f03/f030301-api";
import namingConverter from "@misc/naming-converter";
import F050402SCN from "@components/f05/F050402SCN.vue";

export default {
  components: {
    F050402SCN
  },
  props: {},
  data() {
    return {
      // 角色查詢表單
      roleForm: {
        roleCat: "",
        roleType: "",
        roleNm: "",
        pageNo: 1,
        pageSize: 10,
        sortColumn: null,
        sortType: null
      },
      // 角色查詢表單驗證規則
      roleFormRule: {
        roleCat: [
          {
            required: true,
            message: "請選擇一般/複合",
            trigger: "change"
          }
        ],
        roleType: [
          {
            required: true,
            message: "請選擇角色類別",
            trigger: "change"
          }
        ]
      },
      // 一般/複合選單
      roleCatList: [
        {
          value: "N",
          label: "一般角色"
        },
        {
          value: "C",
          label: "複合角色"
        }
      ],
      // Table Columns
      roleTableColumns: [
        {
          title: "角色類別",
          key: "roleTypeNm"
        },
        {
          title: "角色代碼",
          key: "roleId",
          sortable: "custom"
        },
        {
          title: "角色名稱",
          key: "roleNm"
        },
        {
          title: "角色說明",
          key: "roleMemo"
        },
        {
          title: "角色狀態",
          key: "roleStsNm"
        },
        {
          title: "動作",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                props: {
                  disabled: this.disableUpdRoleRsrcBtn(params.row)
                },
                on: {
                  click: () => {
                    this.showUpdResourceModal(params.row);
                  }
                }
              },
              "設定資源"
            );
          }
        }
      ],
      // 回傳資料
      qryResultObj: {
        totalCount: null,
        pageNo: null,
        roleInfoList: []
      },
      // 元件鍵值
      componentKeys: {
        roleTableKey: 1
      },
      // 畫面元件控制
      viewComponentCtrl: {
        viewUpdResourceModal: false
      },
      // 異動角色標的
      targetRole: {}
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢角色清單
     */
    doQryRoleList: async function() {
      this.$refs["roleForm"].validate(async valid => {
        if (!valid) {
          return;
        }
        this.qryResultObj = await f030301Api.doGetRoleList(this.roleForm);
        this.roleForm.pageNo = this.qryResultObj.pageNo;
      });
    },
    /**
     * 查詢角色清單並重新渲染Table
     */
    doQryRoleListRerenderTable: async function() {
      this.roleForm.pageNo = 1;
      this.roleForm.sortColumn = null;
      this.roleForm.sortType = null;

      await this.doQryRoleList();
      this.componentKeys.roleTableKey += 1;
    },
    /**
     * 處理角色清單排序
     */
    handleSortChange: async function(col) {
      if (!this.qryResultObj.totalCount) {
        return;
      }
      // normal: 取消排序
      if (col.order === "normal") {
        this.roleForm.pageNo = 1;
        this.roleForm.sortColumn = null;
        this.roleForm.sortType = null;
      }
      // normal: 取消排序
      if (col.order !== "normal") {
        this.roleForm.pageNo = 1;
        this.roleForm.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.roleForm.sortType = col.order.toUpperCase();
      }
      // 依據條件查詢角色資訊
      await this.doQryRoleList();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.roleForm.pageSize = newPageSize;
      this.doQryRoleListRerenderTable();
    },
    /**
     * 停用異動角色資源按鈕
     */
    disableUpdRoleRsrcBtn: function(row) {
      return row.roleSts === "I";
    },
    /**
     * 顯示異動資源Modal
     */
    showUpdResourceModal: function(row) {
      this.targetRole = row;
      this.viewComponentCtrl.viewUpdResourceModal = true;
    },
    /**
     * 隱藏異動資源Modal
     */
    hideModal: function(isRefresh) {
      this.targetRole = {};
      this.viewComponentCtrl.viewUpdResourceModal = false;
      if (
        isRefresh &&
        !isBlank(this.roleForm.roleCat) &&
        !isBlank(this.roleForm.roleType)
      ) {
        this.doQryRoleListRerenderTable();
      }
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
