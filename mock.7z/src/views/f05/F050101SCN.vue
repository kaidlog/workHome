<template>
  <div>
    <Form
      ref="formValidate"
      :model="formValidate"
      :rules="ruleValidate"
      :label-width="120"
    >
      <OrgSelect
        :divisionProp.sync="formValidate.selectedDivision"
        :headquarterProp.sync="formValidate.selectedHeadquarter"
        :departmentProp.sync="formValidate.selectedDepartment"
        :sectionProp.sync="formValidate.selectedSection"
        disableGroup
        disableUser
      />
      <Row>
        <Col span="8">
          <FormItem label="系統狀態" prop="sysSts">
            <sys-cd-select :ctId="30" :value.sync="formValidate.sysSts" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="系統代碼" prop="sysId">
            <Input
              v-model="formValidate.sysId"
              maxlength="10"
              show-word-limit
            />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="系統名稱" prop="sysNm">
            <Input
              v-model="formValidate.sysNm"
              maxlength="150"
              show-word-limit
            />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="querySys">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="editSys({})">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table
      :columns="sysColumn"
      :data="sysList"
      @on-sort-change="handleSort"
      border
    >
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="page.total"
        :page-size="page.size"
        :current.sync="page.index"
        @on-change="querySys"
        @on-page-size-change="handlePageSizeChange"
        transfer
      ></Page>
    </Row>

    <F050102SCN
      :isEditModalVisible="isEditModalVisible"
      :sysInfo="sysInfo"
      @close="hideModal"
    />
  </div>
</template>

<script>
import isBlank from "is-blank";
import f050101Api from "@api/f05/f050101-api";
import namingConverter from "@misc/naming-converter";
import F050102SCN from "@components/f05/F050102SCN.vue";
import OrgSelect from "@components/common/OrgSelect.vue";

export default {
  components: {
    F050102SCN,
    OrgSelect
  },
  data() {
    return {
      // 是否顯示對話框(F050102SCN)
      isEditModalVisible: false,
      ruleValidate: {
        selectedDivision: [
          {
            required: true,
            message: "請至少選擇事業處",
            trigger: "change"
          }
        ],
        sysSts: [
          {
            required: true,
            message: "請選擇系統狀態",
            trigger: "change"
          }
        ]
      },
      formValidate: {
        // 事業處
        selectedDivision: "",
        // 本部
        selectedHeadquarter: "",
        // 部門
        selectedDepartment: "",
        // 科別
        selectedSection: "",
        // 使用者AD帳號
        adAccount: "",
        // 系統代碼
        sysId: "",
        // 系統名稱
        sysNm: "",
        // 系統狀態
        sysSts: ""
      },
      // 系統資訊物件，用以props給子組件
      sysInfo: {},
      // page
      page: {
        index: 1,
        total: 0,
        size: 10,
        // 排序欄位
        sortColumn: null,
        // 排序方向
        sortType: null
      },
      // table
      sysList: [],
      sysColumn: [
        {
          title: "管理單位",
          key: "sysOwner"
        },
        {
          title: "系統代碼",
          key: "sysId",
          sortable: "custom"
        },
        {
          title: "系統名稱",
          key: "sysNm"
        },
        {
          title: "系統狀態",
          key: "sysStsNm",
          sortable: "custom"
        },
        {
          title: "排序編號",
          key: "sortNum",
          align: "right"
        },
        {
          title: "URL",
          key: "url"
        },
        {
          title: "系統說明",
          key: "sysMemo"
        },
        {
          title: "動作",
          slot: "action",
          width: "150",
          align: "center",
          render: (h, params) => {
            return h(
              "Button",
              {
                on: {
                  click: () => {
                    this.editSys(params.row);
                  }
                }
              },
              "修改"
            );
          }
        }
      ]
    };
  },
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    querySys: function() {
      this.$refs["formValidate"].validate(valid => {
        if (valid) {
          this.doGetSystemList();
        }
      });
    },
    /**
     * 查詢系統資訊清單
     */
    doGetSystemList: async function() {
      let result = await f050101Api.doGetSystemList({
        grpId: this.grpId,
        sysId: this.formValidate.sysId,
        sysNm: this.formValidate.sysNm,
        sysSts: this.formValidate.sysSts,
        pageNo: this.page.index,
        pageSize: this.page.size,
        sortColumn: this.page.sortColumn,
        sortType: this.page.sortType
      });

      this.page.total = result.totalCount;
      this.sysList = result.systemList;
    },
    /**
     * 處理排序
     */
    handleSort: function(col) {
      if (!this.page.total) {
        return;
      }

      // normal: 取消排序
      if (col.order === "normal") {
        this.page.sortColumn = null;
        this.page.sortType = null;
      }

      // normal: 取消排序
      if (col.order !== "normal") {
        this.page.sortColumn = namingConverter.camelCase2UnderscoreUppercase(
          col.key
        );
        this.page.sortType = col.order.toUpperCase();
      }

      this.querySys();
    },
    /**
     * 處理每頁筆數改變
     */
    handlePageSizeChange: function(newPageSize) {
      this.page.size = newPageSize;
      this.querySys();
    },
    /**
     * 新增/修改系統資訊
     */
    editSys: function(sys) {
      this.sysInfo = sys;
      if (!isBlank(sys)) {
        this.sysInfo.selectedDivision = this.formValidate.selectedDivision;
        this.sysInfo.selectedHeadquarter = this.formValidate.selectedHeadquarter;
        this.sysInfo.selectedDepartment = this.formValidate.selectedDepartment;
        this.sysInfo.selectedSection = this.formValidate.selectedSection;
      }
      this.isEditModalVisible = true;
    },
    /**
     * 關閉 Modal
     */
    hideModal: function(isRefresh) {
      this.isEditModalVisible = false;

      // 避免使用者在沒查詢的狀況下新增後出現表單檢驗文字
      if (
        isRefresh &&
        !isBlank(this.grpId) &&
        !isBlank(this.formValidate.sysSts)
      ) {
        this.querySys();
      }
    }
  },
  computed: {
    // 群組編號 (用以查詢系統資料)
    grpId: function() {
      return (
        this.formValidate.selectedSection ||
        this.formValidate.selectedDepartment ||
        this.formValidate.selectedHeadquarter ||
        this.formValidate.selectedDivision
      );
    }
  },
  props: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>
