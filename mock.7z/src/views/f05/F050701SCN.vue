<template>
  <div>
    <Form ref="formRef" :model="formData" :rules="formRules" :label-width="120">
      <Row>
        <Col span="8">
          <FormItem label="角色名稱" prop="roleNm">
            <Input
              search
              enter-button
              @on-search="showRoleModal"
              v-model="formData.roleNm"
              maxlength="20"
              readonly
            />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資源名稱" prop="rsrcNm">
            <Input
              search
              enter-button
              @on-search="showRsrcModal"
              v-model="formData.rsrcNm"
              maxlength="10"
              readonly
            />
          </FormItem>
        </Col>
      </Row>
    </Form>

    <Row type="flex" justify="end" :gutter="8">
      <Col span="1.5">
        <Button @click="getAttrList">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
      <Col span="1.5">
        <Button type="primary" @click="showAttrModal">
          <font-awesome-icon :icon="'plus-circle'" /><span> 新增</span>
        </Button>
      </Col>
    </Row>
    <br />

    <Table :columns="attrColumn" :data="attrData" border>
      <template slot-scope="{ row }" slot="action">
        <Button type="error" @click="showRemoveModal(row)">移除</Button>
        <span>{{ row.name }}</span>
      </template>
    </Table>

    <F050702SCN
      :isRoleModalVisible="isRoleModalVisible"
      @update="updateRole"
      @cancel="hideModal"
    />

    <F050703SCN
      :isRsrcModalVisible="isRsrcModalVisible"
      @update="updateRsrc"
      @cancel="hideModal"
    />

    <F050704SCN
      :isAttrModalVisible="isAttrModalVisible"
      :roleId="formData.roleId"
      :rsrcSeqNo="formData.rsrcSeqNo"
      @update="refreshAttrData"
      @cancel="hideModal"
    />

    <Modal
      v-model="isRemoveModalVisible"
      :closable="false"
      :mask-closable="false"
      @on-ok="deleteAttr"
      @on-cancel="hideModal"
    >
      <p slot="header">
        <font-awesome-icon :icon="'exclamation-circle'" />
        <span> 請確認是否移除角色資源屬性</span>
      </p>
      <Row>
        <Col span="12">目標角色:</Col>
        <Col span="12">{{
          roleRsrcSelected ? roleRsrcSelected.roleNm : ""
        }}</Col>
      </Row>
      <Row>
        <Col span="12">目標資源:</Col>
        <Col span="12">{{
          roleRsrcSelected ? roleRsrcSelected.rsrcNm : ""
        }}</Col>
      </Row>
      <Row>
        <Col span="12">屬性鍵:</Col>
        <Col span="12">{{ attrToRmv ? attrToRmv.attrKey : "" }}</Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import f050701Api from "@api/f05/f050701-api";
import F050702SCN from "@components/f05/F050702SCN.vue";
import F050703SCN from "@components/f05/F050703SCN.vue";
import F050704SCN from "@components/f05/F050704SCN.vue";

export default {
  components: {
    F050702SCN,
    F050703SCN,
    F050704SCN
  },
  props: {},
  data() {
    return {
      // 欲移除的角色資源屬性
      attrToRmv: {
        attrSeqNo: "",
        attrKey: ""
      },
      // 表單資料
      formData: {
        // 角色名稱
        roleNm: "",
        // 資源名稱
        rsrcNm: "",
        // 角色代碼
        roleId: "",
        // 資源編碼
        rsrcSeqNo: ""
      },
      // 選定的角色及資源
      roleRsrcSelected: {
        // 角色名稱
        roleNm: "",
        // 資源名稱
        rsrcNm: "",
        // 角色代碼
        roleId: "",
        // 資源編碼
        rsrcSeqNo: ""
      },
      //是否顯示角色對話框
      isRoleModalVisible: false,
      //是否顯示資源對話框
      isRsrcModalVisible: false,
      //是否顯示屬性對話框
      isAttrModalVisible: false,
      // 是否顯示對話框(移除角色資源屬性)
      isRemoveModalVisible: false,
      //欄位非空驗證規則
      formRules: {
        // 角色名稱
        roleNm: [
          {
            required: true,
            message: "請選擇角色",
            trigger: "change"
          }
        ],
        // 資源名稱
        rsrcNm: [
          {
            required: true,
            message: "請選擇資源",
            trigger: "change"
          }
        ]
      },
      // 屬性資料清單
      attrData: [],
      // 屬性欄位
      attrColumn: [
        {
          title: "屬性鍵",
          key: "attrKey"
        },
        {
          title: "屬性值",
          key: "attrVal"
        },
        {
          title: "說明",
          key: "attrMemo"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ]
    };
  },
  computed: {},
  methods: {
    /**
     * 顯示角色查詢Modal
     */
    showRoleModal: function() {
      this.isRoleModalVisible = true;
    },
    /**
     * 顯示資源查詢Modal
     */
    showRsrcModal: function() {
      this.isRsrcModalVisible = true;
    },
    /**
     * 顯示新增屬性Modal
     */
    showAttrModal: function() {
      this.$refs["formRef"].validate(valid => {
        if (valid) {
          this.isAttrModalVisible = true;
        }
      });
    },
    /**
     * 顯示'確認移除角色資源屬性'Modal
     */
    showRemoveModal: function(row) {
      this.isRemoveModalVisible = true;
      this.attrToRmv.attrSeqNo = row.attrSeqNo;
      this.attrToRmv.attrKey = row.attrKey;
    },
    /**
     * 刪除屬性
     */
    deleteAttr: function() {
      f050701Api
        .deleteAttr({
          attrSeqNo: this.attrToRmv.attrSeqNo,
          roleId: this.roleRsrcSelected.roleId,
          resourceSeqNo: this.roleRsrcSelected.rsrcSeqNo
        })
        .then(() => {
          // 重新獲取角色資源屬性清單
          this.getAttrList();
          // 顯示成功訊息
          this.$Message.info("刪除成功");
        });
    },
    /**
     * 查詢屬性
     */
    getAttrList: function() {
      this.$refs["formRef"].validate(async valid => {
        if (valid) {
          let result = await f050701Api.getAttrList({
            roleId: this.formData.roleId,
            resourceSeqNo: this.formData.rsrcSeqNo,
            // 屬性類別: RR
            attrType: "RR"
          });

          this.attrData = result;
          // 深拷貝表單的的角色資源資料，作為操作目標
          this.roleRsrcSelected = this._.cloneDeep(this.formData);
        }
      });
    },
    /**
     * 關閉角色Modal，更新角色選擇
     */
    updateRole: function(roleSelected) {
      this.hideModal();
      this.formData.roleNm = roleSelected.roleNm;
      this.formData.roleId = roleSelected.roleId;
    },
    /**
     * 關閉資源Modal，更新資源選擇
     */
    updateRsrc: function(rsrcSelected) {
      this.hideModal();
      this.formData.rsrcNm = rsrcSelected.rsrcNm;
      this.formData.rsrcSeqNo = rsrcSelected.rsrcSeqNo;
    },
    /**
     * 關閉屬性Modal，重新查詢屬性資料清單
     */
    refreshAttrData: function() {
      this.hideModal();
      this.getAttrList();
    },
    /**
     * 關閉所有Modal
     */
    hideModal: function() {
      this.isRoleModalVisible = false;
      this.isRsrcModalVisible = false;
      this.isAttrModalVisible = false;
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
