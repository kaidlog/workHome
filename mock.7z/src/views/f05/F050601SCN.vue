<template>
  <div>
    <Form ref="formRef" :model="formData" :rules="formRules" :label-width="120">
      <Row>
        <Col span="8">
          <FormItem label="系統" prop="sysId">
            <SysSelect :value.sync="formData.sysId" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資源狀態" prop="rsrcSts">
            <sys-cd-select :ctId="30" :value.sync="formData.rsrcSts" />
          </FormItem>
        </Col>
        <Col span="8">
          <FormItem label="資源類別" prop="rsrcType">
            <sys-cd-select :ctId="36" :value.sync="formData.rsrcType" />
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="8">
          <FormItem label="資源等級" prop="confLv">
            <sys-cd-select :ctId="37" :value.sync="formData.confLv" />
          </FormItem>
        </Col>
      </Row>
    </Form>
    <Row type="flex" justify="end">
      <Col span="1.5">
        <Button @click="getResourceList">
          <font-awesome-icon :icon="'search'" /><span> 查詢</span>
        </Button>
      </Col>
    </Row>
    <br />
    <Table :columns="rsrcColumn" :data="rsrcData" border>
      <template slot-scope="{ row }" slot="action">
        <Button @click="editAttr(row)">設定屬性</Button>
      </template>
    </Table>
    <br />
    <Row type="flex" justify="center">
      <Page
        show-total
        show-elevator
        show-sizer
        :total="rsrcPage.total"
        :current.sync="rsrcPage.index"
        :page-size="rsrcPage.size"
        @on-change="getResourceList"
        @on-page-size-change="handleResourcePageSizeChange"
      ></Page>
    </Row>

    <F050602SCN
      :isAttrModalVisible="isAttrModalVisible"
      :rsrc="rsrcSelected"
      @close="hideModal"
    />
  </div>
</template>

<script>
import f050601Api from "@api/f05/f050601-api";
import F050602SCN from "@components/f05/F050602SCN";
import SysSelect from "@components/common/SysSelect";

export default {
  components: {
    F050602SCN,
    SysSelect
  },
  props: {},
  data() {
    return {
      // 表單資料
      formData: {
        // 系統代碼
        sysId: "",
        // 資源狀態
        rsrcSts: "",
        // 資源類別
        rsrcType: "",
        // 資源等級
        confLv: ""
      },
      // 操作目標資源
      rsrcSelected: {
        // 資源主鍵
        resourceSeqNo: "",
        // 資源名稱
        rsrcNm: ""
      },
      // 是否顯示對話框
      isAttrModalVisible: false,
      // 驗證欄位非空提醒
      formRules: {
        sysId: [
          {
            required: true,
            message: "請選擇系統",
            trigger: "change"
          }
        ]
      },
      // 資源資料清單
      rsrcData: [],
      // 資源欄位
      rsrcColumn: [
        {
          title: "資源類別",
          key: "rsrcTypeNm"
        },
        {
          title: "資源等級",
          key: "confLvNm"
        },
        {
          title: "資源名稱",
          key: "rsrcNm"
        },
        {
          title: "資源說明",
          key: "rsrcMemo"
        },
        {
          title: "資源狀態",
          key: "rsrcStsNm"
        },
        {
          title: "動作",
          slot: "action",
          align: "center"
        }
      ],
      //page
      rsrcPage: {
        index: 1,
        total: 0,
        size: 10
      }
    };
  },
  computed: {},
  methods: {
    /**
     * 檢核欄位非空才做查詢
     */
    getResourceList: function() {
      this.$refs["formRef"].validate(async valid => {
        if (valid) {
          let result = await f050601Api.getResourceList({
            sysId: this.formData.sysId,
            rsrcSts: this.formData.rsrcSts,
            rsrcType: this.formData.rsrcType,
            confLv: this.formData.confLv,
            pageNo: this.rsrcPage.index,
            pageSize: this.rsrcPage.size
          });

          this.rsrcPage.index = result.pageNo;
          this.rsrcPage.total = result.totalCount;
          this.rsrcData = result.resourceList;
        }
      });
    },
    /**
     * 資源傳給子組件
     */
    editAttr: function(row) {
      this.rsrcSelected = row;
      this.isAttrModalVisible = true;
    },
    /**
     * 關閉Modal
     */
    hideModal: function() {
      this.isAttrModalVisible = false;
      this.rsrcSelected = {};
    },
    /**
     * 處理資源每頁筆數改變
     */
    handleResourcePageSizeChange: function(newPageSize) {
      this.rsrcPage.size = newPageSize;
      this.getResourceList();
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    /**
     * Response 500 跳轉前把所有 Modal 關閉
     */
    this.hideModal();
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
