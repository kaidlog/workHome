/**
 * 所有模組共享的getters
 */
export default {
  /**
   * 是否顯示資料處理中Spinner
   */
  isShowSpinner: state => {
    return state.axios.requestCount > 0;
  },
  /**
   * 是否顯示登出處理中Spinner
   */
  isShowLogoutSpinner: state => {
    return state.misc.showLogoutSpinner;
  },
  /**
   * 取得登入者基本資料
   */
  loginUserProfile: state => {
    return state.userProfile.loginUserProfile;
  },
  /**
   * 取得操作者基本資料
   */
  optUserProfile: state => {
    return state.userProfile.optUserProfile;
  },
  /**
   * 取得左側功能選單
   */
  leftMenus: state => {
    return state.userProfile.optUserProfile.system.leftMenuList || [];
  },
  /**
   * 取得SpanId，發生異常時前端顯示(用於除錯)
   */
  spanId: state => {
    return state.axios.spanId;
  },
  /**
   * 取得功能標題
   */
  title: state => {
    return state.layout.title;
  }
};
