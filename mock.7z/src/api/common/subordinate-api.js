const axios = require("axios");

export default {
  /**
   * 查詢上層群組資料清單，最高取到處級單位
   * @param {*} payload 查詢條件
   */
  doQryUpperUnit: async function(payload) {
    let result = await axios.post("/subordinate/get_upper_unit", payload);
    return result.data.body;
  },
  /**
   * 查詢從屬群組資料清單
   * @param {*} payload 查詢條件
   */
  doQrySubordinateUnit: async function(payload) {
    let result = await axios.post("/subordinate/get_subordinate_unit", payload);
    return result.data.body;
  },
  /**
   * 查詢從屬人員資料清單
   * @param {*} payload 查詢條件
   */
  doQrySubordinateUser: async function(payload) {
    let result = await axios.post("/subordinate/get_subordinate_user", payload);
    return result.data.body;
  }
};
