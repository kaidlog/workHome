const axios = require("axios");

export default {
  /**
   * 查詢互斥角色清單
   * @param {*} payload 查詢條件
   */
  doQryExclusives: async function(payload) {
    let result = await axios.post("/role/qry_exclusives", payload);
    return result.data.body;
  },
  /**
   * 查詢互斥衝突的角色代碼清單
   * @param {*} payload 查詢條件
   */
  doQryExclusiveConflict: async function(payload) {
    let result = await axios.post("/role/qry_exclusive_conflict", payload);
    return result.data.body;
  }
};
