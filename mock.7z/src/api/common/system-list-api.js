const axios = require("axios");
import { map } from "lodash";

export default {
  /**
   * 查詢系統清單
   * @param {*} payload 查詢條件
   */
  doQrySystemList: async function(payload) {
    let result = await axios.post("/system/get_system_list", payload);
    return map(result.data.body, function(row) {
      return {
        value: row.sysId,
        label: row.sysNm
      };
    });
  }
};
