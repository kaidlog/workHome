const axios = require("axios");

export default {
  /**
   * 新增/修改角色
   * @param payload 新增/修改參數
   */
  doUpdRole: async function(payload) {
    let result = await axios.post("/f050302/01", payload);
    return result.data.body;
  },
  /**
   * 查詢角色數量
   * @param payload 查詢參數
   */
  doQryRoleCount: async function(payload) {
    let result = await axios.post("/f050302/02", payload);
    return result.data.body;
  }
};
