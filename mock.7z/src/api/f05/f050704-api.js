const axios = require("axios");

export default {
  /**
   * 新增角色資源屬性清單
   * @param payload 新增參數
   */
  addAttr: async function(payload) {
    let result = await axios.post("/f050704/01", payload);
    return result.data.body;
  }
};
