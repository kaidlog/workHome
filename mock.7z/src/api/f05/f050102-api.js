const axios = require("axios");

export default {
  /**
   * 新增/修改系統
   * @param payload 新增/修改參數
   */
  doUpdSystem: async function(payload) {
    let result = await axios.post("/f050102/01", payload);
    return result.data.body;
  },
  /**
   * 查詢系統數量
   * @param payload 查詢參數
   */
  doQrySystemCount: async function(payload) {
    let result = await axios.post("/f050102/02", payload);
    return result.data.body;
  }
};
