const axios = require("axios");
import { map } from "lodash";

export default {
  /**
   * 查詢該角色已互斥的角色清單
   * @param payload 查詢參數
   */
  doGetExclusiveRoles: async function(payload) {
    let result = await axios.post("/f050304/01", payload);
    return map(result.data.body, function(row) {
      return {
        key: row.roleId,
        label: row.roleNm
      };
    });
  },
  /**
   * 查詢角色清單排除該角色樹系的複合角色
   * @param payload 查詢參數
   */
  doGetSelectableRoles: async function(payload) {
    let result = await axios.post("/f050304/02", payload);
    return map(result.data.body, function(row) {
      return {
        key: row.roleId,
        label: row.roleNm
      };
    });
  },
  /**
   * 新增/移除互斥角色(同一個transaction)
   * @param payload 新增/移除參數
   */
  doUpdExclusiveRoles: async function(payload) {
    let result = await axios.post("/f050304/03", payload);
    return result.data.body;
  }
};
