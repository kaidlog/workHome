const axios = require("axios");

export default {
  /**
   * 查詢角色清單
   * @param payload 查詢參數
   */
  getRoleList: async function(payload) {
    let result = await axios.post("/f050702/01", payload);
    return result.data.body;
  }
};
