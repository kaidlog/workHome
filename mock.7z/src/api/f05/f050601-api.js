const axios = require("axios");

export default {
  /**
   * 查詢資源清單
   * @param payload 查詢參數
   */
  getResourceList: async function(payload) {
    let result = await axios.post("/f050601/01", payload);
    return result.data.body;
  }
};
