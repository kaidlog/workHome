const axios = require("axios");

export default {
  /**
   * 查詢系統清單
   * @param payload 查詢參數
   */
  doGetSystemList: async function(payload) {
    let result = await axios.post("/f050101/01", payload);
    return result.data.body;
  }
};
