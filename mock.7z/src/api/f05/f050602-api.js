const axios = require("axios");

export default {
  /**
   * 查詢該資源屬性清單
   * @param payload 查詢參數
   */
  getResourceAttrList: async function(payload) {
    let result = await axios.post("/f050602/01", payload);
    return result.data.body;
  },
  /**
   * 新增資源屬性
   * @param payload 新增參數
   */
  addResourceAttr: async function(payload) {
    let result = await axios.post("/f050602/02", payload);
    return result.data.body;
  },
  /**
   * 刪除資源屬性
   * @param payload 刪除參數
   */
  delResourceAttr: async function(payload) {
    let result = await axios.post("/f050602/03", payload);
    return result.data.body;
  }
};
