const axios = require("axios");

export default {
  /**
   * 查詢該角色屬性清單
   * @param payload 查詢參數
   */
  getRoleAttrList: async function(payload) {
    let result = await axios.post("/f050502/01", payload);
    return result.data.body;
  },
  /**
   * 新增角色屬性
   * @param payload 新增參數
   */
  addRoleAttr: async function(payload) {
    let result = await axios.post("/f050502/02", payload);
    return result.data.body;
  },
  /**
   * 刪除角色屬性
   * @param payload 刪除參數
   */
  delRoleAttr: async function(payload) {
    let result = await axios.post("/f050502/03", payload);
    return result.data.body;
  }
};
