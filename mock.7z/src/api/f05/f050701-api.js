const axios = require("axios");

export default {
  /**
   * 查詢角色資源屬性清單
   * @param payload 查詢參數
   */
  getAttrList: async function(payload) {
    let result = await axios.post("/f050701/01", payload);
    return result.data.body;
  },
  /**
   * 刪除角色資源屬性
   * @param payload 刪除參數
   */
  deleteAttr: async function(payload) {
    let result = await axios.post("/f050701/02", payload);
    return result.data.body;
  }
};
