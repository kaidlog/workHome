const axios = require("axios");

export default {
  /**
   * 查詢資源清單
   * @param payload 查詢條件
   */
  doQryResourceLists: async function(payload) {
    let result = await axios.post("/f050402/01", payload);

    let body = result.data.body;
    let rsrcList = body.unconfiguredResources.concat(body.configuredResources);

    return {
      selectedRsrcSeqNo: body.configuredResources.map(rsrc => {
        return rsrc.resourceSeqNo;
      }),
      rsrcList: rsrcList.map(rsrc => {
        return {
          key: rsrc.resourceSeqNo,
          label: rsrc.rsrcNm
        };
      })
    };
  },
  /**
   * 異動角色關聯資源
   * @param payload 查詢條件
   */
  doUpdRoleResource: async function(payload) {
    let result = await axios.post("/f050402/02", payload);
    return result.data.body;
  }
};
