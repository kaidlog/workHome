const axios = require("axios");

export default {
  /**
   * 查詢資源清單
   * @param payload 查詢參數
   */
  doGetResourceList: async function(payload) {
    let result = await axios.post("/f050201/01", payload);
    return result.data.body;
  }
};
