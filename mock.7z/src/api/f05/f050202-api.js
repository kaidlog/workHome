const axios = require("axios");

export default {
  /**
   * 新增/修改資源
   * @param payload 新增/修改參數
   */
  doUpdResource: async function(payload) {
    let result = await axios.post("/f050202/01", payload);
    return result.data.body;
  },
  /**
   * 新增/修改選單
   * @param payload 新增/修改參數
   */
  doUpdMenu: async function(payload) {
    let result = await axios.post("/f050202/02", payload);
    return result.data.body;
  },
  /**
   * 查詢上層選單
   * @param payload 查詢參數
   */
  doGetMenuList: async function(payload) {
    let result = await axios.post("/f050202/03", payload);
    return result.data.body;
  }
};
