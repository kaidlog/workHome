const axios = require("axios");
const fileDownload = require("js-file-download");

export default {
  /**
   * 查詢資源清單
   * @param payload 查詢條件
   */
  downloadReport: function(payload, fileName) {
    axios
      .post("/f040101/01", payload, {
        responseType: "blob"
      })
      .then(res => {
        fileDownload(res.data, fileName);
      });
  }
};
