const axios = require("axios");

export default {
  /**
   * 查詢群組資料清單
   * @param {*} payload 查詢條件
   */
  doGetGroupList: async function(payload) {
    let result = await axios.post("/f020301/01", payload);
    return result.data.body;
  }
};
