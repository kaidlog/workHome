const axios = require("axios");

export default {
  /**
   * 取得欲修改群組資訊
   * @param {*} payload
   */
  doGetGroup4Upd: async function(payload) {
    let result = await axios.post("/f020302/01", payload);
    return result.data.body;
  },
  /**
   * 新增/修改群組
   * @param {*} payload 異動資料
   */
  doUpdGroup: async function(payload) {
    let result = await axios.post("/f020302/02", payload);
    return result.data.body;
  }
};
