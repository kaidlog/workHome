const axios = require("axios");

export default {
  /**
   * 查詢群組使用者資料
   * @param {*} payload 查詢條件
   */
  doGetGroupUserList: async function(payload) {
    let result = await axios.post("/f020101/01", payload);
    return result.data.body;
  },
  /**
   * 移除群組使用者
   * @param {*} payload 移除資料
   */
  doRemoveGroupUser: async function(payload) {
    let result = await axios.post("/f020101/02", payload);
    return result.data.body;
  },
  /**
   * 取得群組管理者(非管理員)擔任LEADER的群組清單
   */
  doGetGroupList: async function() {
    let result = await axios.post("/f020101/03");
    return result.data.body;
  }
};
