const axios = require("axios");

export default {
  /**
   * 查詢群組管理者清單
   * @param {*} payload 查詢條件
   */
  doGetGroupLeaderList: async function(payload) {
    let result = await axios.post("/f020201/01", payload);
    return result.data.body;
  },
  /**
   * 移除群組管理者
   * @param {*} payload 查詢條件
   */
  doRemoveGroupLeader: async function(payload) {
    let result = await axios.post("/f020201/02", payload);
    return result.data.body;
  }
};
