const axios = require("axios");

export default {
  /**
   * 查詢角色清單
   * @param {*} payload 查詢條件
   */
  doGetRoleLists: async function(payload) {
    let result = await axios.post("/f020303/01", payload);
    return result.data.body;
  },
  /**
   * 送出角色異動
   */
  doUpdGrpRoles: async function(payload) {
    let result = await axios.post("/f020303/02", payload);
    return result.data.body;
  }
};
