const axios = require("axios");

export default {
  /**
   * 查詢使用者清單
   * @param {*} payload 查詢條件
   */
  doGetUserList: async function(payload) {
    let result = await axios.post("/f020202/01", payload);
    return result.data.body;
  },
  /**
   * 新增群組管理者
   * @param {*} payload 新增資料
   */
  doAddGroupLeader: async function(payload) {
    let result = await axios.post("/f020202/02", payload);
    return result.data.body;
  }
};
