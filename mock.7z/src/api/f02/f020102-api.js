const axios = require("axios");

export default {
  /**
   * 新增/移除群組使用者
   * @param {*} payload 異動資料
   */
  doUpdGroupUser: async function(payload) {
    let result = await axios.post("/f020102/01", payload);
    return result.data.body;
  }
};
