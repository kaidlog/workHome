const axios = require("axios");

export default {
  /**
   * 查詢單位/使用者代理資料
   * @param {*} payload 查詢條件
   */
  doGetAgentList: async function(payload) {
    let result = await axios.post("/f010101/01", payload);
    return result.data.body;
  },
  /**
   * 停用代理 (停用後不得再啟用，需新增)
   * @param {*} payload 停用資料
   */
  doInactivateAgent: async function(payload) {
    let result = await axios.post("/f010101/02", payload);
    return result.data.body;
  }
};
