const axios = require("axios");

export default {
  /**
   * 新增/修改使用者(僅可於其他處新增/修改委外使用者)
   * @param {*} payload 新增/修改資料
   */
  doUpdateUser: async function(payload) {
    let result = await axios.post("/f010202/01", payload);
    return result.data.body;
  },
  /**
   * 查詢使用者數量
   * @param {*} payload 查詢參數
   */
  doQryUserCount: async function(payload) {
    let result = await axios.post("/f010202/02", payload);
    return result.data.body;
  }
};
