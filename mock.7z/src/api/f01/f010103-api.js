const axios = require("axios");

export default {
  /**
   * 查詢被代理人角色清單
   * @param {*} payload 查詢條件
   */
  doGetAgentUserRoles: async function(payload) {
    let result = await axios.post("/f010103/01", payload);
    return result.data.body;
  },
  /**
   * 新增代理
   * @param {*} payload 新增代理資料
   */
  doAddAgent: async function(payload) {
    let result = await axios.post("/f010103/02", payload);
    return result.data.body;
  },
  /**
   * 依設定對象取得同上層單位的同職位使用者或同單位所屬使用者, S: Self(找同職位) / O: Others(找同單位)
   * @param {*} payload 設定對象
   */
  doGetUserList: async function(payload) {
    let result = await axios.post("/f010103/03", payload);
    return result.data.body;
  },
  /**
   * 依代理SeqNo取得代理資訊
   * @param {*} payload 代理SeqNo
   */
  doGetAgent: async function(payload) {
    let result = await axios.post("/f010103/04", payload);
    return result.data.body;
  }
};
