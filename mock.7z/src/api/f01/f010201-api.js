const axios = require("axios");

export default {
  /**
   * 查詢使用者清單
   * @param {*} payload 查詢條件
   */
  doGetUserList: async function(payload) {
    let result = await axios.post("/f010201/01", payload);
    return result.data.body;
  },
  /**
   * 停權/復權使用者
   * @param {*} payload 停權/復權資料
   */
  doToggleUserSts: async function(payload) {
    let result = await axios.post("/f010201/02", payload);
    return result.data.body;
  }
};
