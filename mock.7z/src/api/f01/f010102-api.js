const axios = require("axios");

export default {
  /**
   * 查詢代理角色資料
   * @param {*} payload 查詢條件
   */
  doGetAgentRoleList: async function(payload) {
    let result = await axios.post("/f010102/01", payload);
    return result.data.body;
  }
};
