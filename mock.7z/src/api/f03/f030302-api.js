const axios = require("axios");

export default {
  /**
   * 查詢角色對應群組清單
   * @param payload 查詢參數
   */
  doGetGroupList: async function(payload) {
    let result = await axios.post("/f030302/01", payload);
    return result.data.body;
  },
  /**
   * 查詢角色對應資源清單
   * @param payload 查詢參數
   */
  doGetResourceList: async function(payload) {
    let result = await axios.post("/f030302/02", payload);
    return result.data.body;
  }
};
