const axios = require("axios");

export default {
  /**
   * 查詢系統資源
   * @param payload 查詢參數
   */
  doGetResourceList: async function(payload) {
    let result = await axios.post("/f030401/01", payload);
    return result.data.body;
  },
  /**
   * 查詢系統關聯角色
   * @param payload 查詢參數
   */
  doGetRoleList: async function(payload) {
    let result = await axios.post("/f030401/02", payload);
    return result.data.body;
  }
};
