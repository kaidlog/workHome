const axios = require("axios");

export default {
  /**
   * 查詢群組使用者清單
   * @param payload 查詢參數
   */
  doGetGroupUserList: async function(payload) {
    let result = await axios.post("/f030201/01", payload);
    return result.data.body;
  },
  /**
   * 查詢群組角色清單
   * @param payload 查詢參數
   */
  doGetGroupRoleList: async function(payload) {
    let result = await axios.post("/f030201/02", payload);
    return result.data.body;
  },
  /**
   * 查詢子群組清單
   * @param payload 查詢參數
   */
  doGetSubordinateList: async function(payload) {
    let result = await axios.post("/f030201/03", payload);
    return result.data.body;
  }
};
