const axios = require("axios");

export default {
  /**
   * 儲存前端存取記錄log
   * @param {*} payload 前端存取記錄儲存參數
   */
  doSaveFrontendAccessLog: async function(payload) {
    return await axios.post("/frontend_access_log/01", payload);
  }
};
