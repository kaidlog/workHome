import Vue from "vue";
import VueRouter from "vue-router";
import store from "@store";
import userProfileApi from "@api/core/user-profile-api";
import frontendAccessLogApi from "@api/core/frontend-access-log-api";

Vue.use(VueRouter);

const routes = [
  // f01 ------------------------------------------------------------------------------------------
  {
    /** 代理人設定 */
    path: "/f010101scn",
    name: "F010101SCN",
    component: () =>
      import(/* webpackChunkName: "f01" */ "@views/f01/F010101SCN.vue")
  },
  {
    /** 使用者資料維護 */
    path: "/f010201scn",
    name: "F010201SCN",
    component: () =>
      import(/* webpackChunkName: "f01" */ "@views/f01/F010201SCN.vue")
  },

  // f02 ------------------------------------------------------------------------------------------
  {
    /** 使用者群組人員管理 */
    path: "/f020101scn",
    name: "F020101SCN",
    component: () =>
      import(/* webpackChunkName: "f02" */ "@views/f02/F020101SCN.vue")
  },
  {
    /** 使用者群組管理者維護 */
    path: "/f020201scn",
    name: "F020201SCN",
    component: () =>
      import(/* webpackChunkName: "f02" */ "@views/f02/F020201SCN.vue")
  },
  {
    /** 使用者群組管理 */
    path: "/f020301scn",
    name: "F020301SCN",
    component: () =>
      import(/* webpackChunkName: "f02" */ "@views/f02/F020301SCN.vue")
  },

  // f03 ------------------------------------------------------------------------------------------
  {
    /** 使用者查詢 */
    path: "/f030101scn",
    name: "F030101SCN",
    component: () =>
      import(/* webpackChunkName: "f03" */ "@views/f03/F030101SCN.vue")
  },
  {
    /** 群組查詢 */
    path: "/f030201scn",
    name: "F030201SCN",
    component: () =>
      import(/* webpackChunkName: "f03" */ "@views/f03/F030201SCN.vue")
  },
  {
    /** 角色查詢 */
    path: "/f030301scn",
    name: "F030301SCN",
    component: () =>
      import(/* webpackChunkName: "f03" */ "@views/f03/F030301SCN.vue")
  },
  {
    /** 系統查詢 */
    path: "/f030401scn",
    name: "F030401SCN",
    component: () =>
      import(/* webpackChunkName: "f03" */ "@views/f03/F030401SCN.vue")
  },

  // f04 ------------------------------------------------------------------------------------------
  {
    /** 權限報表下載 */
    path: "/f040101scn",
    name: "F040101SCN",
    component: () =>
      import(/* webpackChunkName: "f04" */ "@views/f04/F040101SCN.vue")
  },

  // f05 ------------------------------------------------------------------------------------------
  {
    /** 系統管理 */
    path: "/f050101scn",
    name: "F050101SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050101SCN.vue")
  },
  {
    /** 資源管理 */
    path: "/f050201scn",
    name: "F050201SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050201SCN.vue")
  },
  {
    /** 角色管理 */
    path: "/f050301scn",
    name: "F050301SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050301SCN.vue")
  },
  {
    /** 權限設定 */
    path: "/f050401scn",
    name: "F050401SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050401SCN.vue")
  },
  {
    /** 角色屬性管理 */
    path: "/f050501scn",
    name: "F050501SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050501SCN.vue")
  },
  {
    /** 資源屬性管理 */
    path: "/f050601scn",
    name: "F050601SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050601SCN.vue")
  },
  {
    /** 角色資源屬性管理 */
    path: "/f050701scn",
    name: "F050701SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050701SCN.vue")
  },

  // Core -----------------------------------------------------------------------------------------
  {
    /** Home page */
    path: "/",
    name: "LandingPage",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/f03/F030101SCN.vue")
  },
  {
    /** TODO */
    path: "/about",
    name: "About",
    component: () => import(/* webpackChunkName: "Core" */ "@views/About.vue")
  },
  {
    /** 代理人身份切換 */
    path: "/agent",
    name: "Agent",
    component: () => import(/* webpackChunkName: "Core" */ "@views/Agent.vue")
  },
  {
    /** 500 Server Internal Server Error */
    path: "/error",
    name: "UnknownError",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/UnknownError.vue")
  },
  {
    /** 403 Forbidden */
    path: "/forbidden",
    name: "Forbidden",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/Forbidden.vue")
  },
  {
    /** User Profile not found */
    path: "/user_profile_not_found",
    name: "UserProfileNotFound",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/UserProfileNotFound.vue")
  },
  {
    /** Page not found */
    path: "*",
    name: "NotFound",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/NotFound.vue")
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.VUE_APP_PUBLIC_PATH,
  routes
});

router.beforeEach((to, from, next) => {
  // 1. 如果到下列頁面，直接放行 -----------------------------------------------------------------------------------------------
  if (
    to.name === "NotFound" ||
    to.name === "Forbidden" ||
    to.name === "UnknownError" ||
    to.name === "UserProfileNotFound" ||
    to.name === "F010101SCN"
  ) {
    next();
    return;
  }

  // 2. 如果是正式環境且要去代理人身份切換頁面，直接導到存取被拒頁 ----------------------------------------------------------------
  if (process.env.NODE_ENV === "prod" && to.name === "Agent") {
    router.push("/forbidden");
    return;
  }

  // 3. 如果已經登入過，發送一個request到server端記錄Access Log ----------------------------------------------------------------
  if (store.state.userProfile.optUserProfile.adAccount) {
    frontendAccessLogApi
      .doSaveFrontendAccessLog({
        resourceUri: to.path,
        resourceType: "M" // M: Menu類
      })
      .finally(() => {
        next();
        return;
      });
  }

  // 4. 如果尚未取得基本資料，發送一個request跟server端取得，並放入store裡 -------------------------------------------------------
  if (!store.state.userProfile.optUserProfile.adAccount) {
    userProfileApi.doFetchLoginUserProfile().then(userProfile => {
      if (userProfile && userProfile.adAccount) {
        store.dispatch("doStoredUserProfile", userProfile);
        next();
      } else {
        store.dispatch("doCleanUserProfile");
        router.push("/user_profile_not_found");
      }
    });
  }
});

export default router;
