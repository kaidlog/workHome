import mockInit from "@mock/";

// Reference to https://github.com/ctimmerm/axios-mock-adapter/blob/master/README.md
if ("Y" === process.env.VUE_APP_ENABLE_MOCK) {
  const axios = require("axios");
  const MockAdapter = require("axios-mock-adapter");
  const mock = new MockAdapter(axios);

  mockInit(mock);

  /** 其他未吻合的請求，都直接將Request送到Server端 */
  mock.onAny().passThrough();
}
