import Vue from "vue";
import ViewUI from "view-design";
import i18n from "@conf/i18n-config";
import "view-design/dist/styles/iview.css";
import "@assets/theme.less";

const options = {
  select: {
    arrow: "md-arrow-dropdown"
  },
  i18n: function(path, options) {
    let value = i18n.t(path, options);
    if (value !== null && value !== undefined) {
      return value;
    }
    return "";
  }
};

Vue.use(ViewUI, options);
