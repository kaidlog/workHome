import Vue from "vue";
import VueI18n from "vue-i18n";
import en from "view-design/dist/locale/en-US";
import zh_TW from "view-design/dist/locale/zh-TW";

Vue.use(VueI18n);
Vue.locale = () => {};

zh_TW.i.page.item = "筆";
zh_TW.i.page.items = "筆";

zh_TW.i.page.page = "筆";
zh_TW.i.page.page = "筆";

const i18n = new VueI18n({
  locale: "zh_TW",
  messages: {
    en,
    zh_TW
  }
});

export default i18n;
