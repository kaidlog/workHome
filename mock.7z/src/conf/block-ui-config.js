import Vue from "vue";
import BlockUI from "vue-blockui";

Vue.use(BlockUI);
