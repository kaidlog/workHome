import Vue from "vue";
import GlobalMixin from "@mixins/global-mixin";
import EsunAlert from "@components/common/EsunAlert.vue";
import EsunConfirm from "@components/common/EsunConfirm.vue";
import SysCdRadio from "@components/common/SysCdRadio.vue";
import SysCdSelect from "@components/common/SysCdSelect.vue";
import SysCdCheckbox from "@components/common/SysCdCheckbox.vue";

/**
 * https://vuejs.org/v2/api/index.html
 */
Vue.config.debug = process.env.NODE_ENV !== "prod";
Vue.config.silent = process.env.NODE_ENV === "prod";
Vue.config.devtools = process.env.NODE_ENV !== "prod";
Vue.config.performance = process.env.NODE_ENV !== "prod";
Vue.config.productionTip = process.env.NODE_ENV !== "prod";

Vue.$log.debug("loaded-env", process.env);

Vue.mixin(GlobalMixin);

// Registered Global Vue Component --------------------------------------------------------------------
Vue.component("sys-cd-radio", SysCdRadio);
Vue.component("sys-cd-select", SysCdSelect);
Vue.component("sys-cd-checkbox", SysCdCheckbox);
Vue.component("esun-alert", EsunAlert);
Vue.component("esun-confirm", EsunConfirm);
