import VueFuse from "vue-fuse";
import Vue from "vue";

Vue.use(VueFuse);
