import Vue from "vue";
import VCharts from "v-charts";

Vue.use(VCharts);
