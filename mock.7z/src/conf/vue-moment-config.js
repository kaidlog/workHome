import Vue from "vue";

const moment = require("moment");
require("moment/locale/zh-tw");

Vue.use(require("vue-moment"), {
  moment
});
