import Vue from "vue";
import $ from "jquery";

Vue.prototype.$ = $;
